package com.sk.dlsp.bi.bindings;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "userListType", propOrder = { "user" })
public class UserListType implements Serializable {

	private static final long serialVersionUID = 5928086635953927710L;
	
	protected List<UserType> user;

    /**
     * Gets the value of the site property.
     *
     * <p>
     * This accessor method returns a reference to the live list, not a
     * snapshot. Therefore any modification you make to the returned list will
     * be present inside the JAXB object. This is why there is not a
     * <CODE>set</CODE> method for the site property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     *
     * <pre>
     * getSite().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list {@link SiteType }
     *
     *
     */
    public List<UserType> getUser() {
        if (user == null) {
        	user = new ArrayList<UserType>();
        }
        return this.user;
    }
}
