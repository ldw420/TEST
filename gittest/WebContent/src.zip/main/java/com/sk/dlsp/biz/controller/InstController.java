package com.sk.dlsp.biz.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sk.dlsp.biz.service.InstService;
import com.sk.dlsp.common.consts.CommonConstants;
import com.sk.dlsp.common.util.SessionUtil;
import com.sk.dlsp.model.InstVo;
import com.sk.dlsp.model.ResponseDto;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(CommonConstants.API_PREFIX)
public class InstController {

	@Autowired InstService instService;

	@GetMapping("/inst")
	@ApiOperation(value = "인스턴스 조회")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "schInstTy", value = "인스턴스유형", required = false)
	})
	public ResponseDto getInstList(@RequestParam(required = false) String schInstTy) {
		Map<String,String> param = new HashMap<>();
		param.put("schInstTy", schInstTy);

		List<InstVo> instList = instService.getInstList(param);

		ResponseDto result = new ResponseDto();
		result.putData("instList", instList);
		return result;
	}

	@GetMapping("/inst/{sn}")
	@ApiOperation(value = "인스턴스 상세 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "sn", value = "인스턴스 키", required = true)
	})
	public ResponseDto getInstList(@PathVariable int sn) {
		InstVo instDetail = instService.getInstDetail(sn);

		ResponseDto result = new ResponseDto();
		result.putData("instDetail", instDetail);
		return result;
	}

	@PostMapping("/inst")
	@ApiOperation(value = "인스턴스 등록")
	public ResponseDto insertInst(@RequestBody InstVo instVo) {
		SessionUtil.addUserInfo(instVo);
		int re = instService.insertInst(instVo);

		ResponseDto result = new ResponseDto();
		return result;
	}
	@PutMapping("/inst/{sn}")
	@ApiOperation(value = "인스턴스 수정")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "sn", value = "인스턴스 키", required = true)
	})
	public ResponseDto updateInst(@PathVariable int sn ,@RequestBody InstVo instVo) {
		SessionUtil.addUserInfo(instVo);
		instVo.setSn(sn);
		int re = instService.updateInst(instVo);

		ResponseDto result = new ResponseDto();
		return result;
	}

	@DeleteMapping("/inst/{instId}")
	@ApiOperation(value = "인스턴스 삭제")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "instId", value = "인스턴스 키", required = true)
	})
	public ResponseDto deleteInst(@PathVariable(required = true) String instId) {
		String [] instSplit = instId.split(",");
		ResponseDto result = new ResponseDto();
		try {
			int[] instIds = Arrays.stream(instSplit).mapToInt(Integer::parseInt).toArray();
			int re = instService.deleteInst(instIds);
		}catch(NumberFormatException ne) {
			result.setCode(CommonConstants.FAIL);
			result.setMessage("잘못된 키값입니다.");
		}
		return result;
	}

}
