package com.sk.dlsp.biz.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sk.dlsp.biz.mapper.AuthAppMapper;
import com.sk.dlsp.model.AuthAppVo;
import com.sk.dlsp.model.BiVo;  

@Service
@Transactional
public class AuthAppService {
    @Autowired AuthAppMapper authAppMapper;

	public List<AuthAppVo> getAuthAppList(Map<String, Object> param){
		return authAppMapper.getAuthAppList(param);
	}
	
	public int getAuthAppListCount(Map<String, Object> param) {
		return authAppMapper.getAuthAppListCount(param);
	}
	
	public int confmNo(AuthAppVo vo) {
		int re = authAppMapper.confmNo(vo);
		 
		return re;
	}
	
	public int confmUsrAuthChang(AuthAppVo vo) {
		int re = authAppMapper.confmUsrAuthChang(vo);
		 
		return re;
	}
	
	public int insertAuthApp(AuthAppVo vo) {
		return authAppMapper.insertAuthApp(vo);
	}

	public int authCheckCnt(AuthAppVo vo) {
		return authAppMapper.authCheckCnt(vo);
	}
	 
 

}
