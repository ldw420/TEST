package com.sk.dlsp.biz.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.sk.dlsp.model.UserCsvFileVo;
import com.sk.dlsp.model.UserVo;

@Mapper
public interface UserMapper {

	public List<UserVo> getUserList(Map<String,String> param);

	public UserVo getUser(String usrId);

	public int insertUser(UserVo userVo);

	public int deleteUser(String[] UsrIds);

	public int updateUser(UserVo userVo);

	public List<UserCsvFileVo> getUserListIntoCsvFileByToday();
}
