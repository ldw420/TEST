package com.sk.dlsp.model;

public class WordVo extends CommonVo{

	private int sn;     //순번
	private String abrv; //약어
	private String srclang; //원어
	private String koreanNm; // 한글명
	private String wordDc; //용어 설명
	private String ref; //출처

	public int getSn() {
		return sn;
	}
	public void setSn(int sn) {
		this.sn = sn;
	}
	public String getAbrv() {
		return abrv;
	}
	public void setAbrv(String abrv) {
		this.abrv = abrv;
	}
	public String getSrclang() {
		return srclang;
	}
	public void setSrclang(String srclang) {
		this.srclang = srclang;
	}
	public String getKoreanNm() {
		return koreanNm;
	}
	public void setKoreanNm(String koreanNm) {
		this.koreanNm = koreanNm;
	}
	public String getWordDc() {
		return wordDc;
	}
	public void setWordDc(String wordDc) {
		this.wordDc = wordDc;
	}
	public String getRef() {
		return ref;
	}
	public void setRef(String ref) {
		this.ref = ref;
	}
}
