package com.sk.dlsp.biz.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sk.dlsp.biz.mapper.GovMetaMapper;
import com.sk.dlsp.model.MetaDataCopmVo;
import com.sk.dlsp.model.MetaDataVo;

@Service
@Transactional
public class GovMetaService {

	@Autowired GovMetaMapper govMetaMapper;

	public boolean batchMetaDataCopm(List<MetaDataCopmVo> list) {
		govMetaMapper.deleteMetaDataCopm();
		govMetaMapper.insertMetaDataCopm(list);
		return true;
	}

	public boolean batchMetaData(List<MetaDataVo> list) {
		govMetaMapper.deleteMetaData();
		govMetaMapper.insertMetaData(list);

		return true;
	}
}
