package com.sk.dlsp.biz.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sk.dlsp.biz.service.MenuService;
import com.sk.dlsp.common.consts.CommonConstants;
import com.sk.dlsp.common.util.SessionUtil;
import com.sk.dlsp.model.MenuVo;
import com.sk.dlsp.model.PdeVo;
import com.sk.dlsp.model.ResponseDto;
import com.sk.dlsp.model.UserInfo;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(CommonConstants.API_PREFIX)
public class MenuController {

	@Autowired MenuService menuService;

	@GetMapping("/menu")
	@ApiOperation(value = "메뉴 조회")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "schMenuNm", value = "메뉴명", required = false),
	    @ApiImplicitParam(name = "schUseAt", value = "사용여부", required = false)
	})
	public ResponseDto getMenuList(@RequestParam(required = false) String schMenuNm
								  ,@RequestParam(required = false) String schUseAt) {
		Map<String,String> param = new HashMap<>();
		param.put("schMenuNm", schMenuNm);
		param.put("schUseAt", schUseAt);

		List<MenuVo> menuList = menuService.getMenuList(param);

		ResponseDto result = new ResponseDto();
		result.putData("menuList", menuList);
		return result;
	}

	@GetMapping("/menu/{menuId}")
	@ApiOperation(value = "메뉴 상세 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "menuId", value = "메뉴ID", required = true)
	})
	public ResponseDto getMenuList(@PathVariable String menuId) {
		MenuVo menuDetail = menuService.getMenuDetail(menuId);

		ResponseDto result = new ResponseDto();
		result.putData("menuDetail", menuDetail);
		return result;
	}
	
	@PostMapping("/menuCheck/")
	@ApiOperation(value = "메뉴 권한 채크")
	public ResponseDto getMenuCheck(@RequestBody MenuVo menuVo, HttpServletRequest request) {
		
		UserInfo userInfo = SessionUtil.getUserInfo();
		ResponseDto result = new ResponseDto();
		
	 
			menuVo.setAuthIdChk(userInfo.getAuthId());
			
			int menuCheck = menuService.getMenuCheck(menuVo);
			
			if (menuCheck > 0) {
				result.setCode(CommonConstants.SUCCESS);
			} else {
				result.setCode(CommonConstants.NOTAUTH);
			}
		  
		
		return result; 
 
	}

	@PostMapping("/menu")
	@ApiOperation(value = "메뉴 등록")
	public ResponseDto insertMenu(@RequestBody MenuVo menuVo) {
		SessionUtil.addUserInfo(menuVo);
		ResponseDto result = new ResponseDto();
		
		int cntUrl = menuService.getCntMenuNm(menuVo);
		
		
		if (cntUrl > 0) { 
			result.setCode(CommonConstants.FAIL);
			result.setMessage("이미 등록된 메뉴입니다.");
			return result;
		}else { 
			
			String maxCodeValue = menuService.getMaxMenuCode(); 
			int maxAuthCode = Integer.parseInt(maxCodeValue.substring(1,5))+1; 
			String menuId  = "M"+String.format("%04d%n", maxAuthCode);

			menuVo.setMenuId(menuId.replaceAll(System.getProperty("line.separator"), " ")); 
			
			
			int re = menuService.insertMenu(menuVo);
		}
		
		
 
		return result;
	}
	@PutMapping("/menu/{menuId}")
	@ApiOperation(value = "메뉴 수정")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "menuId", value = "메뉴ID", required = true)
	})
	public ResponseDto updateMenu(@PathVariable String menuId ,@RequestBody MenuVo menuVo) {
		SessionUtil.addUserInfo(menuVo);
		menuVo.setMenuId(menuId);
		int re = menuService.updateMenu(menuVo);

		ResponseDto result = new ResponseDto();
		return result;
	}

	@DeleteMapping("/menu/{menuId}")
	@ApiOperation(value = "메뉴 삭제")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "menuId", value = "메뉴 키", required = true)
	})
	public ResponseDto deleteMenu(@PathVariable(required = true) String menuId) {
		String [] menuIds = menuId.split(",");
		ResponseDto result = new ResponseDto();
		try {
			int re = menuService.deleteMenu(menuIds);
		}catch(NumberFormatException ne) {
			result.setCode(CommonConstants.FAIL);
			result.setMessage("잘못된 키값입니다.");
		}
		return result;
	}

}
