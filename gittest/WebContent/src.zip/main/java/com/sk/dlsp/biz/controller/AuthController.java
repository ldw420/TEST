package com.sk.dlsp.biz.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sk.dlsp.biz.service.AuthService;
import com.sk.dlsp.common.consts.CommonConstants;
import com.sk.dlsp.common.util.SessionUtil;
import com.sk.dlsp.model.AuthVo;
import com.sk.dlsp.model.ResponseDto;
import com.sk.dlsp.model.UserInfo;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(CommonConstants.API_PREFIX +"/auth")
public class AuthController {

	@Autowired AuthService authService;

	/**
	 * 권한 조회
	 * @return
	 */
	@GetMapping("/auth")
	@ApiOperation(value = "권한 조회")
	public ResponseDto getAuthList() {

		List<AuthVo> authList = authService.getAuthList();

		ResponseDto result = new ResponseDto();
		result.putData("authList", authList);
		return result;
	}
	
	/**
	 * 권한 추가
	 * @param authVo
	 * @return
	 */
	@PostMapping("/auth")
	@ApiOperation(value = "권한 추가")
	public ResponseDto insertAuth(@RequestBody AuthVo authVo) {
		ResponseDto result = new ResponseDto();
		
		UserInfo userInfo = SessionUtil.getUserInfo();
		
		try {
			//임시 sessionid 
			authVo.setRegisterId(userInfo.getUsrId());
			authVo.setUpdtId(userInfo.getUsrId());   
			int cntAuthNm = authService.getCntAuthNm(authVo.getAuthNm().trim());
			
			if (cntAuthNm > 0) { 
				result.setCode(CommonConstants.FAIL);
				result.setMessage("존재하지 하는 권한명 입니다");
				return result;
			}else { 
				String maxCodeValue = authService.getMaxAuthCode(); 
				int maxAuthCode = Integer.parseInt(maxCodeValue.substring(1,5))+1; 
				String authId  = "A"+String.format("%04d%n", maxAuthCode);

				authVo.setAuthId(authId.replaceAll(System.getProperty("line.separator"), " ")); 
			
				int re = authService.insertAuth(authVo);
			}
		} catch(Exception e) {
			e.printStackTrace();
			result.setCode(CommonConstants.FAIL);
			result.setMessage("권한 등록 처리중 오류가 발생하였습니다.");
			return result;
		}
		return result;

	}
	
	/**
	 * 권한 미사용
	 * @param authId
	 * @param authVo
	 * @return
	 */
	@PutMapping("/authUnUse/{authId}")
	@ApiOperation(value = "권한 미사용")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authId", value = "권한 코드", required = true)
	})
	public ResponseDto unUseAuth(@PathVariable(required = true) String authId, AuthVo authVo) {
		
		UserInfo userInfo = SessionUtil.getUserInfo();
		
		authVo.setUpdtId(userInfo.getUsrId());   
		authVo.setAuthIds(authId.split(","));
		int re = authService.unUseAuth(authVo);

		ResponseDto result = new ResponseDto();
		return result;
	}
	
	/**
	 * 권한 사용
	 * @param authId
	 * @param authVo
	 * @return
	 */
	@PutMapping("/authUse/{authId}")
	@ApiOperation(value = "권한 사용")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authId", value = "권한 코드", required = true)
	})
	public ResponseDto useAuth(@PathVariable(required = true) String authId , AuthVo authVo) {
		
		UserInfo userInfo = SessionUtil.getUserInfo();
		authVo.setUpdtId(userInfo.getUsrId());   
		authVo.setAuthIds(authId.split(","));
		int re = authService.useAuth(authVo);

		ResponseDto result = new ResponseDto();
		return result;
	}
	
	/**
	 * 권한 삭제
	 * @param authId
	 * @return
	 */
	@DeleteMapping("/authDel/{authId}")
	@ApiOperation(value = "권한 삭제")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authId", value = "권한 코드", required = true)
	})
	public ResponseDto authDel(@PathVariable(required = true) String authId) {
		
		String [] authIds = authId.split(",");
		int re = authService.authDel(authIds);

		ResponseDto result = new ResponseDto();
		return result;
	}
}
