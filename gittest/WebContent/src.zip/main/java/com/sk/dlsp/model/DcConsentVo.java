package com.sk.dlsp.model;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class DcConsentVo {

	private String tableId;
	private String reqCompanyCode;
	private String staDtm;
	private String endDtm;
	private String sttus;
	
	
	
	
	public String getTableId() {
		return tableId;
	}




	public void setTableId(String tableId) {
		this.tableId = tableId;
	}




	public String getReqCompanyCode() {
		return reqCompanyCode;
	}




	public void setReqCompanyCode(String reqCompanyCode) {
		this.reqCompanyCode = reqCompanyCode;
	}




	public String getStaDtm() {
		return staDtm;
	}




	public void setStaDtm(String staDtm) {
		this.staDtm = staDtm;
	}




	public String getEndDtm() {
		return endDtm;
	}




	public void setEndDtm(String endDtm) {
		this.endDtm = endDtm;
	}




	public String getSttus() {
		return sttus;
	}




	public void setSttus(String sttus) {
		this.sttus = sttus;
	}




	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this,ToStringStyle.MULTI_LINE_STYLE); 
	}
	

	
}
