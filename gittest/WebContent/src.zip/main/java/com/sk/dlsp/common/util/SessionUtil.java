package com.sk.dlsp.common.util;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.interfaces.JWTVerifier;
import com.sk.dlsp.common.consts.AuthConstants;
import com.sk.dlsp.common.consts.UserInfoConstants;
import com.sk.dlsp.model.CommonVo;
import com.sk.dlsp.model.UserInfo;

public class SessionUtil {

	// Vo 객체에 session정보 추가
	public static <T> void  addUserInfo(T vo){
		//session user 임시 값
		UserInfo userInfo = getUserInfo();
		String sessionId = userInfo.getUsrId();
		if(vo instanceof CommonVo) {
			CommonVo v = (CommonVo)vo;
			v.setRegisterId(sessionId);
			v.setUpdtId(sessionId);
		}
	}

	public static UserInfo getUserInfo(){
		String userToken = CookieUtil.getCookieValue(AuthConstants.TOKEN);
		UserInfo userInfo = new UserInfo();
		JWTVerifier verifier = JWT.require(Algorithm.HMAC256(AuthConstants.SECURE_KEY))
			.withIssuer(AuthConstants.ISSURE).build();

		DecodedJWT jwt = verifier.verify(userToken);

		userInfo.setUsrId(jwt.getClaim(UserInfoConstants.USRID).asString());
		userInfo.setNm(jwt.getClaim(UserInfoConstants.NM).asString());
		userInfo.setAgency(jwt.getClaim(UserInfoConstants.AGENCY).asString());
		userInfo.setAgencyNm(jwt.getClaim(UserInfoConstants.AGENCY_NM).asString());
		userInfo.setDeptcode(jwt.getClaim(UserInfoConstants.DEPTCODE).asString());
		userInfo.setDeptname(jwt.getClaim(UserInfoConstants.DEPTNAME).asString());
		userInfo.setPartneryn(jwt.getClaim(UserInfoConstants.PARTNERYN).asString());
		userInfo.setAuthId(jwt.getClaim(UserInfoConstants.AUTH_ID).asString());
		userInfo.setAuthNm(jwt.getClaim(UserInfoConstants.AUTH_NM).asString());
		userInfo.setPwChgCd(jwt.getClaim(UserInfoConstants.PW_CHG_CD).asString());

		return userInfo;
	}
}
