package com.sk.dlsp.model;

public class MetaDataVo {
	private String classKey;
	private String classTitle;
	private String abbrName;
	private String classLevel;
	private String upClassKey;
	private String upClassTitle;
	private String subjectArea;
	private String bizMeta;
	private String classTypeCode;
	private String classTypeName;
	private String createDt;
	private String modifyDt;

	public String getClassKey() {
		return classKey;
	}
	public void setClassKey(String classKey) {
		this.classKey = classKey;
	}
	public String getClassTitle() {
		return classTitle;
	}
	public void setClassTitle(String classTitle) {
		this.classTitle = classTitle;
	}
	public String getAbbrName() {
		return abbrName;
	}
	public void setAbbrName(String abbrName) {
		this.abbrName = abbrName;
	}
	public String getClassLevel() {
		return classLevel;
	}
	public void setClassLevel(String classLevel) {
		this.classLevel = classLevel;
	}
	public String getUpClassKey() {
		return upClassKey;
	}
	public void setUpClassKey(String upClassKey) {
		this.upClassKey = upClassKey;
	}
	public String getUpClassTitle() {
		return upClassTitle;
	}
	public void setUpClassTitle(String upClassTitle) {
		this.upClassTitle = upClassTitle;
	}
	public String getSubjectArea() {
		return subjectArea;
	}
	public void setSubjectArea(String subjectArea) {
		this.subjectArea = subjectArea;
	}
	public String getBizMeta() {
		return bizMeta;
	}
	public void setBizMeta(String bizMeta) {
		this.bizMeta = bizMeta;
	}
	public String getClassTypeCode() {
		return classTypeCode;
	}
	public void setClassTypeCode(String classTypeCode) {
		this.classTypeCode = classTypeCode;
	}
	public String getClassTypeName() {
		return classTypeName;
	}
	public void setClassTypeName(String classTypeName) {
		this.classTypeName = classTypeName;
	}
	public String getCreateDt() {
		return createDt;
	}
	public void setCreateDt(String createDt) {
		this.createDt = createDt;
	}
	public String getModifyDt() {
		return modifyDt;
	}
	public void setModifyDt(String modifyDt) {
		this.modifyDt = modifyDt;
	}
}
