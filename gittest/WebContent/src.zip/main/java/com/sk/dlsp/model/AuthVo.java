package com.sk.dlsp.model;

public class AuthVo extends CommonVo{

	private String authId;  //권한 ID
	private String authNm;  //권한명
	private String useAt;  //사용여부
	private String [] authIds; //권한 배열(사용, 미사용처리시사용)
	
	public String getAuthId() {
		return authId;
	}
	public void setAuthId(String authId) {
		this.authId = authId;
	}
	public String getAuthNm() {
		return authNm;
	}
	public void setAuthNm(String authNm) {
		this.authNm = authNm;
	}
	public String getUseAt() {
		return useAt;
	}
	public void setUseAt(String useAt) {
		this.useAt = useAt;
	}
	public String[] getAuthIds() {
		return authIds;
	}
	public void setAuthIds(String[] authIds) {
		this.authIds = authIds;
	}
	
	

}
