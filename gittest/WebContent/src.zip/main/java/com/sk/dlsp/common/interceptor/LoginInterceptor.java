package com.sk.dlsp.common.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.sk.dlsp.biz.service.AuthService;
import com.sk.dlsp.common.consts.AuthConstants;
import com.sk.dlsp.common.exception.NotLoginException;
import com.sk.dlsp.common.util.CookieUtil;
import com.sk.dlsp.common.util.SessionUtil;
import com.sk.dlsp.model.UserInfo;

public class LoginInterceptor extends HandlerInterceptorAdapter {

	@Autowired AuthService authService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		String authToken = CookieUtil.getCookieValue(AuthConstants.TOKEN);

		try {
			if(authToken == null) {
				throw new NotLoginException();
			}
			UserInfo userInfo = SessionUtil.getUserInfo();
		}catch(Exception e) {
			throw new NotLoginException(e.getMessage());
		}
		return true;
    }

}