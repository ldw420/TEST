package com.sk.dlsp.dc.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.sk.dlsp.model.CodeDetailVo;
import com.sk.dlsp.model.DcCompVo;
import com.sk.dlsp.model.DcConsentVo;
import com.sk.dlsp.model.DcCtgVo;
import com.sk.dlsp.model.DcReqBlockChainVo;
import com.sk.dlsp.model.DcSuccessVo;
import com.sk.dlsp.model.DcVo;

@Mapper
public interface DcMapper {

	List<DcVo> getDcList(Map<String, Object> param);

	int getDcListCount(Map<String, Object> param);

	List<DcCtgVo> getDcCtgList(Map<String, Object> param);

	List<DcCompVo> getDcCopmList(Map<String, Object> param);

	int insertDcDataUseApp(Map<String, Object> param);

	int insertDcDataUseAppDetail(Map<String, Object> detail);

	DcReqBlockChainVo getDcDataUseAppList(String param);

	String getCmpCompanyCode(Map<String, Object> param);

	int updateHitCnt(Map<String, Object> param);

	DcVo getDcDetailInfo(Map<String, Object> param);
	
	List<CodeDetailVo> getDcCodeInfoList(Map<String, Object> param);

	List<DcConsentVo> getConsentList(Map<String, Object> param);

	int insertDcSearchWord(Map<String, Object> param);

	List<DcCtgVo> getDcCtgCountList(Map<String, Object> param);

	List<DcCompVo> getDcCopmCountList(Map<String, Object> param);

	int updateSuccessYnFromBlockChain(DcSuccessVo dcSuccessVo);

}
