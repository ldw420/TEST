package com.sk.dlsp.biz.mapper;

import java.util.List; 

import org.apache.ibatis.annotations.Mapper;

import com.sk.dlsp.model.AuthVo; 

@Mapper
public interface AuthMapper {

    public List<AuthVo> getAuthList(); 

	public int insertAuth(AuthVo vo);
	
	public int getCntAuthNm(String chkAuthNm);
	
	public String getMaxAuthCode();
	
	public int unUseAuth(AuthVo vo);
	 
	
	public int useAuth(AuthVo vo);
	
	public int authDel(String[] authId);
 

}
