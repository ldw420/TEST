package com.sk.dlsp.ae.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.sk.dlsp.model.AnalsVo;
import com.sk.dlsp.model.BbsAnswerVo;
import com.sk.dlsp.model.BbsVo;
import com.sk.dlsp.model.InstInfoVo;

@Mapper
public interface AnalsMapper {

	public List<AnalsVo> aeInstInfoList();

	public List<AnalsVo> datasetList(String koreanNm);

	public List<AnalsVo> datasetInfoList(AnalsVo analsVo);

	public List<AnalsVo> datasetInfoAllList(AnalsVo analsVo);

	public String aeInstInfo(String instTy);

	public int deleteDataSetInfo(AnalsVo analsVo);

	public void insertDataSetInfo(AnalsVo analsVo);

	public List<InstInfoVo> instInfoList(AnalsVo analsVo);
	
}