package com.sk.dlsp.common.exception;

public class BizException extends Exception{

	private static final long serialVersionUID = -363625966745779593L;

	public BizException(String message) {
        super(message);
    }
}