package com.sk.dlsp.biz.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sk.dlsp.biz.mapper.MenuMapper;
import com.sk.dlsp.model.MenuVo;

@Service
@Transactional
public class MenuService {
    @Autowired MenuMapper menuMapper;

	public List<MenuVo> getMenuList(Map<String,String> param){
		return menuMapper.getMenuList(param);
	}

	public MenuVo getMenuDetail(String menuId) {
		return menuMapper.getMenuDetail(menuId);
	}

	public int getCntMenuNm(MenuVo menuVo) {
		return menuMapper.getCntMenuNm(menuVo);
	}
	
	public String getMaxMenuCode() {
		return menuMapper.getMaxMenuCode();
	}
	
	public int insertMenu(MenuVo menuVo) {
		return menuMapper.insertMenu(menuVo);
	}

	public int updateMenu(MenuVo menuVo) {
		return menuMapper.updateMenu(menuVo);
	}

	public int deleteMenu(String[] menuIds) {
		return menuMapper.deleteMenu(menuIds);
	}
	
	public int getMenuCheck(MenuVo menuVo) {
		return menuMapper.getMenuCheck(menuVo);
	}
}
