package com.sk.dlsp.common.exception;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sk.dlsp.common.consts.CommonConstants;
import com.sk.dlsp.model.ResponseDto;

@ControllerAdvice
public class ExceptionControllerAdvice {

	@ExceptionHandler(NotLoginException.class)
	@ResponseBody
	public ResponseDto handleError(HttpServletRequest request) {
		ResponseDto response = new ResponseDto(CommonConstants.EXCEPTION);
		response.setCode(CommonConstants.NOT_LOGIN);
		return response;
	}
	@ExceptionHandler(BizException.class)
	@ResponseBody
	public ResponseDto handleError(BizException exception,HttpServletRequest request) {
		ResponseDto response = new ResponseDto(CommonConstants.EXCEPTION);
		response.setMessage(exception.getMessage());
		return response;
	}

	@ExceptionHandler
	public ModelAndView handleError(Exception exception, HttpServletRequest request) {

		ModelAndView mav = new ModelAndView();
		mav.setViewName("forward:/exception/500");
        request.setAttribute(CommonConstants.MESSAGE, exception.getMessage());

        return mav;
	}

}
