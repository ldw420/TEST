package com.sk.dlsp.model;

public class MenuVo extends CommonVo {

	private String menuId;
	private String menuNm;
	private String menuDc;
	private String menuUrl;
	private int menuSortSn;
	private String upperMenuId;
	private String upperMenuNm;
	private String authIdChk;
	private String useAt;
	private String menuPath;
	
	

	public String getMenuPath() {
		return menuPath;
	}

	public void setMenuPath(String menuPath) {
		this.menuPath = menuPath;
	}

	public String getMenuId() {
		return menuId;
	}

	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}

	public String getMenuNm() {
		return menuNm;
	}

	public void setMenuNm(String menuNm) {
		this.menuNm = menuNm;
	}

	public String getMenuDc() {
		return menuDc;
	}

	public void setMenuDc(String menuDc) {
		this.menuDc = menuDc;
	}

	public String getMenuUrl() {
		return menuUrl;
	}

	public void setMenuUrl(String menuUrl) {
		this.menuUrl = menuUrl;
	}

	public int getMenuSortSn() {
		return menuSortSn;
	}

	public void setMenuSortSn(int menuSortSn) {
		this.menuSortSn = menuSortSn;
	}

	public String getUpperMenuId() {
		return upperMenuId;
	}

	public void setUpperMenuId(String upperMenuId) {
		this.upperMenuId = upperMenuId;
	}

	public String getUpperMenuNm() {
		return upperMenuNm;
	}

	public void setUpperMenuNm(String upperMenuNm) {
		this.upperMenuNm = upperMenuNm;
	}

	public String getAuthIdChk() {
		return authIdChk;
	}

	public void setAuthIdChk(String authIdChk) {
		this.authIdChk = authIdChk;
	}

	public String getUseAt() {
		return useAt;
	}

	public void setUseAt(String useAt) {
		this.useAt = useAt;
	}

}
