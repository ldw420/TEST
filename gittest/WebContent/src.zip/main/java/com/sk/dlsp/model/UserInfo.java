package com.sk.dlsp.model;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class UserInfo {

	private String usrId;
	private String nm;
	private String agency;
	private String agencyNm;
	private String deptcode;
	private String deptname;
	private String partneryn;
	private String authId;
	private String authNm;
	private String pwChgCd;

	public String getUsrId() {
		return usrId;
	}
	public void setUsrId(String usrId) {
		this.usrId = usrId;
	}
	public String getNm() {
		return nm;
	}
	public void setNm(String nm) {
		this.nm = nm;
	}
	public String getAgency() {
		return agency;
	}
	public void setAgency(String agency) {
		this.agency = agency;
	}
	public String getAgencyNm() {
		return agencyNm;
	}
	public void setAgencyNm(String agencyNm) {
		this.agencyNm = agencyNm;
	}
	public String getDeptcode() {
		return deptcode;
	}
	public void setDeptcode(String deptcode) {
		this.deptcode = deptcode;
	}
	public String getDeptname() {
		return deptname;
	}
	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}
	public String getPartneryn() {
		return partneryn;
	}
	public void setPartneryn(String partneryn) {
		this.partneryn = partneryn;
	}
	public String getAuthId() {
		return authId;
	}
	public void setAuthId(String authId) {
		this.authId = authId;
	}
	public String getAuthNm() {
		return authNm;
	}
	public void setAuthNm(String authNm) {
		this.authNm = authNm;
	}
	public String getPwChgCd() {
		return pwChgCd;
	}
	public void setPwChgCd(String pwChgCd) {
		this.pwChgCd = pwChgCd;
	}
	@Override
	public String toString() {
		String json = "";;
		try {
			json = new ObjectMapper().writeValueAsString(this);
		} catch (JsonProcessingException e) {
		}
		return json;
	}

}
