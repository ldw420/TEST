package com.sk.dlsp.model;

public class CodeDetailVo extends CommonVo{

	private String groupCodeId;
	private String groupCodeNm;
	private String groupCodeDc;
	private String detailCodeId;
	private String detailCodeNm;
	private String detailCodeDc;
	private int detailCodeOrdr;
	private String useAt;
	private String [] detailCodeIds;
	
	

	public String[] getDetailCodeIds() {
		return detailCodeIds;
	}
	public void setDetailCodeIds(String[] detailCodeIds) {
		this.detailCodeIds = detailCodeIds;
	}
	public String getGroupCodeId() {
		return groupCodeId;
	}
	public void setGroupCodeId(String groupCodeId) {
		this.groupCodeId = groupCodeId;
	}
	public String getGroupCodeNm() {
		return groupCodeNm;
	}
	public void setGroupCodeNm(String groupCodeNm) {
		this.groupCodeNm = groupCodeNm;
	}
	public String getGroupCodeDc() {
		return groupCodeDc;
	}
	public void setGroupCodeDc(String groupCodeDc) {
		this.groupCodeDc = groupCodeDc;
	}
	public String getDetailCodeId() {
		return detailCodeId;
	}
	public void setDetailCodeId(String detailCodeId) {
		this.detailCodeId = detailCodeId;
	}
	public String getDetailCodeNm() {
		return detailCodeNm;
	}
	public void setDetailCodeNm(String detailCodeNm) {
		this.detailCodeNm = detailCodeNm;
	}
	public String getDetailCodeDc() {
		return detailCodeDc;
	}
	public void setDetailCodeDc(String detailCodeDc) {
		this.detailCodeDc = detailCodeDc;
	}
	public int getDetailCodeOrdr() {
		return detailCodeOrdr;
	}
	public void setDetailCodeOrdr(int detailCodeOrdr) {
		this.detailCodeOrdr = detailCodeOrdr;
	}
	public String getUseAt() {
		return useAt;
	}
	public void setUseAt(String useAt) {
		this.useAt = useAt;
	}

}
