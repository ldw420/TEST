package com.sk.dlsp.common.consts;

import java.util.HashMap;
import java.util.Map;

public enum BbsType {

	notice("00001"),faq("00002"),qna("00003");

	private static final Map<String,BbsType> namesEnum = new HashMap<>();

    final private String code;

    static {
    	for(BbsType type: values()) {
    		namesEnum.put(type.name(), type);
    	}
    }
    public static BbsType findBy(String name) {
    	return namesEnum.get(name);
    }

    BbsType(String code){
        this.code = code;
    }
    public String getCode() {
    	return this.code;
    }
}

