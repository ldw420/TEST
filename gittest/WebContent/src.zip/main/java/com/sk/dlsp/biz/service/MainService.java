package com.sk.dlsp.biz.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sk.dlsp.biz.mapper.MainMapper;
import com.sk.dlsp.model.AuthAppVo;
import com.sk.dlsp.model.BbsVo;
import com.sk.dlsp.model.BiVo;
import com.sk.dlsp.model.DcConfmVo;
import com.sk.dlsp.model.DcVo;
import com.sk.dlsp.model.MydashboardVo;
import com.sk.dlsp.model.SrchwrdVo;
import com.sk.dlsp.model.UseCaseVo;

@Service
@Transactional
public class MainService {

	@Autowired MainMapper mainMapper;

	public List<BbsVo> getNoticeList(){
		return mainMapper.getNoticeList();
	}
	public List<SrchwrdVo> getSrchwrdList(){
		return mainMapper.getSrchwrdList();
	}
	public List<MydashboardVo> getUseCaseListVo(){
		return mainMapper.getUseCaseListVo();
	}
	public BiVo getBiVo() {
		return mainMapper.getBiVo();
	}
	public UseCaseVo getUseCaseVo() {
		return mainMapper.getUseCaseVo();
	}
	
	public int getConfmAppCnt(MydashboardVo mydashboardVo){
		return mainMapper.getConfmAppCnt(mydashboardVo);
	}
	
	public List<MydashboardVo> getMyAppCnt(MydashboardVo mydashboardVo){
		return mainMapper.getMyAppCnt(mydashboardVo);
	}
	
	public List<MydashboardVo> getConfmAppList(MydashboardVo mydashboardVo){
		return mainMapper.getConfmAppList(mydashboardVo);
	}
	
	public List<MydashboardVo> getMyAppList(MydashboardVo mydashboardVo){
		return mainMapper.getMyAppList(mydashboardVo);
	}
	
	public List<MydashboardVo> getMyScrapList(MydashboardVo mydashboardVo){
		return mainMapper.getMyScrapList(mydashboardVo);
	}
	
	public List<MydashboardVo> getMyDataList(MydashboardVo mydashboardVo){
		return mainMapper.getMyDataList(mydashboardVo);
	}
	
	public AuthAppVo getAuthDetail(int sn) {
		return mainMapper.getAuthDetail(sn);
	}
	
	public BiVo getReportDetail(int sn) {
		return mainMapper.getReportDetail(sn);
	}
	
	public DcConfmVo getDataAppDetail(String sn) {
		return mainMapper.getDataAppDetail(sn);
	}
	
	public int setConfmData(MydashboardVo mydashboardVo) {
		return mainMapper.setConfmData(mydashboardVo);
	}
	
	public int setReqConfmData(MydashboardVo mydashboardVo) {
		return mainMapper.setReqConfmData(mydashboardVo);
	}
	
	public int setConfmReport(MydashboardVo mydashboardVo) {
		return mainMapper.setConfmReport(mydashboardVo);
	}
	
	public int setConfmAuthApp(MydashboardVo mydashboardVo) {
		return mainMapper.setConfmAuthApp(mydashboardVo);
	}
	
	public List<MydashboardVo> getTebleList(String transId){
		return mainMapper.getTebleList(transId);
	}
	public int getStatusCheck() {
		return mainMapper.getStatusCheck();
	}
	 
}
