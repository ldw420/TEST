package com.sk.dlsp.biz.controller;

import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.jsoup.Connection.Method;
import org.jsoup.Connection.Response;
import org.jsoup.Jsoup;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sk.dlsp.biz.service.LoginService;
import com.sk.dlsp.biz.service.UserService;
import com.sk.dlsp.common.consts.CommonConstants;
import com.sk.dlsp.common.util.StringUtil;
import com.sk.dlsp.model.EmailAuthVo;
import com.sk.dlsp.model.ResponseDto;
import com.sk.dlsp.model.UserVo;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(CommonConstants.API_PREFIX)
public class LoginController {

	@Autowired UserService userService;
	@Autowired LoginService loginService;

	@Value("${prop.server.gdiim.domain.url}") private String GDI_IM_URL;
	@Value("${prop.server.gdiim.id}")         private String GDI_IM_ID;
	@Value("${prop.server.gdiim.pwd}") 	      private String GDI_IM_PWD;
	@Value("${prop.server.auth.url}")         private String AUTH_SERVER_URL;

	@ApiOperation(value = "인증메일 보내기")
	@PostMapping("/noAuth/sendEmailAuth")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "email", value = "이메일주소", required = true)
	})
	public ResponseDto sendEmailAuth(@RequestParam String email)throws Exception {
		ResponseDto result = new ResponseDto();
		Map<String,String> param = new HashMap<>();
		param.put("usrId", email);

		boolean re = loginService.sendEmailAuth(param);
		if(!re)result.setFailMessage("인증메일 발송에 실패했습니다. 잠시 후 다시 시도해주세요");
		return result;
	}

	@ApiOperation(value = "이메일인증 확인")
	@PostMapping("/noAuth/emailAuth")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "usrId", value = "아이디", required = true),
	    @ApiImplicitParam(name = "checkValue", value = "인증번호", required = true)
	})
	public ResponseDto emailAuth(@RequestParam String usrId,@RequestParam String checkValue)throws Exception {
		ResponseDto result = new ResponseDto();

		EmailAuthVo vo = loginService.getEmailAuth(usrId);
		if(vo == null || !vo.getCheckValue().equals(checkValue)) {
			result.setFailMessage("인증 번호가 올바르지 않습니다.");
		}else{
			loginService.updateEmailAuth(vo);
		}
		return result;
	}

	@ApiOperation(value = "패스워드 변경")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "usrId", value = "아이디", required = true),
	    @ApiImplicitParam(name = "pw", value = "패스워드", required = true)
	})
	@RequestMapping("/noAuth/pwChg")
	public ResponseDto pwChg(@RequestParam String usrId
							 ,@RequestParam String pw)throws Exception {
		ResponseDto result = new ResponseDto();

		//이메일 인증 여부 체크 (메일보낸지 15분이내,인증여부)
		EmailAuthVo vo = loginService.getEmailAuthOk(usrId);
		if(vo==null) {
			result.setFailMessage("이메일 인증이 되지 않은 아이디입니다.");return result;
		}
		//패스워드 체크
		String pattern1 = ".*[0-9].*";
		String pattern2 = ".*[a-zA-Z].*";
		String pattern3 = ".*[~!@\\#$%<>^&*.].*";
		if(pw.length() < 8 || !pw.matches(pattern1) ||!pw.matches(pattern2) ||!pw.matches(pattern3)) {
			result.setFailMessage("영문+숫자+특수기호 8자리 이상으로 구성하여야 합니다.");return result;
		}

		String url = GDI_IM_URL + "/im/wsvc/account/updatePwd2";
		Map<String,String> param = new HashMap<>();
		param.put("loginid", usrId);
		param.put("pwd", StringUtil.encryptSha(pw));

		String auth = java.util.Base64.getEncoder().encodeToString(String.format("%s:%s",GDI_IM_ID,GDI_IM_PWD).getBytes(StandardCharsets.UTF_8));  //WebService 용  SYSTEM ID:패스워드
		Response res = null;
		try {
			/* 인증서 무시 코드*/
			TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager(){
	            public X509Certificate[] getAcceptedIssuers(){return new X509Certificate[0];}
	            public void checkClientTrusted(X509Certificate[] certs, String authType){}
	            public void checkServerTrusted(X509Certificate[] certs, String authType){}
	        }};
	        SSLContext sc = SSLContext.getInstance("TLS");
	        sc.init(null, trustAllCerts, new SecureRandom());
	        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

			res = Jsoup.connect(url).header("Authorization", "Basic " + auth).method(Method.POST).data(param).execute();
			String re = res.body();
			String reCode = re.split("\\|")[0];
			String reMessage = re.split("\\|")[1];
			result.setMessage(re);
			result.putData("resultCode",reCode);
			result.putData("resultMessage",reMessage);
		} catch (Exception e) {
			result.setFailMessage("비밀번호 변경 중 오류");
			result.putData("er:", e.getMessage());
		}
		return result;
	}

	@PostMapping("/join")
	@ApiOperation(value = "회원가입")
	public ResponseDto join(@RequestBody UserVo userVo)throws Exception {
		ResponseDto result = new ResponseDto();
		String usrId = userVo.getUsrId();
		boolean checkAuth = false;

		//인증서버 정보로 한번 더 검사
		try {
			Map<String,String> param = new HashMap<>();
			param.put("userID", usrId);
			param.put("password", userVo.getPw());
			Response res = Jsoup.connect(AUTH_SERVER_URL+"/api/authCheck").method(Method.POST)
					      .data(param).ignoreContentType(true) .execute();
			JSONObject js = (JSONObject)new JSONParser().parse(res.body());
			Map userInfo = (Map)((Map)js.get("data")).get("userInfo");
			String rsAgency = String.valueOf(userInfo.get("agency"));
			if(!userVo.getAgency().equals(rsAgency)) {
				checkAuth = true;
			}
		} catch (Exception e) {
			result.setFailMessage("e" + e.getMessage());
			checkAuth = true;
		}
		if(checkAuth) {
			result.setFailMessage("회원 정보가 올바르지 않습니다.");
			return result;
		}

		UserVo dup = userService.getUser(usrId);
		if(dup!=null) {
			result.setFailMessage("이미 가입한 회원입니다.");
			return result;
		}
		userVo.setRegisterId(usrId);
		userVo.setUpdtId(usrId);

		int re = loginService.insertUser(userVo);
		return result;
	}
}
