package com.sk.dlsp.biz.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sk.dlsp.biz.service.AuthAppService;
import com.sk.dlsp.biz.service.AuthService;
import com.sk.dlsp.common.consts.CommonConstants;
import com.sk.dlsp.common.util.SessionUtil;
import com.sk.dlsp.model.AuthAppVo;
import com.sk.dlsp.model.AuthVo;
import com.sk.dlsp.model.BiVo;
import com.sk.dlsp.model.ResponseDto;
import com.sk.dlsp.model.UserInfo;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(CommonConstants.API_PREFIX +"/authApp")
public class AuthAppController {

	@Autowired AuthAppService authAppService;

	/**
	 * 권한 신청 조회
	 * @param pageNo
	 * @param schConfmSttus
	 * @return
	 */
	@GetMapping("/authApp")
	@ApiOperation(value = "권한 신청 조회")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "pageNo", value = "페이지 번호", required = false),
	    @ApiImplicitParam(name = "schConfmSttus", value = "요청상태", required = false),
	    @ApiImplicitParam(name = "schAgency", value = "관계사", required = false)
	})
	public ResponseDto getAuthList(@RequestParam(required = false) int pageNo,
			@RequestParam(required = false) String schConfmSttus,
			@RequestParam(required = false) String schAgency
			) {
		ResponseDto result = new ResponseDto();
		
		if(pageNo < 1)pageNo = 1;
		
		Map<String,Object> param = new HashMap<>(); 
		param.put("schConfmSttus", schConfmSttus);
		param.put("schAgency", schAgency);
		param.put("pageNo", pageNo);

		List<AuthAppVo> authAppList = authAppService.getAuthAppList(param);
		int authAppListCount = authAppService.getAuthAppListCount(param);
		
		if (authAppListCount==0) {
			authAppListCount=1;
		}

		result.putData("authAppListCount", authAppListCount);
		result.putData("authAppList", authAppList);
		return result;
	}
	
	/**
	 * 반려처리
	 * @param chkSn
	 * @param authAppVo
	 * @param request
	 * @return
	 */
	@PutMapping("/confmNo/{chkSn}")
	@ApiOperation(value = "반려처리")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "chkSn", value = "권한 코드", required = true)
	})
	public ResponseDto confmNo(@PathVariable(required = true) String chkSn, AuthAppVo authAppVo, HttpServletRequest request) {
		
		ResponseDto result = new ResponseDto();
		
		try { 
			 
			UserInfo userInfo = SessionUtil.getUserInfo();
			
			String [] sn = chkSn.split(",");
			
			for (int i=0; i<sn.length; i++) {
				authAppVo.setSn(Integer.parseInt(sn[i]));
				authAppVo.setConfmId(userInfo.getUsrId());
				authAppVo.setConfmSttus("00003"); 
			 
				int re = authAppService.confmNo(authAppVo);
			}
		} catch(Exception e) {
			e.printStackTrace();
			result.setCode(CommonConstants.FAIL);
			result.setMessage("권한신청 반려 처리중 오류가 발생하였습니다.");
			return result;
		}
		return result; 
	}
	
	/**
	 * 승인처리
	 * @param chkSn
	 * @param authAppVo
	 * @param request
	 * @return
	 */
	@PutMapping("/confmOk/{chkSn}")
	@ApiOperation(value = "승인처리")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "chkSn", value = "권한 코드", required = true)
	})
	public ResponseDto confmOk(@PathVariable(required = true) String chkSn, AuthAppVo authAppVo, HttpServletRequest request) {
		
		ResponseDto result = new ResponseDto();
		
		try { 
			 
			UserInfo userInfo = SessionUtil.getUserInfo();
			
			String [] sn = chkSn.split(",");
			
			for (int i=0; i<sn.length; i++) {
				authAppVo.setSn(Integer.parseInt(sn[i]));
				authAppVo.setConfmId(userInfo.getUsrId());
				authAppVo.setConfmSttus("00002"); 
			 
				int re = authAppService.confmNo(authAppVo);
				int re2 = authAppService.confmUsrAuthChang(authAppVo);
				
				
				
			}
		} catch(Exception e) {
			e.printStackTrace();
			result.setCode(CommonConstants.FAIL);
			result.setMessage("권한신청 승인 처리중 오류가 발생하였습니다.");
			return result;
		}
		return result; 
	}
	
	/**
	 * 권한 신청 등록
	 * @param authAppVo
	 * @return
	 */
	@PostMapping("authApp")
	@ApiOperation(value = "권한 신청 등록")
	public ResponseDto insertAuthApp(@RequestBody AuthAppVo authAppVo) {
		
		// Extract the userInfo, 20191022 by pkh 
		UserInfo userInfo = SessionUtil.getUserInfo(); 
		authAppVo.setUpdtId(userInfo.getUsrId());
		authAppVo.setRegisterId(userInfo.getUsrId());
		authAppVo.setComp(userInfo.getAgency());

		ResponseDto result = new ResponseDto();
		
		try { 
			
			int authCheckCnt =  authAppService.authCheckCnt(authAppVo);
			if (authCheckCnt==0) {
				int re = authAppService.insertAuthApp(authAppVo);
			}else {
				result.setCode(CommonConstants.FAIL);
				result.setMessage("이미 권한 신청하였습니다.");
			}

		} catch(Exception e) {
			e.printStackTrace();
			result.setCode(CommonConstants.FAIL);
			result.setMessage("권한 신청 등록 처리중 오류가 발생하였습니다.");
			return result;
		}
		return result; 
	}
}
