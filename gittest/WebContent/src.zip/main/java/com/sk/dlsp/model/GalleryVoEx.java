package com.sk.dlsp.model;

/*
	CREATE TABLE dlp.sp_ma_bi_gallery (
	  bi_rep_sj character varying(200), -- BI REPORT 제목
	  industry_id character varying(100), -- 산업구분id
	  industry_name character varying(100), -- 산업구분이름
	  cn character varying(4000), -- 상세 내용
	  img_name character varying(100), -- 이미지 이름
	  wid character varying(100), -- workbook id
	  vid character varying(100), -- view id
	  view_content_url character varying(100), -- view content url
	  CONSTRAINT sp_ma_bi_gallery_pk PRIMARY KEY (wid, vid)
	);
 */
public class GalleryVoEx extends GalleryVo {

	private int orderByIndex;

	public int getOrderByIndex() {
		return orderByIndex;
	}

	public void setOrderByIndex(int orderByIndex) {
		this.orderByIndex = orderByIndex;
	}

}
