package com.sk.dlsp.model;

public class UserCsvFileVo {

	private String agencyNm;
	private String agencyName;
	private String authNm;
	private String authName;
	private String registDe;
	private String registDate;
	private String cnt;
	public String getAgencyNm() {
		return agencyNm;
	}
	public void setAgencyNm(String agencyNm) {
		this.agencyNm = agencyNm;
	}
	public String getAgencyName() {
		return agencyName;
	}
	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}
	public String getAuthNm() {
		return authNm;
	}
	public void setAuthNm(String authNm) {
		this.authNm = authNm;
	}
	public String getAuthName() {
		return authName;
	}
	public void setAuthName(String authName) {
		this.authName = authName;
	}
	public String getRegistDe() {
		return registDe;
	}
	public void setRegistDe(String registDe) {
		this.registDe = registDe;
	}
	public String getRegistDate() {
		return registDate;
	}
	public void setRegistDate(String registDate) {
		this.registDate = registDate;
	}
	public String getCnt() {
		return cnt;
	}
	public void setCnt(String cnt) {
		this.cnt = cnt;
	}

		
	
	

	

}
