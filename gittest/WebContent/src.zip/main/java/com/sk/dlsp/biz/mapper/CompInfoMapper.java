package com.sk.dlsp.biz.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.sk.dlsp.model.CompInfoVo;

@Mapper
public interface CompInfoMapper {

	List<CompInfoVo> getCompInfoList(Map<String, Object> param);

	int getCompInfoListCount(Map<String, Object> param);

	int insertCompInfoList(CompInfoVo compInfoVo);

}
