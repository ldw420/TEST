package com.sk.dlsp.common.util;

import java.net.URLEncoder;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.sk.dlsp.common.consts.CookieConstants;
import com.sk.dlsp.model.UserInfo;

public class CookieUtil {
	private final static String defaultDomain = "";
	private final static String defaultPath = "/";
	private final static int defaultMaxAge = 30 * 60;

	public static Cookie getCookie(String key) {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		Cookie[] cookies = request.getCookies();
		if (cookies == null) {
			return null;
		}
		Cookie rCookie = null;
		for (Cookie cookie : cookies) {
			String ckName = cookie.getName();
			if (key.equals(ckName)) {
				rCookie = cookie;
				break;
			}
		}
		return rCookie;
	}
	public static String getCookieValue(String key){
		String result = null;
		Cookie cookie = getCookie(key);
		if(cookie != null) {
			result = cookie.getValue();
		}
		return result;
	}

	public static boolean setUserInfoCookie(UserInfo userInfo) throws Exception{
		HttpServletResponse res = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getResponse();
		if(res == null || userInfo == null)return false;
		setCookie(CookieConstants.USRID,userInfo.getUsrId());
		setCookie(CookieConstants.NM,userInfo.getNm());
		setCookie(CookieConstants.AGENCY,userInfo.getAgency());
		setCookie(CookieConstants.AUTH_ID,userInfo.getAuthId());

		return true;
	}

	public static boolean removeCookie(String key) throws Exception{
		return setCookie(defaultDomain,defaultPath,key,"",0,false);
	}
	public static boolean removeUserInfoCookie()throws Exception{
		removeCookie(CookieConstants.USRID);
		removeCookie(CookieConstants.NM);
		removeCookie(CookieConstants.AGENCY);
		removeCookie(CookieConstants.CTTPC);
		removeCookie(CookieConstants.AUTH_ID);
		removeCookie(CookieConstants.AUTH_NM);

		return true;
	}

	public static boolean setCookie(String key, String value) throws Exception {
		return setCookie(key,value,false);
	}
	public static boolean setCookie(String key, String value,boolean httpOnly) throws Exception {
		return setCookie(defaultDomain,defaultPath,key,value,defaultMaxAge,httpOnly);
	}
	public static boolean setCookie(String domain, String path, String key, String value, int maxAge,boolean httpOnly) throws Exception {
		HttpServletResponse res = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getResponse();
		if (res == null) return false;

		Cookie cookie = new Cookie(key, URLEncoder.encode(value, "utf-8"));
		if (domain != null) {
			cookie.setDomain(domain);
		}
		cookie.setMaxAge(maxAge);
		cookie.setPath(path);
		cookie.setHttpOnly(httpOnly);
		res.addCookie(cookie);

		return true;
	}
}
