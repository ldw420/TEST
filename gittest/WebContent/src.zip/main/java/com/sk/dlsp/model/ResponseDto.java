package com.sk.dlsp.model;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.sk.dlsp.common.consts.CommonConstants;

public class ResponseDto {

	private String code;
	private String message;
	private Map<String, Object> data;

	public ResponseDto(String code, String message) {
		this.code = code;
		this.message = message;
		this.data = new HashMap<>();
	}

	public ResponseDto(String code) {
		this(code, "");
	}
	public ResponseDto() {
		this(CommonConstants.SUCCESS);
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCode() {
		return this.code;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	public void setFailMessage(String message) {
		this.code = CommonConstants.FAIL;
		this.message = message;
	}
	public String getMessage() {
		return this.message;
	}

	public Map<String, Object> getData() {
		return this.data;
	}

	public void putData(String key,Object value) {
		this.data.put(key, value);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this,ToStringStyle.MULTI_LINE_STYLE);
	}



}
