package com.sk.dlsp.biz.mapper;

import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.sk.dlsp.model.EmailAuthVo;
import com.sk.dlsp.model.UserVo;

@Mapper
public interface LoginMapper {

	public int insertUser(UserVo userVo);

	public EmailAuthVo getEmailAuth(String usrId);

	public int insertEmailAuth(Map<String, String> param);

	public int updateEmailAuth(EmailAuthVo vo);

	public EmailAuthVo getEmailAuthOk(String usrId);
}
