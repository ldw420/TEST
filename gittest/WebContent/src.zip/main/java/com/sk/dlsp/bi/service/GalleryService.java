package com.sk.dlsp.bi.service;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.security.InvalidParameterException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sk.dlsp.bi.bindings.ProjectListType;
import com.sk.dlsp.bi.bindings.ProjectType;
import com.sk.dlsp.bi.bindings.SiteListType;
import com.sk.dlsp.bi.bindings.SiteType;
import com.sk.dlsp.bi.bindings.TableauCredentialsType;
import com.sk.dlsp.bi.bindings.ViewListType;
import com.sk.dlsp.bi.bindings.ViewType;
import com.sk.dlsp.bi.bindings.WorkbookListType;
import com.sk.dlsp.bi.bindings.WorkbookType;
import com.sk.dlsp.bi.common.TableauCommonConfig;
import com.sk.dlsp.bi.mapper.GalleryMapper;
import com.sk.dlsp.bi.restapi.RestApiUtils;
import com.sk.dlsp.model.GalleryVo;
import com.sk.dlsp.model.GalleryVoEx;

@Service
//@DependsOn(value = { "tableauCommonConfig", "tableauService", "galleryMapper" })
@Transactional
public class GalleryService {

	static Logger _log = LoggerFactory.getLogger(GalleryService.class.getName());

	public static final String VIEW_IMAGE_PATH = "resources/bi/img/";
	public static final String GALLERY_ROOT_PROJECT_NAME = "00.Gallery";

	private final String PREV = "PREV";
	private final String NEXT = "NEXT";

	@Autowired
	private TableauCommonConfig tableauCommonConfig;

	@Autowired
	private GalleryMapper galleryMapper;

	/**
	 * 갤러리목록(카드목록)을 가져온다.
	 * 
	 * @param param
	 * @return
	 */
	public List<GalleryVoEx> getList(Map<String, Object> param) throws Exception {
		return galleryMapper.getList(param);
	}

	public GalleryVo getOne(GalleryVo vo) throws Exception {
		return galleryMapper.getOne(vo);
	}

	/**
	 * 갤러리 정보(카드) 등록
	 * 
	 * @param galleryVo
	 * @return
	 */
	public int insertGalleryData(GalleryVo galleryVo) throws Exception {
		return galleryMapper.insertGalleryData(galleryVo);
	}

	/**
	 * 갤러리 정보(카드) 수정
	 * 
	 * @param galleryVo
	 * @return
	 */
	public int updateGalleryData(GalleryVo galleryVo) throws Exception {
		return galleryMapper.updateGalleryData(galleryVo);
	}

	/**
	 * 갤러리 정보 수정 <br>
	 * gallery 테이블 전체 삭제 후 등록 <br>
	 * gallery_mapping 테이블 gallery와 비교하여 없는 정보 삭제
	 * 
	 * @param viewFileMap
	 * @return
	 * @throws Exeption
	 */
	public int updateGalleryData(List<GalleryVo> galleryVoList) throws Exception {
		int cnt = 0;

		if (galleryVoList != null && !galleryVoList.isEmpty()) {

			// gallery 정보 전체 삭제
			galleryMapper.deleteGalleryDataAll();

			// gallery 정보 새로 등록
			for (GalleryVo galleryVo : galleryVoList) {
				cnt += insertGalleryData(galleryVo);
			}

			// gallery_mapping, gallery 테이블 비교하여 삭제된 정보 gallery_mapping에서 삭제
			galleryMapper.deleteGalleryMapping();
		}

		return cnt;
	}

	/**
	 * 갤러리 정보(카드) 삭제
	 * 
	 * @param galleryIdList
	 * @return
	 */
	public int deleteGalleryData(List<Integer> galleryIdList) throws Exception {
		int deleteCnt = 0;

		if (galleryIdList != null && !galleryIdList.isEmpty()) {
			for (int galleryId : galleryIdList) {
				deleteCnt += deleteGalleryData(galleryId);
			}
		}

		return deleteCnt;
	}

	public int deleteGalleryData(int galleryId) {
		GalleryVo vo = new GalleryVo();

		return galleryMapper.deleteGalleryData(vo);
	}

	/**
	 * 태블로 임베드 url을 만든다. <br>
	 * map에 shrUrl 있어야함.
	 * 
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public String makeTableauEmbedUrl(Map<String, Object> param) throws Exception {
		String result = "";

		String tableauShareUrl = String.valueOf(param.get("shrUrl"));

		if (tableauShareUrl != null && !"".equals(tableauShareUrl)) {
			URL urlTemp = new URL(tableauShareUrl);
			String urlTempParameter = urlTemp.getQuery();

			// doumentname/sheets/viewname 형태로 온다. embed url은 documentname/viewname으로 변경 해야
			// 한다.
//			String viewContentUrl = tableauService.getViewContentUrlFromUrl(tableauShareUrl);
			String viewContentUrl = getViewContentUrlFromUrl(tableauShareUrl);

			String[] paths = tableauShareUrl.split("/");

			if (viewContentUrl != null && !"".equals(viewContentUrl) && paths != null && paths.length > 0) {
				// documentname/sheets/viewname -> doumentname/viewname으로 변경
				viewContentUrl = viewContentUrl.replace("/sheets", "");

				String siteContentUrl = "";

				for (int i = 0; i < paths.length; i++) {
					if ("t".equals(paths[i])) {
						siteContentUrl = paths[i + 1];
					}
				}

				List<WorkbookType> workbookList = tableauCommonConfig.getAllWorkbookList();
				if (workbookList != null && !workbookList.isEmpty()) {

					StringBuilder urlSb = new StringBuilder();

					urlSb.append(tableauCommonConfig.getTableauServerEmbedUrl()).append("/trusted/")
							.append(getTableauTicket(tableauCommonConfig.getTableauServerAdminId(), siteContentUrl));

					// sitecontenturl이 있을경우 urldp /t/{siteContentUrl} 붙인다.
					if (siteContentUrl != null && !"".equals(siteContentUrl)) {
						urlSb.append("/t/").append(siteContentUrl);
					}

					urlSb.append("/views/").append(viewContentUrl).append("?:embed=yes&refresh=yes");

					if (urlTempParameter != null && !"".equals(urlTempParameter)) {
						urlSb.append('&').append(urlTempParameter);
					}

					return urlSb.toString();
				}
			}

		} else {
			throw new InvalidParameterException("태블로 URL이 잘못되었습니다.");
		}

		return result;
	}

	/**
	 * 태블로 임베드 url을 만든다. <br>
	 * shrUrl 없을경우(갤러리)
	 * 
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public String makeTableauEmbedUrl(GalleryVo galleryVo) throws Exception {
		StringBuilder urlSb = new StringBuilder();

		if (galleryVo != null && galleryVo.getViewContentUrl() != null && !"".equals(galleryVo.getViewContentUrl())) {

			urlSb.append(tableauCommonConfig.getTableauServerEmbedUrl()).append("/trusted/")
					.append(getTableauTicket(tableauCommonConfig.getTableauServerAdminId(),
							(tableauCommonConfig.getSiteType() == null ? ""
									: tableauCommonConfig.getSiteType().getContentUrl())));

			SiteType siteType = tableauCommonConfig.getSiteType();
			if (siteType != null && !"".equals(siteType.getContentUrl())) {
				urlSb.append("/t/").append(siteType.getContentUrl());
			}

			urlSb.append("/views/").append(galleryVo.getViewContentUrl()).append("?:embed=yes&refresh=yes");
		} else {
			throw new Exception("파라미터가 잘못 됐습니다.");
		}

		return urlSb.toString();
	}

	/**
	 * 이전 워크북 vo <br>
	 * order 기준 정해야 한다.(임시로 sn으로 한다.)
	 * 
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public GalleryVo getPrevGallery(List<GalleryVoEx> galleryList, GalleryVo currentGallery) throws Exception {
		return getWorkookVoByType(galleryList, currentGallery, this.PREV);
	}

	/**
	 * 다음 워크북 vo <br>
	 * order 기준 정해야 한다.(임시로 sn으로 한다.)
	 * 
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public GalleryVo getNextGallery(List<GalleryVoEx> galleryList, GalleryVo currentGallery) throws Exception {
		return getWorkookVoByType(galleryList, currentGallery, this.NEXT);
	}

	/**
	 * 이전/다음 워크북 vo
	 * 
	 * @param galleryList
	 * @param currentGallery
	 * @param type
	 * @return
	 */
	private GalleryVo getWorkookVoByType(List<GalleryVoEx> galleryList, GalleryVo currentGallery, String type)
			throws Exception {

		if (galleryList != null && !galleryList.isEmpty() && currentGallery != null && type != null
				&& !"".equals(type)) {

			int currentIdx = -1;
			String currentWid = currentGallery.getWid();
			String currentVid = currentGallery.getVid();
			int galleryListLen = galleryList.size();
			for (int i = 0; i < galleryListLen; i++) {
				GalleryVoEx gallery = galleryList.get(i);
				if (currentWid.equals(gallery.getWid()) && currentVid.equals(gallery.getVid())) {
					currentIdx = i;
					break;
				}
			}

			if (currentIdx != -1) {
				if (this.PREV.equals(type) && ((currentIdx - 1) >= 0)) {
					return galleryList.get(currentIdx - 1);
				} else if (this.NEXT.equals(type) && ((currentIdx + 1) < galleryListLen)) {
					return galleryList.get(currentIdx + 1);
				}
			}
		}

		return null;
	}

	/**
	 * 갤러리에서 썸네일까지 보여줄 갤러리 목록 수정
	 * 
	 * @param galleryList
	 * @return
	 * @throws Exception
	 */
	public boolean updateMappingData(List<Map<String, Object>> galleryList) throws Exception {
		int insertCnt = 0;
		int galleryListLen = -1;

		if (galleryList != null && !galleryList.isEmpty()) {
			galleryListLen = galleryList.size();

			// delete
			galleryMapper.deleteGalleryMappingAll();

			// insert
			for (Map<String, Object> galleryVoMap : galleryList) {
				insertCnt += galleryMapper.insertGalleryMapping(galleryVoMap);
			}
		}

		return insertCnt == galleryListLen;
	}

	/**
	 * 미리보기 이미지 다운로드
	 * 
	 * @param tableauShareUrl
	 * @return
	 * @throws Exception
	 */
	public File getPreviewImage(String tableauShareUrl) throws Exception {
//		return tableauService.getPreviewImage(tableauShareUrl, VIEW_IMAGE_PATH);
		return getPreviewImage(tableauShareUrl, VIEW_IMAGE_PATH);
	}

	public boolean setGalleryData(TableauCredentialsType adminCredentials, SiteType siteType) throws Exception {
		// workbook(workbook 가져올 때 view도 같이 가져온다.)

		setWorkbookList(adminCredentials, siteType);

		// view image
		List<WorkbookType> galleryWorkbookList = tableauCommonConfig.getGalleryWorkbookList();
		if (galleryWorkbookList != null && !galleryWorkbookList.isEmpty()) {

			List<GalleryVo> galleryVoList = new ArrayList<GalleryVo>();

			// ******************************* 디버깅 후 삭제 예정(김광민)
			// ******************************
			/*
			 * int downloadDoneIdx = 1; int galleryViewLen = 0; for (WorkbookType
			 * galleryWorkbookTmp : galleryWorkbookList) { ViewListType viewListTypeTmp =
			 * galleryWorkbookTmp.getViews(); if (viewListTypeTmp != null) { List<ViewType>
			 * viewTypeListTmp = viewListTypeTmp.getView(); if (viewTypeListTmp != null &&
			 * !viewTypeListTmp.isEmpty()) { galleryViewLen += viewTypeListTmp.size(); } } }
			 */
			// ************************************* 여기까지
			// *************************************

			for (WorkbookType galleryWorkbook : galleryWorkbookList) {

				String workbookId = galleryWorkbook.getId();
				String industryId = galleryWorkbook.getProject().getId();
				String industryName = galleryWorkbook.getProject().getName();

				ViewListType viewListType = galleryWorkbook.getViews();
				if (viewListType != null) {

					List<ViewType> viewTypeList = viewListType.getView();
					if (viewTypeList != null && !viewTypeList.isEmpty()) {
						for (ViewType viewType : viewTypeList) {
							// 파일명에서 공백 제거, 특수문자 언더바로 변경
							String fileName = viewType.getName();
							fileName = fileName.replaceAll("\\p{Z}", "");
							fileName = fileName.replaceAll("[^\uAC00-\uD7A3xfe0-9a-zA-Z\\s]", "_");

							File viewImage = getViewImage(viewType.getId(), VIEW_IMAGE_PATH, fileName);

							// db에 저장.
							if (viewImage != null) {

								// ******************************* 디버깅 후 삭제 예정(김광민)
								// ******************************
								// _log.error("Image download done.({}/{})", downloadDoneIdx++, galleryViewLen);
								// System.out.println("Image Download done.(" + downloadDoneIdx++ + "/" +
								// galleryViewLen + ")");
								// ************************************* 여기까지
								// *************************************

								GalleryVo galleryVo = new GalleryVo();
								// view name
								galleryVo.setBiRepSj(viewType.getName());
								// description
								galleryVo.setCn(galleryWorkbook.getDescription());
								// industry
								galleryVo.setIndustryId(industryId);
								galleryVo.setIndustryName(industryName);
								// image name
								galleryVo.setImgName(viewImage.getName());
								// view id
								galleryVo.setVid(viewType.getId());
								// workbook id
								galleryVo.setWid(workbookId);
								// view content url(view contenturl(workbookcontentUrl/sheets/viewcontenturl
								galleryVo.setViewContentUrl(viewType.getContentUrl().replace("sheets/", ""));

								galleryVoList.add(galleryVo);
							} else {
								_log.error("Image download failure.({})", viewType.getName());
							}
						}
					}
				}
			}

			updateGalleryData(galleryVoList);
		}

		return true;
	}

	public List<Map<String, Object>> getGalleryIndustryList() throws Exception {
		List<Map<String, Object>> industryList = new ArrayList<Map<String, Object>>();

		List<ProjectType> industryProjectList = tableauCommonConfig.getGalleryIndustryList();
		if (industryProjectList != null && !industryProjectList.isEmpty()) {

			// list -> map(K : industryId, V : cnt)
			Map<String, Object> industryCntMap = new HashMap<String, Object>();
			List<Map<String, Object>> industryCntList = galleryMapper.getCountByIndustry();
			for (Map<String, Object> industryCntTemp : industryCntList) {
				industryCntMap.put((String) industryCntTemp.get("industryId"), industryCntTemp.get("cnt"));
			}

			// project 기준으로 db에 저장된 내용 참조하여 id, name, cnt 있는 맵 생성
			for (ProjectType industryProject : industryProjectList) {
				Map<String, Object> industryMap = new HashMap<String, Object>();
				industryMap.put("industryId", industryProject.getId());
				industryMap.put("industryName", industryProject.getName());
				industryMap.put("cnt",
						(industryCntMap.containsKey(industryProject.getId())
								? industryCntMap.get(industryProject.getId())
								: 0));

				industryList.add(industryMap);
			}
		}

		return industryList;
	}

	public int getMappingCount() throws Exception {
		return galleryMapper.getMappingCount();
	}

	public int getCountAll() throws Exception {
		return tableauCommonConfig.getGalleryWorkbookList() == null ? 0
				: tableauCommonConfig.getGalleryWorkbookList().size();
	}

	/* tableau service */

	// talbeau server info
	public String getTableauApiVersion() throws Exception {
		String result = "";

		RestApiUtils restApiUtils = RestApiUtils.getInstance();

		Map<String, String> serverInfo = restApiUtils
				.invokeServerInfo(tableauCommonConfig.getTableauAdminCredentials());

		if (serverInfo != null && !serverInfo.isEmpty()) {
			result = serverInfo.get("restApiVersion");
		}

		return result;
	}

	// admin credentials
	public TableauCredentialsType signInAdmin(String siteContentUrl, String tableauServerUrl,
			String tableauServerAdminId, String tableauServerAdminPw) throws Exception {
//		String tableauServerUrl = TableauCommonConfig.getTableauServerUrl();
//		String tableauServerAdminId = tableauCommonConfig.getTableauServerAdminId();
//		String tableauServerAdminPw = tableauCommonConfig.getTableauServerAdminPw();

		if (tableauServerUrl != null && tableauServerAdminId != null && tableauServerAdminPw != null) {
			RestApiUtils restApiUtils = RestApiUtils.getInstance();

			if (restApiUtils == null) {
//				System.out.println("RestApiUtils is null");
			}

			TableauCredentialsType adminCredentials = restApiUtils.invokeSignIn(tableauServerAdminId,
					tableauServerAdminPw, (siteContentUrl == null ? "" : siteContentUrl));

			if (adminCredentials == null) {
				throw new Exception("태블로 로그인 실패.");
			}

			return adminCredentials;
		}

		return null;
	}

	public void setViewInWorkbook(WorkbookType workbook, TableauCredentialsType credentials, String siteId)
			throws Exception {
		RestApiUtils restApiUtils = RestApiUtils.getInstance();
		workbook.setViews(restApiUtils.invokeQueryViewsForWorkbook(credentials, siteId, workbook.getId()));
	}

	// ticket
	public String getTableauTicket(String tableauUserId, String siteContentUrl) {

		String tableauHostUrl = TableauCommonConfig.getTableauServerUrl();

		try {
			if (tableauHostUrl != null && !"".equals(tableauHostUrl)) {
				HttpClient httpClient = null;
				HttpPost httpPost = new HttpPost(tableauHostUrl + "/trusted");

				if (tableauHostUrl.startsWith("https")) {
					httpClient = new DefaultHttpClient();

					SSLContext sslContext = SSLContext.getInstance("TLS");
					sslContext.init(null, new TrustManager[] { easyTrustManager }, null);
					SSLSocketFactory socketFactory = new SSLSocketFactory(sslContext,
							SSLSocketFactory.STRICT_HOSTNAME_VERIFIER);

					Scheme sch = new Scheme("https", 443, socketFactory);

					httpClient.getConnectionManager().getSchemeRegistry().register(sch);
					httpClient.getParams().setParameter("http.protocol.expect-continue", false);
					httpClient.getParams().setParameter("http.connecion.timeout", 3 * 1000);
					httpClient.getParams().setParameter("http.socket.timeout", 3 * 1000);
					httpClient.getParams().setParameter("http.connection-manager.timeout", 3 * 1000);
					httpClient.getParams().setParameter("http.protocol.head-body-timeout", 3 * 1000);

				} else {
					httpClient = HttpClientBuilder.create().build();
				}

				List<NameValuePair> params = new ArrayList<NameValuePair>();
				params.add(new BasicNameValuePair("username", tableauUserId));
				if (siteContentUrl != null && !"".equals(siteContentUrl)) {
					params.add(new BasicNameValuePair("target_site", siteContentUrl));
				}

				httpPost.setEntity(new UrlEncodedFormEntity(params, "UTF-8"));

				HttpResponse response = httpClient.execute(httpPost);
				HttpEntity respEntity = response.getEntity();

				if (respEntity != null) {
					String content = EntityUtils.toString(respEntity);
					return content;
				}
			}
		} catch (Exception e) {
			_log.error(e.toString());
		}

		return "";
	}

	TrustManager easyTrustManager = new X509TrustManager() {

		@Override
		public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
			// TODO Auto-generated method stub

		}

		@Override
		public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
			// TODO Auto-generated method stub

		}

		@Override
		public X509Certificate[] getAcceptedIssuers() {
			// TODO Auto-generated method stub
			return null;
		}

	};

	/**
	 * 썸네일 이미지
	 * 
	 * @param workbookUrl
	 * @param savePath
	 * @return
	 * @throws Exception
	 */
	public File getPreviewImage(String workbookUrl, String savePath) throws Exception {

		String workbookId = getWorkbookIdFromUrl(workbookUrl);
		String viewId = getViewIdFromUrl(workbookUrl);

		RestApiUtils restApiUtils = RestApiUtils.getInstance();
		File previewImage = restApiUtils.invokeQueryViewPreviewImage(tableauCommonConfig.getTableauAdminCredentials(),
				getSiteId(), workbookId, viewId);

		if (previewImage != null && previewImage.exists()) {
			File dir = new File(savePath);
			if (!dir.exists()) {
				dir.mkdirs();
			}

			File realFile = new File(savePath + viewId + ".png");

			BufferedImage bi = ImageIO.read(previewImage);
			ImageIO.write(bi, "png", realFile);

			return realFile;
		} else {
			return null;
		}
	}

	/**
	 * 워크북 이미지
	 * 
	 * @param viewId
	 * @param savePath
	 * @param fileName
	 * @return
	 * @throws Exception
	 */
	public File getViewImage(String viewId, String savePath, String fileName) throws Exception {

		RestApiUtils restApiUtils = RestApiUtils.getInstance();
		File previewImage = restApiUtils.invokeQueryViewImage(tableauCommonConfig.getTableauAdminCredentials(),
				getSiteId(), viewId, null);

		if (previewImage != null && previewImage.exists()) {
			// resources/bi/images에 저장
			File dir = new File(savePath);
			if (!dir.exists()) {
				dir.mkdirs();
			}

			File realFile = new File(savePath + fileName + ".png");

			BufferedImage bi = ImageIO.read(previewImage);
			ImageIO.write(bi, "png", realFile);

			return realFile;
		} else {
			return null;
		}
	}

	/**
	 * url에서 workbookid 가져옴
	 * 
	 * @param url
	 * @return
	 * @throws Exception
	 */
	public String getWorkbookIdFromUrl(String url) throws Exception {
		String workbookId = "";

		String[] paths = url.split("/");
		if (paths != null && paths.length > 0) {
			String documentName = "";

			for (int i = 0; i < paths.length; i++) {
				if ("views".equals(paths[i])) {
					documentName = paths[i + 1];
					break;
				}
			}

			List<WorkbookType> workbookList = tableauCommonConfig.getAllWorkbookList();
			if (workbookList != null && !workbookList.isEmpty()) {
				workbookId = "";

				for (WorkbookType workbook : workbookList) {
					if (documentName.equals(workbook.getContentUrl())) {
						workbookId = workbook.getId();
						break;
					}
				}
			}

		}

		return workbookId;
	}

	/**
	 * url에서 view content url 가져온다.
	 * 
	 * @param url
	 * @return
	 * @throws Exception
	 */
	public String getViewContentUrlFromUrl(String url) throws Exception {
		String viewContentUrl = "";

		String[] paths = url.split("/");
		if (paths != null && paths.length > 0) {

			for (int i = 0; i < paths.length; i++) {
				if ("views".equals(paths[i])) {
					viewContentUrl = paths[i + 1] + "/sheets/" + paths[i + 2].split("\\?")[0];
					break;
				}
			}
		}

		return viewContentUrl;
	}

	/**
	 * url에서 view id 가져온다.
	 * 
	 * @param url
	 * @return
	 * @throws Exception
	 */
	public String getViewIdFromUrl(String url) throws Exception {
		String viewId = "";

		String viewContentUrl = getViewContentUrlFromUrl(url);

		if (viewContentUrl != null && !"".equals(viewContentUrl)) {
			List<WorkbookType> workbookList = tableauCommonConfig.getAllWorkbookList();
			if (viewContentUrl != null && !"".equals(viewContentUrl) && workbookList != null
					&& !workbookList.isEmpty()) {
				for (WorkbookType workbook : workbookList) {
					ViewListType viewListType = workbook.getViews();
					List<ViewType> viewTypeList = viewListType.getView();
					if (viewTypeList != null && !viewTypeList.isEmpty()) {
						for (ViewType viewType : viewTypeList) {
							if (viewContentUrl.equals(viewType.getContentUrl())) {
								viewId = viewType.getId();
								break;
							}
						}
					}
				}
			}
		}
		return viewId;
	}

	/**
	 * 사이트 정보를 세팅한다
	 * 
	 * @throws Exception
	 */
	public void setSite(TableauCredentialsType adminCredentials) throws Exception {
		// TableauCredentialsType adminCredentials =
		// tableauCommonConfig.getTableauAdminCredentials();
		RestApiUtils restApiUtils = RestApiUtils.getInstance();

		SiteListType siteListType = restApiUtils.invokeQuerySites(adminCredentials);
		if (siteListType != null) {
			List<SiteType> siteTypeList = siteListType.getSite();
			if (siteTypeList != null && !siteTypeList.isEmpty()) {

				tableauCommonConfig.setSiteTypeList(siteTypeList);

				if (siteTypeList.size() == 1) {
					tableauCommonConfig.setSiteType(siteTypeList.get(0));
				} else {
					String siteName = tableauCommonConfig.getTableauSiteName();

					for (SiteType siteType : siteTypeList) {
						if (siteName != null) {
							if (siteName.equals(siteType.getName())) {
								tableauCommonConfig.setSiteType(siteType);
								break;
							}
						}
					}
				}
			}
		}
	}

	/**
	 * 사이트 id를 가져온다.
	 * 
	 * @return
	 * @throws Exception
	 */
	public String getSiteId() throws Exception {
		SiteType siteType = tableauCommonConfig.getSiteType();
		if (siteType != null) {
			return siteType.getId();
		}

		return null;
	}

	/**
	 * 워크북 목록을 세팅한다.
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean setWorkbookList(TableauCredentialsType adminCredentials, SiteType siteType) throws Exception {
		if (adminCredentials == null) {
//			System.out.println("admin credentials is null(GalleryService.setWorkbookList)");

			adminCredentials = tableauCommonConfig.getTableauAdminCredentials();
		}

		if (siteType == null) {
//			System.out.println("site Type is null(GalleryService.setWorkbookList)");

			siteType = tableauCommonConfig.getSiteType();
		}

		List<WorkbookType> workbookList = getWorkbookList(adminCredentials, siteType);
		tableauCommonConfig.setAllWorkbookList(workbookList);

		List<ProjectType> projectList = getProjectList(adminCredentials, siteType);

		if (projectList != null && !projectList.isEmpty() && workbookList != null && !workbookList.isEmpty()) {
			String rootProjectId = "";
			List<WorkbookType> galleryWorkbookList = new ArrayList<WorkbookType>();

			List<ProjectType> galleryProjectList = new ArrayList<ProjectType>();
			List<String> galleryProjectIdList = new ArrayList<String>();

			int projectListLen = projectList.size();
			int i = 0;
			while (i < projectListLen) {
				ProjectType project = projectList.get(i);

				// root project id
				if ("".equals(rootProjectId) && GalleryService.GALLERY_ROOT_PROJECT_NAME.equals(project.getName())) {
					rootProjectId = project.getId();
					i = 0;
					continue;
				}

				if (rootProjectId.equals(project.getParentProjectId())) {
					galleryProjectList.add(project);
					galleryProjectIdList.add(project.getId());
				}

				i++;
			}

			// 갤러리 프로젝트(산업) 목록 관리해야한다.
			tableauCommonConfig.setGalleryIndustryList(galleryProjectList);

			// 워크북 중 갤러리 하위 프로젝트에 속한 워크북만 추려내기.
			for (WorkbookType workbook : workbookList) {
				String projectId = workbook.getProject().getId();
				if (galleryProjectIdList.contains(projectId)) {
					galleryWorkbookList.add(workbook);
				}
			}

			tableauCommonConfig.setGalleryWorkbookList(galleryWorkbookList);
		}

		return true;
	}

	/**
	 * 태블로 서버에서 워크북 목록을 가져온다.
	 * 
	 * @return
	 * @throws Exception
	 */
	public List<WorkbookType> getWorkbookList(TableauCredentialsType adminCredentials, SiteType siteType)
			throws Exception {
		// TableauCredentialsType adminCredentials =
		// tableauCommonConfig.getTableauAdminCredentials();

		if (tableauCommonConfig == null) {
//			System.out.println("TableauCommonConfig is null");
		}

		RestApiUtils restApiUtils = RestApiUtils.getInstance();

//			String siteId = getSiteId();
		if (siteType == null) {
//			System.out.println("site Type is null(GalleryService.setWorkbookList)");

			siteType = tableauCommonConfig.getSiteType();
		}

		String siteId = (siteType == null ? adminCredentials.getSite().getId() : siteType.getId());
//		System.out.println("site id : " + siteId);

		WorkbookListType workbookListType = restApiUtils.invokeQueryWorkbooksForSite(adminCredentials, siteId, 1, null,
				true);
		if (workbookListType != null) {
			List<WorkbookType> workbookTypeList = workbookListType.getWorkbook();
			if (workbookTypeList != null && !workbookTypeList.isEmpty()) {

				// workbook에 view 매핑
				for (WorkbookType workbook : workbookTypeList) {
					// site 매핑
					workbook.setSite(siteType);
					// view 매핑
					setViewInWorkbook(workbook, adminCredentials, siteId);
				}
			}

			return workbookTypeList;
		}

		return null;
	}

	/**
	 * 태블로 서버에서 프로젝트 목록을 가져온다.
	 * 
	 * @return
	 * @throws Exception
	 */
	public List<ProjectType> getProjectList(TableauCredentialsType adminCredentials, SiteType siteType)
			throws Exception {
//			TableauCredentialsType adminCredentials = tableauCommonConfig.getTableauAdminCredentials();

		RestApiUtils restApiUtils = RestApiUtils.getInstance();

		ProjectListType projectListType = restApiUtils.invokeQueryProjects(adminCredentials,
				(siteType == null ? "" : siteType.getId()));
		if (projectListType != null) {
			return projectListType.getProject();
		}

		return null;
	}

	/**
	 * url 조합을 통해 섬네일 이미지를 가져온다.
	 * 
	 * @param tableauShareUrl
	 * @param savePath
	 * @return
	 * @throws Exception
	 */
	public File getPreviewImageViaUrl(String tableauShareUrl, String savePath) throws Exception {

		if (StringUtils.isNotEmpty(tableauShareUrl)) {

			// doumentname/sheets/viewname 형태로 온다. embed url은 documentname/viewname으로 변경 해야
			// 한다.
			String viewContentUrl = getViewContentUrlFromUrl(tableauShareUrl);

			String[] paths = tableauShareUrl.split("/");

			if (viewContentUrl != null && !"".equals(viewContentUrl) && paths != null && paths.length > 0) {
				// documentname/sheets/viewname -> doumentname/viewname으로 변경
				viewContentUrl = viewContentUrl.replace("/sheets", "");

				System.out.println("view content url : " + viewContentUrl);

				String siteContentUrl = "";

				for (int i = 0; i < paths.length; i++) {
					if ("t".equals(paths[i])) {
						siteContentUrl = paths[i + 1];
					}
				}

				StringBuilder urlSb = new StringBuilder();

				urlSb.append(TableauCommonConfig.getTableauServerUrl()).append("/trusted/")
						.append(getTableauTicket(tableauCommonConfig.getTableauServerAdminId(), siteContentUrl));

				// sitecontenturl이 있을경우 urldp /t/{siteContentUrl} 붙인다.
				if (siteContentUrl != null && !"".equals(siteContentUrl)) {
					urlSb.append("/t/").append(siteContentUrl);
				}

				urlSb.append("/thumb/views/").append(viewContentUrl).append("?:embed=yes&:refresh=yes");

				System.out.println("getPreviewImageViaUrl : " + urlSb.toString());

				// 파일명(documentname_viewname)
				String fileName = viewContentUrl;
				fileName = fileName.replaceAll("[^\\uAC00-\\uD7A3xfe0-9a-zA-Z\\\\s]", "_").replaceAll("\\p{Z}", "");
				fileName += ".png";

				System.out.println("file name : " + fileName);

				return doImageDownload(urlSb.toString(), savePath, fileName);
			}
		}

		return null;
	}

	public File doImageDownload(String url, String savePath, String fileName) {

		try {
			if (StringUtils.isNotEmpty(url) && StringUtils.isNotEmpty(savePath)) {

				if (url.indexOf("?") == -1) {
					url += "?";
				}

				url += "&:format=png";

				System.out.println("doImageDownload : " + url);

				HttpClient httpClient = null;
				HttpGet httpGet = new HttpGet(url);

				if (url.startsWith("https")) {
					httpClient = new DefaultHttpClient();

					SSLContext sslContext = SSLContext.getInstance("TLS");
					sslContext.init(null, new TrustManager[] { easyTrustManager }, null);
					SSLSocketFactory socketFactory = new SSLSocketFactory(sslContext,
							SSLSocketFactory.STRICT_HOSTNAME_VERIFIER);

					Scheme sch = new Scheme("https", 443, socketFactory);

					httpClient.getConnectionManager().getSchemeRegistry().register(sch);
					httpClient.getParams().setParameter("http.protocol.expect-continue", false);
					httpClient.getParams().setParameter("http.connecion.timeout", 3 * 1000);
					httpClient.getParams().setParameter("http.socket.timeout", 3 * 1000);
					httpClient.getParams().setParameter("http.connection-manager.timeout", 3 * 1000);
					httpClient.getParams().setParameter("http.protocol.head-body-timeout", 3 * 1000);

				} else {
					httpClient = HttpClientBuilder.create().build();
				}

				HttpResponse response = httpClient.execute(httpGet);
				HttpEntity respEntity = response.getEntity();

				if (respEntity != null) {
					InputStream is = respEntity.getContent();

					System.out.println("input stream : " + is.toString());

					File dir = new File(savePath);
					if (!dir.exists()) {
						dir.mkdirs();
					}

					File img = new File(savePath + fileName);

					BufferedImage bi = null;
					bi = ImageIO.read(is);
					ImageIO.write(bi, "png", img);

					System.out.println("File create : " + img.getPath() + "/" + img.getName());
					return img;
				} else {
					System.out.println("respEntity is null");
				}
			}
		} catch (Exception e) {
			_log.error(e.toString());
			e.printStackTrace();
		}

		return null;
	}

	/* @Scheduled(fixedDelay = 60 * 10000 * 3) */
	public boolean setWorkbookList() {

		try {
			TableauCredentialsType adminCredentials = tableauCommonConfig.getTableauAdminCredentials();
			SiteType siteType = tableauCommonConfig.getSiteType();

			List<WorkbookType> workbookList = getWorkbookList(adminCredentials, siteType);
			tableauCommonConfig.setAllWorkbookList(workbookList);

			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
}
