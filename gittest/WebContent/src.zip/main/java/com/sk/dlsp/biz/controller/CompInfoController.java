package com.sk.dlsp.biz.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sk.dlsp.biz.service.CompInfoService;
import com.sk.dlsp.common.consts.CommonConstants;
import com.sk.dlsp.common.util.SessionUtil;
import com.sk.dlsp.model.CompInfoVo;
import com.sk.dlsp.model.ResponseDto;
import com.sk.dlsp.model.UserInfo;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(CommonConstants.API_PREFIX)
public class CompInfoController {
	@Autowired CompInfoService compInfoService;
	
	@GetMapping("/comp-info")
	@ApiOperation(value = "company info 조회")
	public ResponseDto getCompInfoList(@RequestParam(required = false, defaultValue="1") int pageNo ) throws Exception {
		
		ResponseDto result = new ResponseDto();

		// Extract the userInfo, 20191022 by pkh 
		UserInfo userInfo = SessionUtil.getUserInfo();
	
		try {
			Map<String,Object> param = new HashMap<>();
			param.put("pageNo", pageNo);
			
			// get the data from the DB
			List<CompInfoVo> compInfoList = compInfoService.getCompInfoList(param); 
//			int compInfoListCount 		  = compInfoService.getCompInfoListCount(param);
			
			result.putData("compInfoList", compInfoList);
//			result.putData("compInfoListCount", compInfoListCount);
		} catch(Exception e) {
			result.setCode(CommonConstants.FAIL);
			result.setMessage("company info 조회 중  오류가 발생하였습니다.");
		}

		return result;
	}
	
	@PostMapping("/comp-info")
	@ApiOperation(value = "company info 등록")
	public ResponseDto insertCompInfoList(@RequestBody CompInfoVo compInfoVo) throws Exception {
		ResponseDto result = new ResponseDto();
		
		// Extract the userInfo, 20191022 by pkh 
		UserInfo userInfo = SessionUtil.getUserInfo();
		compInfoVo.setUpdtId(userInfo.getUsrId());
		compInfoVo.setRegisterId(userInfo.getUsrId());
		
		try {
			int re = compInfoService.insertCompInfoList(compInfoVo);

		} catch(Exception e) {
			result.setCode(CommonConstants.FAIL);
			result.setMessage("company info 등록 처리중 오류가 발생하였습니다.");
			return result;
		}
		
		return result;
	}
	
	
	

}
