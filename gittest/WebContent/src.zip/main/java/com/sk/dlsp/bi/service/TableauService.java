package com.sk.dlsp.bi.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.sk.dlsp.bi.common.TableauCommonConfig;

/**
 * 태블로 서버 관련 서비스이다.
 * 
 * @author planit-partners
 *
 */
@Component
public class TableauService implements CommandLineRunner {

	static Logger _log = LoggerFactory.getLogger(TableauService.class.getName());

	@Autowired
	private TableauCommonConfig tableauCommonConfig;

	@Override
	public void run(String... args) throws Exception {
		long startTime = System.currentTimeMillis();

		try {
			tableauCommonConfig.getTableauInformation();
		} catch (Exception e) {
			_log.error(e.toString());
		} finally {
			_log.info("End to Load Tableau Data({} sec.)", ((System.currentTimeMillis() - startTime) / 1000.0));
		}
	}

}
