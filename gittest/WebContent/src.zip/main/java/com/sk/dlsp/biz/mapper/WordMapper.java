package com.sk.dlsp.biz.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.sk.dlsp.model.WordVo;

@Mapper
public interface WordMapper {

	public List<WordVo> getWordList(Map<String,String> param);
	
	public List<WordVo> getWordDetail(WordVo wordVo);

	public int insertWord(WordVo wordVo);

	public int deleteWord(int[] wordIds);
}
