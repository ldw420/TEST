package com.sk.dlsp.biz.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sk.dlsp.biz.mapper.AuthMapper; 
import com.sk.dlsp.model.AuthVo; 

@Service
@Transactional
public class AuthService {
    @Autowired AuthMapper authMapper;

	public List<AuthVo> getAuthList(){
		return authMapper.getAuthList();
	}

	public String getMaxAuthCode() {
		return authMapper.getMaxAuthCode();
	}

	public int insertAuth(AuthVo vo) {
		return authMapper.insertAuth(vo);
	}
	
	public int getCntAuthNm(String chkAuthNm) {
		return authMapper.getCntAuthNm(chkAuthNm);
	}
	
	public int unUseAuth(AuthVo vo) {
		int re = authMapper.unUseAuth(vo);
		 
		return re;
	}
	
 
	
	public int authDel(String[] authId) {
		int re = authMapper.authDel(authId);
		 
		return re;
	}
	
	public int useAuth(AuthVo vo) {
		int re = authMapper.useAuth(vo);
		 
		return re;
	}
 

 

}
