package com.sk.dlsp.common.util;

import java.nio.charset.StandardCharsets;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceAsync;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceAsyncClient;
import com.amazonaws.services.simpleemail.model.Body;
import com.amazonaws.services.simpleemail.model.Content;
import com.amazonaws.services.simpleemail.model.Destination;
import com.amazonaws.services.simpleemail.model.Message;
import com.amazonaws.services.simpleemail.model.SendEmailRequest;

@Component
public class EmailUtil {

	@Value("${prop.aws.email.from}") String FROM;
	@Value("${prop.aws.email.accessKeyId}") String accessKeyId;
	@Value("${prop.aws.email.secretAccessKey}") String secretAccessKey;
	static Logger logger = LoggerFactory.getLogger(EmailUtil.class);

	public boolean sendEmail(String to,String subject,String htmlbody,String textbody) {
		boolean result = false;
		try {

			BasicAWSCredentials basicAWSCredentials = new BasicAWSCredentials(accessKeyId, secretAccessKey);
			AmazonSimpleEmailServiceAsync client = AmazonSimpleEmailServiceAsyncClient.asyncBuilder()
					.withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials))
					.withRegion(Regions.US_EAST_1).build();

			SendEmailRequest request = new SendEmailRequest().withDestination(new Destination().withToAddresses(to))
					.withMessage(new Message()
							.withBody(new Body().withHtml(new Content().withCharset(StandardCharsets.UTF_8.name()).withData(htmlbody))
							.withText(new Content().withCharset(StandardCharsets.UTF_8.name()).withData(textbody)))
							.withSubject(new Content().withCharset(StandardCharsets.UTF_8.name()).withData(subject)))
					.withSource(FROM);
			client.sendEmail(request);
			result = true;
		} catch (Exception ex) {
			logger.error("email send error :%s" + to);
			logger.error(ex.getMessage());
			result = false;
		}
		return result;
	}
}