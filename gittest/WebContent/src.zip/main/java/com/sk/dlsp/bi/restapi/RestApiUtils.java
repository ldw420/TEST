package com.sk.dlsp.bi.restapi;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ws.rs.core.Cookie;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.stream.StreamSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.google.common.io.Files;
import com.sk.dlsp.bi.bindings.CapabilityType;
import com.sk.dlsp.bi.bindings.FileUploadType;
import com.sk.dlsp.bi.bindings.GranteeCapabilitiesType;
import com.sk.dlsp.bi.bindings.GroupListType;
import com.sk.dlsp.bi.bindings.GroupType;
import com.sk.dlsp.bi.bindings.ObjectFactory;
import com.sk.dlsp.bi.bindings.PermissionsType;
import com.sk.dlsp.bi.bindings.ProjectListType;
import com.sk.dlsp.bi.bindings.ProjectType;
import com.sk.dlsp.bi.bindings.SiteListType;
import com.sk.dlsp.bi.bindings.SiteRoleType;
import com.sk.dlsp.bi.bindings.SiteType;
import com.sk.dlsp.bi.bindings.TableauCredentialsType;
import com.sk.dlsp.bi.bindings.TsRequest;
import com.sk.dlsp.bi.bindings.TsResponse;
import com.sk.dlsp.bi.bindings.UserListType;
import com.sk.dlsp.bi.bindings.UserType;
import com.sk.dlsp.bi.bindings.ViewListType;
import com.sk.dlsp.bi.bindings.WorkbookListType;
import com.sk.dlsp.bi.bindings.WorkbookType;
import com.sk.dlsp.bi.common.TableauCommonConfig;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.multipart.BodyPart;
import com.sun.jersey.multipart.FormDataBodyPart;
import com.sun.jersey.multipart.MultiPart;
import com.sun.jersey.multipart.MultiPartMediaTypes;
import com.sun.jersey.multipart.file.FileDataBodyPart;

/**
 * This class encapsulates the logic used to make requests to the Tableau Server
 * REST API. This class is implemented as a singleton.
 */
//@Component
public class RestApiUtils {

	private static Logger m_logger = LoggerFactory.getLogger(RestApiUtils.class);

	private enum Operation {
		ADD_WORKBOOK_PERMISSIONS(getApiUriBuilder().path("sites/{siteId}/workbooks/{workbookId}/permissions")),
		ADD_USER(getApiUriBuilder().path("sites/{siteId}/users")),
		UPDATE_USER(getApiUriBuilder().path("sites/{siteId}/users/{userId}")),
		DELETE_USER(getApiUriBuilder().path("sites/{siteId}/users/{userId}")),
		APPEND_FILE_UPLOAD(getApiUriBuilder().path("sites/{siteId}/fileUploads/{uploadSessionId}")),
		CREATE_GROUP(getApiUriBuilder().path("sites/{siteId}/groups")),
		ADD_USER_TO_GROUP(getApiUriBuilder().path("sites/{siteId}/groups/{groupId}/users")),
		UPDATE_GROUP(getApiUriBuilder().path("sites/{siteId}/groups/{groupId}")),
		DELETE_GROUP(getApiUriBuilder().path("sites/{siteId}/groups/{groupId}")),
		DELETE_GROUP_USER(getApiUriBuilder().path("sites/{siteId}/groups/{groupId}/users/{userId}")),
		INITIATE_FILE_UPLOAD(getApiUriBuilder().path("sites/{siteId}/fileUploads")),
		PUBLISH_WORKBOOK(getApiUriBuilder().path("sites/{siteId}/workbooks")),
		QUERY_PROJECTS(getApiUriBuilder().path("sites/{siteId}/projects")),
		QUERY_SITES(getApiUriBuilder().path("sites")), 
		QUERY_USERS(getApiUriBuilder().path("sites/{siteId}/users")),
		QUERY_USERS_IN_GROUP(getApiUriBuilder().path("sites/{siteId}/groups/{groupId}/users")),
		QUERY_USER_ON_SITE(getApiUriBuilder().path("sites/{siteId}/users/{userId}")),
		QUERY_GROUPS(getApiUriBuilder().path("sites/{siteId}/groups")),
		QUERY_WORKBOOKS_FOR_USER(getApiUriBuilder().path("sites/{siteId}/users/{userId}/workbooks")),
		QUERY_WORKBOOKS_FOR_SITE(getApiUriBuilder().path("sites/{siteId}/workbooks")),
		QUERY_VIEWS_FOR_WORKBOOK(getApiUriBuilder().path("sites/{siteId}/workbooks/{workbookId}/views")),
		SIGN_IN(getApiUriBuilder().path("auth/signin")), 
		SIGN_OUT(getApiUriBuilder().path("auth/signout")),
		SERVER_INFO(getApiUriBuilder().path("serverinfo")), 
		SWITCH_SITE(getApiUriBuilder().path("auth/switchSite")),
		QUERY_VIEW_IMAGE(getApiUriBuilder().path("sites/{siteId}/views/{viewId}/image")), 
		QUERY_VIEW_PREVIEW_IMAGE(getApiUriBuilder().path("sites/{siteId}/workbooks/{workbookId}/views/{viewId}/previewImage"));

		private final UriBuilder m_builder;

		Operation(UriBuilder builder) {
			m_builder = builder;
		}

		UriBuilder getUriBuilder() {
			return m_builder;
		}

		String getUrl(Object... values) {
			return m_builder.build(values).toString();
		}
	}

	private static final String PARAM_GET_ALL_FIELDS = "&fields=_all_";

	// The only instance of the RestApiUtils
	private static RestApiUtils INSTANCE = null;
	private static Marshaller s_jaxbMarshaller;
	private static Unmarshaller s_jaxbUnmarshaller;

	/**
	 * Creates an instance of UriBuilder, using the URL of the server specified in
	 * the configuration file.
	 *
	 * @return the URI builder
	 */
	private static UriBuilder getApiUriBuilder() {

		try {
//			String host = m_properties.getProperty("tableau.server.url");
			String host = TableauCommonConfig.getTableauServerUrl();
			// api 버전 3.4로 고정
			return UriBuilder.fromPath(host + "/api/3.4");
		} catch (Exception e) {
			m_logger.error(e.getMessage());
		}

		return null;
	}

	public static RestApiUtils getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new RestApiUtils();
			//initialize(); 
		}

		return INSTANCE;
	}

	public RestApiUtils() {

	}

	private static void initialize() {
		try {
//			InputStream in = RestApiUtils.class.getClassLoader().getResourceAsStream("application.properties");
//			m_properties.load(in);
			JAXBContext jaxbContext = JAXBContext.newInstance(TsRequest.class, TsResponse.class);
			s_jaxbMarshaller = jaxbContext.createMarshaller();
			s_jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		} catch (JAXBException ex) {
			m_logger.error(ex.getMessage());
		} catch (NullPointerException e) {
			e.printStackTrace();
		}
	}

	private final String TABLEAU_AUTH_HEADER = "X-Tableau-Auth";

	private final String TABLEAU_PAYLOAD_NAME = "request_payload";

	private final String CHARSET = "utf-8";

	private ObjectFactory m_objectFactory = new ObjectFactory();

	// This class is implemented as a singleton, so it cannot be constructed
	// externally

	/**
	 * Creates a grantee capability object used to modify permissions on Tableau
	 * Server. A grantee capability contains the group ID and a map of capabilities
	 * and their permission mode.
	 *
	 * @param group           the group the permissions apply to
	 * @param capabilitiesMap the map of capability name to permission mode
	 * @return the grantee capability for the group
	 */
	public GranteeCapabilitiesType createGroupGranteeCapability(GroupType group, Map<String, String> capabilitiesMap) {
		GranteeCapabilitiesType granteeCapabilities = m_objectFactory.createGranteeCapabilitiesType();

		// Sets the grantee to the specified group
		granteeCapabilities.setGroup(group);
		GranteeCapabilitiesType.Capabilities capabilities = m_objectFactory.createGranteeCapabilitiesTypeCapabilities();

		// Iterates over the list of capabilities and creates a capability
		// element
		for (String key : capabilitiesMap.keySet()) {
			CapabilityType capabilityType = m_objectFactory.createCapabilityType();

			// Sets the capability name and permission mode
			capabilityType.setName(key);
			capabilityType.setMode(capabilitiesMap.get(key));

			// Adds the capability to the list of capabilities for the grantee
			capabilities.getCapability().add(capabilityType);
		}

		// Sets the list of capabilities for the grantee element
		granteeCapabilities.setCapabilities(capabilities);

		return granteeCapabilities;
	}

	/**
	 * Invokes an HTTP request to add permissions to the target workbook.
	 *
	 * @param credential          the credential containing the authentication token
	 *                            to use for this request
	 * @param siteId              the ID of the target site
	 * @param workbookId          the ID of the target workbook
	 * @param granteeCapabilities the list of grantees, including the permissions to
	 *                            add for this workbook
	 * @return the permissions added to the workbook, otherwise <code>null</code>
	 */
	public PermissionsType invokeAddPermissionsToWorkbook(TableauCredentialsType credential, String siteId,
			String workbookId, List<GranteeCapabilitiesType> granteeCapabilities) {

		m_logger.info(String.format("Adding permissions to workbook '%s'.", workbookId));

		String url = Operation.ADD_WORKBOOK_PERMISSIONS.getUrl(siteId, workbookId);

		// Creates the payload used to add permissions
		TsRequest payload = createPayloadForAddingWorkbookPermissions(workbookId, granteeCapabilities);

		// Makes a PUT request using the credential's authenticity token
		TsResponse response = put(url, credential.getToken(), payload);

		// Verifies that the response has a permissions element
		if (response.getPermissions() != null) {
			m_logger.info("Add workbook permissions is successful!");

			return response.getPermissions();
		}

		// No permissions were added
		return null;
	}

	/**
	 * smkim Invokes an HTTP request to add user to site
	 *
	 * @param credential the credential containing the authentication token to use
	 *                   for this request
	 * @param siteId     the ID of the target site
	 * @param userName
	 *
	 * @param siteRole
	 *
	 * @return the userId, userName, siteRole, otherwise <code>null</code>
	 */

	public UserType invokeAddUser(TableauCredentialsType credential, String siteId, String userName,
			SiteRoleType siteRole) {

		m_logger.info(String.format("Adding user to site '%s'.", userName));

		String url = Operation.ADD_USER.getUrl(siteId);

		// Creates the payload used to add user
		TsRequest payload = createPayloadForAddUser(userName, siteRole);

		// Makes a PUT request using the credential's authenticity token
		TsResponse response = post(url, credential.getToken(), payload);

		// Verifies that the response has a user element
		if (response.getError() == null && response.getUser() != null) {
			m_logger.info("Add user is successful!");
			return response.getUser();
		} else {
			m_logger.error(response.getError().getDetail());
			return null;
		}
	}

	/**
	 *
	 * smkim Invokes an HTTP request to update user to site
	 *
	 * @param credential the credential containing the authentication token to use
	 *                   for this request
	 * @param siteId     the ID of the target site
	 * @param fullName,  email, password, siteRole
	 *
	 * @return the userId, userName, siteRole, otherwise <code>null</code>
	 */

	public UserType invokeUpdateUser(TableauCredentialsType credential, String siteId, UserType user) {

		m_logger.info(String.format("Updating user to site '%s'.", user.getId()));

		String url = Operation.UPDATE_USER.getUrl(siteId, user.getId());

		// Creates the payload used to update user
		TsRequest payload = createPayloadForUpdateUser(user.getFullName(), user.getEmail(), user.getPassword(),
				user.getSiteRole());

		// Makes a PUT request using the credential's authenticity token
		TsResponse response = put(url, credential.getToken(), payload);

		// Verifies that the response has a user element
		if (response.getUser() != null) {
			m_logger.info("Update user is successful!");

			return response.getUser();
		}

		// No users were updated
		return null;
	}

	/**
	 *
	 * smkim Invokes an HTTP request to delete user to site
	 *
	 * @return <code>null</code>
	 */

	public boolean invokeDeleteUser(TableauCredentialsType credential, String siteId, String userId, String userName) {

		m_logger.info(String.format("Deleting user to site '%s'.", userName));

		String url = Operation.DELETE_USER.getUrl(siteId, userId);

		// Makes a PUT request using the credential's authenticity token
		TsResponse response = delete(url, credential.getToken());

		if (response == null) {
			m_logger.info("Delete user is successful!");
			return true;
		} else {
			m_logger.error(response.getError().getDetail());
			return false;
		}
	}

	/**
	 * Invokes an HTTP request to create a group on target site.
	 *
	 * @param credential     the credential containing the authentication token to
	 *                       use for this request
	 * @param siteId         the ID of the target site
	 * @param groupName      the name to assign to the new group
	 * @param requestPayload the payload used to create the group
	 * @return the group if it was successfully created, otherwise <code>null</code>
	 */
	public GroupType invokeCreateGroup(TableauCredentialsType credential, String siteId, String groupName) {

		m_logger.info(String.format("Creating group '%s' on site '%s'.", groupName, siteId));

		String url = Operation.CREATE_GROUP.getUrl(siteId);

		// Creates the payload to create the group
		TsRequest payload = createPayloadForCreatingGroup(groupName);

		// Make a POST request with specified credential's authenticity token
		// and payload
		TsResponse response = post(url, credential.getToken(), payload);

		// Verifies that the response has a group element
		if (response.getGroup() != null) {
			m_logger.info("Create group is successful!");

			return response.getGroup();
		}

		// No group was created
		return null;
	}

	/**
	 * Invokes an HTTP request to add user to group on target site.
	 *
	 * @param credential the credential containing the authentication token to use
	 *                   for this request
	 * @param siteId     the ID of the target site
	 * @param groupId    the id to assign to the group
	 * @param userId     the id to assign to the user
	 * @return the group if it was successfully created, otherwise <code>null</code>
	 */
	public UserType invokeAddUserToGroup(TableauCredentialsType credential, String siteId, String groupId,
			String userId) {

		m_logger.info(String.format("Add user to group '%s' on user '%s'.", groupId, userId));

		String url = Operation.ADD_USER_TO_GROUP.getUrl(siteId, groupId);

		// Creates the payload to create the group
		TsRequest payload = createPayloadForAddUserToGroup(userId);

		// Make a POST request with specified credential's authenticity token
		// and payload
		TsResponse response = post(url, credential.getToken(), payload);

		// Verifies that the response has a group element
		if (response.getUser() != null) {
			m_logger.info("Create group is successful!");

			return response.getUser();
		} else if (response.getError() != null) {
			if (response.getError().getCode().intValue() == 409011) {
				return new UserType();
			}
		}

		// No group was created
		return null;
	}

	/**
	 * Invokes an HTTP request to update a group on target site.
	 *
	 * @param credential     the credential containing the authentication token to
	 *                       use for this request
	 * @param siteId         the ID of the target site
	 * @param groupName      the name to assign to the update group
	 * @param requestPayload the payload used to update the group
	 * @return the group if it was successfully updated, otherwise <code>null</code>
	 */
	public GroupType invokeUpdateGroup(TableauCredentialsType credential, String siteId, String groupId,
			String groupName) {

		m_logger.info(String.format("Update group '%s' on site '%s'.", groupName, siteId));

		String url = Operation.UPDATE_GROUP.getUrl(siteId, groupId);

		// Creates the payload to create the group
		TsRequest payload = createPayloadForUpdatingGroup(groupName);

		// Make a PUT request with specified credential's authenticity token
		// and payload
		TsResponse response = put(url, credential.getToken(), payload);

		// Verifies that the response has a group element
		if (response.getGroup() != null) {
			m_logger.info("Create group is successful!");

			return response.getGroup();
		}

		// No group was created
		return null;
	}

	/**
	 * Invokes an HTTP request to delete a group on target site.
	 *
	 * @param credential the credential containing the authentication token to use
	 *                   for this request
	 * @param siteId     the ID of the target site
	 * @param groupId    the id to assign to the delete group
	 * @return boolean
	 */
	public boolean invokeDeleteGroup(TableauCredentialsType credential, String siteId, String groupId) {

		m_logger.info(String.format("Delete group '%s' on site '%s'.", groupId, siteId));

		String url = Operation.DELETE_GROUP.getUrl(siteId, groupId);

		// Make a delete request with specified credential's authenticity token
		TsResponse response = delete(url, credential.getToken());

		if (response == null) {
			m_logger.info("delete group is successful!");
			return true;
		} else {
			m_logger.error(response.getError().getDetail());
		}

		return false;
	}

	/**
	 * Invokes an HTTP request to delete a group user on target site.
	 *
	 * @param credential the credential containing the authentication token to use
	 *                   for this request
	 * @param siteId     the ID of the target site
	 * @param groupId    the id to assign to the delete group user
	 * @return boolean
	 */
	public boolean invokeDeleteGroupUser(TableauCredentialsType credential, String siteId, String groupId,
			String userId) {

		m_logger.info(String.format("Delete group user '%s' on site '%s' user '%s'.", groupId, siteId, userId));

		String url = Operation.DELETE_GROUP_USER.getUrl(siteId, groupId, userId);

		// Make a delete request with specified credential's authenticity token
		TsResponse response = delete(url, credential.getToken());

		if (response == null) {
			m_logger.info("delete group user is successful!");
			return true;
		} else {
			m_logger.error(response.getError().getDetail());
		}

		return false;
	}

	/**
	 * Invokes an HTTP request to publish a workbook to target site.
	 *
	 * @param credential     the credential containing the authentication token to
	 *                       use for this request
	 * @param siteId         the ID of the target site
	 * @param requestPayload the XML payload containing the workbook attributes used
	 *                       to publish the workbook
	 * @param workbookFile   the workbook file to publish
	 * @param chunkedPublish whether to publish the workbook in chunks or not
	 * @return the workbook if it was published successfully, otherwise
	 *         <code>null</code>
	 */
	public WorkbookType invokePublishWorkbook(TableauCredentialsType credential, String siteId, String projectId,
			String workbookName, File workbookFile, boolean chunkedPublish) {

		m_logger.info(String.format("Publishing workbook '%s' on site '%s'.", workbookName, siteId));

		if (chunkedPublish) {
			return invokePublishWorkbookChunked(credential, siteId, projectId, workbookName, workbookFile);
		} else {
			return invokePublishWorkbookSimple(credential, siteId, projectId, workbookName, workbookFile);
		}
	}

	/**
	 * Invokes an HTTP request to query the projects on the target site.
	 *
	 * @param credential the credential containing the authentication token to use
	 *                   for this request
	 * @param siteId     the ID of the target site
	 */
	public ProjectListType invokeQueryProjects(TableauCredentialsType credential, String siteId) {

		m_logger.info(String.format("Querying projects on site '%s'.", siteId));

		String url = Operation.QUERY_PROJECTS.getUrl(siteId);

		// Makes a GET request with the authenticity token
		TsResponse response = get(url, credential.getToken());

		// Verifies that the response has a projects element
		if (response.getProjects() != null) {
			m_logger.info("Query projects is successful!");

			return response.getProjects();
		}

		// No projects were found
		return null;
	}

	/**
	 * Invokes an HTTP request to query the sites on the server.
	 *
	 * @param credential the credential containing the authentication token to use
	 *                   for this request
	 * @return a list of sites if the query succeeded, otherwise <code>null</code>
	 */
	public SiteListType invokeQuerySites(TableauCredentialsType credential) {

		m_logger.info("Querying sites on Server.");

		String url = Operation.QUERY_SITES.getUrl();

		// Makes a GET request with the authenticity token
		TsResponse response = get(url, credential != null ? credential.getToken() : null);

		// Verifies that the response has a sites element
		if (response.getSites() != null) {
			m_logger.info("Query sites is successful!");

			return response.getSites();
		}

		// No sites were found
		return null;
	}

	/**
	 * smkim
	 *
	 * basic usage : invokeQueryUsers(credential, currentSiteId,"All",null)
	 *
	 * @return a list of sites if the query succeeded, otherwise <code>null</code>
	 */
	public UserListType invokeQueryUsers(TableauCredentialsType credential, String siteId, int pageNum,
			UserListType userList, boolean getAllList) {

		m_logger.info("Querying users on Server.");
		int defaultPageSize = 1000;
		if (userList == null) {
			userList = new UserListType();
		}

		String url = Operation.QUERY_USERS.getUrl(siteId);
		String Params = "?pageSize=" + String.valueOf(defaultPageSize) + "&pageNumber=" + String.valueOf(pageNum)
				+ PARAM_GET_ALL_FIELDS;
		TsResponse response = get(url + Params, credential.getToken());

		if (response.getPagination() != null) {
			userList.getUser().addAll(response.getUsers().getUser());
			int total = response.getPagination().getTotalAvailable().intValue();
			int getUserSize = userList.getUser().size();
			m_logger.info(String.format("Query workbooks Page %d - Workbook Size : %d, Total Size : %d",
					response.getPagination().getPageNumber(), getUserSize, total));

			if (total > getUserSize && getAllList) {
				invokeQueryUsers(credential, siteId, pageNum + 1, userList, true);
			}
		}

		return userList;

	}

	/**
	 * Invokes an HTTP request to query the user on the site.
	 *
	 * @param credential the credential containing the authentication token to use
	 *                   for this request sitd id
	 *
	 *                   user id
	 * @return a list of sites if the query succeeded, otherwise <code>null</code>
	 */
	public UserType invokeQueryUserOnSite(TableauCredentialsType credential, String siteId, String userId) {

		m_logger.info("Querying User On Site");

		String url = Operation.QUERY_USER_ON_SITE.getUrl(siteId, userId);

		// Makes a GET request with the authenticity token
		TsResponse response = get(url, credential.getToken());

		// Verifies that the response has a sites element
		if (response.getUser() != null) {
			m_logger.info("Query user on site Success");

			return response.getUser();
		}

		// No sites were found
		return null;
	}

	/**
	 * smkim
	 *
	 * basic usage : invokeQueryUsersInGroup(credential,
	 * currentSiteId,groupId,1,null,true)
	 *
	 * @return a list of sites if the query succeeded, otherwise <code>null</code>
	 */
	public UserListType invokeQueryUsersInGroup(TableauCredentialsType credential, String siteId, String groupId,
			int pageNum, UserListType userList, boolean getAllList) {

		m_logger.info("Querying users in group.");
		int defaultPageSize = 1000;
		if (userList == null) {
			userList = new UserListType();
		}

		String url = Operation.QUERY_USERS_IN_GROUP.getUrl(siteId, groupId);
		String Params = "?pageSize=" + String.valueOf(defaultPageSize) + "&pageNumber=" + String.valueOf(pageNum);
		TsResponse response = get(url + Params, credential.getToken());

		if (response.getPagination() != null) {
			userList.getUser().addAll(response.getUsers().getUser());
			int total = response.getPagination().getTotalAvailable().intValue();
			int getUserSize = userList.getUser().size();
			m_logger.info(String.format("Query workbooks Page %d - Workbook Size : %d, Total Size : %d",
					response.getPagination().getPageNumber(), getUserSize, total));

			if (total > getUserSize && getAllList) {
				invokeQueryUsersInGroup(credential, siteId, groupId, pageNum + 1, userList, true);
			}
		}

		return userList;

	}

	/**
	 * smkim
	 *
	 */
	public GroupListType invokeQueryGroups(TableauCredentialsType credential, String siteId) {

		m_logger.info("Querying groups on Server.");

		String url = Operation.QUERY_GROUPS.getUrl(siteId);

		// pageSize를 default(100) -> 1000 변경
		url += "?pageSize=1000";

		// Makes a GET request with the authenticity token
		TsResponse response = get(url, credential.getToken());

		// Verifies that the response has a users element
		if (response != null && response.getGroups() != null) {
			m_logger.info("Query groups is successful!");

			return response.getGroups();
		}

		// No Groups were found
		return null;
	}

	/**
	 * Invokes an HTTP request to query for the list of workbooks for which the user
	 * has read capability.
	 *
	 * @param credential the credential containing the authentication token to use
	 *                   for this request
	 * @param siteId     the ID of the target site
	 * @param userId     the ID of the target user
	 *
	 *                   basic usage : invokeQueryWorkbooks(credential,
	 *                   currentSiteId,userId,1,null,true)
	 * @return a list of workbooks if the query succeeded, otherwise
	 *         <code>null</code>
	 */
	public WorkbookListType invokeQueryWorkbooksForUser(TableauCredentialsType credential, String siteId, String userId,
			int pageNum, WorkbookListType workBookList, boolean getAllList) {

		m_logger.info(String.format("Querying workbooks on site '%s'.", siteId));
		int defaultPageSize = 1000;
		if (workBookList == null) {
			workBookList = new WorkbookListType();
		}

		String url = Operation.QUERY_WORKBOOKS_FOR_USER.getUrl(siteId, userId);
		String Params = "?pageSize=" + String.valueOf(defaultPageSize) + "&pageNumber=" + String.valueOf(pageNum);
		TsResponse response = get(url + Params, credential.getToken());

		if (response.getPagination() != null) {
			workBookList.getWorkbook().addAll(response.getWorkbooks().getWorkbook());
			int total = response.getPagination().getTotalAvailable().intValue();
			int getWorkbookSize = workBookList.getWorkbook().size();
			m_logger.info(String.format("Query workbooks Page %d - Workbook Size : %d, Total Size : %d",
					response.getPagination().getPageNumber(), getWorkbookSize, total));
			if (total > getWorkbookSize && getAllList) {
				invokeQueryWorkbooksForUser(credential, siteId, userId, pageNum + 1, workBookList, true);
			}
		}

		return workBookList;
	}

	/**
	 * Invokes an HTTP request to query for the list of workbooks for which the user
	 * has read capability.
	 *
	 * @param credential the credential containing the authentication token to use
	 *                   for this request
	 * @param siteId     the ID of the target site
	 * @param userId     the ID of the target user
	 *
	 *                   basic usage : invokeQueryWorkbooks(credential,
	 *                   currentSiteId,userId,1,null,true)
	 * @return a list of workbooks if the query succeeded, otherwise
	 *         <code>null</code>
	 */
	public WorkbookListType invokeQueryWorkbooksForSite(TableauCredentialsType credential, String siteId, int pageNum,
			WorkbookListType workBookList, boolean getAllList) {

		siteId = siteId == null ? "" : siteId;

		m_logger.info(String.format("Querying workbooks on site '%s'.", siteId));
		int defaultPageSize = 1000;
		if (workBookList == null) {
			workBookList = new WorkbookListType();
		}

		String url = Operation.QUERY_WORKBOOKS_FOR_SITE.getUrl(siteId);
		String Params = "?pageSize=" + String.valueOf(defaultPageSize) + "&pageNumber=" + String.valueOf(pageNum);
		TsResponse response = get(url + Params, credential.getToken());

		if (response.getPagination() != null) {
			workBookList.getWorkbook().addAll(response.getWorkbooks().getWorkbook());
			int total = response.getPagination().getTotalAvailable().intValue();
			int getWorkbookSize = workBookList.getWorkbook().size();
			m_logger.info(String.format("Query workbooks Page %d - Workbook Size : %d, Total Size : %d",
					response.getPagination().getPageNumber(), getWorkbookSize, total));
			if (total > getWorkbookSize && getAllList) {
				invokeQueryWorkbooksForSite(credential, siteId, pageNum + 1, workBookList, true);
			}
		}

		return workBookList;
	}

	/**
	 * smkim
	 *
	 * basic usage : invokeQueryViewsForWorkbook(credential,
	 * currentSiteId,workbookId)
	 *
	 * @return a list of sites if the query succeeded, otherwise <code>null</code>
	 */
	public ViewListType invokeQueryViewsForWorkbook(TableauCredentialsType credential, String siteId,
			String workbookId) {

		m_logger.info(String.format("Querying views for workbook '%s'.", workbookId));

		String url = Operation.QUERY_VIEWS_FOR_WORKBOOK.getUrl(siteId, workbookId);

		// Makes a GET request with the authenticity token
		TsResponse response = get(url, credential.getToken());

		// Verifies that the response has a projects element
		if (response.getViews() != null) {
			m_logger.info("Query views is successful!");

			return response.getViews();
		}

		return null;

	}

	/**
	 * Invokes an HTTP request to sign in to the server.
	 *
	 * @param requestPayload the payload containing the username and password to
	 *                       authenticate
	 * @return the credential if authentication was successful, otherwise
	 *         <code>null</code>
	 */
	public TableauCredentialsType invokeSignIn(String username, String password, String contentUrl) {

		m_logger.info("Signing in to Tableau Server");

		String url = Operation.SIGN_IN.getUrl();

		// Creates the payload required to authenticate to server
		TsRequest payload = createPayloadForSignin(username, password, contentUrl);

		// Makes a POST request with no credential
		TsResponse response = post(url, null, payload);

		// Verifies that the response has a credentials element
		if (response.getCredentials() != null) {
			m_logger.info("Sign in is successful!");

			return response.getCredentials();
		}

		// No credential were received
		return null;
	}

	/**
	 * Invokes an HTTP request to sign out of the Server.
	 *
	 * @param credential the credential containing the authentication token to use
	 *                   for this request
	 */
	public void invokeSignOut(TableauCredentialsType credential) {

		m_logger.info("Signing out of Tableau Server");

		String url = Operation.SIGN_OUT.getUrl();

		// Creates the HTTP client object and makes the HTTP request to the
		// specified URL
		Client client = Client.create();
		WebResource webResource = client.resource(url);

		// Makes a POST request with the payload and credential
		ClientResponse clientResponse = webResource.header(TABLEAU_AUTH_HEADER, credential.getToken())
				.post(ClientResponse.class);

		if (clientResponse.getStatus() == Status.NO_CONTENT.getStatusCode()) {
			m_logger.info("Successfully signed out of Tableau Server");
		} else {
			m_logger.error("Failed to sign out of Tableau Server");
		}
	}

	/**
	 * Creates the request payload used to add permissions for a workbook.
	 *
	 * @param workbookId          the ID of the workbook the permissions payload
	 *                            applies to
	 * @param granteeCapabilities the list of capabilities for the payload
	 * @return the request payload
	 */
	private TsRequest createPayloadForAddingWorkbookPermissions(String workbookId,
			List<GranteeCapabilitiesType> granteeCapabilities) {
		// Creates the parent tsRequest element
		TsRequest requestPayload = m_objectFactory.createTsRequest();

		// Creates the permissions element
		PermissionsType permissions = m_objectFactory.createPermissionsType();

		// Creates the workbook and set the workbook ID
		WorkbookType workbook = m_objectFactory.createWorkbookType();
		workbook.setId(workbookId);

		// Sets the workbook element and capabilities element
		permissions.setWorkbook(workbook);
		permissions.getGranteeCapabilities().addAll(granteeCapabilities);

		// Adds the permissions element to the request payload
		requestPayload.setPermissions(permissions);

		return requestPayload;
	}

	/**
	 * Creates the request payload used to create a group.
	 *
	 * @param groupName the name for the new group
	 * @return the request payload
	 */
	private TsRequest createPayloadForCreatingGroup(String groupName) {
		// Creates the parent tsRequest element
		TsRequest requestPayload = m_objectFactory.createTsRequest();

		// Creates group element
		GroupType group = m_objectFactory.createGroupType();

		// Sets the group name
		group.setName(groupName);

		// Adds the group element to the request payload
		requestPayload.setGroup(group);

		return requestPayload;
	}

	/**
	 * Creates the request payload used to update a group.
	 *
	 * @param groupName the name for the update group
	 * @return the request payload
	 */
	private TsRequest createPayloadForUpdatingGroup(String groupName) {
		// Creates the parent tsRequest element
		TsRequest requestPayload = m_objectFactory.createTsRequest();

		// Creates group element
		GroupType group = m_objectFactory.createGroupType();

		// Sets the group name
		group.setName(groupName);

		// Adds the group element to the request payload
		requestPayload.setGroup(group);

		return requestPayload;
	}

	/**
	 * Creates the request payload used to sign in to the server.
	 *
	 * @param username   the username of the user to authenticate
	 * @param password   the password of the user to authenticate
	 * @param contentUrl the content URL for the site to authenticate to
	 * @return the request payload
	 */
	private TsRequest createPayloadForSignin(String username, String password, String contentUrl) {
		// Creates the parent tsRequest element
		TsRequest requestPayload = m_objectFactory.createTsRequest();

		// Creates the credentials element and site element
		TableauCredentialsType signInCredentials = m_objectFactory.createTableauCredentialsType();
		SiteType site = m_objectFactory.createSiteType();

		// Sets the content URL of the site to sign in to
		site.setContentUrl(contentUrl);
		signInCredentials.setSite(site);

		// Sets the name and password of the user to authenticate
		signInCredentials.setName(username);
		signInCredentials.setPassword(password);

		// Adds the credential element to the request payload
		requestPayload.setCredentials(signInCredentials);

		return requestPayload;
	}

	/**
	 * Creates the request payload used to publish a workbook.
	 *
	 * @param workbookName the name for the new workbook
	 * @param projectId    the ID of the project to publish to
	 * @return the request payload
	 */
	private TsRequest createPayloadToPublishWorkbook(String workbookName, String projectId) {
		// Creates the parent tsRequest element
		TsRequest requestPayload = m_objectFactory.createTsRequest();

		// Creates the workbook element
		WorkbookType workbook = m_objectFactory.createWorkbookType();

		// Creates the project element
		ProjectType project = m_objectFactory.createProjectType();

		// Sets the target project ID
		project.setId(projectId);

		// Sets the workbook name
		workbook.setName(workbookName);

		// Sets the project
		workbook.setProject(project);

		// Adds the workbook element to the request payload
		requestPayload.setWorkbook(workbook);

		return requestPayload;
	}

	/**
	 * smkim
	 *
	 * @param userName, siteRole
	 *
	 */
	private TsRequest createPayloadForAddUser(String userName, SiteRoleType siteRole) {
		// Creates the parent tsRequest element
		TsRequest requestPayload = m_objectFactory.createTsRequest();

		// Creates user element
		UserType user = m_objectFactory.createUserType();

		// Sets the user name
		user.setName(userName);
		user.setSiteRole(siteRole);

		// Adds the user element to the request payload
		requestPayload.setUser(user);

		return requestPayload;
	}

	/**
	 * smkim
	 *
	 * @param fullName, email, password, siteRole
	 *
	 */

	private TsRequest createPayloadForUpdateUser(String fullName, String email, String password,
			SiteRoleType siteRole) {
		// Creates the parent tsRequest element
		TsRequest requestPayload = m_objectFactory.createTsRequest();

		// Creates user element
		UserType user = m_objectFactory.createUserType();

		// Sets the user name
		user.setFullName(fullName);
		user.setEmail(email);
		user.setPassword(password);
		user.setSiteRole(siteRole);

		// Adds the user element to the request payload
		requestPayload.setUser(user);

		return requestPayload;
	}

	/**
	 * Creates the request payload used to publish a workbook.
	 *
	 * @param workbookName the name for the new workbook
	 * @param projectId    the ID of the project to publish to
	 * @return the request payload
	 */
	private TsRequest createPayloadForAddUserToGroup(String userId) {
		// Creates the parent tsRequest element
		TsRequest requestPayload = m_objectFactory.createTsRequest();

		// Creates user element
		UserType user = m_objectFactory.createUserType();

		// Sets the user id
		user.setId(userId);

		// Adds the user element to the request payload
		requestPayload.setUser(user);

		return requestPayload;
	}

	/**
	 * Creates a GET request using the specified URL.
	 *
	 * @param url       the URL to send the request to
	 * @param authToken the authentication token to use for this request
	 * @return the response from the request
	 */
	private TsResponse get(String url, String authToken) {
		// Creates the HTTP client object and makes the HTTP request to the
		// specified URL
		Client client = Client.create();
		WebResource webResource = client.resource(url);

		// Sets the header and makes a GET request
		ClientResponse clientResponse = webResource.header(TABLEAU_AUTH_HEADER, authToken).get(ClientResponse.class);

		// Parses the response from the server into an XML string
		String responseXML = clientResponse.getEntity(String.class);

		m_logger.info("Response: \n" + responseXML);

		// Returns the unmarshalled XML response
		return unmarshalResponse(responseXML);
	}

	/**
	 * Creates a DELETE request using the specified URL.
	 *
	 * @param url       the URL to send the request to
	 * @param authToken the authentication token to use for this request
	 * @return the response from the request
	 */
	private TsResponse delete(String url, String authToken) {
		// Creates the HTTP client object and makes the HTTP request to the
		// specified URL
		Client client = Client.create();
		WebResource webResource = client.resource(url);

		// Sets the header and makes a GET request
		ClientResponse clientResponse = webResource.header(TABLEAU_AUTH_HEADER, authToken).delete(ClientResponse.class);

		if (clientResponse.getStatus() == Status.NO_CONTENT.getStatusCode()) {
			// Success
			return null;
		} else {
			// Parses the response from the server into an XML string
			String responseXML = clientResponse.getEntity(String.class);
			m_logger.info("Response: \n" + responseXML);
			// Returns the unmarshalled XML response
			return unmarshalResponse(responseXML);
		}
	}

	/**
	 * Invokes an HTTP request to append to target file upload on target site.
	 *
	 * @param credential      the credential containing the authentication token to
	 *                        use for this request
	 * @param siteId          the ID of the target site
	 * @param uploadSessionId the session ID of the target file upload
	 * @param chunk           the chunk of data to append to target file upload
	 * @param numChunkBytes   the number of bytes in the chunk of data
	 */
	private void invokeAppendFileUpload(TableauCredentialsType credential, String siteId, String uploadSessionId,
			byte[] chunk, int numChunkBytes) {

		m_logger.info(String.format("Appending to file upload '%s'.", uploadSessionId));

		String url = Operation.APPEND_FILE_UPLOAD.getUrl(siteId, uploadSessionId);

		// Writes the chunk of data to a temporary file
		try (FileOutputStream outputStream = new FileOutputStream("appendFileUpload.temp")) {
			outputStream.write(chunk, 0, numChunkBytes);
		} catch (IOException e) {
			throw new IllegalStateException("Failed to create temporary file to append to file upload");
		}

		// Makes a multipart PUT request with specified credential's
		// authenticity token and payload
		BodyPart filePart = new FileDataBodyPart("tableau_file", new File("appendFileUpload.temp"),
				MediaType.APPLICATION_OCTET_STREAM_TYPE);
		putMultipart(url, credential.getToken(), null, filePart);
	}

	/**
	 * Invokes an HTTP request to create a new file upload on target site.
	 *
	 * @param credential the credential containing the authentication token to use
	 *                   for this request
	 * @param siteId     the ID of the target site
	 * @return the file upload if created successfully, otherwise <code>null</code>
	 */
	private FileUploadType invokeInitiateFileUpload(TableauCredentialsType credential, String siteId) {

		m_logger.info(String.format("Initia projects on site '%s'.", siteId));

		String url = Operation.INITIATE_FILE_UPLOAD.getUrl(siteId);

		// Make a POST request with the authenticity token
		TsResponse response = post(url, credential.getToken());

		// Verifies that the response has a file upload element
		if (response.getFileUpload() != null) {
			m_logger.info("Initiate file upload is successful!");

			return response.getFileUpload();
		}

		// No file upload is found
		return null;
	}

	/**
	 * Initiates a file upload session to get an upload session id. This upload
	 * session id is used to upload the workbook in chunks. After the workbook has
	 * been uploaded, publish the workbook using the upload session id.
	 *
	 * @param credential     the credential containing the authentication token to
	 *                       use for this request
	 * @param siteId         the ID of the target site
	 * @param requestPayload the XML payload containing the workbook attributes used
	 *                       to publish the workbook
	 * @param workbookFile   the workbook file to publish
	 * @return the workbook if it was published successfully, otherwise
	 *         <code>null</code>
	 */
	private WorkbookType invokePublishWorkbookChunked(TableauCredentialsType credential, String siteId,
			String projectId, String workbookName, File workbookFile) {

		// Initiates a new file upload to get an upload session id
		FileUploadType fileUpload = invokeInitiateFileUpload(credential, siteId);

		// Builds the URL with the upload session id and workbook type
		UriBuilder builder = Operation.PUBLISH_WORKBOOK.getUriBuilder()
				.queryParam("uploadSessionId", fileUpload.getUploadSessionId())
				.queryParam("workbookType", Files.getFileExtension(workbookFile.getName()));
		String url = builder.build(siteId, fileUpload.getUploadSessionId()).toString();

		// Creates a buffer to read 100KB at a time
		byte[] buffer = new byte[100000];
		int numReadBytes = 0;

		// Reads the specified workbook and appends each chunk to the file
		// upload
		try (FileInputStream inputStream = new FileInputStream(workbookFile.getAbsolutePath())) {
			while ((numReadBytes = inputStream.read(buffer)) != -1) {
				invokeAppendFileUpload(credential, siteId, fileUpload.getUploadSessionId(), buffer, numReadBytes);
			}
		} catch (IOException e) {
			throw new IllegalStateException("Failed to read the workbook file.");
		}

		// Creates the payload to publish the workbook
		TsRequest payload = createPayloadToPublishWorkbook(workbookName, projectId);

		// Makes a multipart POST request with specified credential's
		// authenticity token and payload
		TsResponse response = postMultipart(url, credential.getToken(), payload, null);

		// Verifies that the response has a workbook element
		if (response.getWorkbook() != null) {
			m_logger.info("Publish workbook is successful!");

			return response.getWorkbook();
		}

		// No workbook was published
		return null;
	}

	/**
	 * Invokes an HTTP request to publish a workbook to target site including the
	 * workbook in the request.
	 *
	 * @param credential     the credential containing the authentication token to
	 *                       use for this request
	 * @param siteId         the ID of the target site
	 * @param requestPayload the XML payload containing the workbook attributes used
	 *                       to publish the workbook
	 * @param workbookFile   the workbook file to publish
	 * @return the workbook if it was published successfully, otherwise
	 *         <code>null</code>
	 */
	private WorkbookType invokePublishWorkbookSimple(TableauCredentialsType credential, String siteId, String projectId,
			String workbookName, File workbookFile) {

		String url = Operation.PUBLISH_WORKBOOK.getUrl(siteId);

		// Creates the payload to publish the workbook
		TsRequest payload = createPayloadToPublishWorkbook(workbookName, projectId);

		// Makes a multipart POST request with specified credential's
		// authenticity token and payload
		BodyPart filePart = new FileDataBodyPart("tableau_workbook", workbookFile,
				MediaType.APPLICATION_OCTET_STREAM_TYPE);
		TsResponse response = postMultipart(url, credential.getToken(), payload, filePart);

		// Verifies that the response has a workbook element
		if (response.getWorkbook() != null) {
			m_logger.info("Publish workbook is successful!");

			return response.getWorkbook();
		}

		// No workbook was published
		return null;
	}

	/**
	 * Creates a POST request using the specified URL without a payload.
	 *
	 * @param url       the URL to send the request to
	 * @param authToken the authentication token to use for this request
	 * @return the response from the request
	 */
	private TsResponse post(String url, String authToken) {

		// Creates the HTTP client object and makes the HTTP request to the
		// specified URL
		Client client = Client.create();
		WebResource webResource = client.resource(url);

		// Makes a POST request with the payload and credential
		ClientResponse clientResponse = webResource.header(TABLEAU_AUTH_HEADER, authToken).post(ClientResponse.class);

		// Parses the response from the server into an XML string
		String responseXML = clientResponse.getEntity(String.class);

		m_logger.debug("Response: \n" + responseXML);

		// Returns the unmarshalled XML response
		return unmarshalResponse(responseXML);
	}

	/**
	 * Creates a POST request using the specified URL with the specified payload.
	 *
	 * @param url            the URL to send the request to
	 * @param authToken      the authentication token to use for this request
	 * @param requestPayload the payload to send with the request
	 * @return the response from the request
	 */
	private TsResponse post(String url, String authToken, TsRequest requestPayload) {
		// Creates an instance of StringWriter to hold the XML for the request
		StringWriter writer = new StringWriter();

		// Marshals the TsRequest object into XML format if it is not null
		if (requestPayload != null) {
			try {
				s_jaxbMarshaller.marshal(requestPayload, writer);
			} catch (JAXBException ex) {
				m_logger.error("There was a problem marshalling the payload");
			}
		}

		// Converts the XML into a string
		String payload = writer.toString();

		m_logger.debug("Input payload: \n" + payload);

		// Creates the HTTP client object and makes the HTTP request to the
		// specified URL
		Client client = Client.create();
		WebResource webResource = client.resource(url);

		// Makes a POST request with the payload and credential
		ClientResponse clientResponse = webResource.header(TABLEAU_AUTH_HEADER, authToken).type(MediaType.TEXT_XML_TYPE)
				.post(ClientResponse.class, payload);

		// Parses the response from the server into an XML string
		String responseXML = clientResponse.getEntity(String.class);

		m_logger.debug("Response: \n" + responseXML);

		// Returns the unmarshalled XML response
		return unmarshalResponse(responseXML);
	}

	/**
	 * Creates a multipart POST request using the specified URL with the specified
	 * payload.
	 *
	 * @param url            the URL to send the request to
	 * @param authToken      the authentication token to use for this request
	 * @param requestPayload the payload to send with the request
	 * @param file           the file to send with the request
	 * @return the response from the request
	 */
	private TsResponse postMultipart(String url, String authToken, TsRequest requestPayload, BodyPart filePart) {
		// Creates an instance of StringWriter to hold the XML for the request
		StringWriter writer = new StringWriter();

		// Marshals the TsRequest object into XML format if it is not null
		if (requestPayload != null) {
			try {
				s_jaxbMarshaller.marshal(requestPayload, writer);
			} catch (JAXBException ex) {
				m_logger.error("There was a problem marshalling the payload");
			}
		}

		// Converts the XML into a string
		String payload = writer.toString();

		m_logger.debug("Input payload: \n" + payload);

		// Creates the XML request payload portion of the multipart request
		BodyPart payloadPart = new FormDataBodyPart(TABLEAU_PAYLOAD_NAME, payload);

		// Creates the multipart object and adds the file portion of the
		// multipart request to it
		MultiPart multipart = new MultiPart();
		multipart.bodyPart(payloadPart);

		if (filePart != null) {
			multipart.bodyPart(filePart);
		}

		// Creates the HTTP client object and makes the HTTP request to the
		// specified URL
		Client client = Client.create();
		WebResource webResource = client.resource(url);

		// Makes a multipart POST request with the multipart payload and
		// authenticity token
		ClientResponse clientResponse = webResource.header(TABLEAU_AUTH_HEADER, authToken)
				.type(MultiPartMediaTypes.createMixed()).post(ClientResponse.class, multipart);

		// Parses the response from the server into an XML string
		String responseXML = clientResponse.getEntity(String.class);

		m_logger.debug("Response: \n" + responseXML);

		// Returns the unmarshalled XML response
		return unmarshalResponse(responseXML);
	}

	/**
	 * Creates a PUT request using the specified URL with the specified payload.
	 *
	 * @param url            the URL to send the request to
	 * @param authToken      the authentication token to use for this request
	 * @param requestPayload the payload to send with the request
	 * @return the response from the request
	 */
	private TsResponse put(String url, String authToken, TsRequest requestPayload) {
		// Creates an instance of StringWriter to hold the XML for the request
		StringWriter writer = new StringWriter();

		// Marshals the TsRequest object into XML format if it is not null
		if (requestPayload != null) {
			try {
				s_jaxbMarshaller.marshal(requestPayload, writer);
			} catch (JAXBException ex) {
				m_logger.error("There was a problem marshalling the payload");
			}
		}

		// Converts the XML into a string
		String payload = writer.toString();

		m_logger.debug("Input payload: \n" + payload);

		// Creates the HTTP client object and makes the HTTP request to the
		// specified URL
		Client client = Client.create();
		WebResource webResource = client.resource(url);

		// Makes a PUT request with the payload and credential
		ClientResponse clientResponse = webResource.header(TABLEAU_AUTH_HEADER, authToken).type(MediaType.TEXT_XML_TYPE)
				.put(ClientResponse.class, payload);

		// Parses the response from the server into an XML string
		String responseXML = clientResponse.getEntity(String.class);

		m_logger.debug("Response: \n" + responseXML);

		// Returns the unmarshalled XML response
		return unmarshalResponse(responseXML);
	}

	/**
	 * Creates a multipart PUT request using the specified URL with the specified
	 * payload.
	 *
	 * @param url            the URL to send the request to
	 * @param authToken      the authentication token to use for this request
	 * @param requestPayload the payload to send with the request
	 * @param file           the file to send with the request
	 * @return the response from the request
	 */
	private TsResponse putMultipart(String url, String authToken, TsRequest requestPayload, BodyPart filePart) {
		// Creates an instance of StringWriter to hold the XML for the request
		StringWriter writer = new StringWriter();

		// Marshals the TsRequest object into XML format if it is not null
		if (requestPayload != null) {
			try {
				s_jaxbMarshaller.marshal(requestPayload, writer);
			} catch (JAXBException ex) {
				m_logger.error("There was a problem marshalling the payload");
			}
		}

		// Converts the XML into a string
		String payload = writer.toString();

		m_logger.debug("Input payload: \n" + payload);

		// Creates the XML request payload portion of the multipart request
		BodyPart payloadPart = new FormDataBodyPart(TABLEAU_PAYLOAD_NAME, payload);

		// Creates the multipart object and adds the file portion of the
		// multipart request to it
		MultiPart multipart = new MultiPart();
		multipart.bodyPart(payloadPart);

		if (filePart != null) {
			multipart.bodyPart(filePart);
		}

		// Creates the HTTP client object and makes the HTTP request to the
		// specified URL
		Client client = Client.create();
		WebResource webResource = client.resource(url);

		// Makes a multipart POST request with the multipart payload and
		// authenticity token
		ClientResponse clientResponse = webResource.header(TABLEAU_AUTH_HEADER, authToken)
				.type(MultiPartMediaTypes.createMixed()).put(ClientResponse.class, multipart);

		// Parses the response from the server into an XML string
		String responseXML = clientResponse.getEntity(String.class);

		m_logger.debug("Response: \n" + responseXML);

		// Returns the unmarshalled XML response
		return unmarshalResponse(responseXML);
	}

	/**
	 * Return the unmarshalled XML result, or an empty TsResponse if it can't be
	 * unmarshalled.
	 *
	 * @param responseXML the XML string from the response
	 * @return the TsResponse of unmarshalled input
	 */
	private TsResponse unmarshalResponse(String responseXML) {
		TsResponse tsResponse = m_objectFactory.createTsResponse();
		try {
			// Creates a StringReader instance to store the response and then
			// unmarshals the response into a TsResponse object
			StringReader reader = new StringReader(responseXML);
			tsResponse = s_jaxbUnmarshaller.unmarshal(new StreamSource(reader), TsResponse.class).getValue();
		} catch (JAXBException e) {
			m_logger.error("Failed to parse response from server due to:");
			m_logger.error(e.getMessage());
		}

		return tsResponse;
	}

	// ExcelDownload------------------------------------------------------------------test
	public String getReport(TableauCredentialsType authToken) {
		// Creates the HTTP client object and makes the HTTP request to the
		// specified URL
		Client client = Client.create();
		WebResource webResource = client
				.resource("http://203.234.230.66:8000/views/_test2/sido_1?:embed=yes&:from_wg=true");

		Cookie cookie = new Cookie("workgroup_session_id", authToken.getToken());
		// Sets the header and makes a GET request
		ClientResponse clientResponse = webResource.cookie(cookie).get(ClientResponse.class);

		// Parses the response from the server into an XML string
		String responseHtml = clientResponse.getEntity(String.class);

		Pattern pattern = Pattern.compile("<textarea id=\"tsConfigContainer\">(.*)</textarea>");

		Matcher match = pattern.matcher(responseHtml);

		String tsConfigContainer = null;

		if (match.find()) { // tsConfigContainer 태그를 찾았다면..
			tsConfigContainer = match.group(0);
		}
		m_logger.info("Response: \n" + tsConfigContainer);

		return tsConfigContainer;
	}

	/// api/api-version/sites/site-id/views/view-id/pdf
	/// api/api-version/sites/site-id/workbooks/workbook-id/views/view-id/previewImage
	public String getPdf(TableauCredentialsType authToken, String siteId, String workbookId, String viewId) {

		Client client = Client.create();
		// WebResource webResource =
		// client.resource("http://52.231.76.61:8000/api/2.4/sites/" + siteId +
		// "/views/" + viewId + "/pdf");
		WebResource webResource = client.resource("http://52.231.76.61:8000/api/2.4/sites/" + siteId + "/workbooks/"
				+ workbookId + "/views/" + viewId + "/previewImage");
		ClientResponse clientResponse = webResource.header(TABLEAU_AUTH_HEADER, authToken)
				.type(MediaType.APPLICATION_OCTET_STREAM).get(ClientResponse.class);

		String responseXML = clientResponse.getEntity(String.class);
		// Cookie cookie=new Cookie("workgroup_session_id",
		// authToken.getToken());
		// Sets the header and makes a GET request
		// ClientResponse clientResponse =
		// webResource.cookie(cookie).get(ClientResponse.class);

		// Parses the response from the server into an XML string
		// TsResponse response = clientResponse.getEntity(TsResponse.class);

		//
		// "http://MY-SERVER/api/2.8/sites/1edc53ac-e247-4870-9fd3-6fad0ce5f84d/views/2474164d-8d37-4a4c-abc7-c2070fd25fd5/pdf"
		// -X GET -H "X-Tableau-Auth:12ab34cd56ef78ab90cd12ef34ab56cd"
		return responseXML;
	}

	public Map<String, String> invokeServerInfo(TableauCredentialsType credential) throws Exception {

		Map<String, String> ret = new HashMap<String, String>();

		String url = Operation.SERVER_INFO.getUrl();

		Client client = Client.create();
		WebResource webResource = client.resource(url);

		// Sets the header and makes a GET request
		ClientResponse clientResponse = webResource.header(TABLEAU_AUTH_HEADER, credential.getToken())
				.get(ClientResponse.class);

		// Parses the response from the server into an XML string
		String responseXML = clientResponse.getEntity(String.class);

		// 파싱
		Document doc = parseXML(responseXML);

		// product version
		NodeList pv = doc.getElementsByTagName("productVersion");
		// rest api version
		NodeList rav = doc.getElementsByTagName("restApiVersion");

		// product version 소수점 한자리까지만 관리.
		// ex) 2019.2.0 -> 2019.2

		String productVersion = pv.item(0).getTextContent();
		if (productVersion != null && !"".equals(productVersion)) {
			String[] splittedProductVersion = productVersion.split("\\.");

			if (splittedProductVersion != null && splittedProductVersion.length >= 1) {
				productVersion = splittedProductVersion[0] + "." + splittedProductVersion[1];
			}
		}

		ret.put("restApiVersion", rav.item(0).getTextContent());
		// ret.put("productVersion", pv.item(0).getTextContent());
		ret.put("productVersion", productVersion);

		m_logger.info("Response: \n" + responseXML);

		return ret;
	}

	private Document parseXML(String xml) throws Exception {

		Document doc = null;
		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();

			doc = dBuilder.parse(new ByteArrayInputStream(xml.getBytes()));
			doc.getDocumentElement().normalize();

		} catch (Exception ex) {
			throw ex;
		}

		return doc;
	}

	public TableauCredentialsType invokeSwitchSite(TableauCredentialsType credentials, String contentUrl) {

		m_logger.info("Switch Tableau Server Site");

		String url = Operation.SWITCH_SITE.getUrl();

		// Creates the payload required to authenticate to server
		TsRequest payload = createPayloadForSwtichSite(contentUrl);

		// Makes a POST request with no credential
		TsResponse response = post(url, credentials.getToken(), payload);

		// Verifies that the response has a credentials element
		if (response.getCredentials() != null) {
			m_logger.info("Switch Tableau Server Site is successful!");

			return response.getCredentials();
		}

		// No credential were received
		return null;
	}

	private TsRequest createPayloadForSwtichSite(String contentUrl) {
		// Creates the parent tsRequest element
		TsRequest requestPayload = m_objectFactory.createTsRequest();

		// Creates the credentials element and site element
		SiteType site = m_objectFactory.createSiteType();

		// Sets the content URL of the site to sign in to
		site.setContentUrl(contentUrl);

		// Adds the credential element to the request payload
		requestPayload.setSite(site);

		return requestPayload;
	}

	public File invokeQueryViewImage(TableauCredentialsType credentials, String siteId, String viewId, String parameter)
			throws Exception {
		if (viewId == null || "".equals(viewId)) {
			return null;
		}

		String url = Operation.QUERY_VIEW_IMAGE.getUrl(siteId, viewId);

		if (parameter != null && !"".equals(parameter)) {
			url = url + "?vf_" + URLEncoder.encode(parameter, CHARSET);
		}

		Client client = Client.create();
		WebResource webResource = client.resource(url);

		// Sets the header and makes a GET request
		ClientResponse clientResponse = webResource.header(TABLEAU_AUTH_HEADER, credentials.getToken())
				.get(ClientResponse.class);
		File image = clientResponse.getEntity(File.class);

		return image;
	}

	public File invokeQueryViewPreviewImage(TableauCredentialsType credentials, String siteId, String workbookId,
			String viewId) throws Exception {

		String url = Operation.QUERY_VIEW_PREVIEW_IMAGE.getUrl(siteId, workbookId, viewId);

		Client client = Client.create();
		WebResource webResource = client.resource(url);

		ClientResponse clientResponse = webResource.header(TABLEAU_AUTH_HEADER, credentials.getToken())
				.get(ClientResponse.class);
		File image = clientResponse.getEntity(File.class);

		return image;
	}
}
