package com.sk.dlsp.model;

public class PdeVo extends CommonVo{

	private int sn;  //서약서 순번 또는 버전
	private String cn;  //서약서 내용
	
 
	public int getSn() {
		return sn;
	}
	public void setSn(int sn) {
		this.sn = sn;
	}
	public String getCn() {
		return cn;
	}
	public void setCn(String cn) {
		this.cn = cn;
	}
 
	
	 

}
