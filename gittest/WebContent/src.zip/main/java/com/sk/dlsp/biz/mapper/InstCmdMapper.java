package com.sk.dlsp.biz.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.sk.dlsp.model.InstCmdVo;

@Mapper
public interface InstCmdMapper {

	public List<InstCmdVo> getInstCmdList(Map<String,String> param);

	public InstCmdVo getInstCmdDetail(int sn);

	public int insertInstCmd(InstCmdVo instCmdVo);

	public int updateInstCmd(InstCmdVo instCmdVo);

	public int deleteInstCmd(int[] instIds);

	public int deleteInstCmdPer(InstCmdVo instCmdVo);
	
}
