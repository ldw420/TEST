package com.sk.dlsp.model;

public class AnalsVo {
	private String userId;
	private String instanceNm;

	private String sn;

	// 인스턴스 타입
	private String vCpu;
	private String memory;
	private String price;
	private String instTy;
	private String portalInstNm;

	// 데이터셋
	private String copm;
	private String indsgrp;
	private String tabNm;
	private String koreanNm;
	private String attr;
	private String s3BktAddr;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getInstanceNm() {
		return instanceNm;
	}
	public void setInstanceNm(String instanceNm) {
		this.instanceNm = instanceNm;
	}
	public String getSn() {
		return sn;
	}
	public void setSn(String sn) {
		this.sn = sn;
	}
	public String getvCpu() {
		return vCpu;
	}
	public void setvCpu(String vCpu) {
		this.vCpu = vCpu;
	}
	public String getMemory() {
		return memory;
	}
	public void setMemory(String memory) {
		this.memory = memory;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getInstTy() {
		return instTy;
	}
	public void setInstTy(String instTy) {
		this.instTy = instTy;
	}
	public String getPortalInstNm() {
		return portalInstNm;
	}
	public void setPortalInstNm(String portalInstNm) {
		this.portalInstNm = portalInstNm;
	}
	public String getCopm() {
		return copm;
	}
	public void setCopm(String copm) {
		this.copm = copm;
	}
	public String getIndsgrp() {
		return indsgrp;
	}
	public void setIndsgrp(String indsgrp) {
		this.indsgrp = indsgrp;
	}
	public String getTabNm() {
		return tabNm;
	}
	public void setTabNm(String tabNm) {
		this.tabNm = tabNm;
	}
	public String getKoreanNm() {
		return koreanNm;
	}
	public void setKoreanNm(String koreanNm) {
		this.koreanNm = koreanNm;
	}
	public String getAttr() {
		return attr;
	}
	public void setAttr(String attr) {
		this.attr = attr;
	}
	public String getS3BktAddr() {
		return s3BktAddr;
	}
	public void setS3BktAddr(String s3BktAddr) {
		this.s3BktAddr = s3BktAddr;
	}
}