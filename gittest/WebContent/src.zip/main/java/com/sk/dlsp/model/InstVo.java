package com.sk.dlsp.model;

public class InstVo extends CommonVo{
	private int sn;
	private String instTy;
	private String instCl;
	private String vcpu;
	private String gpu;
	private String memory;
	private String gpumemory;
	private String nwPrfm;
	private String price;
	private String portalUseAt;
	private String portalInstNm;
	private String useAt;

	public int getSn() {
		return sn;
	}
	public void setSn(int sn) {
		this.sn = sn;
	}
	public String getInstTy() {
		return instTy;
	}
	public void setInstTy(String instTy) {
		this.instTy = instTy;
	}
	public String getInstCl() {
		return instCl;
	}
	public void setInstCl(String instCl) {
		this.instCl = instCl;
	}
	public String getVcpu() {
		return vcpu;
	}
	public void setVcpu(String vcpu) {
		this.vcpu = vcpu;
	}
	public String getGpu() {
		return gpu;
	}
	public void setGpu(String gpu) {
		this.gpu = gpu;
	}
	public String getMemory() {
		return memory;
	}
	public void setMemory(String memory) {
		this.memory = memory;
	}
	public String getGpumemory() {
		return gpumemory;
	}
	public void setGpumemory(String gpumemory) {
		this.gpumemory = gpumemory;
	}
	public String getNwPrfm() {
		return nwPrfm;
	}
	public void setNwPrfm(String nwPrfm) {
		this.nwPrfm = nwPrfm;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getPortalUseAt() {
		return portalUseAt;
	}
	public void setPortalUseAt(String portalUseAt) {
		this.portalUseAt = portalUseAt;
	}
	public String getPortalInstNm() {
		return portalInstNm;
	}
	public void setPortalInstNm(String portalInstNm) {
		this.portalInstNm = portalInstNm;
	}
	public String getUseAt() {
		return useAt;
	}
	public void setUseAt(String useAt) {
		this.useAt = useAt;
	}


}
