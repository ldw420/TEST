package com.sk.dlsp.model;

public class DcVo extends CommonVo{

	//
	private String classKey;
	private String classTitle;
	private String classTitleName;
	private String abbrName;
	private String classLevel;
	private String upClassKey;
	private String upClassTitle;
	private String subject_area;
	private String bizMeta;
	private String classTypeCode;
	private String classTypeName;
	private String createDt;
	private String modifyDt;
	private String cmpCompanyCode;
	private String cmpCompanyCodeNm;
	//
	private String displayOrder;
	private String classTitlePath;
	private String upClassLevel;
	private String pathFirst;
	private String pathSecond;
	private String pathThird;
	private String displayFirst;
	private String displaySecond;
	private String displayThird;
	
	private String rdcnt;    //조회수
	private String applyCnt; //신청건수 (DB저장시점 +1 증가)
	private String docId; //스크랩
	private String shareYn; //공유여부
	//
	public String getClassKey() {
		return classKey;
	}
	public void setClassKey(String classKey) {
		this.classKey = classKey;
	}
	public String getClassTitle() {
		return classTitle;
	}
	public void setClassTitle(String classTitle) {
		this.classTitle = classTitle;
	}
	
	public String getClassTitleName() {
		return classTitleName;
	}
	public void setClassTitleName(String classTitleName) {
		this.classTitleName = classTitleName;
	}
	public String getAbbrName() {
		return abbrName;
	}
	public void setAbbrName(String abbrName) {
		this.abbrName = abbrName;
	}
	public String getClassLevel() {
		return classLevel;
	}
	public void setClassLevel(String classLevel) {
		this.classLevel = classLevel;
	}
	public String getUpClassKey() {
		return upClassKey;
	}
	public void setUpClassKey(String upClassKey) {
		this.upClassKey = upClassKey;
	}
	public String getUpClassTitle() {
		return upClassTitle;
	}
	public void setUpClassTitle(String upClassTitle) {
		this.upClassTitle = upClassTitle;
	}
	public String getSubject_area() {
		return subject_area;
	}
	public void setSubject_area(String subject_area) {
		this.subject_area = subject_area;
	}
	public String getBizMeta() {
		return bizMeta;
	}
	public void setBizMeta(String bizMeta) {
		this.bizMeta = bizMeta;
	}
	public String getClassTypeCode() {
		return classTypeCode;
	}
	public void setClassTypeCode(String classTypeCode) {
		this.classTypeCode = classTypeCode;
	}
	public String getClassTypeName() {
		return classTypeName;
	}
	public void setClassTypeName(String classTypeName) {
		this.classTypeName = classTypeName;
	}
	public String getCreateDt() {
		return createDt;
	}
	public void setCreateDt(String createDt) {
		this.createDt = createDt;
	}
	public String getModifyDt() {
		return modifyDt;
	}
	public void setModifyDt(String modifyDt) {
		this.modifyDt = modifyDt;
	}
	public String getCmpCompanyCode() {
		return cmpCompanyCode;
	}
	public void setCmpCompanyCode(String cmpCompanyCode) {
		this.cmpCompanyCode = cmpCompanyCode;
	}
	public String getCmpCompanyCodeNm() {
		return cmpCompanyCodeNm;
	}
	public void setCmpCompanyCodeNm(String cmpCompanyCodeNm) {
		this.cmpCompanyCodeNm = cmpCompanyCodeNm;
	}
	public String getDisplayOrder() {
		return displayOrder;
	}
	public void setDisplayOrder(String displayOrder) {
		this.displayOrder = displayOrder;
	}
	public String getClassTitlePath() {
		return classTitlePath;
	}
	public void setClassTitlePath(String classTitlePath) {
		this.classTitlePath = classTitlePath;
	}
	public String getUpClassLevel() {
		return upClassLevel;
	}
	public void setUpClassLevel(String upClassLevel) {
		this.upClassLevel = upClassLevel;
	}
	public String getPathFirst() {
		return pathFirst;
	}
	public void setPathFirst(String pathFirst) {
		this.pathFirst = pathFirst;
	}
	public String getPathSecond() {
		return pathSecond;
	}
	public void setPathSecond(String pathSecond) {
		this.pathSecond = pathSecond;
	}
	public String getPathThird() {
		return pathThird;
	}
	public void setPathThird(String pathThird) {
		this.pathThird = pathThird;
	}
	public String getDisplayFirst() {
		return displayFirst;
	}
	public void setDisplayFirst(String displayFirst) {
		this.displayFirst = displayFirst;
	}
	public String getDisplaySecond() {
		return displaySecond;
	}
	public void setDisplaySecond(String displaySecond) {
		this.displaySecond = displaySecond;
	}
	public String getDisplayThird() {
		return displayThird;
	}
	public void setDisplayThird(String displayThird) {
		this.displayThird = displayThird;
	}
	public String getRdcnt() {
		return rdcnt;
	}
	public void setRdcnt(String rdcnt) {
		this.rdcnt = rdcnt;
	}
	public String getApplyCnt() {
		return applyCnt;
	}
	public void setApplyCnt(String applyCnt) {
		this.applyCnt = applyCnt;
	}
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public String getShareYn() {
		return shareYn;
	}
	public void setShareYn(String shareYn) {
		this.shareYn = shareYn;
	}
	
	
	
	
	
	
	
}
