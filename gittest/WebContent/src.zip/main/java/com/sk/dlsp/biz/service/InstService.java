package com.sk.dlsp.biz.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sk.dlsp.biz.mapper.InstMapper;
import com.sk.dlsp.model.InstVo;

@Service
@Transactional
public class InstService {
    @Autowired InstMapper instMapper;

	public List<InstVo> getInstList(Map<String,String> param){
		return instMapper.getInstList(param);
	}

	public InstVo getInstDetail(int sn) {
		return instMapper.getInstDetail(sn);
	}

	public int insertInst(InstVo instVo) {
		return instMapper.insertInst(instVo);
	}

	public int updateInst(InstVo instVo) {
		return instMapper.updateInst(instVo);
	}

	public int deleteInst(int[] instIds) {
		return instMapper.deleteInst(instIds);
	}
}
