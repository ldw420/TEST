package com.sk.dlsp.biz.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.sk.dlsp.model.MetaDataCopmVo;
import com.sk.dlsp.model.MetaDataVo;

@Mapper
public interface GovMetaMapper {

	int deleteMetaData();

	int deleteMetaDataCopm();

	int insertMetaDataCopm(List<MetaDataCopmVo> list);

	int insertMetaData(List<MetaDataVo> list);
}
