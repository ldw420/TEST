package com.sk.dlsp.biz.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sk.dlsp.biz.mapper.WordMapper;
import com.sk.dlsp.model.WordVo;

@Service
@Transactional
public class WordService {
    @Autowired WordMapper wordMapper;

	public List<WordVo> getWordList(Map<String,String> param){
		return wordMapper.getWordList(param);
	}
	
	public List<WordVo> getWordDetail(WordVo wordVo){
		return wordMapper.getWordDetail(wordVo);
	}

	public int insertWord(WordVo wordVo) {
		return wordMapper.insertWord(wordVo);
	}

	public int deleteWord(int[] wordIds) {
		return wordMapper.deleteWord(wordIds);
	}


}
