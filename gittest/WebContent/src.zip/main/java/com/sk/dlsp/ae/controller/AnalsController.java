package com.sk.dlsp.ae.controller;

import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Base64.Encoder;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicSessionCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3URI;
import com.amazonaws.services.sagemaker.AmazonSageMaker;
import com.amazonaws.services.sagemaker.AmazonSageMakerClientBuilder;
import com.amazonaws.services.sagemaker.model.AmazonSageMakerException;
import com.amazonaws.services.sagemaker.model.CreateNotebookInstanceLifecycleConfigRequest;
import com.amazonaws.services.sagemaker.model.CreateNotebookInstanceLifecycleConfigResult;
import com.amazonaws.services.sagemaker.model.CreateNotebookInstanceRequest;
import com.amazonaws.services.sagemaker.model.CreateNotebookInstanceResult;
import com.amazonaws.services.sagemaker.model.CreatePresignedNotebookInstanceUrlRequest;
import com.amazonaws.services.sagemaker.model.DeleteNotebookInstanceLifecycleConfigRequest;
import com.amazonaws.services.sagemaker.model.DeleteNotebookInstanceRequest;
import com.amazonaws.services.sagemaker.model.DescribeNotebookInstanceRequest;
import com.amazonaws.services.sagemaker.model.DescribeNotebookInstanceResult;
import com.amazonaws.services.sagemaker.model.ListNotebookInstanceLifecycleConfigsRequest;
import com.amazonaws.services.sagemaker.model.ListNotebookInstancesRequest;
import com.amazonaws.services.sagemaker.model.ListTagsRequest;
import com.amazonaws.services.sagemaker.model.ListTagsResult;
import com.amazonaws.services.sagemaker.model.NotebookInstanceSummary;
import com.amazonaws.services.sagemaker.model.StartNotebookInstanceRequest;
import com.amazonaws.services.sagemaker.model.StopNotebookInstanceRequest;
import com.amazonaws.services.sagemaker.model.Tag;
import com.amazonaws.services.sagemaker.model.UpdateNotebookInstanceRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sk.dlsp.ae.service.AnalsService;
import com.sk.dlsp.biz.service.InstCmdService;
import com.sk.dlsp.biz.service.UserService;
import com.sk.dlsp.common.consts.CommonConstants;
import com.sk.dlsp.common.exception.BizException;
import com.sk.dlsp.common.util.SessionUtil;
import com.sk.dlsp.common.util.StringUtil;
import com.sk.dlsp.dc.service.DcApiService;
import com.sk.dlsp.model.AnalsVo;
import com.sk.dlsp.model.InstCmdVo;
import com.sk.dlsp.model.InstInfoVo;
import com.sk.dlsp.model.ResponseDto;
import com.sk.dlsp.model.UserInfo;
import com.sk.dlsp.model.UserVo;

@RestController
@Component 
@RequestMapping(CommonConstants.API_PREFIX )
public class AnalsController {
	
	// 실제 운영시는 이것을 false 로 수정바람
	static final boolean _is_session_user_set = true;
	
	static Logger _log = LoggerFactory.getLogger( AnalsController.class.getName());  
	
	// GDI / SAML 정식 공유 전에 DB 에서 정보 읽어 와서 처리하는 것으로 임시 처리
	@Autowired UserService userService;
	
	@Autowired AnalsService analsService;

	@Autowired InstCmdService instCmdService;
	
	//추가 20191024, by pkh 
	//수정 20191029, by pkh
	@Value("${prop.server.govMetaApi.datasetlist-table-info.url}") String tableListUrl;
	@Autowired DcApiService dcApiService;
	
	static final Regions _clientRegion = Regions.AP_NORTHEAST_2;

	//	static final AWSCredentials awsCreds2 = new BasicAWSCredentials("AKIA2VLTTOQT7WC2F2DH", "/zN1fOCEoFAZBSqBqlaRy1Q0Obs7U5IRJL8CiGOp");	// youthlazy1
	// saml 처리되면 삭제해야 하는 부분임
	//	static final AWSCredentials awsCreds = new BasicAWSCredentials("AKIA37VP3AHDICW5CH5X", "ZUi7/fFEzoKpSSnei9CfYljCf+9Nrf8JvIuVpxNd");	// skcc00000sysd02000
	
    // Sagemaker 생성시 필요한 Args. 
	String _aws_rolearn = "arn:aws:iam::615568422424:role/DL-SageMaker-Analy-S3-rw-role";
	String _aws_subnetid = "subnet-0cb078a08da09e413";
	String _aws_useruser = "ec2-user";
	String _aws_securitygroup = "sg-0cec4ef3d440f6ab5";
	String _aws_tag_company_nm = "company";
	String _aws_tag_company_value = "SKCC_HP";

	String _aws_tag_creater = "creator";
	
	final String _aws_tag_resource_key = "dlpowner";
	
	// UservVO 에서 수집
	String dev_aws_rolearnManage = "arn:aws:iam::615568422424:role/DL-IAM-ExternalPortalGen-SageMakerS3-rw-role"; // SAML 변경 예정. test 용
	String dev_aws_roleSessionManage    = "DL-IAM-ExternalPortalGen-SageMakerS3-rw-role"; // SAML 변경 예정. test 용

	String dev_aws_rolearnRun = "arn:aws:iam::615568422424:role/DL-SageMaker-Analy-S3-rw-role"; // SAML 변경 예정. test 용
	String dev_aws_roleSessionRun    = "DL-SageMaker-Analy-S3-rw-role"; // SAML 변경 예정. test 용

	String dev_aws_tag_company_value = "SKCC_HP";
	String dev_aws_accesskeyid = "AKIA37VP3AHDICW5CH5X";
	String dev_aws_secretAccessKey = "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";
	String dev_aws_userid = "youthlazy";
	String dev_aws_subnetid = "subnet-0cb078a08da09e413";
	String dev_aws_securitygroup = "sg-0cec4ef3d440f6ab5";

	final String _admin_user_id = "admin@sk.com";	
	
	// AWS 성능 문제로 sagemaker instance 별 dataset 수 count 가져 오는 것 여부 설정
	// 문제가 생기면 false 로 수정해야 함
	final boolean _check_user_data_count = true;
	
	// Tag 에 사용자별로 instance 가져 오는 것 여부 설정.
	// false면 admin@sk.com 으로 해서, 전체를 가져옴.
	// sessionutil 정보랑 맞물림
	final boolean _check_user_tag = true;
	///////////////////////////////////////////////////////////
	
	final int _aws_list_max_ = 50;

    String _err_msg = "";
    
    // tag 불로 오는데, 하도 에러가 많아서, hash에 정보 저장함.
    static Hashtable<String, List<Tag>> _aws_user_tags = new Hashtable<String, List<Tag>> ();
    
    static Hashtable<String, InstCmdVo> _user_instance_owner = new Hashtable<String, InstCmdVo> ();
    
    // db 데이터셋 건수 읽오 오는데, 하도 에러가 많아서, hash 에 정보 저장함.
    
    static Hashtable<String, Integer> _aws_user_datacount = new Hashtable<String, Integer> ();
    

    // 사용자별 data set count 를 static hash 에 저장하기 위함.
    // DB 호출 최소화를 위해서 ...
    // WAS memory 를 사용함 : was tuning 필요.
    private void reset_user_data_count ( ) {
    	
        // instance 별로 dataset 건수를 가지고 있음.
        // 전체를 한번에 읽어 오도록 하기 위함. --> AWS API 호출 건수 문제로 인해 ... 
        AnalsVo analsVo = new AnalsVo();
        List<InstInfoVo> instInfos = analsService.instInfoList(analsVo);
        
        if ( instInfos != null ) {
        	for ( InstInfoVo info1 : instInfos) {
        		// hinstinfo.put ( info1.getInstanceName(), info1.getCntDataset());
        		_aws_user_datacount.put ( info1.getInstanceName(), info1.getCntDataset());
        	}
        }
    	
    }
    
    private void set_instance_owner () {
    	
    	HashMap<String,String> param = new HashMap<String,String> (); 
    	List<InstCmdVo> instances = instCmdService.getInstCmdList( param);
    	
    	if ( instances != null ) {
	    	for ( InstCmdVo inst : instances ) {
	    		_user_instance_owner.put( inst.getInstanceName(), inst ); 
	    	}
    	}
    }
    
    private String get_instance_owner ( String instancename ) {
    	
    	if ( _user_instance_owner.containsKey(instancename)) {
    		InstCmdVo inst = _user_instance_owner.get(instancename);
    		return inst.getUsrId();
    	}
    	else return null;
    	
    }

    private void del_instance_owner( String instancename ) {
    	
    	_user_instance_owner.remove( instancename );
    }
    
    
	private AmazonSageMaker getSageMaker (UserVo user) throws Exception, AmazonSageMakerException {
		AmazonSageMaker smClient = null;
		
		String accessKeyId;
		String secretAccessKey;
		String sessionToken;
		

	    int _err_step = 0;
	    int _err_substep = 0;
	    int _err_loop_cnt = 0;
	    
		_err_substep = 1;
		accessKeyId = user.getAccessKeyId();
		secretAccessKey = user.getSecretAccessKey();
		sessionToken = user.getSessionToken();

		_err_msg = " accessKeyId = " + accessKeyId + "\n secretAccessKey = " + secretAccessKey + "\n sessionToken = " + sessionToken + "\n";
		
		_err_substep = 2;
		BasicSessionCredentials sageMakerCreds = new BasicSessionCredentials(
				accessKeyId,
				secretAccessKey,
				sessionToken);

		_err_substep = 3;
		smClient = AmazonSageMakerClientBuilder.standard()
				.withCredentials(new AWSStaticCredentialsProvider(sageMakerCreds))
				.withRegion(_clientRegion)
				.build();			
		
		_err_substep = 4;
		
		return smClient;
	}
	
	
	@SuppressWarnings("unchecked")
	private UserVo getUser ( HttpServletRequest request, HttpServletResponse response ) {
		
		UserVo user = null;
		
		String workingid = "";
		
		try {	

			UserInfo userInfo = SessionUtil.getUserInfo();

			if ( ! _check_user_tag ) workingid = _admin_user_id;
			else {
			 
				if ( userInfo == null ) {
					// db 에 login 정보 없음. return 해야 함.
					_log.error ( "!!!! UserInfo NULL " );
					return null;
				}
				
				workingid = userInfo.getUsrId();
			}
			
			// ID check 용도
			// 운영에서 이것은 열어야 함.
			user = userService.getUser( workingid );

			if ( user != null ) {
				// 개발용 code 임. userid 등 모두 정상처리되면 삭제 필요
				// 계정을 바꾸어 주어야 함. // hard coding 됨.
				// if (  _check_user_tag ) user.setUsrId( dev_aws_userid);
			}
			else {				
				// 개발 test : 강제로 user 를 설정함.
				// SAML 이 되면, 이것을 풀어야 함.
				if ( _check_user_tag ) {
					_log.error ( "!!!! userVo NULL " );
					return null;
				}
				else {
					user = new UserVo (); 
					user.setAccessKeyId( dev_aws_accesskeyid);
					user.setSecretAccessKey( dev_aws_secretAccessKey);
					user.setUsrId( dev_aws_userid);
					
					// tagging 값.
					user.setAgency(dev_aws_tag_company_value);
	
					user.setRoleIdManage(dev_aws_rolearnManage);
					user.setRoleArnManage(dev_aws_rolearnManage);
					user.setRoleSessionManage(dev_aws_roleSessionManage);
	
					user.setRoleIdRun(dev_aws_rolearnRun);
					user.setRoleArnRun(dev_aws_rolearnRun);
					user.setRoleSessionRun(dev_aws_rolearnRun);
					
					user.setSecurityGroup(dev_aws_securitygroup);
					user.setSubnetId(dev_aws_subnetid);
				}
			}
			
			// 핵심정보라서 .. session 에 넣지 말자는 의견입니다.
			// session.setAttribute( _session_user_key, user );
		}
		catch ( Exception e ) {
			_log.debug ( " user 설정 오류 : " + e );
		}

		return user;
		
	}	

/*
	@SuppressWarnings("unchecked")
	private AssumeRoleResult getAssumeRole( UserVo user, String roleGbn) {
		AssumeRoleRequest aReq = new AssumeRoleRequest();
		AssumeRoleResult aRes = new AssumeRoleResult();

		try {
			
			if ( user == null ) return null;

			AWSSecurityTokenService stsClient = AWSSecurityTokenServiceClientBuilder.standard()
	      		.withCredentials(new AWSStaticCredentialsProvider(awsCreds))
	            .withRegion(_clientRegion)
	            .build();

	        if("s".equals(roleGbn)) {
	        	aReq.setRoleArn(  "arn:aws:iam::615568422424:role/DL-IAM-ExternalPortalGen-SageMakerS3-rw-role");
	        	aReq.setRoleSessionName( "DL-IAM-ExternalPortalGen-SageMakerS3-rw-role");
	        } else {
		        aReq.setRoleArn( "arn:aws:iam::615568422424:role/DL-SageMaker-Analy-S3-rw-role");
		        aReq.setRoleSessionName( "DL-SageMaker-Analy-S3-rw-role");
	        }

	        aRes = stsClient.assumeRole(aReq);
	        
		} catch(Exception e) {
			e.printStackTrace();
		}

		return aRes;
	}
*/

/*
	@SuppressWarnings("unused")
	private Object getCredentials() {
		Object objRslt = null;

		try {
	        AWSSecurityTokenService stsClient = AWSSecurityTokenServiceClientBuilder.standard()
	      		.withCredentials(new AWSStaticCredentialsProvider(awsCreds2))
	            .withRegion(_clientRegion)
	            .build();

			GetSessionTokenRequest getSessionTokenRequest = new GetSessionTokenRequest().withDurationSeconds(7200);
			GetSessionTokenResult sessionTokenResult = stsClient.getSessionToken(getSessionTokenRequest);

	        Credentials sessionCredentials = sessionTokenResult
	                .getCredentials()
	                .withSessionToken(sessionTokenResult.getCredentials().getSessionToken())
	                .withExpiration(sessionTokenResult.getCredentials().getExpiration());

	        objRslt = new BasicSessionCredentials(sessionCredentials.getAccessKeyId(), sessionCredentials.getSecretAccessKey(), sessionCredentials.getSessionToken());
		} catch(Exception e) {
			e.printStackTrace();
		}

		return objRslt;
	}
*/

	@SuppressWarnings("unchecked")
	@GetMapping("/analsList")
	private void analsList(@RequestParam(value="notebookInstanceName") String notebookInstanceName, HttpServletRequest request, HttpServletResponse response) throws Exception {
		BasicSessionCredentials bsc = null;

        JSONObject jsonObject = null;
        JSONArray jsonArray = new JSONArray();

        ListNotebookInstancesRequest req = new ListNotebookInstancesRequest();
        ListNotebookInstanceLifecycleConfigsRequest listReq = new ListNotebookInstanceLifecycleConfigsRequest();
        DeleteNotebookInstanceLifecycleConfigRequest desReq = new DeleteNotebookInstanceLifecycleConfigRequest();
        
        

        int _err_step = 0;
        int _err_substep = 0;
        int _err_loop_cnt = 0;
        
		try {
			
			UserVo user;
			
			user = getUser ( request, response );
			
			_err_step = 1;
			
			/*
			 * 원래 코드
			Credentials cre = getAssumeRole( user, "s").getCredentials();
			bsc = new BasicSessionCredentials(cre.getAccessKeyId(), cre.getSecretAccessKey(), cre.getSessionToken());

	        AmazonSageMaker smClient = AmazonSageMakerClientBuilder.standard()
	        		.withCredentials(new AWSStaticCredentialsProvider(bsc))
	        		.withRegion(_clientRegion)
	        		.build();
			*/
			// 통합 코드
			AmazonSageMaker smClient = getSageMaker (user);
			
	        _err_step = 2;
	        
	        if ( smClient != null ) {
	        	
	        	_err_substep = 10;

	        	/*
		        for(NotebookInstanceLifecycleConfigSummary listRes : smClient.listNotebookInstanceLifecycleConfigs(listReq).getNotebookInstanceLifecycleConfigs()) {
		        	_log.debug ("##### NotebookInstanceLifecycleConfigName : "+listRes.getNotebookInstanceLifecycleConfigName());
		        }
		        */
	        	_err_substep = 11;

	        }
	        
	        _err_step = 3;
	        
	        boolean bowner = false;
	        String tmp1;

	        req.setMaxResults( _aws_list_max_ );
	        
	        set_instance_owner ();
	        
	        ///////////////////////////////////////////////////////////////////////////////
	        
	        _err_step = 4;
	        
	        _err_loop_cnt = 0;
	        
	        Hashtable<String, String> htmp_price = new Hashtable<String, String> (); 
	        
	        for (NotebookInstanceSummary objectSummary : smClient.listNotebookInstances(req).getNotebookInstances()) {
	        
	        	String instance_name = objectSummary.getNotebookInstanceName();
	        	
	        	_err_loop_cnt++;
	        	
	        	_err_substep = 0;
	        	
		        bowner = false;

		        String instance_owner = get_instance_owner( instance_name);
		        if ( user.getUsrId().equals(instance_owner)) bowner = true; 
		        else {

			        if ( instance_owner == null && _check_user_tag ) {
			        	
			        	List<Tag> tags;
			        		
				        ListTagsRequest listtagReq = new ListTagsRequest ();
				        	
				        listtagReq.setResourceArn( objectSummary.getNotebookInstanceArn());
		
					    ListTagsResult tagResults = smClient.listTags(listtagReq);
	
					    tags = tagResults.getTags();
					    
				        _log.debug ("##### tag result : " + user.getUsrId() + " - " + tags.toString());	        
			        	
				        tmp1 = "_";
				        for ( Tag tag : tags ) {
				        	if ( tag.getKey().equals(_aws_tag_creater)) {
				        		tmp1 = tag.getValue();
				        		if ( tmp1 != null && tmp1.equals(user.getUsrId())) {
				        			bowner = true;
				        			break;
				        		}
				        	}
				        }
				        
				        if ( ! objectSummary.getNotebookInstanceStatus().equals("Deleting")) {
				        	
					        InstCmdVo inst = new InstCmdVo ();
					        inst.setInstanceName( instance_name );
					        inst.setUsrId( tmp1);
					        inst.setCmdType("C");
							
					        // 이거는 DB 에 저장하기 전 instance 들 정보 입력하기 위함이다.
					        try {
					        	instCmdService.insertInstCmd(inst);
					        }
					        catch ( Exception e___) {
					        	
					        }
					        ////////////////////////////////////////////////////////////////////////
					        
					        _user_instance_owner.put( instance_name, inst);
				        }
				        
			        }

		        }
		        
		        _err_substep = 1;
		        //Data Steward 권한일때는 해당 관계사의 모든 인스턴스 보여준다.(박영철 수정)
		       // if (!user.getAuthId().equals("A0002")) {
	        	
			        if ( ! bowner && ! user.getUsrId().equals( _admin_user_id )) {
			        	continue;
			        }
		       // }
	        	
	        	jsonObject = new JSONObject();
		        
	        	_log.debug ("##### objectSummary : "+objectSummary);
	        	_log.debug ("##### NotebookInstanceName : "+objectSummary.getNotebookInstanceName());
	        	_log.debug ("##### NotebookInstanceArn : "+objectSummary.getNotebookInstanceArn());
	        	_log.debug ("##### NotebookInstanceStatus : "+objectSummary.getNotebookInstanceStatus());
	        	_log.debug ("##### Url : "+objectSummary.getUrl());
	        	_log.debug ("##### InstanceType : "+objectSummary.getInstanceType());
	        	_log.debug ("##### CreationTime : "+objectSummary.getCreationTime());
	        	_log.debug ("##### LastModifiedTime : "+objectSummary.getLastModifiedTime());

	        	jsonObject.put("notebookInstanceName", objectSummary.getNotebookInstanceName());
	        	jsonObject.put("notebookInstanceArn", objectSummary.getNotebookInstanceArn());
	        	jsonObject.put("notebookInstanceStatus", objectSummary.getNotebookInstanceStatus());
	        	jsonObject.put("url", objectSummary.getUrl());
	        	jsonObject.put("instanceType", objectSummary.getInstanceType());

	        	SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	        	transFormat.setTimeZone(TimeZone.getTimeZone("GMT+9"));
	        	
	        	String creationTime = transFormat.format(objectSummary.getCreationTime());

	        	jsonObject.put("creationTime", creationTime);

		        _err_substep = 2;

	        	if ( htmp_price.containsKey(objectSummary.getInstanceType())) {
	        		jsonObject.put("price", htmp_price.get(objectSummary.getInstanceType()));
	        	}
	        	else {
	        		tmp1 = analsService.aeInstInfo( objectSummary.getInstanceType() );
	        		htmp_price.put(objectSummary.getInstanceType(),tmp1); 
	        		jsonObject.put("price", tmp1);
	        	}
	        	
		        _err_substep = 3;
		        
		        // data count 에 관한 것이 없으면, 다시 채움.
    			if ( ! _aws_user_datacount.containsKey(instance_name)) {
    				reset_user_data_count ();
    			}	
        		
    			if ( _aws_user_datacount.containsKey(instance_name)) {
    				jsonObject.put("dataSetInfoCnt", _aws_user_datacount.get(instance_name));
        		}
        		else {
        			jsonObject.put("dataSetInfoCnt", 0);
        		}
	        		
		        _err_substep = 4;
		        
	        	jsonArray.add(jsonObject);
	        }

	        _err_step = 5;
	        
	        response.setContentType("application/json; charset=UTF-8");

	        PrintWriter out = response.getWriter();
	        
	        if ( jsonArray.size() > 0 ) out.print(jsonArray.toString());
	        else {
				jsonObject = new JSONObject();
				jsonObject.put("error", " no data ");
				jsonObject.put("status", "SUCC");
				out.print(jsonObject.toString());
	        }
	        out.flush();
	        out.close();
	        
	        // _err_step = 5;
	        
		} catch(Exception e) {
			
			try {
				jsonObject = new JSONObject();
				//jsonObject.put("error", " err : " + _err_step + ", loop_cnt = " + _err_loop_cnt + ", substep = " + _err_substep + "\n"  + _err_msg + "\n" + e.getMessage());
							
				jsonObject.put("error", "재로그인 후 사용 가능합니다.");			
				jsonObject.put("status", "ERROR");
	        	response.setContentType("application/json; charset=UTF-8");
		        PrintWriter out = response.getWriter();
		        out.print(jsonObject.toString());
		        out.flush();
		        out.close();
			}
			catch ( Exception e_error) {
				
			}
		}
	}

	@SuppressWarnings("unchecked")
	@RequestMapping("/getPreUrl")
	private void getPreUrl(@RequestParam(value="notebookInstanceName") String notebookInstanceName, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		
		JSONObject jsonObject = new JSONObject();
        JSONArray jsonArray = new JSONArray();

		
		BasicSessionCredentials bsc = null;
		CreatePresignedNotebookInstanceUrlRequest req = new CreatePresignedNotebookInstanceUrlRequest();

		try {
			
			UserVo user;
			
			user = getUser ( request, response );

			/*
			 * 원래 코드

			Credentials cre = getAssumeRole( user, "n").getCredentials();
			bsc = new BasicSessionCredentials(cre.getAccessKeyId(), cre.getSecretAccessKey(), cre.getSessionToken());
	        AmazonSageMaker smClient = AmazonSageMakerClientBuilder.standard()
	        		.withCredentials(new AWSStaticCredentialsProvider(bsc))
	        		.withRegion(_clientRegion)
	        		.build();
			 */
			// 통합 코드
			AmazonSageMaker smClient = getSageMaker (user);
	        
	        req.setNotebookInstanceName(notebookInstanceName);
	        req.setSessionExpirationDurationInSeconds(7200);

	        

//        	_log.info ("##### preUrl : "+smClient.createPresignedNotebookInstanceUrl(req).getAuthorizedUrl());

			jsonObject.put("preUrl", smClient.createPresignedNotebookInstanceUrl(req).getAuthorizedUrl());

			response.setContentType("application/json; charset=UTF-8");

			PrintWriter out = response.getWriter();
	        out.print(jsonObject.toString());
	        out.flush();
	        out.close();
		} catch(Exception e) {
			try {
				jsonObject = new JSONObject();
				jsonObject.put("error", e.getMessage());
				jsonObject.put("status", "ERROR");
	        	response.setContentType("application/json; charset=UTF-8");
		        PrintWriter out = response.getWriter();
		        out.print(jsonObject.toString());
		        out.flush();
		        out.close();
			}
			catch ( Exception e_error) {
				
			}

		}
	}

	@SuppressWarnings("unchecked")
	@GetMapping("/getAeInstInfoList")
	private void getAeInstInfoList(HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject jsonObject = null;
        JSONArray jsonArray = new JSONArray();

		try {
			
			UserVo user;
			
			user = getUser ( request, response );
						
			List<AnalsVo> aeInstInfoList = analsService.aeInstInfoList();

			if(aeInstInfoList.size() > 0) {
				for(AnalsVo str : aeInstInfoList) {
					jsonObject = new JSONObject();

					jsonObject.put("sn", str.getSn());
					jsonObject.put("instTy", str.getInstTy().substring(str.getInstTy().lastIndexOf(".")+1));
					jsonObject.put("portalInstNm", str.getPortalInstNm());
					jsonObject.put("instTyFull", str.getInstTy());
					jsonObject.put("vCpu", str.getvCpu());
					jsonObject.put("memory", str.getMemory());
					jsonObject.put("price", str.getPrice());

					jsonArray.add(jsonObject);
				}
			}

			response.setContentType("application/json; charset=UTF-8");

			PrintWriter out = response.getWriter();
	        out.print(jsonArray.toString());
	        out.flush();
	        out.close();
		} catch(Exception e) {
			try {
				jsonObject = new JSONObject();
				jsonObject.put("error", e.getMessage());
				jsonObject.put("status", "ERROR");
	        	response.setContentType("application/json; charset=UTF-8");
		        PrintWriter out = response.getWriter();
		        out.print(jsonObject.toString());
		        out.flush();
		        out.close();
			}
			catch ( Exception e_error) {
				
			}
		}
	}

	@SuppressWarnings("unchecked")
	@RequestMapping("/analsRegist")
	private void analsRegist(@RequestParam(value="ins01") String ins01,
			@RequestParam(value="ins02") String ins02,
			@RequestParam(value="ins03") String ins03,
			@RequestParam(value="dtArr", required=false) String dtArr,
			@RequestParam(value="s3Arr", required=false) String s3Arr,
			HttpServletRequest request,
			HttpServletResponse response) throws Exception, AmazonSageMakerException {
		String contents = "";
		String lifeCycleNm = "";
		boolean chkName = false;
		
		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArray = new JSONArray();

		BasicSessionCredentials bsc = null;
		CreateNotebookInstanceRequest req = new CreateNotebookInstanceRequest();
		ListNotebookInstancesRequest listReq = new ListNotebookInstancesRequest();
		CreateNotebookInstanceLifecycleConfigRequest lifeReq = new CreateNotebookInstanceLifecycleConfigRequest();
		CreateNotebookInstanceLifecycleConfigResult lifeRes = new CreateNotebookInstanceLifecycleConfigResult();
		
		try {
			
			UserVo user;
			
			user = getUser ( request, response );
			req.setNotebookInstanceName(ins01);
	        req.setInstanceType(ins02);
	        req.setVolumeSizeInGB(Integer.parseInt(ins03));

/* 없어질 부분	        
//	        req.setRoleArn("arn:aws:iam::823928750534:role/service-role/AmazonSageMaker-Executionrole-20190712T144746");
//	        req.setRoleArn(getAssumeRole( user, "n").getAssumedRoleUser().getArn());
//	        req.setDirectInternetAccess("vpc-09d23a06e12dc959b");
*/
	        // AWS sagemaker param 설정
	        // req.setRoleArn(  user.getRoleArnRun()); // _aws_rolearn );
	        // req.setSubnetId( user.getSubnetId()); // _aws_subnetid);
	        req.setRoleArn ( _aws_rolearn );
	        req.setSubnetId( _aws_subnetid);
	        List sgi = new ArrayList();
	        // sgi.add( user.getSecurityGroup()); // _aws_securitygroup );
	        sgi.add(  _aws_securitygroup );
	        req.setSecurityGroupIds(sgi);
	        
	        // TAG 설정 ...
	        List<Tag> tags = new ArrayList<Tag>();
	        Tag tag = new Tag ( );
	        tag.setKey  (_aws_tag_company_nm);
	        tag.setValue(  user.getAgencyNm()  );
	        tags.add( tag );
	        Tag tag_resource = new Tag ( );
	        tag_resource.setKey  (_aws_tag_resource_key);
	        tag_resource.setValue( user.getRoleArnRun() + "@" + user.getUsrId()); // _aws_rolearn + "youthlazy"     
	        tags.add( tag_resource );

	        Tag tag_creator = new Tag ( );
	        tag_creator.setKey  (_aws_tag_creater);
	        tag_creator.setValue( user.getUsrId()); // _aws_rolearn + "youthlazy"     
	        tags.add( tag_creator );
	        
	        ///////////////////////////////////////////////////////////
	        req.setTags (tags);

			// 삭제하자 ... tags = _aws_user_tags.put( ins01, tags );
			
	        
	        /*
	         * 원래 코드 
			Credentials cre = getAssumeRole( user, "n").getCredentials();
			bsc = new BasicSessionCredentials(cre.getAccessKeyId(), cre.getSecretAccessKey(), cre.getSessionToken());
	        AmazonSageMaker smClient = AmazonSageMakerClientBuilder.standard()
	        		.withCredentials(new AWSStaticCredentialsProvider(bsc))
	        		.withRegion(_clientRegion)
	        		.build();
	         */
			// 통합 코드
			AmazonSageMaker smClient = getSageMaker (user);
	        
	        // 노트북 인스턴스명 validation
	        for(NotebookInstanceSummary objectSummary : smClient.listNotebookInstances(listReq).getNotebookInstances()) {
	        	if(ins01.equals(objectSummary.getNotebookInstanceName())) {
	        		chkName = true;
	        	}
	        }

			if(!chkName) {
				 
					dtArr = dtArr.replaceAll("%3A%2F%2F", "://");
					dtArr = dtArr.replaceAll("%22", "\"");
					dtArr = dtArr.replaceAll("%5B", "[");
					dtArr = dtArr.replaceAll("%5D", "]");
					dtArr = dtArr.replaceAll("%2F", "/");
					dtArr = dtArr.replaceAll("&quot;", "\"");
					
					//dtArr = HtmlUtils.htmlUnescape(URLDecoder.decode(dtArr, "utf-8"));
					
					
					s3Arr = s3Arr.replaceAll("%3A%2F%2F", "://");
					s3Arr = s3Arr.replaceAll("%22", "\"");
					s3Arr = s3Arr.replaceAll("%5B", "[");
					s3Arr = s3Arr.replaceAll("%5D", "]");
					s3Arr = s3Arr.replaceAll("%2F", "/");
					s3Arr = s3Arr.replaceAll("&quot;", "\"");
					
					//s3Arr = HtmlUtils.htmlUnescape(URLDecoder.decode(s3Arr, "utf-8"));
					
					

				// 화면에서 넘어온 데이터셋 파싱
				JSONParser parser = new JSONParser();

				Object obj1 = parser.parse(dtArr);
				JSONArray jsonArray2 = (JSONArray) obj1;

				_log.debug(" dtArr = " + dtArr);
				_log.debug(" s3Arr = " + s3Arr);
				
				// 데이터셋 size 0 이상일 경우 S3 데이터셋 복제를 위한 수명 수기 SET
				if(jsonArray2.size() > 0) {
					
					
					String s3Addr = "";

					// 화면에서 넘어온 데이터셋 S3 버킷 주소 파싱
					Object obj2 = parser.parse(s3Arr);
					JSONArray jsonArray3 = (JSONArray) obj2;

					String basedir = "/home/" + _aws_useruser + "/SageMaker/";
					// 수명 주기 쉘 스크립트 작성
					contents = "#!/bin/bash" + "\n"
							+ "set -e" + "\n"
							+ "sudo -i -u " + _aws_useruser + " bash << EOF" + "\n"
							+ "cd " + basedir  + "\n"
							;

					StringBuffer contentSb = new StringBuffer(contents);
					
					// 파싱된 데이터셋 S3 버킷 주소 SET
					for(int i = 0; i < jsonArray3.size(); i++) {
												
						AmazonS3URI url = new AmazonS3URI ( jsonArray3.get(i).toString() );
						
						s3Addr += " sudo aws s3 sync "+ jsonArray3.get(i).toString() + " " + basedir + url.getKey().replace("/", "\\>") + "/ \n";
					}

					contents = contentSb.append(s3Addr).append("EOF").toString();
					
					
					// 완성된 쉘 스크립트 ex
					// 권한 문제로 sudo 붙입 (해당 권한 SK 확인중)
//					#!/bin/bash
//					set -e
//					sudo -i -u ec2-user bash << EOF
//					cd /home/ec2-user/SageMaker
//					sudo aws s3 sync s3://refined-skcchp-dat-p-skcchplake/hp_app_log/tgid=svc_hot3/work_dt=20190901/hour=06/ .
//					sudo aws s3 sync s3://refined-skcchp-dat-p-skcchplake/hp_app_log_memo/tgid=svc_hot5/work_dt=20190905/hour=06/ .
//					EOF

					_log.info ("##### contents : "+contents);

					// 수명 주기 쉘 스크립트 BASE64 인코딩 및 json array add
					byte[] targetBytes = contents.getBytes("UTF-8");
					Encoder encoder = Base64.getEncoder();
					String encodedString = encoder.encodeToString(targetBytes);

					jsonObject.put("Content", encodedString);
					jsonArray.add(jsonObject);

					// 수명 주기명 SET (노트북 인스턴스명-lifecycle-currentTimeMills)
			        lifeCycleNm = ins01+"-lifecycle-"+System.currentTimeMillis();

					lifeReq.setNotebookInstanceLifecycleConfigName(lifeCycleNm);

					/*
					 *  수명 주기 쉘 스크립트 SET
					 *  setOnCreate : 노트북 인스턴스 생성 시 한 번 쉘 스크립트 실행 하는 메서드
					 *  setOnStart : 노트북 인스턴스 생성 후 노트북 인스턴시 시작 시 한 번 쉘 스크립트 실행 하는 메서드
					 *  
					 */
					lifeReq.setOnCreate(jsonArray);

					// 수명 주기 등록
					lifeRes = smClient.createNotebookInstanceLifecycleConfig(lifeReq);

					req.setLifecycleConfigName(lifeCycleNm);

					AnalsVo analsVo = new AnalsVo();

					// 로그인 아이디
					analsVo.setUserId(user.getUsrId()); // "youthlazy"
					analsVo.setInstanceNm(ins01);

					// 상세/수정 화면에 선택한 데이터셋 view를 위한 포탈 DB에 해당 내역 delete ~ insert
					if(analsService.deleteDataSetInfo(analsVo) >= 0) {
						for(int i = 0; i < jsonArray2.size(); i++) {
							analsVo.setTabNm(jsonArray2.get(i).toString());
							analsService.insertDataSetInfo(analsVo);
						}
					}
				}
				
				// 노트북 인스턴스 생성
				CreateNotebookInstanceResult result = smClient.createNotebookInstance(req);
				
				// 에러가 나도 그냥 흘려 버립니다.
				try {
					InstCmdVo instcmd = new InstCmdVo ();
					instcmd.setInstanceName(ins01);
					instcmd.setUsrId(user.getUsrId());
					instcmd.setCmdType("C");
					instCmdService.insertInstCmd(instcmd);

					// global static 에 정보 저장.
					_user_instance_owner.put( ins01, instcmd);
					/////////////////////////////////////////////////////////////////

				}
				catch ( Exception e_inst ) {
					_log.error( e_inst.getLocalizedMessage());
				}
				/////////////////////////////////////////////////////////////////////
				
				// 생성 완료 후 노트북 인스턴스 ARN 화면에 넘겨줌
				jsonObject.put("instanceArn", result.getNotebookInstanceArn());
			} else {
				// 동일한 노트북 인스턴스명 존재 시 화면에 리턴
				jsonObject.put("instanceArn", "nameDuplication");
			}

			// 초기 생성 속도 좀 기다리는 것으로 함...
			try {
				Thread.sleep( 1500);
			} catch(Exception e_) {
				
			}
			////////////////////////////////////////////////////////////////////////////

	        response.setContentType("application/json; charset=UTF-8");

	        PrintWriter out = response.getWriter();
	        out.print(jsonObject.toString());
	        out.flush();
	        out.close();
		} catch(Exception e) {
			try {
				jsonObject = new JSONObject();
				jsonObject.put("error", e.getMessage());
				jsonObject.put("status", "ERROR");
	        	response.setContentType("application/json; charset=UTF-8");
		        PrintWriter out = response.getWriter();
		        out.print(jsonObject.toString());
		        out.flush();
		        out.close();
			}
			catch ( Exception e_error) {
				
			}
		}
	}

	@SuppressWarnings("unchecked")
	@GetMapping("/analsDetail")
	private void analsDetail(@RequestParam(value="notebookInstanceName") String notebookInstanceName, HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject jsonObject = new JSONObject();
        JSONObject jsonObject2 = null;
        JSONArray jsonArray = new JSONArray();

        BasicSessionCredentials bsc = null;
		DescribeNotebookInstanceRequest desReq = new DescribeNotebookInstanceRequest();
		DescribeNotebookInstanceResult desRslt = new DescribeNotebookInstanceResult();

		try {
			
			UserVo user;
			
			user = getUser ( request, response );

			/*
			 * 원래 코드 
			Credentials cre = getAssumeRole( user, "s").getCredentials();
			bsc = new BasicSessionCredentials(cre.getAccessKeyId(), cre.getSecretAccessKey(), cre.getSessionToken());
	        AmazonSageMaker smClient = AmazonSageMakerClientBuilder.standard()
	        		.withCredentials(new AWSStaticCredentialsProvider(bsc))
	        		.withRegion(_clientRegion)
	        		.build();
			 */
			// 통합 코드
			AmazonSageMaker smClient = getSageMaker (user);
			
			
	        desReq.setNotebookInstanceName(notebookInstanceName);
	        desRslt = smClient.describeNotebookInstance(desReq);

//	        _log.info ("##### failedReason : "+desRslt.getFailureReason());

        	jsonObject.put("notebookInstanceName", desRslt.getNotebookInstanceName());
        	jsonObject.put("instanceType", desRslt.getInstanceType());
        	jsonObject.put("notebookInstanceStatus", desRslt.getNotebookInstanceStatus());
        	jsonObject.put("url", desRslt.getUrl());
        	jsonObject.put("volumeSizeInGb", desRslt.getVolumeSizeInGB());

        	List<AnalsVo> aeInstInfoList = analsService.aeInstInfoList();

			if(aeInstInfoList.size() > 0) {
				for(AnalsVo str : aeInstInfoList) {
//					_log.info ("##### list : "+str.getInstTy()+" / "+str.getMemory()+" / "+str.getPrice()+" / "+str.getSn()+" / "+str.getvCpu());
					jsonObject2 = new JSONObject();

					jsonObject2.put("sn", str.getSn());
					jsonObject2.put("portalInstNm", str.getPortalInstNm());
					jsonObject2.put("instTy", str.getInstTy().substring(str.getInstTy().lastIndexOf(".")+1));
					jsonObject2.put("instTyFull", str.getInstTy());
					jsonObject2.put("vCpu", str.getvCpu());
					jsonObject2.put("memory", str.getMemory());
					jsonObject2.put("price", str.getPrice());

					jsonArray.add(jsonObject2);
				}
			}

			jsonObject.put("aeInstInfoList", jsonArray.toString());

			response.setContentType("application/json; charset=UTF-8");

			PrintWriter out = response.getWriter();
	        out.print(jsonObject.toString());
	        out.flush();
	        out.close();
		} catch(Exception e) {
			try {
				jsonObject = new JSONObject();
				jsonObject.put("error", e.getMessage());
				jsonObject.put("status", "ERROR");
	        	response.setContentType("application/json; charset=UTF-8");
		        PrintWriter out = response.getWriter();
		        out.print(jsonObject.toString());
		        out.flush();
		        out.close();
			}
			catch ( Exception e_error) {
				
			}
		}
	}

	@SuppressWarnings("unchecked")
	@RequestMapping("/startNotebookInstances")
	private void startNotebookInstances(@RequestParam(value="notebookInstanceName") String notebookInstanceName, HttpServletRequest request, HttpServletResponse response) throws Exception {
		JSONObject jsonObject = new JSONObject();
        JSONArray jsonArray = new JSONArray();

		BasicSessionCredentials bsc = null;
		StartNotebookInstanceRequest req = new StartNotebookInstanceRequest();

		try {
			
			UserVo user;
			
			user = getUser ( request, response );

			/*
			Credentials cre = getAssumeRole( user, "s").getCredentials();
			bsc = new BasicSessionCredentials(cre.getAccessKeyId(), cre.getSecretAccessKey(), cre.getSessionToken());
	        AmazonSageMaker smClient = AmazonSageMakerClientBuilder.standard()
	        		.withCredentials(new AWSStaticCredentialsProvider(bsc))
	        		.withRegion(_clientRegion)
	        		.build();
			*/
			// 통합 코드
			AmazonSageMaker smClient = getSageMaker (user);

	        req.setNotebookInstanceName(notebookInstanceName);

	        smClient.startNotebookInstance(req);

			jsonObject.put("status", "SUCCESS");

			response.setContentType("application/json; charset=UTF-8");

			PrintWriter out = response.getWriter();
	        out.print(jsonObject.toString());
	        out.flush();
	        out.close();
		} catch(Exception e) {
			try {
				jsonObject = new JSONObject();
				jsonObject.put("error", e.getMessage());
				jsonObject.put("status", "ERROR");
	        	response.setContentType("application/json; charset=UTF-8");
		        PrintWriter out = response.getWriter();
		        out.print(jsonObject.toString());
		        out.flush();
		        out.close();
			}
			catch ( Exception e_error) {
				
			}
		}
	}

	@SuppressWarnings("unchecked")
	@RequestMapping("/stopNotebookInstances")
	private void stopNotebookInstances(@RequestParam(value="notebookInstanceName") String notebookInstanceName, HttpServletRequest request, HttpServletResponse response) throws Exception {
		JSONObject jsonObject = new JSONObject();
        JSONArray jsonArray = new JSONArray();

		BasicSessionCredentials bsc = null;
		StopNotebookInstanceRequest req = new StopNotebookInstanceRequest();

		try {
			
			UserVo user;
			
			user = getUser ( request, response );

			/*
			Credentials cre = getAssumeRole( user, "s").getCredentials();
			bsc = new BasicSessionCredentials(cre.getAccessKeyId(), cre.getSecretAccessKey(), cre.getSessionToken());
	        AmazonSageMaker smClient = AmazonSageMakerClientBuilder.standard()
	        		.withCredentials(new AWSStaticCredentialsProvider(bsc))
	        		.withRegion(_clientRegion)
	        		.build();
			*/
			// 통합 코드
			AmazonSageMaker smClient = getSageMaker (user);
						
	        req.setNotebookInstanceName(notebookInstanceName);

	        smClient.stopNotebookInstance(req);

			jsonObject.put("status", "SUCCESS");

			response.setContentType("application/json; charset=UTF-8");

			PrintWriter out = response.getWriter();
	        out.print(jsonObject.toString());
	        out.flush();
	        out.close();
		} catch(Exception e) {

			try {
				jsonObject = new JSONObject();
				jsonObject.put("error", e.getMessage());
				jsonObject.put("status", "ERROR");
	        	response.setContentType("application/json; charset=UTF-8");
		        PrintWriter out = response.getWriter();
		        out.print(jsonObject.toString());
		        out.flush();
		        out.close();
			}
			catch ( Exception e_error) {
				
			}
		}
	}

	@SuppressWarnings("unchecked")
	@RequestMapping("/deleteNotebookInstances")
	private void deleteNotebookInstances(@RequestParam(value="notebookInstanceName") String notebookInstanceName, HttpServletRequest request, HttpServletResponse response) throws Exception {

		JSONObject jsonObject = new JSONObject();
        JSONArray jsonArray = new JSONArray();

		BasicSessionCredentials bsc = null;
		DeleteNotebookInstanceRequest req = new DeleteNotebookInstanceRequest();

		try {
			
			UserVo user;
			
			user = getUser ( request, response );

			/*
			Credentials cre = getAssumeRole( user, "s").getCredentials();
			bsc = new BasicSessionCredentials(cre.getAccessKeyId(), cre.getSecretAccessKey(), cre.getSessionToken());
	        AmazonSageMaker smClient = AmazonSageMakerClientBuilder.standard()
	        		.withCredentials(new AWSStaticCredentialsProvider(bsc))
	        		.withRegion(_clientRegion)
	        		.build();
			*/
			// 통합 코드
			AmazonSageMaker smClient = getSageMaker (user);
						
	        req.setNotebookInstanceName(notebookInstanceName);

	        smClient.deleteNotebookInstance(req);

        	AnalsVo analsVo = new AnalsVo();

    		analsVo.setUserId(user.getUsrId()); // "youthlazy"
    		analsVo.setInstanceNm(notebookInstanceName);

    		/*
    		try {
    			_aws_user_tags.remove( notebookInstanceName );
    		}
    		catch ( Exception e_del ) {
    			
    		}
    		*/
    		
        	if(analsService.deleteDataSetInfo(analsVo) >= 0) {
        		jsonObject.put("status", "SUCCESS");
        	}

        	/////////////////////////////////////////////
        	
	        InstCmdVo inst = new InstCmdVo ();
	        inst.setInstanceName( notebookInstanceName );
	        inst.setUsrId( user.getUsrId());
	        inst.setCmdType("C");
			
	        // 이거는 DB 에 저장하기 전 instance 들 정보 입력하기 위함이다.
	        try {
	        	del_instance_owner ( notebookInstanceName );
	        	instCmdService.deleteInstCmdPer(inst);
	        }
	        catch ( Exception e___) {
	        	
	        }        	
        	
	        
        	
        	
        	
        	response.setContentType("application/json; charset=UTF-8");

        	PrintWriter out = response.getWriter();
	        out.print(jsonObject.toString());
	        out.flush();
	        out.close();
		} catch(Exception e) {
			try {
				jsonObject = new JSONObject();
				jsonObject.put("error", e.getMessage());
				jsonObject.put("status", "ERROR");
	        	response.setContentType("application/json; charset=UTF-8");
		        PrintWriter out = response.getWriter();
		        out.print(jsonObject.toString());
		        out.flush();
		        out.close();
			}
			catch ( Exception e_error) {
				
			}
		}
	}

	@SuppressWarnings("unchecked")
	@RequestMapping("/analsStatusChk")
	private void analsStatusChk(@RequestParam(value="nameArr", required=false) String nameArr, HttpServletRequest request, HttpServletResponse response) throws Exception {

		JSONObject jObj1 = null;
        JSONArray jArr = new JSONArray();

		JSONObject jsonObject = new JSONObject();
        JSONArray jsonArray = new JSONArray();
        
        BasicSessionCredentials bsc = null;
        ListNotebookInstancesRequest req = new ListNotebookInstancesRequest();

		try {
			
			UserVo user;
			user = getUser ( request, response );
			/*
			Credentials cre = getAssumeRole( user, "s").getCredentials();
			bsc = new BasicSessionCredentials(cre.getAccessKeyId(), cre.getSecretAccessKey(), cre.getSessionToken());
	        AmazonSageMaker smClient = AmazonSageMakerClientBuilder.standard()
	        		.withCredentials(new AWSStaticCredentialsProvider(bsc))
	        		.withRegion(_clientRegion)
	        		.build();
			*/
			// 통합 코드
			
			AmazonSageMaker smClient = getSageMaker (user);
			//특수 문자 변경 			
			nameArr = nameArr.replaceAll("&quot;", "\"");
 
			JSONParser parser = new JSONParser();
			Object obj = parser.parse(nameArr);
			jsonArray = (JSONArray)obj;

			JSONObject jObj2 = new JSONObject();
			jObj2.put("listSize", smClient.listNotebookInstances(req).getNotebookInstances().size());

			jArr.add(jObj2);

			for(int i = 0; i < jsonArray.size(); i++) {
				JSONObject jsonObj = (JSONObject)jsonArray.get(i);
				for (NotebookInstanceSummary objectSummary : smClient.listNotebookInstances(req).getNotebookInstances()) {
					if(jsonObj.get("name").equals(objectSummary.getNotebookInstanceName())) {
						jObj1 = new JSONObject();
						jObj1.put("notebookInstanceName", objectSummary.getNotebookInstanceName());
						jObj1.put("notebookInstanceStatus", objectSummary.getNotebookInstanceStatus());

						jArr.add(jObj1);
					}
				}
			}
//			_log.info ("##### jArr : "+jArr.toString());

			response.setContentType("application/json; charset=UTF-8");
			PrintWriter out = response.getWriter();
	        out.print(jArr.toString());
	        out.flush();
	        out.close();
		} catch(Exception e) {
			try {
				jsonObject = new JSONObject();
				jsonObject.put("error", e.getMessage());
				jsonObject.put("status", "ERROR");
	        	response.setContentType("application/json; charset=UTF-8");
		        PrintWriter out = response.getWriter();
		        out.print(jsonObject.toString());
		        out.flush();
		        out.close();
			}
			catch ( Exception e_error) {
				
			}
		}
	}

	@SuppressWarnings("unchecked")
	@RequestMapping("/analsStatusChkDetail")
	private void analsStatusChkDetail(@RequestParam(value="notebookInstanceName") String notebookInstanceName, HttpServletRequest request, HttpServletResponse response) throws Exception {

		JSONObject jsonObject = new JSONObject();
        JSONArray jsonArray = new JSONArray();

		
        BasicSessionCredentials bsc = null;
		DescribeNotebookInstanceRequest desReq = new DescribeNotebookInstanceRequest();
		DescribeNotebookInstanceResult desRslt = new DescribeNotebookInstanceResult();

		try {
			
			UserVo user;
			
			user = getUser ( request, response );
			
			/*
			Credentials cre = getAssumeRole( user, "s").getCredentials();

			bsc = new BasicSessionCredentials(cre.getAccessKeyId(), cre.getSecretAccessKey(), cre.getSessionToken());

	        AmazonSageMaker smClient = AmazonSageMakerClientBuilder.standard()
	        		.withCredentials(new AWSStaticCredentialsProvider(bsc))
	        		.withRegion(_clientRegion)
	        		.build();
			*/
			// 통합 코드
			AmazonSageMaker smClient = getSageMaker (user);
						
			
	        desReq.setNotebookInstanceName(notebookInstanceName);
	        desRslt = smClient.describeNotebookInstance(desReq);

        	jsonObject.put("notebookInstanceStatus", desRslt.getNotebookInstanceStatus());

        	response.setContentType("application/json; charset=UTF-8");

        	PrintWriter out = response.getWriter();
	        out.print(jsonObject.toString());
	        out.flush();
	        out.close();
		} catch(Exception e) {
			try {
				jsonObject = new JSONObject();
				jsonObject.put("error", e.getMessage());
				jsonObject.put("status", "ERROR");
	        	response.setContentType("application/json; charset=UTF-8");
		        PrintWriter out = response.getWriter();
		        out.print(jsonObject.toString());
		        out.flush();
		        out.close();
			}
			catch ( Exception e_error) {
				
			}
		}
	}
////------------------------------------------------------------------------------------------
	/**
	 * 기능 수정 : 데이터셋 목록조회 부분 Lv3 API 와 연동해서 목록 가져옴
	 * @param companyCode   : 필수 검색 키 
	 * @param koreanNm      : optional
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@GetMapping("/datasetList")
	public ResponseDto getDatasetList(@RequestParam(value="koreanNm", required=false, defaultValue="") String koreanNm ) throws Exception {
		String companyCode = SessionUtil.getUserInfo().getAgency();

		ResponseDto result = new ResponseDto();

		if(StringUtil.isEmpty(companyCode)) {
			throw new BizException("companyCode 는 필수값입니다.");
		}
		
		String reqUrl = tableListUrl;
		reqUrl += "?companyCode=" + companyCode;
		if( !StringUtil.isEmpty(koreanNm)) {
			reqUrl += "&tableId=" + koreanNm;  // 검색어 부분은 tableId or tabeName 모두 tableId 로 통일
		}
		String retData = dcApiService.getXmlApi(reqUrl);  //Lv3 API 호출
		try {
			Map<String,Object> resultData = new HashMap<>();
	    	if( !StringUtil.isEmpty(retData)) {

		    	resultData = new ObjectMapper().readValue(retData, Map.class);
		    	result.putData("dataset", resultData);
		    	
	    	} else {
	    		result.putData("dataset", "");
	    	}
	    	//----get the codeInfoList, Not any more use, 20191111 by pkh
//	    	Map<String,Object> param = new HashMap<>();
//	    	param.put("groupCodeId", "sk004");
//	    	List<CodeDetailVo> codeList = dcApiService.getDcCodeInfoList(param);
//	    	result.putData("codeInfo", codeList);
		} catch(Exception e) {
			result.setCode(CommonConstants.FAIL);
	        result.setMessage("조회중 오류가 발생하였습니다.\n" + e.getMessage());
		}
		return result;
	}
	
	
	@SuppressWarnings("unchecked")
	@GetMapping("/datasetList-old")
	private void datasetList_old(@RequestParam(value="koreanNm", required=false) String koreanNm, HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject jsonObject = null;
        JSONArray jsonArray = new JSONArray();

		try {
			
			List<AnalsVo> datasetList = analsService.datasetList(koreanNm );

			if(datasetList.size() > 0) {
				for(AnalsVo str : datasetList) {
					jsonObject = new JSONObject();

					jsonObject.put("sn", str.getSn());
					jsonObject.put("copm", str.getCopm());
					jsonObject.put("indsGrp", str.getIndsgrp());
					jsonObject.put("tabNm", str.getTabNm());
					jsonObject.put("koreanNm", str.getKoreanNm());
					jsonObject.put("attr", str.getAttr());
					jsonObject.put("s3BktAddr", str.getS3BktAddr());

					jsonArray.add(jsonObject);
				}
			}

			response.setContentType("application/json; charset=UTF-8");

			PrintWriter out = response.getWriter();
	        out.print(jsonArray.toString());
	        out.flush();
	        out.close();
		} catch(Exception e) {
			try {
				jsonObject = new JSONObject();
				jsonObject.put("error", e.getMessage());
				jsonObject.put("status", "ERROR");
	        	response.setContentType("application/json; charset=UTF-8");
		        PrintWriter out = response.getWriter();
		        out.print(jsonObject.toString());
		        out.flush();
		        out.close();
			}
			catch ( Exception e_error) {
				
			}
		}
	}

	@SuppressWarnings("unchecked")
	@GetMapping("/datasetInfoList")
	private void datasetInfoList(@RequestParam(value="instanceName", required=false) String instanceName, HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject jsonObject = null;
        JSONArray jsonArray = new JSONArray();

		try {
			
			UserVo user;
			
			user = getUser ( request, response );
			
			AnalsVo analsVo = new AnalsVo();

			analsVo.setUserId( user.getUsrId());
			
			analsVo.setInstanceNm(instanceName);

			List<AnalsVo> datasetInfoList = analsService.datasetInfoList(analsVo);

			if(datasetInfoList.size() > 0) {
				for(int i = 0; i < datasetInfoList.size(); i++) {
					jsonObject = new JSONObject();

					jsonObject.put("sn", datasetInfoList.get(i).getSn());
					jsonObject.put("tabNm", datasetInfoList.get(i).getTabNm());
					jsonObject.put("s3BktAddr", datasetInfoList.get(i).getS3BktAddr());

					jsonArray.add(jsonObject);
				}
			}

			response.setContentType("application/json; charset=UTF-8");

			PrintWriter out = response.getWriter();
	        out.print(jsonArray.toString());
	        out.flush();
	        out.close();
		} catch(Exception e) {
			try {
				jsonObject = new JSONObject();
				jsonObject.put("error", e.getMessage());
				jsonObject.put("status", "ERROR");
	        	response.setContentType("application/json; charset=UTF-8");
		        PrintWriter out = response.getWriter();
		        out.print(jsonObject.toString());
		        out.flush();
		        out.close();
			}
			catch ( Exception e_error) {
				
			}
		}
	}

	@SuppressWarnings("unchecked")
	@GetMapping("/datasetInfoAllList")
	private void datasetInfoAllList(@RequestParam(value="instanceName", required=false) String instanceName, HttpServletRequest request, HttpServletResponse response) throws Exception {
        JSONObject jsonObject = null;
        JSONArray jsonArray = new JSONArray();

		try {
			
			UserVo user;
			
			user = getUser ( request, response );
			
			AnalsVo analsVo = new AnalsVo();

			analsVo.setUserId( user.getUsrId());
			analsVo.setInstanceNm(instanceName);

			List<AnalsVo> datasetInfoList = analsService.datasetInfoAllList(analsVo);

			if(datasetInfoList.size() > 0) {
				for(int i = 0; i < datasetInfoList.size(); i++) {
					jsonObject = new JSONObject();

					jsonObject.put("sn", datasetInfoList.get(i).getSn());
					jsonObject.put("tabNm", datasetInfoList.get(i).getTabNm());
					jsonObject.put("copm", datasetInfoList.get(i).getCopm());
					jsonObject.put("indsGrp", datasetInfoList.get(i).getIndsgrp());
					jsonObject.put("koreanNm", datasetInfoList.get(i).getKoreanNm());
					jsonObject.put("attr", datasetInfoList.get(i).getAttr());
					jsonObject.put("s3BktAddr", datasetInfoList.get(i).getS3BktAddr());

					jsonArray.add(jsonObject);
				}
			}

			response.setContentType("application/json; charset=UTF-8");

			PrintWriter out = response.getWriter();
	        out.print(jsonArray.toString());
	        out.flush();
	        out.close();
		} catch(Exception e) {
			try {
				jsonObject = new JSONObject();
				jsonObject.put("error", e.getMessage());
				jsonObject.put("status", "ERROR");
	        	response.setContentType("application/json; charset=UTF-8");
		        PrintWriter out = response.getWriter();
		        out.print(jsonObject.toString());
		        out.flush();
		        out.close();
			}
			catch ( Exception e_error) {
				
			}
		}
	}

	@SuppressWarnings("unchecked")
	@RequestMapping("/modifyNotebookInstances")
	private void modifyNotebookInstances(@RequestParam(value="notebookInstanceName") String notebookInstanceName,
			@RequestParam(value="volumeSizeInGb") String volumeSizeInGb,
			@RequestParam(value="dtArr", required=false) String dtArr,
			@RequestParam(value="s3Arr", required=false) String s3Arr,
			HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String contents = "";
		String lifeCycleNm = "";

		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArray = new JSONArray();

		BasicSessionCredentials bsc = null;
		UpdateNotebookInstanceRequest req = new UpdateNotebookInstanceRequest();
		CreateNotebookInstanceLifecycleConfigRequest lifeReq = new CreateNotebookInstanceLifecycleConfigRequest();
		CreateNotebookInstanceLifecycleConfigResult lifeRes = new CreateNotebookInstanceLifecycleConfigResult();

		try {
			
			UserVo user;
			
			user = getUser ( request, response );
			
			/*
			Credentials cre = getAssumeRole( user, "n").getCredentials();

			bsc = new BasicSessionCredentials(cre.getAccessKeyId(), cre.getSecretAccessKey(), cre.getSessionToken());

	        AmazonSageMaker smClient = AmazonSageMakerClientBuilder.standard()
	        		.withCredentials(new AWSStaticCredentialsProvider(bsc))
	        		.withRegion(_clientRegion)
	        		.build();
			*/
			// 통합 코드
			AmazonSageMaker smClient = getSageMaker (user);
						
			
	        req.setNotebookInstanceName(notebookInstanceName);
	        req.setVolumeSizeInGB(Integer.parseInt(volumeSizeInGb));
//	        req.setRoleArn ( _aws_rolearn );
	        
			JSONParser parser = new JSONParser();
			Object obj1 = parser.parse(dtArr);

			JSONArray jsonArray2 = (JSONArray) obj1;

			AnalsVo analsVo = new AnalsVo();
			
			analsVo.setUserId(user.getUsrId()); // "youthlazy"
			analsVo.setInstanceNm(notebookInstanceName);

			if(jsonArray2.size() > 0) {
				String s3Addr = "";

				Object obj2 = parser.parse(s3Arr);
				JSONArray jsonArray3 = (JSONArray) obj2;

				
				contents = "#!/bin/bash" + "\n"
						+ "set -e" + "\n"
						+ "sudo -i -u ec2-user bash << EOF" + "\n"
						+ "cd /home/ec2-user/SageMaker" + "\n";

				StringBuffer contentSb = new StringBuffer(contents);

				// 파싱된 데이터셋 S3 버킷 주소 SET
				String basedir = "/home/" + _aws_useruser + "/SageMaker/";
				for(int i = 0; i < jsonArray3.size(); i++) {
											
					AmazonS3URI url = new AmazonS3URI ( jsonArray3.get(i).toString() );
					
					s3Addr += " sudo aws s3 sync "+ jsonArray3.get(i).toString() + " " + basedir + url.getKey().replace("/", "\\>") + "/ \n";
				}

				contents = contentSb.append(s3Addr).append("EOF").toString();

				_log.info ("##### contents : "+contents);

				byte[] targetBytes = contents.getBytes("UTF-8");
				Encoder encoder = Base64.getEncoder();
				String encodedString = encoder.encodeToString(targetBytes);

				jsonObject.put("Content", encodedString);
				jsonArray.add(jsonObject);

		        lifeCycleNm = notebookInstanceName+"-lifecycle-"+System.currentTimeMillis();

				lifeReq.setNotebookInstanceLifecycleConfigName(lifeCycleNm);
				lifeReq.setOnCreate(jsonArray);

				lifeRes = smClient.createNotebookInstanceLifecycleConfig(lifeReq);

				req.setLifecycleConfigName(lifeCycleNm);

				if(analsService.deleteDataSetInfo(analsVo) >= 0) {
					for(int i = 0; i < jsonArray2.size(); i++) {
						analsVo.setTabNm(jsonArray2.get(i).toString());
						
						analsService.insertDataSetInfo(analsVo);
					}
				}
			} else {
//				req.setLifecycleConfigName("");
				analsService.deleteDataSetInfo(analsVo);
			}

			smClient.updateNotebookInstance(req);

			jsonObject.put("status", "SUCCESS");

			response.setContentType("application/json; charset=UTF-8");

			PrintWriter out = response.getWriter();
	        out.print(jsonObject.toString());
	        out.flush();
	        out.close();
		} catch(Exception e) {
			try {
				jsonObject = new JSONObject();
				jsonObject.put("error", e.getMessage());
				jsonObject.put("status", "ERROR");
	        	response.setContentType("application/json; charset=UTF-8");
		        PrintWriter out = response.getWriter();
		        out.print(jsonObject.toString());
		        out.flush();
		        out.close();
			}
			catch ( Exception e_error) {
				
			}
		}
	}
}

