package com.sk.dlsp.model;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class DcApprovalVo implements Serializable{

	@JsonIgnore
	private static final long serialVersionUID = 5817970230799590338L;
//
	private String classKey;        //
	private String approver;        //데이터 공유 요청 승인자.
	private String approverCom;     //데이터 공유 요청자.
	private String requestAt;       //데이터 공유 요청일시.
	private String requester;       //데이터 공유 요청자.
	private String requesterCom;    //데이터 공유 요청자.
	private String txId;            //트랜젝션 ID
	
	private String companyCode;     //관계사코드
	private String databaseName;    //데이타베이스명
	private String subjectName;      //주제영역명
	
	private String classTitle;      //classLevel=3 제목
	private String reqReason;      //요청사유
	private String resourceId;      //데이타베이스 종류
	//
	private List<DcApprovalDataVo> consentDetailDTOList; //상세  데이타정보
	

	public String getClassKey() {
		return classKey;
	}

	public void setClassKey(String classKey) {
		this.classKey = classKey;
	}

	public String getApprover() {
		return approver;
	}

	public void setApprover(String approver) {
		this.approver = approver;
	}

	public String getApproverCom() {
		return approverCom;
	}

	public void setApproverCom(String approverCom) {
		this.approverCom = approverCom;
	}

	public String getRequestAt() {
		return requestAt;
	}

	public void setRequestAt(String requestAt) {
		this.requestAt = requestAt;
	}

	public String getRequester() {
		return requester;
	}

	public void setRequester(String requester) {
		this.requester = requester;
	}

	public String getRequesterCom() {
		return requesterCom;
	}

	public void setRequesterCom(String requesterCom) {
		this.requesterCom = requesterCom;
	}

	public String getTxId() {
		return txId;
	}

	public void setTxId(String txId) {
		this.txId = txId;
	}
	

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getDatabaseName() {
		return databaseName;
	}

	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	

	public String getClassTitle() {
		return classTitle;
	}

	public void setClassTitle(String classTitle) {
		this.classTitle = classTitle;
	}

	public String getReqReason() {
		return reqReason;
	}

	public void setReqReason(String reqReason) {
		this.reqReason = reqReason;
	}

	public List<DcApprovalDataVo> getConsentDetailDTOList() {
		return consentDetailDTOList;
	}

	public void setConsentDetailDTOList(List<DcApprovalDataVo> consentDetailDTOList) {
		this.consentDetailDTOList = consentDetailDTOList;
	}
	

	public String getResourceId() {
		return resourceId;
	}

	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this,ToStringStyle.MULTI_LINE_STYLE); 
	}


	
	
		
	
	
}
