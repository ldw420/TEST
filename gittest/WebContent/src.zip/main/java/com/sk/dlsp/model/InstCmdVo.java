package com.sk.dlsp.model;

/*
 * instance 생성. 실행. 종료 등에 대한 명령등을 저장하기 위한 VO 입니다.
 */
public class InstCmdVo {

	public int getSn() {
		return sn;
	}
	public void setSn(int sn) {
		this.sn = sn;
	}
	public String getUsrId() {
		return usrId;
	}
	public void setUsrId(String usrId) {
		this.usrId = usrId;
	}
	public String getInsType() {
		return insType;
	}
	public void setInsType(String insType) {
		this.insType = insType;
	}
	public String getCmdType() {
		return cmdType;
	}
	public void setCmdType(String cmdType) {
		this.cmdType = cmdType;
	}
	public String getInstanceName() {
		return instanceName;
	}
	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}
	public String getInstanceStatus() {
		return instanceStatus;
	}
	public void setInstanceStatus(String instanceStatus) {
		this.instanceStatus = instanceStatus;
	}
	public String getInstanceType() {
		return instanceType;
	}
	public void setInstanceType(String instanceType) {
		this.instanceType = instanceType;
	}
	public String getInstanceGendate() {
		return instanceGendate;
	}
	public void setInstanceGendate(String instanceGendate) {
		this.instanceGendate = instanceGendate;
	}
	public String getCmdDate() {
		return cmdDate;
	}
	public void setCmdDate(String cmdDate) {
		this.cmdDate = cmdDate;
	}
	
	private int sn;
	private String usrId;
	private String insType;
	private String cmdType;
	private String instanceName;
	private String instanceStatus;
	private String instanceType;
	private String instanceGendate;
	private String cmdDate;
	
	
}
