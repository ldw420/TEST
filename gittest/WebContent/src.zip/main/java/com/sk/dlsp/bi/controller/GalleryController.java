package com.sk.dlsp.bi.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sk.dlsp.bi.common.TableauCommonConfig;
import com.sk.dlsp.bi.service.GalleryService;
import com.sk.dlsp.common.consts.CommonConstants;
import com.sk.dlsp.model.GalleryVo;
import com.sk.dlsp.model.GalleryVoEx;
import com.sk.dlsp.model.ResponseDto;

@RestController

@RequestMapping(CommonConstants.API_PREFIX + "/gallery")
public class GalleryController {

	static Logger _log = LoggerFactory.getLogger(GalleryController.class.getName());

	@Autowired
	private GalleryService galleryService;

	@Autowired
	private TableauCommonConfig tableauCommonConfig;

	/**
	 * 갤러리 목록을 가져온다.
	 * 
	 * @param Map (K : searchKeyword(category), getMappingData(true/false. 리스트, 그리드
	 *            데이터 분리 위하여 사용))
	 * @return
	 */
	@PostMapping("/list")
	public ResponseDto getList(@RequestBody Map<String, Object> param) {
		ResponseDto responseDto = new ResponseDto();

		try {
			responseDto.putData("galleryList", galleryService.getList(param));
		} catch (Exception e) {
			_log.error(e.toString());
		}

		return responseDto;
	}

	@GetMapping("/refresh")
	public ResponseDto refreshList() {
		ResponseDto result = new ResponseDto();

		long startTime = System.currentTimeMillis();

		try {
			boolean ret = galleryService.setGalleryData(tableauCommonConfig.getTableauAdminCredentials(),
					tableauCommonConfig.getSiteType());

			result.setCode(ret ? CommonConstants.SUCCESS : CommonConstants.FAIL);

		} catch (Exception e) {
			_log.error(e.toString());
		} finally {
			_log.info("End to Load Tableau Data({} sec.)", ((System.currentTimeMillis() - startTime) / 1000.0));
		}

		return result;
	}

	@GetMapping("/refresh-parallel")
	public ResponseDto refreshListNewThread() {
		ResponseDto result = new ResponseDto();

		try {
			new Thread() {
				@Override
				public void run() {
					long startTime = System.currentTimeMillis();

					try {
						galleryService.setGalleryData(tableauCommonConfig.getTableauAdminCredentials(),
								tableauCommonConfig.getSiteType());
					} catch (Exception e) {
						_log.error(e.toString());
					} finally {
						_log.info("End to Load Tableau Data({} sec.)", ((System.currentTimeMillis() - startTime) / 1000.0));
					}
				}
			}.start();
		} catch (Exception e) {
			_log.error(e.toString());
		}

		return result;
	}

	/**
	 * 카테고리별 갤러리 갯수를 가져온다.
	 * 
	 * @return
	 */
	@GetMapping("/get-industry")
	public ResponseDto getCodeDetailList() {
		ResponseDto result = new ResponseDto();
		try {
			result.putData("galleryIndustryList", galleryService.getGalleryIndustryList());
			result.putData("mappingCnt", galleryService.getMappingCount());
			result.putData("allCnt", galleryService.getCountAll());
		} catch (Exception e) {
			_log.error(e.toString());
		}
		return result;
	}

	/**
	 * 갤러리 하나의 정보를 가져온다. <br>
	 * embedded용 태블로 url도 가공하여 넘겨준다. <br>
	 * id값 필수
	 * 
	 * @param param
	 * @return
	 */
	@GetMapping("/data")
	public ResponseDto getData(GalleryVo param) {
		ResponseDto responseDto = new ResponseDto();

		try {

			GalleryVo currentGallery = galleryService.getOne(param);
			if (currentGallery != null) {
				// current gallery vo
				responseDto.putData("currentGallery", currentGallery);
				// tableau url
				responseDto.putData("reportUrl", galleryService.makeTableauEmbedUrl(currentGallery));

				// select gallery list all
				List<GalleryVoEx> galleryList = galleryService.getList(new HashMap<String, Object>());
				// prev workbook
				responseDto.putData("prevGallery", galleryService.getPrevGallery(galleryList, currentGallery));
				// next workbook
				responseDto.putData("nextGallery", galleryService.getNextGallery(galleryList, currentGallery));
			}
		} catch (Exception e) {
			_log.error(e.toString());
		}

		return responseDto;
	}

	/**
	 * 갤러리 화면 관리(어드민 페이지)에서 보여줄 카드를 설정한다. <br>
	 * 이미지 보여줄 카드 선택.
	 * 
	 * @param param
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@PostMapping("/manage/update-mapping")
	public ResponseDto updateMappingData(@RequestBody Map<String, Object> param) {
		ResponseDto responseDto = new ResponseDto();

		try {
			// 갤러리 목록 수정(delete > insert)
			// List<GalleryVoEx> galleryList = (List<GalleryVoEx>) param.get("galleryList");
			List<Map<String, Object>> galleryList = (List<Map<String, Object>>) param.get("galleryList");
			galleryService.updateMappingData(galleryList);
		} catch (Exception e) {
			_log.error(e.toString());
		}

		return responseDto;
	}

	/**
	 * 미리보기 버튼을 눌렀을 경우 썸네일 이미지를 다운받고 파일명을 return한다. <br>
	 * 저장 할 경우 DB에 파일명 저장해야 하므로 파일명만 넘긴다.
	 * 
	 * @param tableauShareUrl
	 * @return
	 * @throws IOException
	 */
	@GetMapping("/get-preview-image")
	public ResponseDto getPreviewImage(@RequestParam String tableauShareUrl) throws IOException {

		ResponseDto result = new ResponseDto();

		try {
			File file = galleryService.getPreviewImage(tableauShareUrl);
			if (file != null && file.exists()) {
				result.putData("fileName", file.getName());
			}
		} catch (Exception e) {
			_log.error(e.toString());
		}

		return result;
	}

	@GetMapping("/show-image")
	public void showImage(HttpServletRequest request, HttpServletResponse response) {
		try {
			String previewImageName = request.getParameter("imageName");
			if (previewImageName == null || "".equals(previewImageName)) {
				return;
			}

			File file = new File(GalleryService.VIEW_IMAGE_PATH + "/" + previewImageName);
			if (file == null || !file.exists()) {
				return;
			}

			InputStream in = new FileInputStream(file);
			response.setContentType(MediaType.IMAGE_PNG_VALUE);
			IOUtils.copy(in, response.getOutputStream());

		} catch (Exception e) {
			_log.error(e.toString());
		}
	}

	@GetMapping("/refresh-tableau-config")
	public ResponseDto refreshTableauConfig() {
		ResponseDto result = new ResponseDto();

		long startTime = System.currentTimeMillis();

		try {
			tableauCommonConfig.getTableauInformation();
			if (tableauCommonConfig.getTableauAdminCredentials() == null) {
				result.setCode(CommonConstants.FAIL);
			}
		} catch (Exception e) {
			_log.error(e.toString());
		} finally {
			_log.info("End to Load Tableau Data({} sec.)", ((System.currentTimeMillis() - startTime) / 1000.0));
		}

		return result;
	}
}