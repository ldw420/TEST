package com.sk.dlsp.bi.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sk.dlsp.bi.bindings.SiteType;
import com.sk.dlsp.bi.bindings.TableauCredentialsType;
import com.sk.dlsp.bi.common.TableauCommonConfig;
import com.sk.dlsp.bi.restapi.RestApiUtils;
import com.sk.dlsp.bi.service.GalleryService;
import com.sk.dlsp.common.consts.CommonConstants;
import com.sk.dlsp.model.ResponseDto;

@Controller
@RequestMapping(CommonConstants.API_PREFIX + "/test")
public class BiTestController {

	@Autowired
	private TableauCommonConfig tableauCommonConfig;

	@Autowired
	private GalleryService galleryService;

	@RequestMapping("/get-workbooks")
	public ResponseDto getWorkbookList() {
		ResponseDto ret = new ResponseDto();
		try {
			RestApiUtils restApiUtils = RestApiUtils.getInstance();
			ret.putData("data", restApiUtils.invokeQueryWorkbooksForSite(
					tableauCommonConfig.getTableauAdminCredentials(), null, 1, null, true));
		} catch (Exception e) {
			e.printStackTrace();
		}

		return ret;
	}

	@RequestMapping("/get-preview-image")
	@ResponseBody
	public ResponseDto getPreviewImage() {

		ResponseDto result = new ResponseDto();

		String tableauUrl = "http://52.79.76.51/views/2/sheet0?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no&:origin=viz_share_link";

		try {
			File file = galleryService.getPreviewImage(tableauUrl);
			if (file != null && file.exists()) {
				result.putData("fileName", file.getName());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	@RequestMapping("/get-gallery-from-memory")
	@ResponseBody
	public ResponseDto getWorkbookFromMemory() {

		ResponseDto result = new ResponseDto();

		try {
			result.putData("data", tableauCommonConfig.getGalleryWorkbookList());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	@RequestMapping("/refresh-gallery")
	@ResponseBody
	public ResponseDto refreshGallery() {

		ResponseDto result = new ResponseDto();

		try {
			galleryService.setGalleryData(tableauCommonConfig.getTableauAdminCredentials(),
					tableauCommonConfig.getSiteType());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	@RequestMapping("/get-embed-url")
	@ResponseBody
	public ResponseDto getTrustedUrl() {
		ResponseDto result = new ResponseDto();

		try {
			String tableauUrl = "http://52.79.76.51/views/2/sheet0?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no&:origin=viz_share_link";

			Map<String, Object> param = new HashMap<String, Object>();
			param.put("shrUrl", tableauUrl);
			result.putData("embedUrl", galleryService.makeTableauEmbedUrl(param));
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	@RequestMapping("/get-site")
	@ResponseBody
	public ResponseDto getSite() {
		ResponseDto result = new ResponseDto();

		try {
			SiteType site = tableauCommonConfig.getSiteType();
			if (site == null) {
				result.setMessage("site is null");
			} else {

				result.putData("siteId", site.getId());
				result.putData("siteName", site.getName());
				result.putData("siteContentUrl", site.getContentUrl());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	@RequestMapping("/get-site-list")
	@ResponseBody
	public ResponseDto getSiteList() {
		ResponseDto result = new ResponseDto();

		try {
			List<SiteType> siteList = tableauCommonConfig.getSiteTypeList();
			if (siteList == null || siteList.isEmpty()) {
				result.setMessage("site is null");
			} else {

				List<Map<String, Object>> ret = new ArrayList<Map<String, Object>>();

				for (SiteType site : siteList) {
					Map<String, Object> siteMap = new HashMap<String, Object>();

					siteMap.put("siteId", site.getId());
					siteMap.put("siteName", site.getName());
					siteMap.put("siteContentUrl", site.getContentUrl());

					ret.add(siteMap);
				}

				result.putData("siteList", ret);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	@RequestMapping("/get-admincredentials")
	@ResponseBody
	public ResponseDto getAdminCredentials() {
		ResponseDto result = new ResponseDto();

		try {
			TableauCredentialsType adminCredentials = tableauCommonConfig.getTableauAdminCredentials();

			if (adminCredentials == null) {
				result.setMessage("admin credentials is null");
			} else {
				result.putData("token", adminCredentials.getToken());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}
}
