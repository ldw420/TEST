package com.sk.dlsp.model;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class DcCompVo extends CommonVo{

	//
	private int sn;
	private String biRepSj;
	private String userId;
	private String userNm;
	private String instCl;
	private String shrUrl;
	private String useAt;
	private String copm;
	private String copmNm;
	private String shrAt;
	private int cnt;
	private int compcnt;
	private String cn;
	private String ctg;
	private String ctgNm;
	private String useAtNm;
	private String imgUrl;
	private String detailCodeId;
	private String detailCodeNm;
	private int docId;
	private String cl;
	private String prevNext;
	private String confmCn;
	public int getSn() {
		return sn;
	}
	public void setSn(int sn) {
		this.sn = sn;
	}
	public String getBiRepSj() {
		return biRepSj;
	}
	public void setBiRepSj(String biRepSj) {
		this.biRepSj = biRepSj;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	public String getInstCl() {
		return instCl;
	}
	public void setInstCl(String instCl) {
		this.instCl = instCl;
	}
	public String getShrUrl() {
		return shrUrl;
	}
	public void setShrUrl(String shrUrl) {
		this.shrUrl = shrUrl;
	}
	public String getUseAt() {
		return useAt;
	}
	public void setUseAt(String useAt) {
		this.useAt = useAt;
	}
	public String getCopm() {
		return copm;
	}
	public void setCopm(String copm) {
		this.copm = copm;
	}
	public String getCopmNm() {
		return copmNm;
	}
	public void setCopmNm(String copmNm) {
		this.copmNm = copmNm;
	}
	public String getShrAt() {
		return shrAt;
	}
	public void setShrAt(String shrAt) {
		this.shrAt = shrAt;
	}
	
	public int getCompcnt() {
		return compcnt;
	}
	public void setCompcnt(int compcnt) {
		this.compcnt = compcnt;
	}
	public int getCnt() {
		return cnt;
	}
	public void setCnt(int cnt) {
		this.cnt = cnt;
	}
	public String getCn() {
		return cn;
	}
	public void setCn(String cn) {
		this.cn = cn;
	}
	public String getCtg() {
		return ctg;
	}
	public void setCtg(String ctg) {
		this.ctg = ctg;
	}
	public String getCtgNm() {
		return ctgNm;
	}
	public void setCtgNm(String ctgNm) {
		this.ctgNm = ctgNm;
	}
	public String getUseAtNm() {
		return useAtNm;
	}
	public void setUseAtNm(String useAtNm) {
		this.useAtNm = useAtNm;
	}
	public String getImgUrl() {
		return imgUrl;
	}
	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}
	public String getDetailCodeId() {
		return detailCodeId;
	}
	public void setDetailCodeId(String detailCodeId) {
		this.detailCodeId = detailCodeId;
	}
	public String getDetailCodeNm() {
		return detailCodeNm;
	}
	public void setDetailCodeNm(String detailCodeNm) {
		this.detailCodeNm = detailCodeNm;
	}
	public int getDocId() {
		return docId;
	}
	public void setDocId(int docId) {
		this.docId = docId;
	}
	public String getCl() {
		return cl;
	}
	public void setCl(String cl) {
		this.cl = cl;
	}
	public String getPrevNext() {
		return prevNext;
	}
	public void setPrevNext(String prevNext) {
		this.prevNext = prevNext;
	}
	public String getConfmCn() {
		return confmCn;
	}
	public void setConfmCn(String confmCn) {
		this.confmCn = confmCn;
	}
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this,ToStringStyle.MULTI_LINE_STYLE); 
	}

}
