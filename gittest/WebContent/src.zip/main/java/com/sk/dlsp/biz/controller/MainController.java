package com.sk.dlsp.biz.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sk.dlsp.biz.service.AuthAppService;
import com.sk.dlsp.biz.service.MainService;
import com.sk.dlsp.common.consts.CommonConstants;
import com.sk.dlsp.common.util.SessionUtil;
import com.sk.dlsp.dc.service.DcService;
import com.sk.dlsp.model.AuthAppVo;
import com.sk.dlsp.model.BbsVo;
import com.sk.dlsp.model.BiVo;
import com.sk.dlsp.model.DcConfmVo;
import com.sk.dlsp.model.DcVo;
import com.sk.dlsp.model.MydashboardVo;
import com.sk.dlsp.model.ResponseDto;
import com.sk.dlsp.model.SrchwrdVo;
import com.sk.dlsp.model.UseCaseVo;
import com.sk.dlsp.model.UserInfo;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(CommonConstants.API_PREFIX + "/main")
public class MainController {

	@Autowired MainService mainService;
	@Autowired AuthAppService authAppService;
	@Autowired DcService dcService;
	
	@Value("${prop.server.blockchain.approval.url}") String approvalUrl;

	@GetMapping("/data")
	public ResponseDto getNoticeList() throws Exception {
		ResponseDto result = new ResponseDto();

		List<BbsVo> bbsList = mainService.getNoticeList();
		result.putData("noticeList", bbsList);
		List<SrchwrdVo> srchwrdList = mainService.getSrchwrdList();
		result.putData("srchwrdList", srchwrdList);
		BiVo biVo = mainService.getBiVo();
		result.putData("biVo", biVo);
		UseCaseVo useCaseVo = mainService.getUseCaseVo();
		result.putData("useCaseVo", useCaseVo);
		List<MydashboardVo> useCaseListVo = mainService.getUseCaseListVo();
		result.putData("useCaseList", useCaseListVo);
		return result;
	}
	 
	
	@PostMapping("/mydashboard")
	@ApiOperation(value = "mydashboard")
	public ResponseDto getMydashboardList(@RequestBody MydashboardVo mydashboardVo) throws Exception {
		
		// Extract the userInfo, 20191022 by pkh 
		UserInfo userInfo = SessionUtil.getUserInfo();
		mydashboardVo.setComp(userInfo.getAgency());
		mydashboardVo.setCompanycode(userInfo.getAgency());
		mydashboardVo.setUserId(userInfo.getUsrId());
		mydashboardVo.setUsrId(userInfo.getUsrId());
		mydashboardVo.setAuthId(userInfo.getAuthId());
		
		ResponseDto result = new ResponseDto();

		//검토 요청 카운트 
		int confmAppCnt = mainService.getConfmAppCnt(mydashboardVo); 
		result.putData("confmAppCnt", confmAppCnt);
		//나의 요청 신청 카운트
		List<MydashboardVo> myAppCnt = mainService.getMyAppCnt(mydashboardVo);
		result.putData("myAppCnt", myAppCnt);
		
		if (mydashboardVo.getDiv().equals("0")) {
			//검토 요청 list
			List<MydashboardVo> getConfmAppList = mainService.getConfmAppList(mydashboardVo);
			result.putData("getConfmAppList", getConfmAppList);
			
			//나의 신청 list
			List<MydashboardVo> getMyAppList = mainService.getMyAppList(mydashboardVo);
			result.putData("getMyAppList", getMyAppList);
		}
		
		//스크랩 데이터
		List<MydashboardVo> myScrapList = mainService.getMyScrapList(mydashboardVo);
		result.putData("myScrapList", myScrapList);
		
		//공유 임박 목록
		List<MydashboardVo> myDataList = mainService.getMyDataList(mydashboardVo);
		result.putData("getMyDataList", myDataList);
		
		
		 

		return result;
	}
	
	
	@PostMapping("/getConfmAppList")
	@ApiOperation(value = "검토할 요청 목록")
	public ResponseDto getConfmAppList(@RequestBody MydashboardVo mydashboardVo) throws Exception {
		
		// Extract the userInfo, 20191022 by pkh 
		UserInfo userInfo = SessionUtil.getUserInfo();
		mydashboardVo.setComp(userInfo.getAgency());
		mydashboardVo.setCompanycode(userInfo.getAgency());
		mydashboardVo.setUserId(userInfo.getUsrId());
		mydashboardVo.setUsrId(userInfo.getUsrId());
		mydashboardVo.setAuthId(userInfo.getAuthId());
		
		ResponseDto result = new ResponseDto();
 
		//검토 요청 list
		List<MydashboardVo> getConfmAppList = mainService.getConfmAppList(mydashboardVo);
		result.putData("getConfmAppList", getConfmAppList);

		return result;
	}
	
	@PostMapping("/getMyAppList")
	@ApiOperation(value = "내가 공유 요청 목록")
	public ResponseDto getMyAppList(@RequestBody MydashboardVo mydashboardVo) throws Exception {
		
		// Extract the userInfo, 20191022 by pkh 
		UserInfo userInfo = SessionUtil.getUserInfo();
		mydashboardVo.setComp(userInfo.getAgency());
		mydashboardVo.setCompanycode(userInfo.getAgency());
		mydashboardVo.setUserId(userInfo.getUsrId());
		mydashboardVo.setUsrId(userInfo.getUsrId());
		
		ResponseDto result = new ResponseDto();
 
		//검토 요청 list
		List<MydashboardVo> getMyAppList = mainService.getMyAppList(mydashboardVo);
		result.putData("getMyAppList", getMyAppList);

		return result;
	}
	
	@GetMapping("/authDetail/{sn}")
	@ApiOperation(value = "승인을 위한 권한 신청 상세 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "sn", value = "권한 신청 키", required = true) 
	})
	public ResponseDto getAuthDetail(@PathVariable(required = true) int sn) throws Exception {

		ResponseDto result = new ResponseDto();
		
		try { 
			//상세 정보 조회
			AuthAppVo confmAuthDetail = mainService.getAuthDetail(sn);
			result.putData("confmDetail", confmAuthDetail);
			
		} catch(Exception e) {
			e.printStackTrace();
			result.setCode(CommonConstants.FAIL);
			result.setMessage("승인을 위한 권한 신청 상세 조회 중  오류가 발생하였습니다.");
			return result;
		}
		return result;
	}
	
	@GetMapping("/reportDetail/{sn}")
	@ApiOperation(value = "승인을 위한 권한 신청 상세 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "sn", value = "데이터 신청 키", required = true) 
	})
	public ResponseDto getReportDetail(@PathVariable(required = true) int sn) throws Exception {

		ResponseDto result = new ResponseDto();
		
		try { 
			//상세 정보 조회
			BiVo confmReportDetail = mainService.getReportDetail(sn);
			result.putData("confmDetail", confmReportDetail);
			
		} catch(Exception e) {
			e.printStackTrace();
			result.setCode(CommonConstants.FAIL);
			result.setMessage("승인을 위한 권한 신청 상세 조회 중  오류가 발생하였습니다.");
			return result;
		}
		return result;
	}
	
	@GetMapping("/dataAppDetail/{sn}")
	@ApiOperation(value = "승인을 위한 권한 신청 상세 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "sn", value = "Bi 키", required = true) 
	})
	public ResponseDto getDataAppDetail(@PathVariable(required = true) String sn) throws Exception {

		ResponseDto result = new ResponseDto();
		
		try {  
			//상세 정보 조회
			DcConfmVo confmDataAppDetail = mainService.getDataAppDetail(sn);
			result.putData("confmDetail", confmDataAppDetail);
			
		} catch(Exception e) {
			e.printStackTrace();
			result.setCode(CommonConstants.FAIL);
			result.setMessage("승인을 위한 권한 신청 상세 조회 중  오류가 발생하였습니다.");
			return result;
		}
		return result;
	}
	
	
	@PostMapping("/confmOkNo")
	@ApiOperation(value = "승인 처리")
	public ResponseDto confmOkNo(@RequestBody MydashboardVo mydashboardVo) throws Exception {
		ResponseDto result = new ResponseDto();

 
		UserInfo userInfo = SessionUtil.getUserInfo(); 
		mydashboardVo.setUserId(userInfo.getUsrId());
		
		int k = 0;
		//블럭체인 연동 체크
		int x = 0;
		try { 
			if (mydashboardVo.getDiv().equals("3")) {
				//데이터 신청 승인 
				
				if (mydashboardVo.getSttus().equals("00002")) {
					//관계사 승인 경우
					k = mainService.setConfmData(mydashboardVo);
					x = dcService.insertDcBlockChainApprovalApi(mydashboardVo.getSn(), approvalUrl);
				}else {
					//요청사 및 반려 및 승인경우  
					if (mydashboardVo.getProvSttus().equals("00001")) {
						k = mainService.setReqConfmData(mydashboardVo);
					}else {
						//관계사 반려입경우
						k = mainService.setConfmData(mydashboardVo);
					}
				}

				
			}else {
				//리포트 공유 및 권한 신청은 키값이 int라서 형변환을 함.
				mydashboardVo.setIntSn(Integer.parseInt(mydashboardVo.getSn()));
				
				if (mydashboardVo.getDiv().equals("1")) {
					k = mainService.setConfmReport(mydashboardVo);
				}else if (mydashboardVo.getDiv().equals("2")){
					
					AuthAppVo authAppVo = new AuthAppVo();
					authAppVo.setSn(mydashboardVo.getIntSn());
					authAppVo.setConfmId(mydashboardVo.getUserId());
					
					k = mainService.setConfmAuthApp(mydashboardVo);
					//승인 처리 일때 권한 자동 변경
					if (mydashboardVo.getSttus().equals("00002")) {
						int re2 = authAppService.confmUsrAuthChang(authAppVo);
					}
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
			result.setCode(CommonConstants.FAIL);
			result.setMessage("승인 처리 중 오류가 발생하였습니다.");
			return result;
		}
		 
		return result;
	}
	
	@GetMapping("/tableList/{transId}")
	@ApiOperation(value = "데이터 요청 신청 테이블  조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "transId", value = "트랜젝션 아이디", required = true) 
	})
	public ResponseDto tableList(@PathVariable(required = true) String transId) throws Exception {

		ResponseDto result = new ResponseDto();
		
		try { 
			//테이블 목록 조회
			List<MydashboardVo> tebleList = mainService.getTebleList(transId);
			result.putData("tebleList", tebleList);
			
		} catch(Exception e) {
			e.printStackTrace();
			result.setCode(CommonConstants.FAIL);
			result.setMessage("데이터 요청 신청 테이블  조회 중  오류가 발생하였습니다.");
			return result;
		}
		return result;
	}
	
	@SuppressWarnings("unused")
	@GetMapping("/connection-health-check")
	@ApiOperation(value = "테이블 연결상태체크")
	public ResponseDto getStatusCheck() throws Exception {

		ResponseDto result = new ResponseDto();
		
		try { 
			//테이블 연결상태 
			int ret = mainService.getStatusCheck();
			result.setMessage("테이블 연결상태 정상");
		} catch(Exception e) {
			e.printStackTrace();
			result.setCode(CommonConstants.FAIL);
			result.setMessage("테이블 연결상태 체크중  오류가 발생하였습니다.");
			return result;
		}
		return result;
	}
	
	

}
