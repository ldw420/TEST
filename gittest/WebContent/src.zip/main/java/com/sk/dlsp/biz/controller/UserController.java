package com.sk.dlsp.biz.controller;

import java.io.File;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.json.CDL;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sk.dlsp.biz.service.UserService;
import com.sk.dlsp.common.consts.CommonConstants;
import com.sk.dlsp.common.exception.BizException;
import com.sk.dlsp.common.util.SessionUtil;
import com.sk.dlsp.model.ResponseDto;
import com.sk.dlsp.model.UserCsvFileVo;
import com.sk.dlsp.model.UserInfo;
import com.sk.dlsp.model.UserVo;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(CommonConstants.API_PREFIX)
public class UserController {
	
	private String USER_CSV_FILE_LOCAL_PATH = "resources/bi/report/";
	@Value("${prov.reprot.image.aws.bucket.name}") String USER_CSV_FILE_AWS_BUCKET_NAME;

	@Autowired
	UserService userService;

	/**
	 * 사용자 목록 조회
	 * 
	 * @param schUsrId
	 * @param schNm
	 * @param schAuth
	 * @return
	 */
	@GetMapping("/user")
	@ApiOperation(value = "사용자 목록 조회")
	@ApiImplicitParams({ @ApiImplicitParam(name = "schUsrId", value = "검색 ID", required = false),
			@ApiImplicitParam(name = "schNm", value = "검색 사용자명", required = false),
			@ApiImplicitParam(name = "schAuth", value = "권한 코드", required = false),
			@ApiImplicitParam(name = "schAgency", value = "관계사 코드", required = false) })
	public ResponseDto getUserList(@RequestParam(required = false) String schUsrId,
			@RequestParam(required = false) String schNm, @RequestParam(required = false) String schAuth,
			@RequestParam(required = false) String schAgency) {
		ResponseDto result = new ResponseDto();
		Map<String, String> param = new HashMap<>();
		param.put("schUsrId", schUsrId);
		param.put("schNm", schNm);
		param.put("schAuth", schAuth);
		param.put("schAgency", schAgency);

		List<UserVo> userList = userService.getUserList(param);		
		result.putData("userList", userList);
		return result;
	}
	
	@GetMapping("/user/csv")
	@ApiOperation(value = "사용자 목록 csv 파일로 저장")
	public ResponseDto getUserListIntoCsvFileByToday() throws Exception {
		UserInfo userInfo = SessionUtil.getUserInfo();
		ResponseDto result = new ResponseDto();
		String jsonString = "";
		JSONObject output;
		try {

			// ---1. Db 데이타 group by 목록 조회------------------------------
			List<UserCsvFileVo> userCsvList = userService.getUserListIntoCsvFileByToday();
			
			Map<String, Object> csvListMap = new HashMap<>();
			csvListMap.put("csvList", userCsvList);
			ObjectMapper om = new ObjectMapper();
			// ---2. Convert List object into json------------------------------
			jsonString = om.writeValueAsString(userCsvList);
			// ---------------------------------
			JSONObject json = new JSONObject (csvListMap);
			JSONArray docs = json.getJSONArray("csvList");
			//*********
			String[] arrSort   = new String[] {"agencyName","registDate","authName","cnt"}; //쿼리문의 alias 와 동일하게 사용해야 함
		    String[] arrTitles = new String[] {"agencyName","registDate","authName","cnt"};
		    JSONArray sortName = new JSONArray(arrSort);
		    JSONArray titles   = new JSONArray(arrTitles);
			//-----------

			// ---3. save file as csv------------------------------
			// fileName: YYYYMMDD
			String strFileName = "serviceportal_user_" + DateTimeFormatter.ofPattern("uuuuMMdd").withZone(ZoneOffset.of("+0900")).format(Instant.now());
			File file = new File(USER_CSV_FILE_LOCAL_PATH + strFileName + ".csv");
			//------------
			StringBuffer sb = new StringBuffer();
		    sb.append(CDL.rowToString(titles));      // 제목부분
		    sb.append(CDL.toString(sortName, docs)); // 내용부분(sort 처리)
		    String csv = sb.toString();
			//------------
			FileUtils.writeStringToFile(file, csv, "euc-kr"); // 한글깨짐 방지용으로 charset=euc-kr

			if (file != null && file.exists()) {
				final AmazonS3 s3 = AmazonS3ClientBuilder.standard().withRegion(Regions.AP_NORTHEAST_2).build();
				s3.putObject(this.USER_CSV_FILE_AWS_BUCKET_NAME, file.getName(), new File(file.getPath()));
				result.putData("fileName", file.getName());
			} else {
				System.out.println("File is null");
				throw new BizException("업로드할 csv 파일이 생성되지 않았습니다.");
			}
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
			throw new BizException("AWS에 csv 저장처리중 오류가 발생했습니다.");
		}
		return result;
	}

	/**
	 * 사용자 상세 조회
	 * 
	 * @param usrId
	 * @return
	 */
	@GetMapping("/user/{usrId}")
	@ApiOperation(value = "사용자 조회")
	@ApiImplicitParams({ @ApiImplicitParam(name = "usrId", value = "사용자 ID", required = true) })
	public ResponseDto getUser(@PathVariable(required = true) String usrId) {
		ResponseDto result = new ResponseDto();
		UserVo userVo = userService.getUser(usrId);
		result.putData("userDetail", userVo);
		return result;
	}

	/**
	 * 사용자 등록
	 * 
	 * @param userVo
	 * @return
	 */
	@PostMapping("/user")
	@ApiOperation(value = "사용자 등록")
	public ResponseDto insertUser(@RequestBody UserVo userVo) {
		ResponseDto result = new ResponseDto();
		SessionUtil.addUserInfo(userVo);
		int re = userService.insertUser(userVo);

		return result;
	}
	


	/**
	 * 사용자 수정
	 * 
	 * @param usrId
	 * @param userVo
	 * @return
	 */
	@PutMapping("/user/{usrId}")
	@ApiOperation(value = "사용자 수정")
	@ApiImplicitParams({ @ApiImplicitParam(name = "usrId", value = "사용자 ID", required = true) })
	public ResponseDto updateUser(@PathVariable(required = true) String usrId, @RequestBody UserVo userVo) {
		ResponseDto result = new ResponseDto();
		userVo.setUsrId(usrId);
		SessionUtil.addUserInfo(userVo);

		int re = userService.updateUser(userVo);
		return result;
	}

	/**
	 * 사용자 삭제
	 * 
	 * @param usrId
	 * @return
	 */
	@DeleteMapping("/user/{usrId}")
	@ApiOperation(value = "사용자 삭제")
	@ApiImplicitParams({ @ApiImplicitParam(name = "usrId", value = "사용자 ID", required = true) })
	public ResponseDto deleteUser(@PathVariable(required = true) String usrId) {
		ResponseDto result = new ResponseDto();
		String[] usrIds = usrId.split(",");
		int re = userService.deleteUser(usrIds);
		return result;
	}
	
	//*****************************************************
	
	//*****************************************************

}
