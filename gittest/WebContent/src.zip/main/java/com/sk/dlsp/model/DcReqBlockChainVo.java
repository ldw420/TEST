package com.sk.dlsp.model;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class DcReqBlockChainVo implements Serializable{

	private static final long serialVersionUID = -8078856054847209913L;
	//
	private String txId;            //트랜젝션 ID
	private String approverCom;     //데이터 공유 요청자.
	private String approver;        //데이터 공유 요청 승인자.
	private String requester;       //데이터 공유 요청자.
	private String requesterCom;    //데이터 공유 요청자.
	private String requestAt;       //데이터 공유 요청일시.
	private String classTitle;       //요청항목의 제목
	private String reqReason;        //요청사유
	//
	private List<DcReqBlockChainDataVo> consentDetailDTOList; //상세  데이타정보
	
	

	public String getTxId() {
		return txId;
	}



	public void setTxId(String txId) {
		this.txId = txId;
	}



	public String getApproverCom() {
		return approverCom;
	}



	public void setApproverCom(String approverCom) {
		this.approverCom = approverCom;
	}



	public String getApprover() {
		return approver;
	}



	public void setApprover(String approver) {
		this.approver = approver;
	}



	public String getRequester() {
		return requester;
	}



	public void setRequester(String requester) {
		this.requester = requester;
	}



	public String getRequesterCom() {
		return requesterCom;
	}



	public void setRequesterCom(String requesterCom) {
		this.requesterCom = requesterCom;
	}



	public String getRequestAt() {
		return requestAt;
	}



	public void setRequestAt(String requestAt) {
		this.requestAt = requestAt;
	}



	public String getClassTitle() {
		return classTitle;
	}



	public void setClassTitle(String classTitle) {
		this.classTitle = classTitle;
	}



	public String getReqReason() {
		return reqReason;
	}



	public void setReqReason(String reqReason) {
		this.reqReason = reqReason;
	}



	public List<DcReqBlockChainDataVo> getConsentDetailDTOList() {
		return consentDetailDTOList;
	}



	public void setConsentDetailDTOList(List<DcReqBlockChainDataVo> consentDetailDTOList) {
		this.consentDetailDTOList = consentDetailDTOList;
	}



	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this,ToStringStyle.MULTI_LINE_STYLE); 
	}


	
	
		
	
	
}
