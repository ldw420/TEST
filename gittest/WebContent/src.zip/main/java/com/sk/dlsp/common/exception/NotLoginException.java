package com.sk.dlsp.common.exception;

public class NotLoginException extends Exception{

	private static final long serialVersionUID = -363625966745779593L;

	public NotLoginException() {

	}
	public NotLoginException(String message) {
        super(message);
    }


}
