package com.sk.dlsp.biz.mapper;

import java.util.List; 

import org.apache.ibatis.annotations.Mapper;

import com.sk.dlsp.model.AuthVo;
import com.sk.dlsp.model.PdeVo; 

@Mapper
public interface PdeMapper {

    public List<PdeVo> getPdeList(); 
    
    public int insertPde(PdeVo vo);
    
    public List<PdeVo> getPdeDetail(PdeVo vo); 
 

}
