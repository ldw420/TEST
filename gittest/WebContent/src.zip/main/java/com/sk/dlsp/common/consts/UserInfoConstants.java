package com.sk.dlsp.common.consts;

public class UserInfoConstants {

	public final static String USRID = "usrid";
	public final static String NM = "nm";
	public final static String AGENCY = "agency";
	public static final String AGENCY_NM = "agencyNm";
	public final static String DEPTCODE = "deptcode";
	public final static String DEPTNAME = "deptname";
	public final static String PARTNERYN = "partneryn";
	public final static String AUTH_ID = "authId";
	public final static String AUTH_NM = "authNm";
	public final static String PW_CHG_CD = "pwChgCd";

}
