package com.sk.dlsp.model;

public class MetaDataCopmVo {
	private String classKey;
	private String cmpCompanyCode;

	public String getClassKey() {
		return classKey;
	}
	public void setClassKey(String classKey) {
		this.classKey = classKey;
	}
	public String getCmpCompanyCode() {
		return cmpCompanyCode;
	}
	public void setCmpCompanyCode(String cmpCompanyCode) {
		this.cmpCompanyCode = cmpCompanyCode;
	}
}
