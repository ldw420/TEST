package com.sk.dlsp.bi.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.sk.dlsp.model.GalleryVo;
import com.sk.dlsp.model.GalleryVoEx;

@Mapper
public interface GalleryMapper {

	List<GalleryVoEx> getList(Map<String, Object> param);

	GalleryVoEx getOne(GalleryVo vo);

	int insertGalleryData(GalleryVo vo);

	int updateGalleryData(GalleryVo vo);

	int deleteGalleryDataAll();

	int deleteGalleryData(GalleryVo vo);

	int deleteGalleryMappingAll();
	
	int deleteGalleryMapping();

	int insertGalleryMapping(Map<String, Object> galleryVo);

	List<Map<String, Object>> getNotMappingCountByIndustry();

	List<Map<String, Object>> getCountByIndustry();

	int getMappingCount();
}
