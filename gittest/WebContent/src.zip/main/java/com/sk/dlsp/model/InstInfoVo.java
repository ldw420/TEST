package com.sk.dlsp.model;

public class InstInfoVo extends CommonVo{ 

	private String instanceName;
	private int cntDataset;
	
	
	public String getInstanceName() {
		return instanceName;
	}
	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}
	public int getCntDataset() {
		return cntDataset;
	}
	public void setCntDataset(int cntDataset) {
		this.cntDataset = cntDataset;
	}
}
