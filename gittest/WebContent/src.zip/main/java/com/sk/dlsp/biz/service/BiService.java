package com.sk.dlsp.biz.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sk.dlsp.biz.mapper.BiMapper;
import com.sk.dlsp.model.BiVo;

@Service
@Transactional
public class BiService {
    @Autowired BiMapper biMapper;

	public List<BiVo> getBiList(Map<String, Object> param){
		return biMapper.getBiList(param);
	}
	
	public List<BiVo> getBiAdminList(Map<String, Object> param){
		return biMapper.getBiAdminList(param);
	}
	
	public List<BiVo> getBiCtgList(Map<String, Object> param){
		return biMapper.getBiCtgList(param);
	}
	
	public List<BiVo> getBiCopmList(Map<String, Object> param){
		return biMapper.getBiCopmList(param);
	}
	
	 
	
	public List<BiVo> getPrevNextBiReport(Map<String, Object> param){
		return biMapper.getPrevNextBiReport(param);
	}

	public BiVo getBiDetail(int sn) {
		return biMapper.getBiDetail(sn);
	}

	public int insertBi(BiVo biVo) {
		return biMapper.insertBi(biVo);
	}

	public int updateBi(BiVo biVo) {
		return biMapper.updateBi(biVo);
	}
	
	public int updateBiCnt(int sn) {
		return biMapper.updateBiCnt(sn);
	}

	public int deleteBi(int[] biIds) {
		return biMapper.deleteBi(biIds);
	}
	
	public int getBiListCount(Map<String, Object> param) {
		return biMapper.getBiListCount(param);
	}
	
	public int getBiAdminListCount(Map<String, Object> param) {
		return biMapper.getBiAdminListCount(param);
	}
	
	public int insertScrap(BiVo biVo) {
		return biMapper.insertScrap(biVo);
	}
	
	public int deleteScrap(BiVo biVo) {
		return biMapper.deleteScrap(biVo);
	}

	public int insertBiSearchWord(Map<String, Object> param) {
		return biMapper.insertBiSearchWord(param);
	}
	
}
