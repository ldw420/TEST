package com.sk.dlsp.biz.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sk.dlsp.biz.service.PdeService;
import com.sk.dlsp.common.consts.CommonConstants;
import com.sk.dlsp.common.util.SessionUtil;
import com.sk.dlsp.model.PdeVo;
import com.sk.dlsp.model.ResponseDto;
import com.sk.dlsp.model.UserInfo;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(CommonConstants.API_PREFIX + "/pde")
public class PdeController {

	@Autowired
	PdeService pdeService;

	/**
	 * 서약서 목록 조회.
	 * 
	 * @param 
	 * @return 
	 * @throws
	 */
	@GetMapping("/pde")
	@ApiOperation(value = "서약서  조회")
	public ResponseDto getPdeList() {

		List<PdeVo> pdeList = pdeService.getPdeList();

		ResponseDto result = new ResponseDto();
		result.putData("pdeList", pdeList);
		return result;
	}

	/**
	 * 서약서 상세 조회.
	 * 
	 * @param sn 
	 * @param pdeVo 
	 * @return @throws
	 */
	@GetMapping("/pde/{sn}")
	@ApiOperation(value = "서약서 상세 조회")
	@ApiImplicitParams({ @ApiImplicitParam(name = "sn", value = "서약서 순번", required = true) })
	public ResponseDto getPdeDetail(@PathVariable(required = true) int sn, PdeVo pdeVo) {

		pdeVo.setSn(sn);
		List<PdeVo> pdeList = pdeService.getPdeDetail(pdeVo);

		ResponseDto result = new ResponseDto();
		result.putData("pdeList", pdeList);
		return result;
	}

	/**
	 * 서약서 등록.
	 * 
	 * @param pdeVo 
	 * @return @throws
	 */
	@PostMapping("/pde")
	@ApiOperation(value = "서약서 추가")
	public ResponseDto insertAuth(@RequestBody PdeVo pdeVo, HttpServletRequest request) {
		ResponseDto result = new ResponseDto();
		SessionUtil.addUserInfo(pdeVo);
		try {

			int re = pdeService.insertPde(pdeVo);

		} catch (Exception e) {
			e.printStackTrace();
			result.setCode(CommonConstants.FAIL);
			result.setMessage("서약서 등록 처리중 오류가 발생하였습니다.");
			return result;
		}
		return result;

	}

}
