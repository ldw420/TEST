package com.sk.dlsp.biz.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sk.dlsp.biz.mapper.CompInfoMapper;
import com.sk.dlsp.model.CompInfoVo;

@Service
@Transactional
public class CompInfoService {
	
	@Autowired CompInfoMapper compInfoMapper;

	public List<CompInfoVo> getCompInfoList(Map<String, Object> param) {
		return compInfoMapper.getCompInfoList(param);
	}

	public int getCompInfoListCount(Map<String, Object> param) {
		return compInfoMapper.getCompInfoListCount(param);
	}

	public int insertCompInfoList(CompInfoVo compInfoVo) {
		return compInfoMapper.insertCompInfoList(compInfoVo);
	}

	
}
