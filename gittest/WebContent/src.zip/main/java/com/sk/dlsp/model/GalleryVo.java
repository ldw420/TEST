package com.sk.dlsp.model;

/*
	CREATE TABLE dlp.sp_ma_bi_gallery (
	  bi_rep_sj character varying(200), -- BI REPORT 제목
	  industry_id character varying(100), -- 산업구분id
	  industry_name character varying(100), -- 산업구분이름
	  cn character varying(4000), -- 상세 내용
	  img_name character varying(100), -- 이미지 이름
	  wid character varying(100), -- workbook id
	  vid character varying(100), -- view id
	  view_content_url character varying(100), -- view content url
	  CONSTRAINT sp_ma_bi_gallery_pk PRIMARY KEY (wid, vid)
	);
 */
public class GalleryVo {

	private String biRepSj;
	private String industryId;
	private String industryName;
	private String cn;
	private String imgName;
	private String wid;
	private String vid;
	private String viewContentUrl;

	public String getBiRepSj() {
		return biRepSj;
	}

	public void setBiRepSj(String biRepSj) {
		this.biRepSj = biRepSj;
	}

	public String getIndustryId() {
		return industryId;
	}

	public void setIndustryId(String industryId) {
		this.industryId = industryId;
	}

	public String getIndustryName() {
		return industryName;
	}

	public void setIndustryName(String industryName) {
		this.industryName = industryName;
	}

	public String getCn() {
		return cn;
	}

	public void setCn(String cn) {
		this.cn = cn;
	}

	public String getImgName() {
		return imgName;
	}

	public void setImgName(String imgName) {
		this.imgName = imgName;
	}

	public String getWid() {
		return wid;
	}

	public void setWid(String wid) {
		this.wid = wid;
	}

	public String getVid() {
		return vid;
	}

	public void setVid(String vid) {
		this.vid = vid;
	}

	public String getViewContentUrl() {
		return viewContentUrl;
	}

	public void setViewContentUrl(String viewContentUrl) {
		this.viewContentUrl = viewContentUrl;
	}

}
