package com.sk.dlsp.model;

public class CodeGroupVo extends CommonVo{

	private String groupCodeId;
	private String groupCodeNm;
	private String groupCodeDc;
	private String useAt;

	public String getGroupCodeId() {
		return groupCodeId;
	}
	public void setGroupCodeId(String groupCodeId) {
		this.groupCodeId = groupCodeId;
	}
	public String getGroupCodeNm() {
		return groupCodeNm;
	}
	public void setGroupCodeNm(String groupCodeNm) {
		this.groupCodeNm = groupCodeNm;
	}
	public String getGroupCodeDc() {
		return groupCodeDc;
	}
	public void setGroupCodeDc(String groupCodeDc) {
		this.groupCodeDc = groupCodeDc;
	}

	public String getUseAt() {
		return useAt;
	}
	public void setUseAt(String useAt) {
		this.useAt = useAt;
	}

}
