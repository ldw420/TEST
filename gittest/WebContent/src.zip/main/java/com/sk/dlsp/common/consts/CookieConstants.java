package com.sk.dlsp.common.consts;

public class CookieConstants {

	public final static String USRID = "sessionUsrId";
	public final static String NM = "sessionNm";
	public final static String AGENCY = "sessionAgency";
	public final static String CTTPC = "sessionCttpc";
	public final static String AUTH_ID = "sessionAuthId";
	public final static String AUTH_NM = "sessionAuthNm";


}
