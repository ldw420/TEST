package com.sk.dlsp.biz.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sk.dlsp.biz.mapper.BbsMapper;
import com.sk.dlsp.model.BbsAnswerVo;
import com.sk.dlsp.model.BbsVo;

@Service
@Transactional
public class BbsService {

	@Autowired BbsMapper bbsMapper;

	public List<BbsVo> getBbsList(Map<String,Object> param){
		return bbsMapper.getBbsList(param);
	}

	public int getBbsListCount(Map<String, Object> param) {
		return bbsMapper.getBbsListCount(param);
	}
	public int insertBbs(BbsVo bbsVo) {
		return bbsMapper.insertBbs(bbsVo);
	}

	public BbsVo getBbsDetail(BbsVo bbsVo) {
		BbsVo detailVo = bbsMapper.getBbsDetail(bbsVo);
		return detailVo;
	}
	public int updateBbsRdcnt(BbsVo bbsVo) {
		return bbsMapper.updateBbsRdcnt(bbsVo);
	}
	public int updateBbs(BbsVo bbsVo) {
		return bbsMapper.updateBbs(bbsVo);
	}

	public int deleteBbs(BbsVo bbsVo) {
		return bbsMapper.deleteBbs(bbsVo);
	}

	public BbsAnswerVo getBbsAnswer(BbsVo bbsVo) {
		return bbsMapper.getBbsAnswer(bbsVo);
	}

	public int insertBbsAnswer(BbsAnswerVo bbsAnswerVo) {
		return bbsMapper.insertBbsAnswer(bbsAnswerVo);
	}

	public int updateBbsAnswer(BbsAnswerVo bbsAnswerVo) {
		return bbsMapper.updateBbsAnswer(bbsAnswerVo);
	}

}
