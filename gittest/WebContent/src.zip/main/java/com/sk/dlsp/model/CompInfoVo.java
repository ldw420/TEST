package com.sk.dlsp.model;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class CompInfoVo {
	
	private String groupCodeId;
	private String detailCodeId;
	private String detailCodeNm;
	private String useAt;
	private String compabrvnm;
	private String subnetId;
	private String securityGroup;
	private String registerId;
	private String updtId;
	private String accountId;
	public String getGroupCodeId() {
		return groupCodeId;
	}
	public void setGroupCodeId(String groupCodeId) {
		this.groupCodeId = groupCodeId;
	}
	public String getDetailCodeId() {
		return detailCodeId;
	}
	public void setDetailCodeId(String detailCodeId) {
		this.detailCodeId = detailCodeId;
	}
	public String getDetailCodeNm() {
		return detailCodeNm;
	}
	public void setDetailCodeNm(String detailCodeNm) {
		this.detailCodeNm = detailCodeNm;
	}
	public String getUseAt() {
		return useAt;
	}
	public void setUseAt(String useAt) {
		this.useAt = useAt;
	}
	public String getCompabrvnm() {
		return compabrvnm;
	}
	public void setCompabrvnm(String compabrvnm) {
		this.compabrvnm = compabrvnm;
	}
	public String getSubnetId() {
		return subnetId;
	}
	public void setSubnetId(String subnetId) {
		this.subnetId = subnetId;
	}
	public String getSecurityGroup() {
		return securityGroup;
	}
	public void setSecurityGroup(String securityGroup) {
		this.securityGroup = securityGroup;
	}
	public String getRegisterId() {
		return registerId;
	}
	public void setRegisterId(String registerId) {
		this.registerId = registerId;
	}
	public String getUpdtId() {
		return updtId;
	}
	public void setUpdtId(String updtId) {
		this.updtId = updtId;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this,ToStringStyle.MULTI_LINE_STYLE); 
	}
	

}
