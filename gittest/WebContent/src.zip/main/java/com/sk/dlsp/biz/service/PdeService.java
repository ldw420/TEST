package com.sk.dlsp.biz.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sk.dlsp.biz.mapper.PdeMapper;
import com.sk.dlsp.model.PdeVo; 

@Service
@Transactional
public class PdeService {
    @Autowired PdeMapper pdeMapper;

	public List<PdeVo> getPdeList(){
		return pdeMapper.getPdeList();
	}
	
	public int insertPde(PdeVo vo) {
		return pdeMapper.insertPde(vo);
	}
	
	public List<PdeVo> getPdeDetail(PdeVo vo) {
		return pdeMapper.getPdeDetail(vo);
	}
 
 

}
