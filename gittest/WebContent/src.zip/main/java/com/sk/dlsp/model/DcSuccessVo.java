package com.sk.dlsp.model;

public class DcSuccessVo {

	private String transId;
	private String reqTbl;
    private String sussYn;
	public String getTransId() {
		return transId;
	}
	public void setTransId(String transId) {
		this.transId = transId;
	}
	
	public String getReqTbl() {
		return reqTbl;
	}
	public void setReqTbl(String reqTbl) {
		this.reqTbl = reqTbl;
	}
	public String getSussYn() {
		return sussYn;
	}
	public void setSussYn(String sussYn) {
		this.sussYn = sussYn;
	}
    
    
    
    
    
	

}
