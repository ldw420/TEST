package com.sk.dlsp.model;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.fasterxml.jackson.annotation.JsonIgnore;


public class DcTableInfoVo implements Serializable{

	@JsonIgnore
	private static final long serialVersionUID = -7606434273377956101L;
	
	private List<DcTableParamVo> tableInfo; //상세  데이타정보

	public List<DcTableParamVo> getTableInfo() {
		return tableInfo;
	}

	public void setTableInfo(List<DcTableParamVo> tableInfo) {
		this.tableInfo = tableInfo;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this,ToStringStyle.MULTI_LINE_STYLE); 
	}
	

	
}
