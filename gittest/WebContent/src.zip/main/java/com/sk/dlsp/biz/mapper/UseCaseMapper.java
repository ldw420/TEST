package com.sk.dlsp.biz.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.sk.dlsp.model.UseCaseVo;

@Mapper
public interface UseCaseMapper {

	public List<UseCaseVo> getUseCaseList(Map<String, Object> param);

	public int getUseCaseListCount(Map<String, Object> param);

	public UseCaseVo getUseCaseDetail(int sn);

	public int insertUseCase(UseCaseVo useCaseVo);

	public int updateUseCase(UseCaseVo useCaseVo);

	public int deleteUseCase(int[] useCaseIds);

}
