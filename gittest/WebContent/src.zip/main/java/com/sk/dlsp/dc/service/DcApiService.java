package com.sk.dlsp.dc.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.json.JSONTokener;
import org.json.XML;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.parser.Parser;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sk.dlsp.common.util.StringUtil;
import com.sk.dlsp.dc.mapper.DcMapper;
import com.sk.dlsp.model.CodeDetailVo;
import com.sk.dlsp.model.DcVo;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

@Service
@Transactional
public class DcApiService {
	@Autowired DcMapper dcMapper;

	public List<DcVo> getDcList(Map<String, Object> param) {
		return dcMapper.getDcList(param);
	}

	public int getDcListCount(Map<String, Object> param) {
		return dcMapper.getDcListCount(param);
	}
	
	public List<CodeDetailVo> getDcCodeInfoList(Map<String, Object> param) {
		return dcMapper.getDcCodeInfoList(param);
	}

	/*
	 * public List<DcVo> getDcCopmList(Map<String, Object> param) { return
	 * dcMapper.getDcCopmList(param); }
	 */
	
	/**
	 * Lv3 api 목록조회시 사용
	 */
	@SuppressWarnings("unchecked")
	public String getXmlApi(String reqUrl) throws Exception {
		//-----------------
		Document doc = Jsoup.connect(reqUrl).header("accept", "application/xhtml+xml; charset=utf-8").parser(Parser.xmlParser()).get();

		if(doc != null && !StringUtil.isEmpty(doc.toString() ) ) {
			Elements items = doc.select("item"); // item is a root tag
			
			if (items != null && !StringUtil.isEmpty(items.toString())) {
				org.json.JSONObject xmlJSONObj = XML.toJSONObject(items.toString());
				String xmlJSONObjString = xmlJSONObj.toString();
			
				//items 가 1개만 있는 경우는 Object 타입이므로 List 타입으로 변형작업
				if(items.size() == 1) {
					
					ObjectMapper om = new ObjectMapper();
					Map<String,Object> tmpMap = om.readValue(xmlJSONObjString, Map.class);
					Map<String,Object> subItemTmpMap = (Map<String, Object>) tmpMap.get("item");
					
					String strJsonMap = om.writeValueAsString(subItemTmpMap);
					Map<String,Object> subItemMap = om.readValue(strJsonMap, Map.class);
					
					List<Map<String,Object>> tmpList = new ArrayList<>();
					tmpList.add(subItemMap);
					Map<String,Object> rMap = new HashMap<>();
					rMap.put("item", tmpList);
					xmlJSONObjString = om.writeValueAsString(rMap);					
				}
				return xmlJSONObjString;
			} else {
				return "";
			}
			
		} else {
			return "";
		}
	}
	
//	public String postXmlApi(String reqUrl) throws Exception {
//		//-----------------
//		Document doc = Jsoup.connect(reqUrl).header("accept", "application/xhtml+xml; charset=utf-8").parser(Parser.xmlParser()).post();
//		Elements items = doc.select("item"); // item is a root tag
//		
//		org.json.JSONObject xmlJSONObj = XML.toJSONObject(items.toString());
//		String xmlJSONObjString = xmlJSONObj.toString();
//		
//		return xmlJSONObjString;
//	}
	
	
	public String apiGet(String requestURL) {
		String retVal = "";
		try {
			OkHttpClient.Builder builder = new OkHttpClient.Builder();
			builder.connectTimeout(30, TimeUnit.SECONDS); 
			builder.readTimeout(30, TimeUnit.SECONDS); 
			builder.writeTimeout(30, TimeUnit.SECONDS);
			OkHttpClient client = new OkHttpClient();
			client = builder.build();
			
			Request request = new Request.Builder()
					.url(requestURL)
					.build(); //GET Request 
                        
                       //동기 처리시 execute함수 사용 
			Response response = client.newCall(request).execute(); 
			
			int resultCode = response.code();
			if(resultCode == 200) {
				//출력
				String message = response.body().string();
				
				// 추가항목이 있는 경우
				Map<String,Object> rMap = new HashMap<>();
				rMap.putAll(this.jsonMerge(message, rMap));
				rMap.put("code", resultCode);
				rMap.put("message", "success");
				// return value
				retVal = new ObjectMapper().writeValueAsString(rMap);
				
			} else {
				retVal = "fail";
			}

		} catch (Exception e){
			retVal = "exception";
		}
		
		return retVal;
	}
	
	public String apiPost(String requestURL, String jsonMessage) throws Exception{
		String retVal = "";
		try{
			OkHttpClient.Builder builder = new OkHttpClient.Builder();
			builder.connectTimeout(30, TimeUnit.SECONDS); 
			builder.readTimeout(30, TimeUnit.SECONDS); 
			builder.writeTimeout(30, TimeUnit.SECONDS);
			OkHttpClient client = new OkHttpClient();
			client = builder.build();
		    
			Request request = new Request.Builder()
					.url(requestURL)
					.post(RequestBody.create(MediaType.parse("application/json"), jsonMessage)) //POST로 전달할 내용 설정 
					.build();

            //동기 처리시 execute함수 사용
			Response response = client.newCall(request).execute();  
			
			int resultCode = response.code();
			if(resultCode == 200) {
				//출력
				String resultBody = response.body().string();
				
				Map<String,Object> rMap = new HashMap<>();
				retVal = resultBody;
				
			} else {
				retVal = "fail";
			}

		} catch (Exception e) {
			System.err.println("apiPost Exception::" + e.getMessage());
			retVal = "exception";
		}
		
		return retVal;
	}
	
	
	@SuppressWarnings({ "unchecked", "unused" })
	private Map<String,Object> jsonMerge(String jsonData, Map<String,Object> map) throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper om = new ObjectMapper();
		Map<String,Object> retMap = new HashMap<>();
		//---------------------------------
		Object json = new JSONTokener(jsonData).nextValue();
		List<Map<String,Object>> list;
		if (json instanceof Map) {
			List<Map<String,Object>> retList = new ArrayList<>();
			Map<String, Object> map1 = om.readValue(jsonData, Map.class);
			Map<String, Object> map2 = map;
			Map<String, Object> merged = new HashMap<String, Object>(map2);
			merged.putAll(map1);
			retList.add(merged);
			merged.put("data", retList);
			retMap.putAll(merged);
		} else if (json instanceof List) {
			List<Map<String,Object>> datalist = om.readValue(jsonData, List.class);
			Map<String, Object> merged = new HashMap<String, Object>();
			merged.put("data", datalist);
			retMap.putAll(merged);
		} else {
//			System.out.println("etc-----------------------");
		}
		return retMap;
	}
	
	

}
