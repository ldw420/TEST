package com.sk.dlsp.biz.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.sk.dlsp.model.MenuVo;

@Mapper
public interface MenuMapper {

	public List<MenuVo> getMenuList(Map<String,String> param);

	public MenuVo getMenuDetail(String menuId);
	
	public int getCntMenuNm(MenuVo menuVo);
	
	public String getMaxMenuCode();

	public int insertMenu(MenuVo menuVo);

	public int updateMenu(MenuVo menuVo);

	public int deleteMenu(String[] menuIds);
	
	public int getMenuCheck(MenuVo menuVo);

}
