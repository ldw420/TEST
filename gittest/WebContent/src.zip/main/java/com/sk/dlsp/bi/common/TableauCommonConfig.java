package com.sk.dlsp.bi.common;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.sk.dlsp.bi.bindings.ProjectType;
import com.sk.dlsp.bi.bindings.SiteListType;
import com.sk.dlsp.bi.bindings.SiteType;
import com.sk.dlsp.bi.bindings.TableauCredentialsType;
import com.sk.dlsp.bi.bindings.WorkbookType;
import com.sk.dlsp.bi.restapi.RestApiUtils;
import com.sk.dlsp.bi.service.GalleryService;

@Component("tableauCommonConfig")
@PropertySource(value = { "classpath:application.properties" })
public class TableauCommonConfig {
	
	static Logger _log = LoggerFactory.getLogger( TableauCommonConfig.class.getName());

	@Autowired
	private GalleryService galleryService;

	// application.properties에 정의한 내용
	@Value("${tableau.server.url}")
	private static String tableauServerUrl;
	@Value("${tableau.server.admin.id}")
	private String tableauServerAdminId;
	@Value("${tableau.server.admin.pw}")
	private String tableauServerAdminPw;
	@Value("${tableau.server.sitename}")
	private String tableauSiteName;
	@Value("${tableau.server.embed.url}")
	private String tableauServerEmbedUrl;
	@Value("${tableau.server.sitecontenturl}")
	private String tableauSiteContentUrl;

	/* 서비스 기동시 가져올 정보들 */
	private static TableauCredentialsType tableauAdminCredentials;
	private static long adminCredentialsFetchTime;
	// embeded url 만들기 위해 가져옴
	private static List<WorkbookType> allWorkbookList;
	// 갤러리 화면을 위해 가져옴
	private static List<WorkbookType> galleryWorkbookList;
	// 갤러리 산업구분을 위해 가져옴
	private static List<ProjectType> galleryIndustryList;
	// embeded url 만들기 위해 가져옴
	private static List<SiteType> siteTypeList;
	private static SiteType siteType;

	public void getTableauInformation() {

		long startTime = System.currentTimeMillis();

		try {

			// tableau admin credentials (rest-api 사용을 위해 필요함.)
			setTableauAdminCredentials(signInAdmin(getTableauSiteContentUrl()));
			setAdminCredentialsFetchTime(new Date().getTime());

			// tableau site
			setSiteType(setSite(getTableauAdminCredentials()));

			// 갤러리 데이터 세팅
			galleryService.setGalleryData(getTableauAdminCredentials(), getSiteType());
		} catch (Exception e) {
			_log.error(e.toString());
		} finally {
			System.out.println(
					"End to Load Tableau Data(" + ((System.currentTimeMillis() - startTime) / 1000.0) + " sec.)");
		}
	}

	private TableauCredentialsType signInAdmin(String siteContentUrl) throws Exception {
		String tableauServerUrl = getTableauServerUrl();
		String tableauServerAdminId = getTableauServerAdminId();
		String tableauServerAdminPw = getTableauServerAdminPw();

		if (tableauServerUrl != null && tableauServerAdminId != null && tableauServerAdminPw != null) {
			RestApiUtils restApiUtils = RestApiUtils.getInstance();

			TableauCredentialsType adminCredentials = restApiUtils.invokeSignIn(tableauServerAdminId,
					tableauServerAdminPw, (siteContentUrl == null ? "" : siteContentUrl));

			if (adminCredentials == null) {
				throw new Exception("태블로 로그인 실패.");
			}

			return adminCredentials;
		}

		return null;
	}

	private SiteType setSite(TableauCredentialsType adminCredentials) throws Exception {

		SiteType ret = null;

		if (adminCredentials == null) {
			adminCredentials = getTableauAdminCredentials();
		}

		RestApiUtils restApiUtils = RestApiUtils.getInstance();

		SiteListType siteListType = restApiUtils.invokeQuerySites(adminCredentials);
		if (siteListType != null) {
			List<SiteType> siteTypeList = siteListType.getSite();
			if (siteTypeList != null && !siteTypeList.isEmpty()) {

				setSiteTypeList(siteTypeList);

				if (siteTypeList.size() == 1) {
					setSiteType(siteTypeList.get(0));
					ret = siteTypeList.get(0);
				} else {
					String siteName = getTableauSiteName();

					for (SiteType siteType : siteTypeList) {
						if (siteName != null) {
							if (siteName.equals(siteType.getName())) {
								setSiteType(siteType);
								ret = siteType;
								break;
							}
						}
					}
				}
			}
		}

		return ret;
	}

	public static String getTableauServerUrl() {
		return tableauServerUrl;
	}

	@Value("${tableau.server.url}")
	public void setTableauServerUrl(String tableauServerUrl2) {
		tableauServerUrl = tableauServerUrl2;
	}

	public String getTableauServerEmbedUrl() {
		return tableauServerEmbedUrl;
	}

	public void setTableauServerEmbedUrl(String tableauServerEmbedUrl) {
		this.tableauServerEmbedUrl = tableauServerEmbedUrl;
	}

	public String getTableauServerAdminId() {
		return tableauServerAdminId;
	}

	public void setTableauServerAdminId(String tableauServerAdminId) {
		this.tableauServerAdminId = tableauServerAdminId;
	}

	public String getTableauServerAdminPw() {
		return tableauServerAdminPw;
	}

	public void setTableauServerAdminPw(String tableauServerAdminPw) {
		this.tableauServerAdminPw = tableauServerAdminPw;
	}

	public TableauCredentialsType getTableauAdminCredentials() {
		// 태블로 admin credentials는 240분이 제한시간(default)이기에 230분마다 다시 가져온다.
		long idleLimitMin = 230;
		long now = new Date().getTime();

		long limittedTime = new Date(this.getAdminCredentialsFetchTime() + (idleLimitMin * 60000)).getTime();

		if (now >= limittedTime) {
			try {
				TableauCredentialsType adminCredentials = galleryService.signInAdmin(null, getTableauServerUrl(),
						this.getTableauServerAdminId(), this.getTableauServerAdminPw());
				this.setTableauAdminCredentials(adminCredentials);
			} catch (Exception e) {
				_log.error(e.toString());

				return null;
			}
		}

		return tableauAdminCredentials;
	}

	public void setTableauAdminCredentials(TableauCredentialsType tableauAdminCredentials2) {
		tableauAdminCredentials = tableauAdminCredentials2;
	}

	public long getAdminCredentialsFetchTime() {
		return adminCredentialsFetchTime;
	}

	public void setAdminCredentialsFetchTime(long adminCredentialsFetchTime2) {
		adminCredentialsFetchTime = adminCredentialsFetchTime2;
	}

	public List<WorkbookType> getAllWorkbookList() {
		return allWorkbookList;
	}

	public synchronized void setAllWorkbookList(List<WorkbookType> allWorkbookList2) {
		allWorkbookList = allWorkbookList2;
	}

	public synchronized List<WorkbookType> getGalleryWorkbookList() {
		return galleryWorkbookList;
	}

	public synchronized void setGalleryWorkbookList(List<WorkbookType> galleryWorkbookList2) {
		galleryWorkbookList = galleryWorkbookList2;
	}

	public String getTableauSiteName() {
		return tableauSiteName;
	}

	public void setTableauSiteName(String tableauSiteName) {
		this.tableauSiteName = tableauSiteName;
	}

	public List<SiteType> getSiteTypeList() {
		return siteTypeList;
	}

	public void setSiteTypeList(List<SiteType> siteTypeList2) {
		siteTypeList = siteTypeList2;
	}

	public SiteType getSiteType() {

		if (siteType == null) {
			try {
				this.setSiteType(setSite(getTableauAdminCredentials()));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				_log.error(e.toString());
			}
		}

		return siteType;
	}

	public void setSiteType(SiteType siteType2) {
		siteType = siteType2;
	}

	public synchronized List<ProjectType> getGalleryIndustryList() {
		return galleryIndustryList;
	}

	public synchronized void setGalleryIndustryList(List<ProjectType> galleryIndustryList2) {
		galleryIndustryList = galleryIndustryList2;
	}

	public String getTableauSiteContentUrl() {
		return tableauSiteContentUrl;
	}

	public void setTableauSiteContentUrl(String tableauSiteContentUrl) {
		this.tableauSiteContentUrl = tableauSiteContentUrl;
	}

}
