package com.sk.dlsp.biz.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sk.dlsp.biz.service.WordService;
import com.sk.dlsp.common.consts.CommonConstants;
import com.sk.dlsp.common.util.SessionUtil;
import com.sk.dlsp.model.BbsAnswerVo;
import com.sk.dlsp.model.BbsVo;
import com.sk.dlsp.model.ResponseDto;
import com.sk.dlsp.model.WordVo;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(CommonConstants.API_PREFIX)
public class WordController {

	@Autowired
	WordService wordService;

	/**
	 * 용어 사전 조회
	 * 
	 * @param schKoreanNm
	 * @return
	 */
	@GetMapping("/word")
	@ApiOperation(value = "용어 사전 조회")
	@ApiImplicitParams({ @ApiImplicitParam(name = "schKoreanNm", value = "검색 한글명", required = false) })
	public ResponseDto getWordList(@RequestParam(required = false) String schKoreanNm) {
		Map<String, String> param = new HashMap<>();
		param.put("schKoreanNm", schKoreanNm);

		List<WordVo> wordList = wordService.getWordList(param);

		ResponseDto result = new ResponseDto();
		result.putData("wordList", wordList);
		return result;
	}

	/**
	 * 용어 사전 상세 조회
	 * 
	 * @param sn
	 * @return
	 */
	@GetMapping("/word/{sn}")
	@ApiOperation(value = "용어 사전 상세 조회")
	@ApiImplicitParams({ @ApiImplicitParam(name = "sn", value = "순번", required = false) })
	public ResponseDto getWordDetail(@PathVariable(required = true) int sn) {
		WordVo wordVo = new WordVo();
		wordVo.setSn(sn);

		List<WordVo> wordList = wordService.getWordDetail(wordVo);

		ResponseDto result = new ResponseDto();
		result.putData("wordList", wordList);
		return result;
	}

	/**
	 * 용어 사전 등록
	 * 
	 * @param wordVo
	 * @return
	 */
	@PostMapping("/word")
	@ApiOperation(value = "용어 사전 등록")
	public ResponseDto insertWord(@RequestBody WordVo wordVo) {
		SessionUtil.addUserInfo(wordVo);
		int re = wordService.insertWord(wordVo);

		ResponseDto result = new ResponseDto();
		return result;
	}

	/**
	 * 용어 사전 삭제
	 * 
	 * @param wordId
	 * @return
	 */
	@DeleteMapping("/word/{wordId}")
	@ApiOperation(value = "용어 사전 삭제")
	@ApiImplicitParams({ @ApiImplicitParam(name = "wordId", value = "용어 키", required = true) })
	public ResponseDto deleteWord(@PathVariable(required = true) String wordId) {
		String[] wordSplit = wordId.split(",");
		ResponseDto result = new ResponseDto();
		try {
			int[] wordIds = Arrays.stream(wordSplit).mapToInt(Integer::parseInt).toArray();
			int re = wordService.deleteWord(wordIds);
		} catch (NumberFormatException ne) {
			result.setCode(CommonConstants.FAIL);
			result.setMessage("잘못된 키값입니다.");
		}
		return result;
	}

}
