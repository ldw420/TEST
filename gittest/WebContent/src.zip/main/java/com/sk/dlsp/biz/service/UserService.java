package com.sk.dlsp.biz.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sk.dlsp.biz.mapper.UserMapper;
import com.sk.dlsp.model.UserCsvFileVo;
import com.sk.dlsp.model.UserVo;

@Service
@Transactional
public class UserService {
    @Autowired UserMapper userMapper;

	public List<UserVo> getUserList(Map<String,String> param){
		return userMapper.getUserList(param);
	}
	public UserVo getUser(String usrId){
		return userMapper.getUser(usrId);
	}

	public int insertUser(UserVo userVo) {
		return userMapper.insertUser(userVo);
	}

	public int deleteUser(String[] usrIds) {
		return userMapper.deleteUser(usrIds);
	}
	public int updateUser(UserVo userVo) {
		return userMapper.updateUser(userVo);
	}
	public List<UserCsvFileVo> getUserListIntoCsvFileByToday() {
		return userMapper.getUserListIntoCsvFileByToday();
	}
}
