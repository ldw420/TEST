package com.sk.dlsp.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class DcReqBlockChainDataVo implements Serializable {

	private static final long serialVersionUID = -6078561121152361844L;
	//
	private String companyCode;       //관계사
	private String databaseName;      //데이타베이스명  
	private String finishAt;          //데이터 공유 종료일.
	private String infoSystemName;    //필수값 Not empty 요소       
	private String requestColumn;     //동의 칼럼 명
	private String requestTable;      //동의 테이블 명
	private String scope;             //동의 데이터 수집 범위
	private String seq;               //동의 테이블 시퀀스
	private String startAt;           //데이터 공유 시작일.
	private String resourceId;        //DBMS 종류
	private String subjectName;       //주제영역
	
	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getDatabaseName() {
		return databaseName;
	}

	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}

	public String getFinishAt() {
		return finishAt;
	}

	public void setFinishAt(String finishAt) {
		this.finishAt = finishAt;
	}

	public String getInfoSystemName() {
		return infoSystemName;
	}

	public void setInfoSystemName(String infoSystemName) {
		this.infoSystemName = infoSystemName;
	}

	public String getRequestColumn() {
		return requestColumn;
	}

	public void setRequestColumn(String requestColumn) {
		this.requestColumn = requestColumn;
	}

	public String getRequestTable() {
		return requestTable;
	}

	public void setRequestTable(String requestTable) {
		this.requestTable = requestTable;
	}

	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}

	public String getSeq() {
		return seq;
	}

	public void setSeq(String seq) {
		this.seq = seq;
	}

	public String getStartAt() {
		return startAt;
	}

	public void setStartAt(String startAt) {
		this.startAt = startAt;
	}

	
	public String getResourceId() {
		return resourceId;
	}

	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}
	

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this,ToStringStyle.MULTI_LINE_STYLE); 
	}
	


}
