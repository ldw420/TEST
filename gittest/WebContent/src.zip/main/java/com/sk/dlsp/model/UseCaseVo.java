package com.sk.dlsp.model;

public class UseCaseVo extends CommonVo {

	private int sn;
	private String sj;
	private String cn;
	private String biurl;
	private String applcData;
	private String copm;
	private String copmNm;
	private String useAt;

	public int getSn() {
		return sn;
	}
	public void setSn(int sn) {
		this.sn = sn;
	}
	public String getSj() {
		return sj;
	}
	public void setSj(String sj) {
		this.sj = sj;
	}
	public String getCn() {
		return cn;
	}
	public void setCn(String cn) {
		this.cn = cn;
	}
	public String getBiurl() {
		return biurl;
	}
	public void setBiurl(String biurl) {
		this.biurl = biurl;
	}
	public String getApplcData() {
		return applcData;
	}
	public void setApplcData(String applcData) {
		this.applcData = applcData;
	}
	public String getCopm() {
		return copm;
	}
	public void setCopm(String copm) {
		this.copm = copm;
	}
	public String getUseAt() {
		return useAt;
	}
	public void setUseAt(String useAt) {
		this.useAt = useAt;
	}
	public String getCopmNm() {
		return copmNm;
	}
	public void setCopmNm(String copmNm) {
		this.copmNm = copmNm;
	}
	
	
}
