package com.sk.dlsp.biz.service;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import com.amazonaws.util.IOUtils;
import com.sk.dlsp.biz.mapper.LoginMapper;
import com.sk.dlsp.common.consts.CommonConstants;
import com.sk.dlsp.common.util.EmailUtil;
import com.sk.dlsp.model.EmailAuthVo;
import com.sk.dlsp.model.UserVo;

@Service
public class LoginService {

	@Autowired LoginMapper mapper;
	@Autowired EmailUtil emailUtil;

	public int insertUser(UserVo userVo) {
		return mapper.insertUser(userVo);
	}

	public EmailAuthVo getEmailAuth(String usrId) {
		return mapper.getEmailAuth(usrId);
	}

	public boolean sendEmailAuth(Map<String, String> param)throws Exception {
		boolean result = false;
		String subject = "COEUE 인증 메일 입니다.";
		Pattern expr = Pattern.compile(CommonConstants.VARIABLE_MATCHER_PATTERN);
		InputStream is = new ClassPathResource(CommonConstants.TEMPLATE_PATH + "emailAuth.template").getInputStream();
		String mailTemplate = IOUtils.toString(is);
		StringBuffer htmlbody = new StringBuffer();
		String textbody = "인증창에서 인증번호를 입력해 주십시요.";
		StringBuffer v = new StringBuffer();
		Random r = new Random();
		for(int i = 0;i < 6;i++) {
			v.append(r.nextInt(10));
		}

		String usrId = param.get("usrId");
		String checkValue = v.toString();
		param.put("checkValue", checkValue);

		Matcher mat = expr.matcher(mailTemplate);
		while (mat.find()) {
			mat.appendReplacement(htmlbody, param.get(mat.group(1)));
		};
		mat.appendTail(htmlbody);
		boolean re = emailUtil.sendEmail(usrId, subject, htmlbody.toString(), textbody);
		if(re) {
			mapper.insertEmailAuth(param);
			result = true;
		}

		return result;
	}

	public int updateEmailAuth(EmailAuthVo vo) {
		return mapper.updateEmailAuth(vo);
	}

	public EmailAuthVo getEmailAuthOk(String usrId) {
		return mapper.getEmailAuthOk(usrId);
	}
}
