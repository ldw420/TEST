package com.sk.dlsp.biz.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.sk.dlsp.model.BbsAnswerVo;
import com.sk.dlsp.model.BbsVo;

@Mapper
public interface BbsMapper {

	public List<BbsVo> getBbsList(Map<String, Object> param);

	public int getBbsListCount(Map<String, Object> param);

	public BbsVo getBbsDetail(BbsVo bbsVo);

	public int insertBbs(BbsVo bbsVo);

	public int updateBbsRdcnt(BbsVo bbsVo);

	public int updateBbs(BbsVo bbsVo);

	public int deleteBbs(BbsVo bbsVo);

	public int insertBbsAnswer(BbsAnswerVo bbsAnswerVo);

	public int updateBbsAnswer(BbsAnswerVo bbsAnswerVo);

	public BbsAnswerVo getBbsAnswer(BbsVo bbsVo);

}
