package com.sk.dlsp.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class DcCtgVo extends CommonVo{

	//
	private String groupNo;
	private String classKey;
	private String classTitle;
	private String abbrName;
	private String bizMeta;
	private String classLevel;
	private String upClassKey;
	private String upClassLevel;
	private String displayOrder;
	private String classTitlePath;
	private String grpCount;
	private String grpLevel;
	private String titleFirst;
	private String titleFirstCnt;
	//
	
	public String getClassKey() {
		return classKey;
	}
	public String getGroupNo() {
		return groupNo;
	}
	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}
	public void setClassKey(String classKey) {
		this.classKey = classKey;
	}
	public String getClassTitle() {
		return classTitle;
	}
	public void setClassTitle(String classTitle) {
		this.classTitle = classTitle;
	}
	public String getAbbrName() {
		return abbrName;
	}
	public void setAbbrName(String abbrName) {
		this.abbrName = abbrName;
	}
	
	public String getBizMeta() {
		return bizMeta;
	}
	public void setBizMeta(String bizMeta) {
		this.bizMeta = bizMeta;
	}
	public String getClassLevel() {
		return classLevel;
	}
	public void setClassLevel(String classLevel) {
		this.classLevel = classLevel;
	}
	public String getUpClassKey() {
		return upClassKey;
	}
	public void setUpClassKey(String upClassKey) {
		this.upClassKey = upClassKey;
	}
	public String getUpClassLevel() {
		return upClassLevel;
	}
	public void setUpClassLevel(String upClassLevel) {
		this.upClassLevel = upClassLevel;
	}
	public String getDisplayOrder() {
		return displayOrder;
	}
	public void setDisplayOrder(String displayOrder) {
		this.displayOrder = displayOrder;
	}
	public String getClassTitlePath() {
		return classTitlePath;
	}
	public void setClassTitlePath(String classTitlePath) {
		this.classTitlePath = classTitlePath;
	}
	public String getGrpCount() {
		return grpCount;
	}
	public void setGrpCount(String grpCount) {
		this.grpCount = grpCount;
	}
	public String getGrpLevel() {
		return grpLevel;
	}
	public void setGrpLevel(String grpLevel) {
		this.grpLevel = grpLevel;
	}
	public String getTitleFirst() {
		return titleFirst;
	}
	public void setTitleFirst(String titleFirst) {
		this.titleFirst = titleFirst;
	}
	public String getTitleFirstCnt() {
		return titleFirstCnt;
	}
	public void setTitleFirstCnt(String titleFirstCnt) {
		this.titleFirstCnt = titleFirstCnt;
	}
	
	
	
}
