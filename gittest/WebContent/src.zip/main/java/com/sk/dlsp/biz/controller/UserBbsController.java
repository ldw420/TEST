package com.sk.dlsp.biz.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sk.dlsp.biz.service.UserBbsService;
import com.sk.dlsp.common.consts.BbsType;
import com.sk.dlsp.common.consts.CommonConstants;
import com.sk.dlsp.common.exception.BizException;
import com.sk.dlsp.common.util.SessionUtil;
import com.sk.dlsp.model.BbsAnswerVo;
import com.sk.dlsp.model.BbsVo;
import com.sk.dlsp.model.ResponseDto;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(CommonConstants.API_PREFIX+"/userbbs")
public class UserBbsController{

	@Autowired UserBbsService service;

	@GetMapping("/{bbsType}")
	@ApiOperation(value = "게시판 조회")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "bbsType", value = "게시판 유형코드(notice,faq,qna)", required = true),
	    @ApiImplicitParam(name = "schBbsSj", value = "게시판 제목", required = false),
	    @ApiImplicitParam(name = "pageNo", value = "페이지 번호", required = false)
	})
	public ResponseDto getBbsList(@PathVariable(required = true) String bbsType,
								  @RequestParam(required = false) String schBbsSj,
								  @RequestParam(required = false) int pageNo) throws Exception {
		if(pageNo < 1)pageNo = 1;
		ResponseDto result = new ResponseDto();
		String bbsTyCode = getBbsTyCode(bbsType);

		Map<String,Object> param = new HashMap<>();
		param.put("bbsTyCode", bbsTyCode);
		param.put("schBbsSj", schBbsSj);
		param.put("pageNo", pageNo);

		List<BbsVo> bbsList = service.getBbsList(param);
		int bbsListCount = service.getBbsListCount(param);
		result.putData("bbsList", bbsList);
		result.putData("bbsListCount", bbsListCount);
		return result;
	}

	@GetMapping("/{bbsType}/{bbsNo}")
	@ApiOperation(value = "게시판 상세")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "bbsType", value = "게시판 유형코드(notice,faq,qna)", required = true),
		@ApiImplicitParam(name = "bbsNo", value = "게시판 글번호", required = true)
	})
	public ResponseDto getBbsDetail(@PathVariable(required = true) String bbsType,
									@PathVariable(required = true) String bbsNo) throws Exception {
		ResponseDto result = new ResponseDto();
		String bbsTyCode = getBbsTyCode(bbsType);
		BbsVo bbsVo = new BbsVo();
		bbsVo.setBbsTyCode(bbsTyCode);
		bbsVo.setBbsNo(Integer.parseInt(bbsNo));

		service.updateBbsRdcnt(bbsVo);
		BbsVo bbsDetail = service.getBbsDetail(bbsVo);
		result.putData("bbsDetail", bbsDetail);
		if("qna".equals(bbsType)) {
			BbsAnswerVo answerVo = service.getBbsAnswer(bbsVo);
			if(answerVo!=null) {
				result.putData("bbsAnswer", answerVo);
			}
			result.putData("bbsPrevDetail", service.getPrevDetail(bbsVo));
			result.putData("bbsNextDetail", service.getNextDetail(bbsVo));
		}else if("notice".equals(bbsType)) {
			result.putData("bbsPrevDetail", service.getPrevDetail(bbsVo));
			result.putData("bbsNextDetail", service.getNextDetail(bbsVo));
		}

		return result;
	}

	@PostMapping("/{bbsType}")
	@ApiOperation(value="게시판 등록")
	public ResponseDto insertBbs(@PathVariable(required = true)String bbsType
								,@RequestBody BbsVo bbsVo) throws Exception {
		ResponseDto result = new ResponseDto();
		String bbsTyCode = getBbsTyCode(bbsType);
		bbsVo.setBbsTyCode(bbsTyCode);
		SessionUtil.addUserInfo(bbsVo);

		int re = service.insertBbs(bbsVo);

		return result;
	}
	@PutMapping("/{bbsType}/{bbsNo}")
	@ApiOperation(value = "게시판 수정")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "bbsType", value = "게시판 유형코드(notice,faq,qna)", required = true),
		@ApiImplicitParam(name = "bbsNo", value = "게시판 글번호", required = true)
	})
	public ResponseDto updateBbs(@PathVariable(required = true) String bbsType,
								 @PathVariable(required = true) String bbsNo,
								 @RequestBody(required = true) BbsVo bbsVo) throws Exception {
		ResponseDto result = new ResponseDto();
		String bbsTyCode = getBbsTyCode(bbsType);

		bbsVo.setBbsTyCode(bbsTyCode);
		bbsVo.setBbsNo(Integer.parseInt(bbsNo));
		SessionUtil.addUserInfo(bbsVo);

		int re = service.updateBbs(bbsVo);

		return result;
	}

	@PostMapping("/answer/{bbsType}/{bbsNo}")
	@ApiOperation(value = "게시판 댓글 등록")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "bbsType", value = "게시판 유형코드(notice,faq,qna)", required = true),
		@ApiImplicitParam(name = "bbsNo", value = "게시판 글번호", required = true)
	})
	public ResponseDto insertBbsAnswer(@PathVariable(required = true) String bbsType,
									   @PathVariable(required = true) String bbsNo,
									   @RequestBody(required = true) BbsAnswerVo bbsAnswerVo) throws Exception {
		ResponseDto result = new ResponseDto();
		getBbsTyCode(bbsType);

		bbsAnswerVo.setBbsNo(Integer.parseInt(bbsNo));
		SessionUtil.addUserInfo(bbsAnswerVo);

		int re = service.insertBbsAnswer(bbsAnswerVo);

		return result;
	}
	@PutMapping("/answer/{bbsType}/{bbsNo}")
	@ApiOperation(value = "게시판 댓글 수정")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "bbsType", value = "게시판 유형코드(notice,faq,qna)", required = true),
		@ApiImplicitParam(name = "bbsNo", value = "게시판 글번호", required = true)
	})
	public ResponseDto updateBbsAnswer(@PathVariable(required = true) String bbsType,
									   @PathVariable(required = true) String bbsNo,
									   @RequestBody(required = true) BbsAnswerVo bbsAnswerVo) throws Exception {
		ResponseDto result = new ResponseDto();
		getBbsTyCode(bbsType);

		bbsAnswerVo.setBbsNo(Integer.parseInt(bbsNo));
		SessionUtil.addUserInfo(bbsAnswerVo);

		int re = service.updateBbsAnswer(bbsAnswerVo);

		return result;
	}

	@DeleteMapping("/{bbsType}/{bbsNo}")
	@ApiOperation(value = "게시판 글 삭제")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "bbsType", value = "게시판 유형코드(notice,faq,qna)", required = true),
		@ApiImplicitParam(name = "bbsNo", value = "게시판 글번호", required = true)
	})
	public ResponseDto deleteBbs(@PathVariable(required = true) String bbsType,
								 @PathVariable(required = true) String bbsNo) throws Exception {
		ResponseDto result = new ResponseDto();
		String bbsTyCode = getBbsTyCode(bbsType);
		BbsVo bbsVo = new BbsVo();
		bbsVo.setBbsTyCode(bbsTyCode);
		bbsVo.setBbsNo(Integer.parseInt(bbsNo));

		int re = service.deleteBbs(bbsVo);

		return result;
	}

	//게시판 타입 검색
	private String getBbsTyCode(String bbsType) throws Exception{
		String bbsTyCode = null;
		BbsType bbsTypeEnum = BbsType.findBy(bbsType);
		if(bbsTypeEnum != null) {
			bbsTyCode = bbsTypeEnum.getCode();
		}
		if(bbsTyCode == null) {
			throw new BizException("잘못된 게시판 유형 코드입니다.");
		}
		return bbsTyCode;
	}
}
