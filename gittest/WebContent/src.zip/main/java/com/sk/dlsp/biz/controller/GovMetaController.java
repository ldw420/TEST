package com.sk.dlsp.biz.controller;

import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sk.dlsp.biz.service.GovMetaService;
import com.sk.dlsp.common.util.StringUtil;
import com.sk.dlsp.model.MetaDataCopmVo;
import com.sk.dlsp.model.MetaDataVo;
import com.sk.dlsp.model.ResponseDto;

@RestController
@RequestMapping("/batch")
public class GovMetaController {

	@Autowired GovMetaService govMetaService;
	@Value("${prop.server.govMetaApi.url}") String govMetaApiUrl;

	@GetMapping("/govMeta/classifications")
	public ResponseDto classifications() throws Exception{
		ResponseDto result = new ResponseDto();
	    Document doc = Jsoup.connect(govMetaApiUrl+"/classifications").header("accept", "application/xhtml+xml; charset=utf-8").get();

	    Elements items = doc.select("item");
		List<MetaDataVo> metaDataList = new ArrayList<>();
		List<MetaDataCopmVo> metaDataCopmList = new ArrayList<>();

	    for(int i = 0 ; i < items.size();i++) {
	    	Element e = items.get(i);
	    	String classKey = e.selectFirst("classKey").text();
	    	if(StringUtil.isEmpty(classKey))continue;

	    	MetaDataVo metaData = new MetaDataVo();
	    	metaData.setClassKey(classKey);
	    	metaData.setClassTitle(e.selectFirst("classTitle").text());
	    	metaData.setClassLevel(e.selectFirst("classLevel").text());
	    	metaData.setUpClassKey(e.selectFirst("upperKey").text());
	    	metaData.setUpClassTitle(e.selectFirst("upperTitle").text());
	    	metaData.setSubjectArea(e.selectFirst("subjectName").text());
	    	metaData.setBizMeta(e.selectFirst("bizMeta").text());
	    	metaData.setClassTypeCode(e.selectFirst("classTypeCode").text());
	    	metaData.setClassTypeName(e.selectFirst("classTypeName").text());
	    	metaData.setCreateDt(e.selectFirst("createDate").text());
	    	metaData.setModifyDt(e.selectFirst("modifyDate").text());
	    	metaDataList.add(metaData);

	    	Elements companies = e.select("companies");
	    	if(companies.hasText()) {
	    		Elements metaDataCopms = companies.select("companyCode");
	    		for(int j = 0;j < metaDataCopms.size();j++) {
	    			MetaDataCopmVo metaDataCopm = new MetaDataCopmVo();
	    			metaDataCopm.setClassKey(classKey);
	    			metaDataCopm.setCmpCompanyCode(metaDataCopms.get(j).text());
	    			metaDataCopmList.add(metaDataCopm);
	    		}
	    	}
	    }
	    govMetaService.batchMetaData(metaDataList);
	    govMetaService.batchMetaDataCopm(metaDataCopmList);

		return result;
	}

}
