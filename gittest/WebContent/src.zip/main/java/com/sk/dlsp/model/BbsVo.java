package com.sk.dlsp.model;

public class BbsVo extends CommonVo{

	private int bbsNo;
	private String bbsTyCode;
	private String bbsSj;
	private String bbsCn;
	private int rdcnt;
	private String emplyrId;
	private String processSttus;
	private String othbcAt;
	private String rcepterId;
	private String useAt;
	private String nm;
	private String answerYn;

	public int getBbsNo() {
		return bbsNo;
	}
	public void setBbsNo(int bbsNo) {
		this.bbsNo = bbsNo;
	}
	public String getBbsTyCode() {
		return bbsTyCode;
	}
	public void setBbsTyCode(String bbsTyCode) {
		this.bbsTyCode = bbsTyCode;
	}
	public String getBbsSj() {
		return bbsSj;
	}
	public void setBbsSj(String bbsSj) {
		this.bbsSj = bbsSj;
	}
	public String getBbsCn() {
		return bbsCn;
	}
	public void setBbsCn(String bbsCn) {
		this.bbsCn = bbsCn;
	}
	public int getRdcnt() {
		return rdcnt;
	}
	public void setRdcnt(int rdcnt) {
		this.rdcnt = rdcnt;
	}
	public String getEmplyrId() {
		return emplyrId;
	}
	public void setEmplyrId(String emplyrId) {
		this.emplyrId = emplyrId;
	}
	public String getProcessSttus() {
		return processSttus;
	}
	public void setProcessSttus(String processSttus) {
		this.processSttus = processSttus;
	}
	public String getOthbcAt() {
		return othbcAt;
	}
	public void setOthbcAt(String othbcAt) {
		this.othbcAt = othbcAt;
	}
	public String getRcepterId() {
		return rcepterId;
	}
	public void setRcepterId(String rcepterId) {
		this.rcepterId = rcepterId;
	}
	public String getUseAt() {
		return useAt;
	}
	public void setUseAt(String useAt) {
		this.useAt = useAt;
	}
	public String getNm() {
		return nm;
	}
	public void setNm(String nm) {
		this.nm = nm;
	}
	public String getAnswerYn() {
		return answerYn;
	}
	public void setAnswerYn(String answerYn) {
		this.answerYn = answerYn;
	}
}
