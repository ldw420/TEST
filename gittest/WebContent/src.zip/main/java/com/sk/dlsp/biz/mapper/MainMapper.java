package com.sk.dlsp.biz.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.sk.dlsp.model.AuthAppVo;
import com.sk.dlsp.model.BbsVo;
import com.sk.dlsp.model.BiVo;
import com.sk.dlsp.model.DcConfmVo;
import com.sk.dlsp.model.DcVo;
import com.sk.dlsp.model.MydashboardVo;
import com.sk.dlsp.model.SrchwrdVo;
import com.sk.dlsp.model.UseCaseVo;

@Mapper
public interface MainMapper {

	public List<BbsVo> getNoticeList();

	public List<SrchwrdVo> getSrchwrdList();
	
	public List<MydashboardVo> getUseCaseListVo();

	public BiVo getBiVo();

	public UseCaseVo getUseCaseVo();
	
	public int getConfmAppCnt(MydashboardVo mydashboardVo);
	
	public List<MydashboardVo> getMyAppCnt(MydashboardVo mydashboardVo);
	
	public List<MydashboardVo> getConfmAppList(MydashboardVo mydashboardVo);
	
	public List<MydashboardVo> getMyAppList(MydashboardVo mydashboardVo);
	
	public List<MydashboardVo> getMyScrapList(MydashboardVo mydashboardVo);
	
	public List<MydashboardVo> getMyDataList(MydashboardVo mydashboardVo);
	
	public AuthAppVo getAuthDetail(int sn);
	
	public BiVo getReportDetail(int sn);
	
	public DcConfmVo getDataAppDetail(String sn);
	
	public int setConfmData(MydashboardVo mydashboardVo);
	
	public int setReqConfmData(MydashboardVo mydashboardVo);
	
	public int setConfmReport(MydashboardVo mydashboardVo);
	
	public int setConfmAuthApp(MydashboardVo mydashboardVo);
	
	public List<MydashboardVo> getTebleList(String transId);

	public int getStatusCheck();
}
