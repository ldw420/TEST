package com.sk.dlsp.biz.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sk.dlsp.biz.mapper.UseCaseMapper;
import com.sk.dlsp.model.UseCaseVo;

@Service
@Transactional
public class UseCaseService {
    @Autowired UseCaseMapper useCaseMapper;

	public List<UseCaseVo> getUseCaseList(Map<String, Object> param){
		return useCaseMapper.getUseCaseList(param);
	}

	public int getUseCaseListCount(Map<String, Object> param) {
		return useCaseMapper.getUseCaseListCount(param);
	}

	public UseCaseVo getUseCaseDetail(int sn) {
		return useCaseMapper.getUseCaseDetail(sn);
	}

	public int insertUseCase(UseCaseVo useCaseVo) {
		return useCaseMapper.insertUseCase(useCaseVo);
	}

	public int updateUseCase(UseCaseVo useCaseVo) {
		return useCaseMapper.updateUseCase(useCaseVo);
	}

	public int deleteUseCase(int[] useCaseIds) {
		return useCaseMapper.deleteUseCase(useCaseIds);
	}

}
