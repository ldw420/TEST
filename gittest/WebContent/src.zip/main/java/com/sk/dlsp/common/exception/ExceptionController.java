package com.sk.dlsp.common.exception;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.env.Profiles;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sk.dlsp.common.consts.CommonConstants;
import com.sk.dlsp.model.ResponseDto;

@Controller
public class ExceptionController {

	@Autowired Environment env;

	@RequestMapping(value = CommonConstants.EXCEPTION_URL_STATUS_404)
	@ResponseBody
	public ResponseDto handleError404(HttpServletRequest request, Exception e) {
		ResponseDto responseDto = new ResponseDto();
		responseDto.setCode(CommonConstants.EXCEPTION);
		responseDto.setMessage("페이지를 찾을 수 없습니다.");
		return responseDto;
	}

	@RequestMapping(value = CommonConstants.EXCEPTION_URL_STATUS_500)
	@ResponseBody
	public ResponseDto handleError500(HttpServletRequest request) {
		ResponseDto responseDto = new ResponseDto();
		responseDto.setCode(CommonConstants.EXCEPTION);
		responseDto.setMessage((String)request.getAttribute(CommonConstants.MESSAGE));
		String[] profiles = env.getActiveProfiles();
		for(String profile:profiles) {
			if("prod".equals(profile)) {
				responseDto.setMessage("시스템 처리중 에러가 발생 하였습니다.");
			}
		}

		return responseDto;
	}
}
