package com.sk.dlsp.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.sk.dlsp.common.interceptor.LoginInterceptor;

@Configuration
public class InterceptorConfig extends WebMvcConfigurerAdapter {


	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(new LoginInterceptor())
		        .addPathPatterns("/api/v*/**/*")
		        .excludePathPatterns("/api/v*/noAuth/*")
		        .excludePathPatterns("/api/v*/join")
			    .excludePathPatterns("/api/v*/login")
			    .excludePathPatterns("/api/v*/code/useDetail/*")
			    .excludePathPatterns("/api/v*/logout");
	}
}
