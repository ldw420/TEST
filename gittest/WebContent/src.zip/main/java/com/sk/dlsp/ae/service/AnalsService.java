package com.sk.dlsp.ae.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sk.dlsp.ae.mapper.AnalsMapper;
import com.sk.dlsp.model.AnalsVo;
import com.sk.dlsp.model.BbsVo;
import com.sk.dlsp.model.InstInfoVo;

@Service
@Transactional
public class AnalsService {
    @Autowired
    AnalsMapper mAnalsMapper;

	public List<AnalsVo> aeInstInfoList(){
		return mAnalsMapper.aeInstInfoList();
	}

	public List<InstInfoVo> instInfoList( AnalsVo analsVo ){
		return mAnalsMapper.instInfoList ( analsVo );
	}
	
	public List<AnalsVo> datasetList(String koreanNm){
		return mAnalsMapper.datasetList(koreanNm);
	}

	public List<AnalsVo> datasetInfoList(AnalsVo analsVo){
		return mAnalsMapper.datasetInfoList(analsVo);
	}

	public List<AnalsVo> datasetInfoAllList(AnalsVo analsVo){
		return mAnalsMapper.datasetInfoAllList(analsVo);
	}

    public String aeInstInfo(String instTy) throws Exception{
        return mAnalsMapper.aeInstInfo(instTy);
    }

	public int deleteDataSetInfo(AnalsVo analsVo) {
		return mAnalsMapper.deleteDataSetInfo(analsVo);
	}

	public void insertDataSetInfo(AnalsVo analsVo) {
		mAnalsMapper.insertDataSetInfo(analsVo);
	}
}