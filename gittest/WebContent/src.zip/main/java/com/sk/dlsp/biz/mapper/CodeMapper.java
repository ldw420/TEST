package com.sk.dlsp.biz.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.sk.dlsp.model.CodeDetailVo;
import com.sk.dlsp.model.CodeGroupVo;

@Mapper
public interface CodeMapper {

    public List<CodeGroupVo> getCodeGroupList(Map<String,String> vo);

    public CodeGroupVo getCodeGroup(String id);

    public List<CodeDetailVo> getCodeDetailList(Map<String,String> vo);
    
    public List<CodeDetailVo> getCodeUseDetailList(Map<String,String> vo);

	public int insertCodeGroup(CodeGroupVo vo);

	public int insertCodeDetail(CodeDetailVo vo);

	public int deleteCodeGroup(String[] groupCodeIds);

	public int deleteCodeDetail(CodeDetailVo codeDetailVo);

	public int deleteCodeDetailByCodeGroup(String[] groupCodeIds);

	public CodeDetailVo getCodeDetail(CodeDetailVo vo);
	
	public int detailCodeUpdeate(CodeDetailVo codeDetailVo);


}
