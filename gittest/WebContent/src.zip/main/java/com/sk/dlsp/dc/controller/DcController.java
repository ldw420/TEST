package com.sk.dlsp.dc.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sk.dlsp.biz.service.BiService;
import com.sk.dlsp.common.consts.CommonConstants;
import com.sk.dlsp.common.exception.BizException;
import com.sk.dlsp.common.util.SessionUtil;
import com.sk.dlsp.common.util.StringUtil;
import com.sk.dlsp.dc.service.DcApiService;
import com.sk.dlsp.dc.service.DcService;
import com.sk.dlsp.model.CodeDetailVo;
import com.sk.dlsp.model.DcApprovalVo;
import com.sk.dlsp.model.DcCompVo;
import com.sk.dlsp.model.DcConsentVo;
import com.sk.dlsp.model.DcCtgVo;
import com.sk.dlsp.model.DcSuccessVo;
import com.sk.dlsp.model.DcTableInfoVo;
import com.sk.dlsp.model.DcTableParamVo;
import com.sk.dlsp.model.DcVo;
import com.sk.dlsp.model.ResponseDto;
import com.sk.dlsp.model.UserInfo;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(CommonConstants.API_PREFIX)
public class DcController {
	
	@Autowired DcService dcService;
	@Autowired BiService biService;
	@Autowired DcApiService dcApiService;
	
	@Value("${prop.server.blockchain.approval.url}") String approvalUrl;
	@Value("${prop.server.blockchain.approval.txId.url}") String approvaltxIdUrl;
	@Value("${prop.server.govMetaApi.classification-table-info.url}") String tableInfoUrl;
	@Value("${prop.server.govMetaApi.table-column-info.url}") String columnInfoUrl;
	
	
	
	@GetMapping("/dc")
	@ApiOperation(value = "Dc 조회")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "schDcSj", value = "카테고리 제목", required = false),
	    @ApiImplicitParam(name = "schCopm", value = "관계사", required = false),
	    @ApiImplicitParam(name = "schCtg" , value = "카테고리", required = false),
	    @ApiImplicitParam(name = "schOrd" , value = "정렬 순서", required = false),
	    @ApiImplicitParam(name = "shareYn" , value = "바로이용가능한데이터보기", required = false),
	    @ApiImplicitParam(name = "pageNo" , value = "페이지 번호", required = false)
	})
	public ResponseDto getDcList(@RequestParam(required = false) String schDcSj
								,@RequestParam(required = false) String schDcSjCopm
								,@RequestParam(required = false) String schOrd
								,@RequestParam(required = false, defaultValue="") String schCopm
								,@RequestParam(required = false, defaultValue="") String schCtg
								,@RequestParam(required = false, defaultValue="") String shareYn
								,HttpServletRequest request
								,@RequestParam(required = false, defaultValue="1") int pageNo ) throws Exception {
		
		// Extract the userInfo, 20191022 by pkh 
		UserInfo userInfo = SessionUtil.getUserInfo();
		
		ResponseDto result = new ResponseDto();
		
		try {
			Map<String,Object> param = new HashMap<>();
			// NullPointException 예방차원으로 @RequestParam 에서 defaultValue 사용
			if(pageNo < 1) pageNo = 1;
			
			param.put("pageNo", pageNo);
			param.put("schDcSj", schDcSj);
			param.put("schCopm", schCopm);
			param.put("schOrd", schOrd);
			param.put("schCtg", schCtg);
			param.put("schDcSjCopm", schDcSjCopm);
			param.put("arrCtg", schCtg.split(","));
			param.put("arrCopm",schCopm.split(","));
			param.put("userId",userInfo.getUsrId());
			param.put("userCompany", userInfo.getAgency());
			param.put("shareYn", shareYn);
			
			List<DcVo> dcList 		= dcService.getDcList(param); 
			int dcListCount 		= dcService.getDcListCount(param);
			
			List<DcCtgVo> dcCtgList = dcService.getDcCtgList(param);
			List<DcCtgVo> dcCtgCountList = dcService.getDcCtgCountList(param);
			
			List<DcCompVo> dcCompList 	= dcService.getDcCopmList(param);
			List<DcCompVo> dcCompCountList 	= dcService.getDcCopmCountList(param);
			// 검색어 저장추가
			if( !StringUtil.isEmpty(schDcSj)) {
				Map<String,Object> srchMap = new HashMap<>();
				srchMap.put("srchwrd", schDcSj);
				dcService.insertDcSearchWord(srchMap);
			}
			
			result.putData("dcList", dcList);
			result.putData("dcListCount", dcListCount);
			result.putData("dcCtgList", dcCtgList);
			result.putData("dcCtgCountList", dcCtgCountList);
			result.putData("dcCompList", dcCompList);
			result.putData("dcCompCountList", dcCompCountList);

		} catch(Exception e) {
			result.setCode(CommonConstants.FAIL);
	        result.setMessage("조회중 오류가 발생하였습니다.\n" + e.getMessage());
		}
		return result;
	}
	
	
	@PostMapping("/dc/{classKey}")
	@ApiOperation(value = "공유요청 항목 DB 저장후 Block-Chain API 호출")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "classKey", value = "분류체계 코드", required = true)
	})
	public ResponseDto insertDcApproval(@PathVariable(required = true) String classKey, @RequestBody DcApprovalVo dcVo) {
		
		// Extract the userInfo, 20191022 by pkh 
	    UserInfo userInfo = SessionUtil.getUserInfo();
		dcVo.setRequester(userInfo.getUsrId());
		dcVo.setRequesterCom(userInfo.getAgency());
		
	    ResponseDto result = new ResponseDto();
	    try {
	    	int ret = dcService.insertDcDataUseAndSendBlockChain(dcVo, approvalUrl, classKey);
	    	if(ret == 0) {
	    		throw new BizException("공유요청 DB 저장 처리중 오류가 발생했습니다.");
	    	}
	    	//
	    } catch(Exception e) {
	    	result.setCode(CommonConstants.FAIL);
	        result.setMessage("등록 처리중 오류가 발생하였습니다.\n" + e.getMessage());
	    }
	    return result;
	}
	
//	@PostMapping("/dc/block-chain/{txId}")
//	@ApiOperation(value = "block chain API요청")
//	@ApiImplicitParams({
//		@ApiImplicitParam(name = "txId", value = "트랜잭션 ID", required = true)
//	})
//	public ResponseDto insertDcApprovalApi(@PathVariable(required = true) String classKey, @PathVariable(required = true) String txId) {
//		ResponseDto result = new ResponseDto();
//		try {
//			if( StringUtil.isEmpty(txId)) {
//				throw new BizException("트랜잭션 ID 값은 필수값입니다.");
//			}
//			
//			int ret = dcService.insertDcApprovalApi(txId);
//			
//			
//			String jsonData = dcService.getDcApprovalData(txId);
//			
//			// block chain api call
//			String retData = dcApiService.apiPost(approvalUrl, jsonData);
//			if("fail".equals(retData) || "exception".equals(retData)) {
//				throw new BizException("block chain api 연계중 오류가 발생하였습니다.");
//			}
//		} catch(Exception e) {
//			result.setCode(CommonConstants.FAIL);
//			result.setMessage("등록 처리중 오류가 발생하였습니다.\n" + e.getMessage());
//		}
//		return result;
//	}
	
	
	@SuppressWarnings({ "unchecked", "unused" })
	@GetMapping("/dc/table-info/{classKey}")
	@ApiOperation(value = "Lv3 테이블 상세정보 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "classKey", value = "분류체계 코드", required = true)
	})
	public ResponseDto getTableInfo(@PathVariable(name="classKey" ,required = true) String classKey) throws Exception{
		ResponseDto result = new ResponseDto();
	    String reqUrl = this.tableInfoUrl;

	    reqUrl += "?classKey=" + classKey;

	    try {
	    	String retData = dcApiService.getXmlApi(reqUrl);

	    	Map<String,Object> resultData = new HashMap<>();
	    	if( !StringUtil.isEmpty(retData)) {

		    	resultData = new ObjectMapper().readValue(retData, Map.class);
		    	result.putData("tableInfo", resultData);
		    	//------------------
	    	} else {
	    		result.putData("tableInfo", new HashMap<>()); //화면단에서 undefined 방지
	    	}
	    	
	    	// 로그인 정보 추출
	    	// Extract the userInfo, 20191028 by pkh 
			UserInfo userInfo = SessionUtil.getUserInfo();
			Map<String,Object> consentMap = new HashMap<>();
			consentMap.put("classKey", classKey);
			consentMap.put("reqComp", userInfo.getAgency());
			
			List<DcConsentVo> consentInfoList = dcService.getConsentList(consentMap);
			result.putData("consentInfo", consentInfoList);
			
	    	// 조회수 +1 
	    	Map<String,Object> paramMap = new HashMap<>();
	    	paramMap.put("classKey", classKey);
	    	
	    	
	    	int retCnt = dcService.updateHitCnt(paramMap);
	    	
	    	// 상세정보 조회 by classKey
	    	paramMap.put("userId", userInfo.getUsrId());
	    	DcVo dcVo = dcService.getDcDetailInfo(paramMap);
	    	result.putData("baseInfo", dcVo);
	    	//
	    	//----get the codeInfoList
	    	Map<String,Object> param = new HashMap<>();
	    	param.put("groupCodeId", "sk004");
	    	List<CodeDetailVo> codeList = dcApiService.getDcCodeInfoList(param);
	    	result.putData("codeInfo", codeList);
	
	    } catch(Exception e) {
	    	result.setCode(CommonConstants.FAIL);
			result.setMessage("Lv3 테이블 api 호출시 오류가 발생하였습니다.\n" + e.getMessage());
	    }
	    return result;
	}
	
	@SuppressWarnings("unchecked")
	@GetMapping("/dc/column-info")
	@ApiOperation(value = "Lv3 컬럼 상세정보 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "tableId"        , value = "테이블 영문명"  , required = true),
		@ApiImplicitParam(name = "companyCode"    , value = "관계사 코드"   , required = true),
		@ApiImplicitParam(name = "databaseName"   , value = "데이터베이스명(위치구분)", required = true),
		@ApiImplicitParam(name = "subjectName"    , value = "주제영역명"    , required = true),
		@ApiImplicitParam(name = "resourceId"     , value = "데이터베이스종류", required = false),
		@ApiImplicitParam(name = "companyName"    , value = "관계사 명"     , required = false),
		@ApiImplicitParam(name = "infoSystemName" , value = "정보시스템명"   , required = false)
	})
	public ResponseDto getColumnInfo(@RequestParam(required = true) String tableId
									,@RequestParam(required = true) String companyCode
									,@RequestParam(required = true) String databaseName
									,@RequestParam(required = true) String subjectName
									,@RequestParam(required = false, defaultValue="test") String resourceId
									,@RequestParam(required = false, defaultValue="") String companyName
									,@RequestParam(required = false, defaultValue="") String infoSystemName ) throws Exception {
		ResponseDto result = new ResponseDto();

	    String reqUrl = this.columnInfoUrl;
	    reqUrl += "?";
	    reqUrl += "tableId=" + tableId + "&";
	    reqUrl += "companyCode=" + companyCode + "&";
	    reqUrl += "databaseName=" + databaseName + "&";
	    reqUrl += "subjectName=" + subjectName + "&";
	    reqUrl += "resourceId=" + resourceId + "&";
	    reqUrl += "companyName=" + companyName + "&";
	    reqUrl += "infoSystemName=" + infoSystemName;
	    
	    try {
	    	String retData = dcApiService.getXmlApi(reqUrl);
	    	Map<String,Object> resultData = new ObjectMapper().readValue(retData, Map.class);
	    	

	    	result.putData("columnInfo", resultData);
	    	
	    } catch(Exception e) {
	    	result.setCode(CommonConstants.FAIL);
			result.setMessage("Lv3 컬럼 api 호출시 오류가 발생하였습니다.\n" + e.getMessage());
	    }
	    
	    return result;
	}
	
	
	@PostMapping("/dc/schema-info")
	@ApiOperation(value = "공유요청할 테이블/컬럼목록 조회")
	/**
	 * 파라미터 요청시 샘플데이타
	 * {
		    "tableInfo" : [
		      {
		            "tableId": "pps_ykiho_v1",
		            "databaseName": "hira_year",
		            "companyCode": "00001",
		            "subjectName": "진료심의정보",
		       },  
		      {
		            "tableId": "pubchem_data",
		            "databaseName": "pubchem_ana",
		            "companyCode": "00001",
		            "subjectName": "진료심의정보"
		       }
		       
		    ]
		}
	 * @param dcSchemaVo
	 * @return
	 * @throws Exception
	 */
	public ResponseDto getDcSchemaInfo(@RequestBody DcTableInfoVo dcSchemaVo) throws Exception {
	    ResponseDto result = new ResponseDto();
	    
	    // 필수값 empty 체크
	    List<DcTableParamVo> tableInfo = dcSchemaVo.getTableInfo();
	    for(int i=0; i<tableInfo.size(); i++) {
	    	DcTableParamVo paramVo = tableInfo.get(i);
	    	if( StringUtil.isEmpty(paramVo.getTableId())) {
				throw new BizException("tableId값은 필수값입니다.");
	    	}
	    	if( StringUtil.isEmpty(paramVo.getDatabaseName())) {
	    		throw new BizException("databaseName값은 필수값입니다.");
	    	}
	    	if( StringUtil.isEmpty(paramVo.getCompanyCode())) {
	    		throw new BizException("companyCode값은 필수값입니다.");	    		
	    	}
	    	if( StringUtil.isEmpty(paramVo.getSubjectName())) {
	    		throw new BizException("subjectName값은 필수값입니다.");	    			    		
	    	}
	    }
	    
	    try {

	    	String reqUrl = this.columnInfoUrl;
	    	List<Map<String,Object>> schemaInfoList = dcService.getApiSchemaInfo(dcSchemaVo, reqUrl);
	    	
	    	result.putData("schemaInfo", schemaInfoList);
	    
	    } catch(Exception e) {
	    	result.setCode(CommonConstants.FAIL);
			result.setMessage("Lv3 컬럼 api 호출시 오류가 발생하였습니다.\n" + e.getMessage());
	    }
	    return result;
	}
	
	
	@SuppressWarnings("unused")
	@PutMapping("/dc/schema-info")
	@ApiOperation(value = "카탈로그 데이터 사용 신청 상세항목중에서 복사성공여부 수정")
	public ResponseDto updateSuccessYnFromBlockChain(@RequestBody DcSuccessVo dcSuccessVo) throws Exception {
	    ResponseDto result = new ResponseDto();
	    
	    if( StringUtils.isEmpty(dcSuccessVo.getTransId())) {
	        throw new BizException("트랜잭션 키 값은 필수값입니다.");
	    }
	    if( StringUtils.isEmpty(dcSuccessVo.getReqTbl())) {
	        throw new BizException("요청테이블 값은 필수값입니다.");
	    }
	    if( StringUtils.isEmpty(dcSuccessVo.getSussYn())) {
	        throw new BizException("복사성공여부 값은 필수값입니다.");
	    }
	    
	    try {
	        int ret = dcService.updateSuccessYnFromBlockChain(dcSuccessVo);
	        
	    } catch(Exception e) {
	        result.setCode(CommonConstants.FAIL);
	        result.setMessage("사용신청 상세항목 복사성공여부 업데이트요청 처리중 오류가 발생하였습니다.\n" + e.getMessage());
	    }
	    

	    return result;
	}
	
	
	
	

}
