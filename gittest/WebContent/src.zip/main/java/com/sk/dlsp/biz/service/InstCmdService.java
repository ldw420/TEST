package com.sk.dlsp.biz.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sk.dlsp.biz.mapper.InstCmdMapper;
import com.sk.dlsp.model.InstCmdVo;

@Service
@Transactional
public class InstCmdService {
	
    @Autowired InstCmdMapper instCmdMapper;

	public List<InstCmdVo> getInstCmdList(Map<String,String> param){
		return instCmdMapper.getInstCmdList(param);
	}

	public InstCmdVo getInstCmdDetail(int sn) {
		return instCmdMapper.getInstCmdDetail(sn);
	}

	public int insertInstCmd(InstCmdVo InstCmdVo) {
		return instCmdMapper.insertInstCmd(InstCmdVo);
	}

	public int updateInstCmd(InstCmdVo InstCmdVo) {
		return instCmdMapper.updateInstCmd(InstCmdVo);
	}

	public int deleteInstCmd(int[] InstCmdIds) {
		return instCmdMapper.deleteInstCmd(InstCmdIds);
	}
	
	public int deleteInstCmdPer(InstCmdVo inst) {
		return instCmdMapper.deleteInstCmdPer (inst);
	}
	
	
}
