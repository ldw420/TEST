package com.sk.dlsp.model;

public class AnalsEnvVo {
	private String instTy;
	private String price;

	public String getInstTy() {
		return instTy;
	}
	public void setInstTy(String instTy) {
		this.instTy = instTy;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
}