package com.sk.dlsp.model;

public class BbsAnswerVo extends CommonVo{

	int bbsAnswerNo;
	int bbsNo;
	String answerCn;
	String nm;

	public int getBbsAnswerNo() {
		return bbsAnswerNo;
	}
	public void setBbsAnswerNo(int bbsAnswerNo) {
		this.bbsAnswerNo = bbsAnswerNo;
	}
	public int getBbsNo() {
		return bbsNo;
	}
	public void setBbsNo(int bbsNo) {
		this.bbsNo = bbsNo;
	}
	public String getAnswerCn() {
		return answerCn;
	}
	public void setAnswerCn(String answerCn) {
		this.answerCn = answerCn;
	}
	public String getNm() {
		return nm;
	}
	public void setNm(String nm) {
		this.nm = nm;
	}
}
