package com.sk.dlsp.biz.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.sk.dlsp.model.InstVo;

@Mapper
public interface InstMapper {

	public List<InstVo> getInstList(Map<String,String> param);

	public InstVo getInstDetail(int sn);

	public int insertInst(InstVo instVo);

	public int updateInst(InstVo instVo);

	public int deleteInst(int[] instIds);

}
