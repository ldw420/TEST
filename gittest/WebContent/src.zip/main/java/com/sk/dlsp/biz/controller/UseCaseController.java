package com.sk.dlsp.biz.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sk.dlsp.biz.service.UseCaseService;
import com.sk.dlsp.common.consts.CommonConstants;
import com.sk.dlsp.common.util.SessionUtil;
import com.sk.dlsp.model.ResponseDto;
import com.sk.dlsp.model.UseCaseVo;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(CommonConstants.API_PREFIX)
public class UseCaseController {

	@Autowired UseCaseService useCaseService;

	@GetMapping("/useCase")
	@ApiOperation(value = "유즈케이스 조회")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "schSj", value = "유즈케이스명", required = false),
	    @ApiImplicitParam(name = "schCopm", value = "관계사", required = false),
	    @ApiImplicitParam(name = "pageNo", value = "페이지 번호", required = false)
	})
	public ResponseDto getUseCaseList(@RequestParam(required = false) String schSj
									 ,@RequestParam(required = false) String schCopm
									 ,@RequestParam(required = false) int pageNo) {
		ResponseDto result = new ResponseDto();
		if(pageNo < 1)pageNo = 1;
		Map<String,Object> param = new HashMap<>();
		param.put("schSj", schSj);
		param.put("schCopm", schCopm);
		param.put("pageNo", pageNo);

		List<UseCaseVo> useCaseList = useCaseService.getUseCaseList(param);
		int useCaseListCount = useCaseService.getUseCaseListCount(param);

		result.putData("useCaseList", useCaseList);
		result.putData("useCaseListCount", useCaseListCount);
		return result;
	}

	@GetMapping("/useCase/{sn}")
	@ApiOperation(value = "유즈케이스 상세 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "sn", value = "유즈케이스 키", required = true)
	})
	public ResponseDto getUseCaseList(@PathVariable int sn) {
		UseCaseVo useCaseDetail = useCaseService.getUseCaseDetail(sn);

		ResponseDto result = new ResponseDto();
		result.putData("useCaseDetail", useCaseDetail);
		return result;
	}

	@PostMapping("/useCase")
	@ApiOperation(value = "유즈케이스 등록")
	public ResponseDto insertUseCase(@RequestBody UseCaseVo useCaseVo) {
		SessionUtil.addUserInfo(useCaseVo);
		int re = useCaseService.insertUseCase(useCaseVo);

		ResponseDto result = new ResponseDto();
		return result;
	}
	@PutMapping("/useCase/{sn}")
	@ApiOperation(value = "유즈케이스 수정")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "sn", value = "유즈케이스 키", required = true)
	})
	public ResponseDto updateUseCase(@PathVariable int sn ,@RequestBody UseCaseVo useCaseVo) {
		SessionUtil.addUserInfo(useCaseVo);
		useCaseVo.setSn(sn);
		int re = useCaseService.updateUseCase(useCaseVo);

		ResponseDto result = new ResponseDto();
		return result;
	}

	@DeleteMapping("/useCase/{useCaseId}")
	@ApiOperation(value = "유즈케이스 삭제")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "useCaseId", value = "유즈케이스 키", required = true)
	})
	public ResponseDto deleteUseCase(@PathVariable(required = true) String useCaseId) {
		String [] useCaseSplit = useCaseId.split(",");
		ResponseDto result = new ResponseDto();
		try {
			int[] useCaseIds = Arrays.stream(useCaseSplit).mapToInt(Integer::parseInt).toArray();
			int re = useCaseService.deleteUseCase(useCaseIds);
		}catch(NumberFormatException ne) {
			result.setCode(CommonConstants.FAIL);
			result.setMessage("잘못된 키값입니다.");
		}
		return result;
	}

}
