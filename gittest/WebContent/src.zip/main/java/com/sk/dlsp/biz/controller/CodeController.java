package com.sk.dlsp.biz.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sk.dlsp.biz.service.CodeService;
import com.sk.dlsp.common.consts.CommonConstants;
import com.sk.dlsp.common.util.SessionUtil;
import com.sk.dlsp.model.AuthAppVo;
import com.sk.dlsp.model.AuthVo;
import com.sk.dlsp.model.CodeDetailVo;
import com.sk.dlsp.model.CodeGroupVo;
import com.sk.dlsp.model.ResponseDto;
import com.sk.dlsp.model.UserInfo;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(CommonConstants.API_PREFIX +"/code")
public class CodeController {

	@Autowired CodeService codeService;

	/**
	 * 그룹 코드 조회
	 * @param schCodeId
	 * @param schCodeNm
	 * @param schUseAt
	 * @return
	 */
	@GetMapping("/group")
	@ApiOperation(value = "그룹 코드 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "schCodeId", value = "상위 코드", required = false),
	    @ApiImplicitParam(name = "schCodeNm", value = "상위코드 명칭", required = false),
	    @ApiImplicitParam(name = "schUseAt", value = "사용여부", required = false)
	})
	public ResponseDto getCodeGroupList(@RequestParam(required = false) String schCodeId
									   ,@RequestParam(required = false) String schCodeNm
									   ,@RequestParam(required = false) String schUseAt) {
		Map<String,String> param = new HashMap<>();
		param.put("schCodeId", schCodeId);
		param.put("schCodeNm", schCodeNm);
		param.put("schUseAt", schUseAt);

		List<CodeGroupVo> codeGroupList = codeService.getCodeGroupList(param);

		ResponseDto result = new ResponseDto();
		result.putData("codeGroupList", codeGroupList);
		return result;
	}

	/**
	 * 상세 코드 조회
	 * @param groupCodeId
	 * @return
	 */
	@GetMapping("/detail/{groupCodeId}")
	@ApiOperation(value = "상세 코드 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "groupCodeId", value = "그룹 코드", required = true)
	})
	public ResponseDto getCodeDetailList(@PathVariable(required = true)  String groupCodeId) {
		Map<String,String> param = new HashMap<>();
		param.put("groupCodeId", groupCodeId);

		List<CodeDetailVo> codeDetailList = codeService.getCodeDetailList(param);

		ResponseDto result = new ResponseDto();
		result.putData("codeDetailList", codeDetailList);
		return result;
	}
	
	/**
	 * 사용자 화면 상세 코드 조회
	 * @param groupCodeId
	 * @return
	 */
	@GetMapping("/useDetail/{groupCodeId}")
	@ApiOperation(value = "사용자 화면 상세 코드 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "groupCodeId", value = "그룹 코드", required = true)
	})
	public ResponseDto useDetail(@PathVariable(required = true)  String groupCodeId) {
		Map<String,String> param = new HashMap<>();
		param.put("groupCodeId", groupCodeId);

		List<CodeDetailVo> codeDetailList = codeService.getCodeUseDetailList(param);

		ResponseDto result = new ResponseDto();
		result.putData("codeDetailList", codeDetailList);
		return result;
	}

	/**
	 * 그룸 코드 추가
	 * @param codeVo
	 * @return
	 */
	@PostMapping("/group")
	@ApiOperation(value = "그룹 코드 추가")
	public ResponseDto insertCodeGroup(@RequestBody CodeGroupVo codeVo) {
		ResponseDto result = new ResponseDto();

		SessionUtil.addUserInfo(codeVo);
		CodeGroupVo validCodeVo = codeService.getCodeGroup(codeVo.getGroupCodeId());
		if(validCodeVo != null) {
			result.setCode(CommonConstants.FAIL);
			result.setMessage("중복 된 그룹 코드가 존재합니다");
			return result;
		}
		int re = codeService.insertCodeGroup(codeVo);

		return result;
	}

	/**
	 * 상세 코드 추가
	 * @param codeVo
	 * @return
	 */
	@PostMapping("/detail")
	@ApiOperation(value = "상세 코드 추가")
	public ResponseDto insertCodeDetail(@RequestBody CodeDetailVo codeVo) {
		ResponseDto result = new ResponseDto();

		SessionUtil.addUserInfo(codeVo);
		CodeGroupVo validCodeVo = codeService.getCodeGroup(codeVo.getGroupCodeId());
		if(validCodeVo == null) {
			result.setCode(CommonConstants.FAIL);
			result.setMessage("존재하지 않는 그룹 코드 입니다");
			return result;
		}
		CodeDetailVo validCodeVo2 = codeService.getCodeDetail(codeVo);
		if(validCodeVo2 != null) {
			result.setCode(CommonConstants.FAIL);
			result.setMessage("중복 된 상세 코드가 존재합니다");
			return result;
		}
		int re = codeService.insertCodeDetail(codeVo);

		return result;
	}

	/**
	 * 그룹 코드 삭제
	 * @param groupCodeId
	 * @return
	 */
	@DeleteMapping("/group/{groupCodeId}")
	@ApiOperation(value = "그룹 코드 삭제")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "groupCodeId", value = "그룹 코드", required = true)
	})
	public ResponseDto deleteCodeGroup(@PathVariable(required = true) String groupCodeId) {
		String [] groupCodeIds = groupCodeId.split(",");
		int re = codeService.deleteCodeGroup(groupCodeIds);
		ResponseDto result = new ResponseDto();
		return result;
	}

	/**
	 * 상세 코드 삭제
	 * @param detailCodeId
	 * @param groupCodeId
	 * @param codeDetailVo
	 * @return
	 */
	@DeleteMapping("/detail/{detailCodeId}/{groupCodeId}")
	@ApiOperation(value = "상세 코드 삭제")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "detailCodeId", value = "상세 코드", required = true),
		@ApiImplicitParam(name = "groupCodeId", value = "그룹 코드", required = true)
	})
	public ResponseDto deleteCodeDetail(@PathVariable(required = true) String detailCodeId, @PathVariable(required = true) String groupCodeId,  CodeDetailVo codeDetailVo) {
		String [] detailCodeIds = detailCodeId.split(",");
		
		codeDetailVo.setDetailCodeIds(detailCodeId.split(","));
		codeDetailVo.setGroupCodeId(groupCodeId);
		int re = codeService.deleteCodeDetail(codeDetailVo);

		ResponseDto result = new ResponseDto();
		return result;
	}
	
	/**
	 * 상세 코드 수정 처리
	 * @param chkSn
	 * @param authAppVo
	 * @param request
	 * @return
	 */
	@PutMapping("/update")
	@ApiOperation(value = "상세 코드 수정 처리")
	public ResponseDto detailCodeUpdeate(@RequestBody CodeDetailVo codeDetailVo, HttpServletRequest request) {
		ResponseDto result = new ResponseDto();
		
		try { 
			 
			UserInfo userInfo = SessionUtil.getUserInfo();
			codeDetailVo.setUpdtId(userInfo.getUsrId());
			int re = codeService.detailCodeUpdeate(codeDetailVo);

		} catch(Exception e) {
			e.printStackTrace();
			result.setCode(CommonConstants.FAIL);
			result.setMessage("권한신청 반려 처리중 오류가 발생하였습니다.");
			return result;
		}
		return result; 
	}
	
}
