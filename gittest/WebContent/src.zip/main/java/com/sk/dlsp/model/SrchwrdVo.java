package com.sk.dlsp.model;

public class SrchwrdVo {

	int rownum;
	String srchwrd;

	public int getRownum() {
		return rownum;
	}
	public void setRownum(int rownum) {
		this.rownum = rownum;
	}
	public String getSrchwrd() {
		return srchwrd;
	}
	public void setSrchwrd(String srchwrd) {
		this.srchwrd = srchwrd;
	}


}
