package com.sk.dlsp.biz.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sk.dlsp.biz.mapper.CodeMapper;
import com.sk.dlsp.model.CodeDetailVo;
import com.sk.dlsp.model.CodeGroupVo;

@Service
@Transactional
public class CodeService {
    @Autowired CodeMapper codeMapper;

	public List<CodeGroupVo> getCodeGroupList(Map<String,String> vo){
		return codeMapper.getCodeGroupList(vo);
	}

	public CodeGroupVo getCodeGroup(String id) {
		return codeMapper.getCodeGroup(id);
	}
	public List<CodeDetailVo> getCodeDetailList(Map<String,String> vo) {
		return codeMapper.getCodeDetailList(vo);
	}
	
	public List<CodeDetailVo> getCodeUseDetailList(Map<String,String> vo) {
		return codeMapper.getCodeUseDetailList(vo);
	}

	public CodeDetailVo getCodeDetail(CodeDetailVo vo) {
		return codeMapper.getCodeDetail(vo);
	}

	public int insertCodeGroup(CodeGroupVo vo) {
		return codeMapper.insertCodeGroup(vo);
	}

	public int insertCodeDetail(CodeDetailVo vo) {
		return codeMapper.insertCodeDetail(vo);
	}

	public int deleteCodeGroup(String[] groupCodeIds) {
		int re = codeMapper.deleteCodeGroup(groupCodeIds);
		if(re > 0) {
			codeMapper.deleteCodeDetailByCodeGroup(groupCodeIds);
		}
		return re;
	}

	public int deleteCodeDetail(CodeDetailVo codeDetailVo) {
		return codeMapper.deleteCodeDetail(codeDetailVo);
	}
	
	public int detailCodeUpdeate(CodeDetailVo vo) {
		return codeMapper.detailCodeUpdeate(vo);
	}

}
