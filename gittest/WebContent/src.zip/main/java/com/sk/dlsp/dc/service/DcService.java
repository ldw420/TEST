package com.sk.dlsp.dc.service;

import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.tomcat.util.buf.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sk.dlsp.common.exception.BizException;
import com.sk.dlsp.common.util.StringUtil;
import com.sk.dlsp.dc.mapper.DcMapper;
import com.sk.dlsp.model.DcApprovalDataVo;
import com.sk.dlsp.model.DcApprovalVo;
import com.sk.dlsp.model.DcCompVo;
import com.sk.dlsp.model.DcConsentVo;
import com.sk.dlsp.model.DcCtgVo;
import com.sk.dlsp.model.DcReqBlockChainVo;
import com.sk.dlsp.model.DcSuccessVo;
import com.sk.dlsp.model.DcTableInfoVo;
import com.sk.dlsp.model.DcTableParamVo;
import com.sk.dlsp.model.DcVo;

@Service
@Transactional
public class DcService {
	
	@Autowired DcMapper dcMapper;
	@Autowired DcApiService dcApiService;

	public List<DcVo> getDcList(Map<String, Object> param) {
		return dcMapper.getDcList(param);
	}

	public int getDcListCount(Map<String, Object> param) {
		return dcMapper.getDcListCount(param);
	}

	public List<DcCtgVo> getDcCtgList(Map<String, Object> param) {
		return dcMapper.getDcCtgList(param);
	}

	public List<DcCompVo> getDcCopmList(Map<String, Object> param) {
		return dcMapper.getDcCopmList(param);
	}

	public int insertDcDataUseApp(Map<String, Object> param) {
		int retCnt = dcMapper.insertDcDataUseApp(param);
		
		if(retCnt > 0) {
			
			return 1;
		} else {
			
			return 0;
		}
		
	}

	public int insertDcDataUse(DcApprovalVo dcVo) throws Exception{
		// insert master 
		// 요청한 data 저장 후 블럭체인 api 호출
		String strTimeUid = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss").withZone(ZoneOffset.of("+0900")).format(Instant.now());
    	String strTxId = strTimeUid.replaceAll("-", "").replaceAll(":","").replaceAll(" ","");
		dcVo.setTxId(strTxId + "SD001");
		
    	Map<String,Object> param = new HashMap<>();
    	//trans_id, confm_comp, confm_id, req_comp, req_id, sttus, register_dtm
    	param.put("transId", dcVo.getTxId());
    	// 승인자 정보(관계사)
    	param.put("confmComp", dcVo.getApproverCom());   	
    	// 승인자 정보(Id) --> empty 처리
    	param.put("confmId", "");
    	param.put("reqComp", dcVo.getRequesterCom());
    	param.put("reqId", dcVo.getRequester());
    	//
    	/**수정내역
    	 * 1. 개발 시연동안 디비저장시 상태값을 00004 로,  
    	 * 2. 시연종료후 상태값 00004 --> 00001  로 수정, 20191031
    	 */
    	param.put("sttus", "00001"); // 
    	param.put("registerDtm", strTimeUid);
    	//	
    	param.put("classTitle", dcVo.getClassTitle());
    	param.put("appPrvonsh", dcVo.getReqReason());
    	
    	param.put("resourceId", dcVo.getResourceId());
    	
    	int retCnt = dcMapper.insertDcDataUseApp(param);

		if(retCnt > 0) {
			// insert detail table
			int datasize = dcVo.getConsentDetailDTOList().size();
			int chkSize = datasize; 
			for(int i=0; i<datasize; i++) {
				DcApprovalDataVo dataVo =  (DcApprovalDataVo) dcVo.getConsentDetailDTOList().get(i);

				Map<String,Object> detail = new HashMap<>();
				
				detail.put("classKey", dcVo.getClassKey());

				detail.put("transId", dcVo.getTxId());
				detail.put("seq", i+1);
				detail.put("reqTbl", dataVo.getRequestTable());
				detail.put("reqCol", dataVo.getRequestColumn());
				detail.put("scope", "1111");
				detail.put("staDtm", dataVo.getStartAt());
				detail.put("endDtm", dataVo.getFinishAt());
				detail.put("shrSttus", ""); // 현재 사용하고 있지 않으므로 emtpty 처리
				//
				detail.put("companyCode", dataVo.getCompanyCode());
				detail.put("databaseName", dataVo.getDatabaseName());
				detail.put("resourceId", dataVo.getResourceId());// 데이터베이스 종류
				detail.put("subjectName", dataVo.getSubjectName());// 주제영역
				detail.put("infoSystemName", dataVo.getInfoSystemName());// infoSystemName 필수값 
				
				int cnt = dcMapper.insertDcDataUseAppDetail(detail);
				if(cnt > 0) {
					chkSize--;
				}
			}
			if(chkSize == 0) {
				return 1;
			} else {
				return 0;
			}
		} else {
			return 0;
		}
	}

	
	public String getDcApprovalData(String param) throws Exception {
		DcReqBlockChainVo ApprovalVoList = dcMapper.getDcDataUseAppList(param);
		ObjectMapper om = new ObjectMapper();
		return om.writeValueAsString(ApprovalVoList);
	}

	public int updateHitCnt(Map<String, Object> param) {
		param.put("cmpCompanyCode", dcMapper.getCmpCompanyCode(param));
		return dcMapper.updateHitCnt(param);
	}

	public DcVo getDcDetailInfo(Map<String, Object> param) {
		return dcMapper.getDcDetailInfo(param);
	}

	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> getApiSchemaInfo(DcTableInfoVo dcSchemaVo, String reqApiUrl) throws Exception {
		List<Map<String,Object>> retList = new ArrayList<>();
		
		List<DcTableParamVo> list = dcSchemaVo.getTableInfo();
		int listsize = list.size();

		for(int i=0; i<listsize; i++) {
			String reqUrl = reqApiUrl;
			DcTableParamVo paramVo = (DcTableParamVo)list.get(i);

			reqUrl += "?";
		    reqUrl += "tableId=" + paramVo.getTableId() + "&";
		    reqUrl += "companyCode=" + paramVo.getCompanyCode() + "&";
		    reqUrl += "databaseName=" + paramVo.getDatabaseName() + "&";
		    reqUrl += "subjectName=" + paramVo.getSubjectName() + "&";
		    reqUrl += "resourceId=" + paramVo.getResourceId();
			String retJson = dcApiService.getXmlApi(reqUrl);  //Lv3 API 호출
			

			if( !StringUtil.isEmpty(retJson)) {
				ObjectMapper om = new ObjectMapper();
				Map<String,Object> tmpMap = om.readValue(retJson, Map.class);
				if( !StringUtil.isEmpty(tmpMap)) {
					List<Map<String,Object>> columnList = (List<Map<String, Object>>) tmpMap.get("item");
					//
					int colsize = columnList.size();
					String[] arrColId = new String[colsize];
					for(int j=0; j<colsize; j++) {
						Map<String,Object> cMap = columnList.get(j);
						arrColId[j] = cMap.get("columnId").toString();
					}
					//
					Map<String,Object> tableMap = new LinkedHashMap<>();
					Map<String,Object> colMap = columnList.get(0);
					String[] arrColName = {"tableId", "tableName","subjectName","resourceId", "databaseName", "companyCode", "companyName","dataCount", "tableOpenYn", "infoSystemName"};
					for(int k=0; k<arrColName.length; k++ ) {
						
						if(arrColName[k].equals("databaseName")) {
							String dbNameLocation = String.valueOf(colMap.get(arrColName[k]));
							if( !StringUtil.isEmpty(dbNameLocation)) {
								String[] arrTemp = dbNameLocation.split("_");
								tableMap.put(arrColName[k], arrTemp[0]);
							} else {
								tableMap.put(arrColName[k], "");						
							}
						} else if(arrColName[k].equals("infoSystemName")) {
							String strInfoSysName = String.valueOf(colMap.get(arrColName[k]));
							if(StringUtil.isEmpty(strInfoSysName)) {
								tableMap.put(arrColName[k], "test"); // Not empty 항목이어서 임시로 defaultValue==test 적용
							} else {
								tableMap.put(arrColName[k], colMap.get(arrColName[k]));																
							}
						} else {
							tableMap.put(arrColName[k], colMap.get(arrColName[k]));
						}
					}
					tableMap.put("requestColumn", StringUtils.join(arrColId));
					tableMap.put("columnData", columnList);
					List<Map<String,Object>> tableList = new ArrayList<>();
					tableList.add(tableMap);
					retList.addAll(tableList);
				}
			} //
		}

		return retList;
	}

	public int insertDcDataUseAndSendBlockChain(DcApprovalVo dcVo, String approvalUrl, String classKey) throws Exception{
		//
		dcVo.setClassKey(classKey);
		int retCnt = this.insertDcDataUse(dcVo);

		String txId = dcVo.getTxId();

		/**수정내역
		 * 1. PROD 에서 block chain api 호출시 연동 오류발생, 시연용으로 해당 부분 주석처리, 20191030
		 * 2. DB 저장 부분과 block chain api 호출 부분을 분리 처리 , block chain 호출 부분 사용안함, 20191031
		 */
		//********block chain 호출 SS**************
//    	if(retCnt > 0) { // 요청항목 DB저장 OK 이면 Block-Chain API 호출
//    		// 저장된 공유요청 항목 조회 (by 트랜잭션ID)  
//    		String jsonData = this.getDcApprovalData(txId);
//
//			// block chain api call
//			String retData = dcApiService.apiPost(approvalUrl, jsonData);
//
//			if("fail".equals(retData) || "exception".equals(retData)) {
//				throw new BizException("block chain api 처리중 오류가 발생하였습니다.");
//			}
//    	} else {
//    		throw new BizException("공유요청 항목 저장시 오류가 발생했습니다.");
//    	}
    	//********block chain 호출 EE**************
		//
		return 1;
	}

	public List<DcConsentVo> getConsentList(Map<String, Object> param) {
		return dcMapper.getConsentList(param);
	}

	public int insertDcSearchWord(Map<String, Object> param) {
		return dcMapper.insertDcSearchWord(param);
		
	}
	
	// block-chain 에 승인 요청을 위한 서비스 함수
	public int insertDcBlockChainApprovalApi(String txId, String approvalUrl) throws Exception {

		String jsonData = this.getDcApprovalData(txId);
		
		// block chain api call
		String retData = dcApiService.apiPost(approvalUrl, jsonData);
		if("fail".equals(retData) || "exception".equals(retData)) {
			throw new BizException("block chain api 연계중 오류가 발생하였습니다.");
		}
		return 1;
	}

	public List<DcCtgVo> getDcCtgCountList(Map<String, Object> param) {
		return dcMapper.getDcCtgCountList(param);
	}

	public List<DcCompVo> getDcCopmCountList(Map<String, Object> param) {
		return dcMapper.getDcCopmCountList(param);
	}

	public int updateSuccessYnFromBlockChain(DcSuccessVo dcSuccessVo) {
		return dcMapper.updateSuccessYnFromBlockChain(dcSuccessVo);
	}
	
	

}
