package com.sk.dlsp.common.consts;

public class AuthConstants {

	public static String TOKEN = "authToken";
	public static String ISSURE = "dslpIssuer";

	public static String SECURE_KEY = "datalakeserviceportal";

}
