package com.sk.dlsp.model;

public class MydashboardVo {
	private String userId;
	private String authId;
	private String comp;
	private int cnt;
	private String sn;
	private int intSn;
	
	private String Title;
	private String item;
	private String usrId;
	private String registDe;
	private String sttus;
	private String provSttus; //이전 승인 상태
	private String confmDe;
	private String staDtm;
	private String endDtm;
	private String sttusNm;
	private String confmId;
	private String confmNm;
	private String confmComp;
	private String userNm;
	private String div;
	private String confmCn;
	private String transId;
	private String check;
	//데이터 신청 테이블 내용
	private String seq;
	private String reqTbl;
	private String reqCol;
	private String shrSttus;
	private String companycode;
	private String databasename;
	private String resourceid;
	private String infosystemname;
	private String classkey;
	private String subjectName;
	
	//스크랩 목록
	private String compNm;
	private String ctgNm;
 
	
 
	public String getProvSttus() {
		return provSttus;
	}
	public void setProvSttus(String provSttus) {
		this.provSttus = provSttus;
	}
	public String getCompNm() {
		return compNm;
	}
	public void setCompNm(String compNm) {
		this.compNm = compNm;
	}
	public String getCtgNm() {
		return ctgNm;
	}
	public void setCtgNm(String ctgNm) {
		this.ctgNm = ctgNm;
	}
	public String getAuthId() {
		return authId;
	}
	public void setAuthId(String authId) {
		this.authId = authId;
	}
	public String getCheck() {
		return check;
	}
	public void setCheck(String check) {
		this.check = check;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getReqTbl() {
		return reqTbl;
	}
	public void setReqTbl(String reqTbl) {
		this.reqTbl = reqTbl;
	}
	public String getReqCol() {
		return reqCol;
	}
	public void setReqCol(String reqCol) {
		this.reqCol = reqCol;
	}
	public String getShrSttus() {
		return shrSttus;
	}
	public void setShrSttus(String shrSttus) {
		this.shrSttus = shrSttus;
	}
	public String getCompanycode() {
		return companycode;
	}
	public void setCompanycode(String companycode) {
		this.companycode = companycode;
	}
	public String getDatabasename() {
		return databasename;
	}
	public void setDatabasename(String databasename) {
		this.databasename = databasename;
	}
	public String getResourceid() {
		return resourceid;
	}
	public void setResourceid(String resourceid) {
		this.resourceid = resourceid;
	}
	public String getInfosystemname() {
		return infosystemname;
	}
	public void setInfosystemname(String infosystemname) {
		this.infosystemname = infosystemname;
	}
	public String getClasskey() {
		return classkey;
	}
	public void setClasskey(String classkey) {
		this.classkey = classkey;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public String getTransId() {
		return transId;
	}
	public void setTransId(String transId) {
		this.transId = transId;
	}
	public int getIntSn() {
		return intSn;
	}
	public void setIntSn(int intSn) {
		this.intSn = intSn;
	}
	public String getConfmCn() {
		return confmCn;
	}
	public void setConfmCn(String confmCn) {
		this.confmCn = confmCn;
	}
	public String getDiv() {
		return div;
	}
	public void setDiv(String div) {
		this.div = div;
	}
	public String getSn() {
		return sn;
	}
	public void setSn(String sn) {
		this.sn = sn;
	}
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	public String getConfmNm() {
		return confmNm;
	}
	public void setConfmNm(String confmNm) {
		this.confmNm = confmNm;
	}
	public String getConfmComp() {
		return confmComp;
	}
	public void setConfmComp(String confmComp) {
		this.confmComp = confmComp;
	}
	public String getConfmId() {
		return confmId;
	}
	public void setConfmId(String confmId) {
		this.confmId = confmId;
	}
	public String getSttusNm() {
		return sttusNm;
	}
	public void setSttusNm(String sttusNm) {
		this.sttusNm = sttusNm;
	}
	public int getCnt() {
		return cnt;
	}
	public void setCnt(int cnt) {
		this.cnt = cnt;
	}
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		Title = title;
	}
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public String getUsrId() {
		return usrId;
	}
	public void setUsrId(String usrId) {
		this.usrId = usrId;
	}
	public String getRegistDe() {
		return registDe;
	}
	public void setRegistDe(String registDe) {
		this.registDe = registDe;
	}
	public String getSttus() {
		return sttus;
	}
	public void setSttus(String sttus) {
		this.sttus = sttus;
	}
	public String getConfmDe() {
		return confmDe;
	}
	public void setConfmDe(String confmDe) {
		this.confmDe = confmDe;
	}
	public String getStaDtm() {
		return staDtm;
	}
	public void setStaDtm(String staDtm) {
		this.staDtm = staDtm;
	}
	public String getEndDtm() {
		return endDtm;
	}
	public void setEndDtm(String endDtm) {
		this.endDtm = endDtm;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public String getComp() {
		return comp;
	}
	public void setComp(String comp) {
		this.comp = comp;
	}
	 
}