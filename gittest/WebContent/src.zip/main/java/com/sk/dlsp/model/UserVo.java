package com.sk.dlsp.model;

import com.amazonaws.auth.AWSCredentials;

public class UserVo extends CommonVo {

	private String usrId;
	private String nm;
	private String pw;
	private String cttpc;
	private String agency;
	private String agencyNm;
	private String authId;
	private String authNm;
	private String pdeConfmDe;
	private String deptcode;
	private String deptname;
	private String partneryn;


	/////////////////////////////////////////////////////////////////////
	// AWS 관련 정보 등 확인 필요 사항 !!!
	//
	private String accessKeyId;
	private String secretAccessKey;
	private String sessionToken;

	//////////////////////////////////////////////////////////////////////



	// sagemaker 생성 정보 조회용
	private String roleArnMange;
	private String roleIdManage;
	private String roleSessionManage;

	// sagemaker 기동 / 변경 용
	private String roleArnRun;
	private String roleIdRun;
	private String roleSessionRun;

	// 계열사 정보에 대한 aws 정보 - agency 에 계열사 명이나 ...
	// 계열사 별로 DB 정보에 저장이 되어야 한 는거니 ...
	private String subnetId;
	private String securityGroup;
	////////////////////////////////////////////////////////////////////

	private AWSCredentials awsCreds = null;


	public String getSessionToken() {
		return sessionToken;
	}

	public void setSessionToken(String sessionToken) {
		this.sessionToken = sessionToken;
	}

	public void setAwsCreds ( AWSCredentials awsCreds ) {
		this.awsCreds = awsCreds;
	}

	public AWSCredentials getAwsCreds () {

		return this.awsCreds;
	}

	public String getRoleArnManage () {

		return this.roleArnMange;
	}

	public void setRoleArnManage ( String roleArnMange ) {
		this.roleArnMange = roleArnMange;
	}

	public String getRoleIdManage () {

		return this.roleIdManage;
	}

	public void setRoleIdManage ( String roleIdManage ) {
		this.roleIdManage = roleIdManage;
	}

	public String getAccessKeyId() {
		return accessKeyId;
	}

	public void setAccessKeyId(String accessKeyId) {
		this.accessKeyId = accessKeyId;
	}

	public String getSecretAccessKey() {
		return secretAccessKey;
	}

	public void setSecretAccessKey(String secretAccessKey) {
		this.secretAccessKey = secretAccessKey;
	}

	public String getAuthNm() {
		return authNm;
	}

	public void setAuthNm(String authNm) {
		this.authNm = authNm;
	}

	public String getUsrId() {
		return usrId;
	}

	public void setUsrId(String usrId) {
		this.usrId = usrId;
	}

	public String getNm() {
		return nm;
	}

	public void setNm(String nm) {
		this.nm = nm;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public String getCttpc() {
		return cttpc;
	}

	public void setCttpc(String cttpc) {
		this.cttpc = cttpc;
	}

	public String getAgency() {
		return agency;
	}

	public void setAgency(String agency) {
		this.agency = agency;
	}

	public String getAuthId() {
		return authId;
	}

	public void setAuthId(String authId) {
		this.authId = authId;
	}

	public String getPdeConfmDe() {
		return pdeConfmDe;
	}

	public void setPdeConfmDe(String pdeConfmDe) {
		this.pdeConfmDe = pdeConfmDe;
	}

	public String getRoleArnMange() {
		return roleArnMange;
	}

	public void setRoleArnMange(String roleArnMange) {
		this.roleArnMange = roleArnMange;
	}

	public String getRoleSessionManage() {
		return roleSessionManage;
	}

	public void setRoleSessionManage(String roleSessionManage) {
		this.roleSessionManage = roleSessionManage;
	}

	public String getRoleArnRun() {
		return roleArnRun;
	}

	public void setRoleArnRun(String roleArnRun) {
		this.roleArnRun = roleArnRun;
	}

	public String getRoleIdRun() {
		return roleIdRun;
	}

	public void setRoleIdRun(String roleIdRun) {
		this.roleIdRun = roleIdRun;
	}

	public String getRoleSessionRun() {
		return roleSessionRun;
	}

	public void setRoleSessionRun(String roleSessionRun) {
		this.roleSessionRun = roleSessionRun;
	}

	public String getSubnetId() {
		return subnetId;
	}

	public void setSubnetId(String subnetId) {
		this.subnetId = subnetId;
	}

	public String getSecurityGroup() {
		return securityGroup;
	}

	public void setSecurityGroup(String securityGroup) {
		this.securityGroup = securityGroup;
	}

	public String getAgencyNm() {
		return agencyNm;
	}

	public void setAgencyNm(String agencyNm) {
		this.agencyNm = agencyNm;
	}

	public String getDeptcode() {
		return deptcode;
	}

	public void setDeptcode(String deptcode) {
		this.deptcode = deptcode;
	}

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}

	public String getPartneryn() {
		return partneryn;
	}

	public void setPartneryn(String partneryn) {
		this.partneryn = partneryn;
	}

}
