package com.sk.dlsp.biz.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.sk.dlsp.bi.service.GalleryService;
import com.sk.dlsp.biz.service.BiService;
import com.sk.dlsp.common.consts.CommonConstants;
import com.sk.dlsp.common.util.SessionUtil;
import com.sk.dlsp.common.util.StringUtil;
import com.sk.dlsp.model.BiVo;
import com.sk.dlsp.model.ResponseDto;
import com.sk.dlsp.model.UserInfo;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(CommonConstants.API_PREFIX)
public class BiController {
	
	// s3에 맞게 경로 수정하셔서 사용하세요.
	private String REPORT_IMAGE_LOCAL_PATH = "resources/bi/report/";
	//private String REPORT_IMAGE_AWS_BUCKET_NAME = "resource-portal-tableauimg-dat-d-datalake";
	
	@Value("${prov.reprot.image.aws.bucket.name}") String REPORT_IMAGE_AWS_BUCKET_NAME;

	@Autowired BiService biService;
	@Autowired GalleryService galleryService;

	/**
	 * Bi 조회
	 * @param schBiRepSj
	 * @param schCopm
	 * @param schOrd
	 * @param schCtg
	 * @param pageNo
	 * @return
	 */
	@GetMapping("/bi")
	@ApiOperation(value = "Bi 조회")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "schBiRepSj", value = "레포트 제목", required = false),
	    @ApiImplicitParam(name = "schCopm", value = "관계사", required = false),
	    @ApiImplicitParam(name = "schCtg", value = "카테고리", required = false),
	    @ApiImplicitParam(name = "schOrd", value = "정렬 순서", required = false)
	})
	public ResponseDto getBiList(@RequestParam(required = false) String schBiRepSj
								,@RequestParam(required = false) String schCopm
								,@RequestParam(required = false) String schOrd
								,@RequestParam(required = false) String schCtg, int pageNo ) {
		// Extract the userInfo, 20191022 by pkh 
		UserInfo userInfo = SessionUtil.getUserInfo();
		if(pageNo < 1)pageNo = 1;
		 
		ResponseDto result = new ResponseDto();
		Map<String,Object> param = new HashMap<>();
		
		param.put("pageNo", pageNo);
		param.put("schBiRepSj", schBiRepSj);
		param.put("schCopm", schCopm);
		param.put("schOrd", schOrd);
		param.put("schCtg", schCtg);
		param.put("copm", userInfo.getAgency());
		param.put("updtId", userInfo.getUsrId());
		param.put("arrCtg", schCtg.split(","));
		param.put("arrCopm", schCopm.split(","));
		
		List<BiVo> biList 		= biService.getBiList(param); 
		int biListCount 		= biService.getBiListCount(param);
		List<BiVo> biCtgList 	= biService.getBiCtgList(param); 
		List<BiVo> biCompList 	= biService.getBiCopmList(param); 
		
		// 검색어 저장추가
		if( !StringUtil.isEmpty(schBiRepSj)) {
			Map<String,Object> srchMap = new HashMap<>();
			srchMap.put("srchwrd", schBiRepSj);
			biService.insertBiSearchWord(srchMap);
		}
		

		
		result.putData("biListCount", biListCount);
		result.putData("biCtgList", biCtgList);
		result.putData("biCompList", biCompList);
		result.putData("biList", biList);
		return result;
	}
	
	/**
	 * Bi 조회
	 * @param schBiRepSj
	 * @param schCopm
	 * @param schOrd
	 * @param schCtg
	 * @param pageNo
	 * @param copm
	 * @return
	 */
	@GetMapping("/biAdmin")
	@ApiOperation(value = "Bi 조회")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "schBiRepSj", value = "레포트 제목", required = false),
	    @ApiImplicitParam(name = "schCopm", value = "관계사", required = false),
	    @ApiImplicitParam(name = "schCtg", value = "카테고리", required = false),
	    @ApiImplicitParam(name = "schOrd", value = "정렬 순서", required = false)
	})
	public ResponseDto getBiAdminList(@RequestParam(required = false) String schBiRepSj
								,@RequestParam(required = false) String schCopm
								,@RequestParam(required = false) String schOrd
								,@RequestParam(required = false) String schCtg, int pageNo , @RequestParam(required = false) String copm) {
		
		if(pageNo < 1)pageNo = 1;
		
		
		ResponseDto result = new ResponseDto();
		Map<String,Object> param = new HashMap<>();
		
		param.put("pageNo", pageNo);
		param.put("schBiRepSj", schBiRepSj);
		param.put("schCopm", schCopm);
		param.put("schOrd", schOrd);
		param.put("schCtg", schCtg);
		
		List<BiVo> biList 		= biService.getBiAdminList(param); 
		int biListCount 		= biService.getBiAdminListCount(param);
 

		
		result.putData("biListCount", biListCount); 
		result.putData("biList", biList);
		return result;
	}

	/**
	 * Bi 상세 조회
	 * @param sn
	 * @param copm
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/bi/{sn}")
	@ApiOperation(value = "Bi 상세 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "sn", value = "Bi 키", required = true)
	})
	public ResponseDto getBiList(@PathVariable(required = true) int sn, @RequestParam(required = false) String copm) throws Exception {

		ResponseDto result = new ResponseDto();
		
		try {
			
			UserInfo userInfo = SessionUtil.getUserInfo();
			
			//cnt 증가
			int re = biService.updateBiCnt(sn);
			//상세 정보 조회
			BiVo biDetail = biService.getBiDetail(sn);
			
			Map<String,Object> param = new HashMap<>();
			param.put("shrUrl",biDetail.getShrUrl());
			param.put("updtDe",biDetail.getUpdtDe());
			param.put("copm", userInfo.getAgency());
			
			List<BiVo> getPrevNextBiReport = biService.getPrevNextBiReport(param);
	
			// prev workbook
			result.putData("prevNextReport", getPrevNextBiReport);
	
			result.putData("reportUrl", galleryService.makeTableauEmbedUrl(param));
			result.putData("biDetail", biDetail);
			
			
		} catch(Exception e) {
			e.printStackTrace();
			result.setCode(CommonConstants.FAIL);
			result.setMessage("Tableau 레포트 상세 조회 중  오류가 발생하였습니다.");
			return result;
		}
		return result;
	}

	/**
	 * Bi 등록
	 * @param biVo
	 * @return
	 */
	@PostMapping("/bi")
	@ApiOperation(value = "Bi 등록")
	public ResponseDto insertBi(@RequestBody BiVo biVo) {
		
		// Extract the userInfo, 20191022 by pkh 
		UserInfo userInfo = SessionUtil.getUserInfo();
		biVo.setCopm(userInfo.getAgency());
		biVo.setUpdtId(userInfo.getUsrId());
		biVo.setRegisterId(userInfo.getUsrId());

		ResponseDto result = new ResponseDto();
		
		try {
			int re = biService.insertBi(biVo);

		} catch(Exception e) {
			e.printStackTrace();
			result.setCode(CommonConstants.FAIL);
			result.setMessage("Tableau 레포트 등록 처리중 오류가 발생하였습니다.");
			return result;
		}
		return result; 
	}
	
	/**
	 * Bi 수정
	 * @param sn
	 * @param biVo
	 * @return
	 */
	@PutMapping("/bi/{sn}")
	@ApiOperation(value = "Bi 수정")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "sn", value = "Bi 키", required = true)
	})
	public ResponseDto updateBi(@PathVariable(required = true) int sn ,@RequestBody BiVo biVo) {
		

		biVo.setSn(sn);
		int re = biService.updateBi(biVo);

		ResponseDto result = new ResponseDto();
		return result;
	}

	/**
	 * Bi 삭제
	 * @param biId
	 * @return
	 */
	@DeleteMapping("/bi/{biId}")
	@ApiOperation(value = "Bi 삭제")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "biId", value = "Bi 키", required = true)
	})
	public ResponseDto deleteBi(@PathVariable(required = true) String biId) {
		String [] biSplit = biId.split(",");
		ResponseDto result = new ResponseDto();
		try {
			int[] biIds = Arrays.stream(biSplit).mapToInt(Integer::parseInt).toArray();
			int re = biService.deleteBi(biIds);
		}catch(NumberFormatException ne) {
			result.setCode(CommonConstants.FAIL);
			result.setMessage("잘못된 키값입니다.");
		}
		return result;
	}
	
	/**
	 * Bi 등록
	 * @param biVo
	 * @return
	 */
	@PostMapping("/scrap")
	@ApiOperation(value = "Bi 등록")
	public ResponseDto insertScrap(@RequestBody BiVo biVo) {
		// Extract the userInfo, 20191022 by pkh 
		UserInfo userInfo = SessionUtil.getUserInfo();
		biVo.setCopm(userInfo.getAgency());
		biVo.setUpdtId(userInfo.getUsrId());
		biVo.setRegisterId(userInfo.getUsrId());

		ResponseDto result = new ResponseDto();
		
		try {
			int re = biService.insertScrap(biVo);

		} catch(Exception e) {
			e.printStackTrace();
			result.setCode(CommonConstants.FAIL);
			result.setMessage("Scrap 등록 처리중 오류가 발생하였습니다.");
			return result;
		}
		return result; 
	}
	
	/**
	 * scrap 삭제 
	 * @param biVo
	 * @return
	 */
	@DeleteMapping("/scrap")
	@ApiOperation(value = "scrap 삭제")
	public ResponseDto deleteScrap(@RequestBody BiVo biVo) {
		// Extract the userInfo, 20191022 by pkh 
		UserInfo userInfo = SessionUtil.getUserInfo();
		biVo.setCopm(userInfo.getAgency());
		biVo.setUpdtId(userInfo.getUsrId());
		biVo.setRegisterId(userInfo.getUsrId());

		ResponseDto result = new ResponseDto();
		
		try {
			int re = biService.deleteScrap(biVo);

		} catch(Exception e) {
			e.printStackTrace();
			result.setCode(CommonConstants.FAIL);
			result.setMessage("Scrap 등록 처리중 오류가 발생하였습니다.");
			return result;
		}
		return result; 
	}
	
	
	/**
	 * 미리보기 버튼을 눌렀을 경우 썸네일 이미지를 다운받고 파일명을 return한다. <br>
	 * 저장 할 경우 DB에 파일명 저장해야 하므로 파일명만 넘긴다.
	 * 
	 * @param tableauShareUrl
	 * @return
	 * @throws IOException
	 * 
	 * @see <a href="https://docs.aws.amazon.com/ko_kr/sdk-for-java/v1/developer-guide/examples-s3-objects.html">
	 * https://docs.aws.amazon.com/ko_kr/sdk-for-java/v1/developer-guide/examples-s3-objects.html
	 * </a>
	 */
	@GetMapping("/get-preview-image")
	public ResponseDto getPreviewImage(@RequestParam String tableauShareUrl) throws IOException {

		ResponseDto result = new ResponseDto();
		try {

			galleryService.setWorkbookList(); //11월 05일 추가
			
			File file = galleryService.getPreviewImage(tableauShareUrl, this.REPORT_IMAGE_LOCAL_PATH);
//			File file = galleryService.getPreviewImageViaUrl(tableauShareUrl, this.REPORT_IMAGE_LOCAL_PATH);
			if (file != null && file.exists()) {
				final AmazonS3 s3 = AmazonS3ClientBuilder.standard().withRegion(Regions.AP_NORTHEAST_2).build();
				try {
					/*
					 * origin
					 * s3.putObject(bucket_name, key_name, new File(file_path));
					 */
					s3.putObject(this.REPORT_IMAGE_AWS_BUCKET_NAME, file.getName(), new File(file.getPath()));
					
					result.putData("fileName", file.getName());
				} catch (AmazonServiceException e) {
				    System.err.println(e.getErrorMessage());
				    throw e;
				}
			} else {
				System.out.println("File is null");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	/**
	 * 이미지 불러오기
	 * 
	 * @param request
	 * @param response
	 * @see <a href="https://docs.aws.amazon.com/ko_kr/sdk-for-java/v1/developer-guide/examples-s3-objects.html">
	 * https://docs.aws.amazon.com/ko_kr/sdk-for-java/v1/developer-guide/examples-s3-objects.html
	 * </a>
	 */
	@GetMapping("/show-image")
	public void showImage(HttpServletRequest request, HttpServletResponse response) {
		try {
			String previewImageName = request.getParameter("imageName");
			if (previewImageName == null || "".equals(previewImageName)) {
				return;
			}	
			
			final AmazonS3 s3 = AmazonS3ClientBuilder.standard().withRegion(Regions.AP_NORTHEAST_2).build();
			try {
			    S3Object o = s3.getObject(this.REPORT_IMAGE_AWS_BUCKET_NAME, previewImageName);
			    S3ObjectInputStream s3is = o.getObjectContent();
			    //File file = new File(this.REPORT_IMAGE_LOCAL_PATH + previewImageName + ".png");
			    File file = new File(this.REPORT_IMAGE_LOCAL_PATH + previewImageName);
			    FileOutputStream fos = new FileOutputStream(file);
			    byte[] read_buf = new byte[1024];
			    int read_len = 0;
			    while ((read_len = s3is.read(read_buf)) > 0) {
			        fos.write(read_buf, 0, read_len);
			    }
			    s3is.close();
			    fos.close();
			    
			    InputStream in = new FileInputStream(file);
				response.setContentType(MediaType.IMAGE_PNG_VALUE);
				IOUtils.copy(in, response.getOutputStream());
			} catch (AmazonServiceException e) {
			    System.err.println(e.getErrorMessage());
			    throw e;
			} catch (FileNotFoundException e) {
			    System.err.println(e.getMessage());
			    throw e;
			} catch (IOException e) {
			    System.err.println(e.getMessage());
			    throw e;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
