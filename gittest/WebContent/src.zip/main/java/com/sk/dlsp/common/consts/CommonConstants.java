package com.sk.dlsp.common.consts;

import org.springframework.stereotype.Component;

@Component
public class CommonConstants {

	public static final String AUTH_SERVER_URL = "http://localhost:8080";
	public static final String API_PREFIX = "/api/v1";

	public static final String RESULT = "result";
	public static final String SUCCESS = "success";
	public static final String NOTAUTH = "notAuth";
	public static final String FAIL = "fail";
	public static final String NOT_LOGIN = "notLogin";
	public static final String MESSAGE = "message";
	public static final String EXCEPTION = "exception";
	public static final String JSON_VIEW = "jsonView";
	public static final String PARAM = "param";
	public static final String USER_INFO = "userInfo";
	public static final String USER_ID = "userId";
	public static final String EXCEPTION_URL_STATUS_400 = "/exception/400";
	public static final String EXCEPTION_URL_STATUS_404 = "/exception/404";
	public static final String EXCEPTION_URL_STATUS_500 = "/exception/500";

	public static final String TEMPLATE_PATH = "templates/";
	public static final String VARIABLE_MATCHER_PATTERN = "\\$\\{([a-zA-Z_]+)\\}";
}
