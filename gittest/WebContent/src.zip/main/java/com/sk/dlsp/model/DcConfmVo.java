package com.sk.dlsp.model;

public class DcConfmVo {

	private String transId;
    private String confmComp;
    private String confmId;
    private String reqComp;
    private String reqId;
    private String sttus;
    private String sttusNm;
    private String registerDtm;
    private String classTitle;
    private String appPrvonsh;
    private String confmDe;
    private String confmCn;
    private String reqUserNm;
    
    
    
    
	public String getReqUserNm() {
		return reqUserNm;
	}
	public void setReqUserNm(String reqUserNm) {
		this.reqUserNm = reqUserNm;
	}
	public String getSttusNm() {
		return sttusNm;
	}
	public void setSttusNm(String sttusNm) {
		this.sttusNm = sttusNm;
	}
	public String getTransId() {
		return transId;
	}
	public void setTransId(String transId) {
		this.transId = transId;
	}
	public String getConfmComp() {
		return confmComp;
	}
	public void setConfmComp(String confmComp) {
		this.confmComp = confmComp;
	}
	public String getConfmId() {
		return confmId;
	}
	public void setConfmId(String confmId) {
		this.confmId = confmId;
	}
	public String getReqComp() {
		return reqComp;
	}
	public void setReqComp(String reqComp) {
		this.reqComp = reqComp;
	}
	public String getReqId() {
		return reqId;
	}
	public void setReqId(String reqId) {
		this.reqId = reqId;
	}
	public String getSttus() {
		return sttus;
	}
	public void setSttus(String sttus) {
		this.sttus = sttus;
	}
	public String getRegisterDtm() {
		return registerDtm;
	}
	public void setRegisterDtm(String registerDtm) {
		this.registerDtm = registerDtm;
	}
	public String getClassTitle() {
		return classTitle;
	}
	public void setClassTitle(String classTitle) {
		this.classTitle = classTitle;
	}
	public String getAppPrvonsh() {
		return appPrvonsh;
	}
	public void setAppPrvonsh(String appPrvonsh) {
		this.appPrvonsh = appPrvonsh;
	}
	public String getConfmDe() {
		return confmDe;
	}
	public void setConfmDe(String confmDe) {
		this.confmDe = confmDe;
	}
	public String getConfmCn() {
		return confmCn;
	}
	public void setConfmCn(String confmCn) {
		this.confmCn = confmCn;
	}
	
	 
	

}
