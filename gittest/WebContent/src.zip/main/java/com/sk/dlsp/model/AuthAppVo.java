package com.sk.dlsp.model;

public class AuthAppVo extends CommonVo{

	private int sn;  //순번
	private String usrId;  //신청자 ID
	private String authId;  //신청 권한 ID
	private String appPrvonsh; // 신청 사유
	private String confmSttus; // 승인 상태
	private String confmSttusNm; // 승인 상태 명
	private String confmDe; // 승인 일자
	private String confmId; // 승인자 ID
	private String appDe; // 신청일자
	private String agency;
	private int [] chkSn; //승인 반려 처리할 순번
	private String usrNm;  //신청자 ID
	private String authNm;  //신청 권한 ID
	private String confmCn;
	private String comp;
	
	
	
	public String getComp() {
		return comp;
	}
	public void setComp(String comp) {
		this.comp = comp;
	}
	public String getConfmCn() {
		return confmCn;
	}
	public void setConfmCn(String confmCn) {
		this.confmCn = confmCn;
	}
	public String getAuthNm() {
		return authNm;
	}
	public void setAuthNm(String authNm) {
		this.authNm = authNm;
	}
	public String getUsrNm() {
		return usrNm;
	}
	public void setUsrNm(String usrNm) {
		this.usrNm = usrNm;
	}
	public int getSn() {
		return sn;
	}
	public void setSn(int sn) {
		this.sn = sn;
	}
	public String getUsrId() {
		return usrId;
	}
	public void setUsrId(String usrId) {
		this.usrId = usrId;
	}
	public String getAuthId() {
		return authId;
	}
	public void setAuthId(String authId) {
		this.authId = authId;
	}
	public String getAppPrvonsh() {
		return appPrvonsh;
	}
	public void setAppPrvonsh(String appPrvonsh) {
		this.appPrvonsh = appPrvonsh;
	}
	public String getConfmSttus() {
		return confmSttus;
	}
	public void setConfmSttus(String confmSttus) {
		this.confmSttus = confmSttus;
	}
	public String getConfmDe() {
		return confmDe;
	}
	public void setConfmDe(String confmDe) {
		this.confmDe = confmDe;
	}
	public String getConfmId() {
		return confmId;
	}
	public void setConfmId(String confmId) {
		this.confmId = confmId;
	}
	public String getAppDe() {
		return appDe;
	}
	public void setAppDe(String appDe) {
		this.appDe = appDe;
	}
	
	 
	public int[] getChkSn() {
		return chkSn;
	}
	public void setChkSn(int[] chkSn) {
		this.chkSn = chkSn;
	}
	public String getAgency() {
		return agency;
	}
	public void setAgency(String agency) {
		this.agency = agency;
	}
	public String getConfmSttusNm() {
		return confmSttusNm;
	}
	public void setConfmSttusNm(String confmSttusNm) {
		this.confmSttusNm = confmSttusNm;
	}
	 
	
	

}
