package com.sk.dlsp.biz.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.sk.dlsp.model.AuthAppVo; 

@Mapper
public interface AuthAppMapper {

    public List<AuthAppVo> getAuthAppList(Map<String, Object> param); 

	public int getAuthAppListCount(Map<String, Object> param);
	
	public int confmNo(AuthAppVo vo);
	
	public int confmUsrAuthChang(AuthAppVo vo);
	
	public int insertAuthApp(AuthAppVo vo);
	
	public int authCheckCnt(AuthAppVo vo);
 
}
