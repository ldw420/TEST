package com.sk.dlsp.biz.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.sk.dlsp.model.BiVo;

@Mapper
public interface BiMapper {

	public List<BiVo> getBiList(Map<String, Object> param);
	
	public List<BiVo> getBiAdminList(Map<String, Object> param);
	
	public List<BiVo> getBiCtgList(Map<String, Object> param);
	
	public List<BiVo> getBiCopmList(Map<String, Object> param);
	
	public List<BiVo> getPrevNextBiReport(Map<String, Object> param);
	 
	public int getBiListCount(Map<String, Object> param);
	
	public int getBiAdminListCount(Map<String, Object> param);

	public BiVo getBiDetail(int sn);
	
	public int updateBiCnt(int sn);

	public int insertBi(BiVo biVo);

	public int updateBi(BiVo biVo);

	public int deleteBi(int[] biIds);
	
	public int insertScrap(BiVo biVo);
	
	public int deleteScrap(BiVo biVo);

	public int insertBiSearchWord(Map<String, Object> param);

}
