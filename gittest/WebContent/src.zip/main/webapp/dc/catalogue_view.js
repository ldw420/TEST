/**
 * TITLE : DLSP
 * DESC : 메인화면 
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var catalogue = function() {};

head.ready(function () {

	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}

	(function($) { "use strict";

	
	
		//var key = commAjax.getParameter("key");
		
		var form,param,pagination,agencyCheck;
		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		catalogue.init = function() {
			
			//메뉴 권한 채크
			//commUsr.menuAuthCheck();
			
			form = $("#frm01");
			param = commAjax.getJsonFromQry(location.href);
			
			//General User 공유요청X
			if (userInfo.authId!="A0003"){
				$("#btnType").css("display","");
			}
			
			//상단
			catalogue.list();
		};
		 
		//상단
		catalogue.list=function(){
			$.ajax({
				type: "Get",
				url : _CONSTANTS["URL_BASE"]+"dc/table-info/"+param.key,
				data: '',
				success : function(data, status, xhr) {
					
					if (data.code=="success") {
						
						var html ='';
						var dcList = data.data.baseInfo;
						var classTitle = dcList.classTitle;
						var dcConsentList = data.data.consentInfo; //공유상태 체크용 Data
						
						if (dcList.docId ==0 || dcList.docId==null || dcList.docId==undefined) {
							html += "<button class='scrap' value="+dcList.classKey+">스크랩</button>";
						}else {
							html += "<button class='scrap on' value="+dcList.classKey+">스크랩</button>";
						}
						
						//관계사가 같을 경우 Y(공유 요청 못함) 
						if (dcList.cmpCompanyCode == userInfo.agency) {
							agencyCheck = "Y";
						}
						
						html += '<h1>'+dcList.classTitleName+'</h1>';
						html += '<p>';
						html += '<span>관계사│'+dcList.cmpCompanyCodeNm+'</span>';
						html += '<span>카테고리│'+dcList.pathFirst+'</span>';
						html += '<span>조회수│'+dcList.rdcnt+'</span>';
						html += '<span>신청건수│'+dcList.applyCnt+'</span>';
						html += '<span>업데이트│'+dcList.modifyDt+'</span>';
						html += '</p>'
						html += '<p>'+dcList.bizMeta+'</p>'
						html += '<input type="hidden" value="'+dcList.cmpCompanyCode+'" id="hidCompCode">';
						html += '<input type="hidden" value="'+dcList.classTitlePath+'" id="hidTitlePath">';
						html += '<input type="hidden" value="'+dcList.cmpCompanyCodeNm+'" id="hidCompName">';
						
						$("#baseArea").empty().append(html);
						
						var dcList = data.data.tableInfo.item;
						
						var tableOpenYn = ''; //공유가능 여부
						var tableShareYn = ''; //공유상태
						var dataCount; //데이터 건수
						var resourceId;
						var description; //설명
						
						html ='';
						//테이블(중단)
						$.each(dcList,function(i) {
					
							//공유 가능여부
							if (dcList[i].tableOpenYn==""){
								tableOpenYn = "Y";
							}else{
								tableOpenYn = dcList[i].tableOpenYn;
							}
						   
							//공유상태 체크
							//dcList[i].tableId=dcConsentList[j].tableId >> 공유상태 Y(공유중)
							tableShareYn="N";
							
						   	if (dcConsentList.length > 0) {
							   $.each(dcConsentList,function(j){
								 	if (dcList[i].tableId==dcConsentList[j].tableId){
								 		tableShareYn="Y";
								 	}
							   })
						   	}
						   	
						   	if (tableOpenYn=="N"){
						   		tableShareYn = "Y";
						   	}
							
							if (agencyCheck == "Y") {
								tableShareYn = "Y";
							}
							
							if( dcList[i].resourceId!="" || dcList[i].resourceId!=undefined || dcList[i].resourceId!=null){
								resourceId=dcList[i].resourceId;								
							}else{
								resourceId="";
							}
								
							if (dcList[i].dataCount!="" && dcList[i].dataCount!=undefined && dcList[i].dataCount!=null){
								dataCount = commaSeparateNumber(dcList[i].dataCount);
							}
							else{
								dataCount = 0;
							}
							
							if (dcList[i].description!="" && dcList[i].description!=undefined && dcList[i].description!=null){
								description = dcList[i].description;
							}
							else{
								description = '';
							}
											
							//컬럼 Param (companyCode,databaseName,subjectName,tableId,tableName,locationPath,resourceId)
							var p = "'"+dcList[i].companyCode+","+dcList[i].databaseName+","+dcList[i].subjectName +","+dcList[i].tableId+","+dcList[i].tableName+","+dcList[i].locationPath+","+dcList[i].resourceId+"'";
							
							//팝업 Param (companyCode,databaseName,subjectName,tableId,classTitle,resourceId,tableShareYn)
							var pp = dcList[i].companyCode+"^^"+dcList[i].databaseName+"^^"+dcList[i].subjectName +"^^"+dcList[i].tableId+"^^"+classTitle +"^^"+dcList[i].resourceId +"^^"+tableShareYn;
							
							html += '<tr onclick="deView('+p+')">';		
							
							if (tableShareYn=="Y") {
								html += "<td onClick='event.cancelBubble=true'><input type='checkbox' name='cataChk' value='"+ pp +"' disabled ></td>";
							}else{
								html += "<td onClick='event.cancelBubble=true'><input type='checkbox' name='cataChk' value='"+ pp +"'></td>";
							}

							//데이터베이스종류 resourceId/테이블명 tableId/한글명 tableName/데이터건수 dataCount/공유가능여부 tableOpenYn/공유상태 tableShareYn/설명 description
							html += '<td>'+resourceId+'</td>';
							html += "<td>"+dcList[i].tableId+"</td>";
							html += "<td>"+dcList[i].tableName+"</td>";
							html += "<td>"+dataCount+"</td>";
							html += "<td>"+tableOpenYn+"</td>";
							html += "<td>"+tableShareYn+"</td>";
							html += "<td class='tal disc'>"+description+"</td>";
							html += "</tr>";
							
							$("#tbodyArea").empty().append(html);
						})
						
					}else{
						alert("Table 조회 중 오류가 발생했습니다.");
					}
				},
			});
		}
	
		//하단(컬럼)
		catalogue.list2=function(p){
			//컬럼 Param (companyCode,databaseName,subjectName,tableId,tableName,locationPath,resourceId)
			var tempP = p.split(",");
			
			var dataPa = {
				"companyCode" : tempP[0],
				"databaseName" : tempP[1],
				"subjectName" : tempP[2],
				"tableId" : tempP[3],
				"resourceId" : tempP[6]
			}
			
			$.ajax({
				type: "Get",
				url : _CONSTANTS["URL_BASE"]+"dc/column-info/",
				data: dataPa,
				success : function(data, status, xhr) {
					if (data.code=="success") {
						var html ='';
						var dcList = data.data.columnInfo.item;
						var no = 1;
						
						var tableDescription ="";
						var encryptYn ="";
						var privateYn ="";
						var dataPrecision ="";
						var dataType ="";
						
						$.each(dcList,function(i) {
							if (dcList[i].dataType!="" && dcList[i].dataType!=undefined && dcList[i].dataType!=null){
								dataType = dcList[i].dataType;
							}
							else{
								dataType = '';
							}
							
							if (dcList[i].dataPrecision!="" && dcList[i].dataPrecision!=undefined && dcList[i].dataPrecision!=null){
								dataPrecision = dcList[i].dataPrecision;
							}
							else{
								dataPrecision = '';
							}
							
							if (dcList[i].privateYn!="" && dcList[i].privateYn!=undefined && dcList[i].privateYn!=null){
								privateYn = dcList[i].privateYn;
							}
							else{
								privateYn = '';
							}
							
							if (dcList[i].encryptYn!="" && dcList[i].encryptYn!=undefined && dcList[i].encryptYn!=null){
								encryptYn = dcList[i].encryptYn;
							}
							else{
								encryptYn = '';
							}
							
							if (dcList[i].tableDescription!="" && dcList[i].tableDescription !=undefined && dcList[i].tableDescription!=null){
								tableDescription = dcList[i].tableDescription;
							}
							else{
								tableDescription = '';
							}
							
							//컬럼명 columnId/컬럼한글명 columnName/데이터타입 dataType/길이 dataPrecision/개인정보여부 privateYn/암호화여부 encryptYn/설명 tableDescription
							html += '<tr>';		
							html += "<td>"+no+"</td>";
							html += "<td>"+dcList[i].columnId+"</td>";
							html += "<td>"+dcList[i].columnName+"</td>";
							html += "<td>"+dataType+"</td>";
							html += "<td>"+dataPrecision+"</td>";
							html += "<td>"+privateYn+"</td>";
							html += "<td>"+encryptYn+"</td>";
							html += "<td>"+tableDescription+"</td>";
							html += "</tr>";
						
							$("#tbodyArea2").empty().append(html);
							
							no = no + 1;
							
						})
						var s3Text ='';
						
						//locationPath
						if (tempP[5] !="" && tempP[5] !=undefined  && tempP[5] !=null) {
							s3Text = tempP[5]; 
						}else{
							s3Text = "Data가 없습니다.";
						}
						
						$("#columnTbl .dash_data_box_top h2").empty().append(tempP[3]);
						$("#s3Area h5").empty().append(s3Text);
					
						
					}else{
						$("#columnTbl .dash_data_box_top h2").empty();
						$("#s3Area h5").empty();
						$("#tbodyArea2").empty();
						//alert("Column 조회 중 오류가 발생했습니다.");
					}
				},
			});
		}
		
		//공유요청 팝업창
		catalogue.pop = function (dataChk){
			//팝업 Param (companyCode,databaseName,subjectName,tableId,classTitle,resourceId,tableShareYn,cmpCompanyCode)
			var p = dataChk
			var tempData = '';
			var splitTempData='';
			var apiData = '{"tableInfo": [';
			var classTitle='';
			var resourceId='';
			var tableShareYn='';
	
			//복수개 체크
			if (p.indexOf(",") != -1) {
				p = p.split(",");
			
				$.each(p,function(i) {
					tempData = p[i].split("^^");
					classTitle=tempData[4];
					tableShareYn=tempData[6];
				
					apiData +='{';
					apiData +='"companyCode" : "'+tempData[0]+'", ';
					apiData +='"databaseName" : "'+tempData[1]+'", ';
					apiData +='"subjectName" : "'+tempData[2]+'", ';
					apiData +='"tableId" : "'+tempData[3]+'", ';
					apiData +='"resourceId" : "'+tempData[5]+'" ';
					apiData +='},';
						
					//요청하기 Param(companyCode,databaseName,subjectName,tableId,classTitle,resourceId)
					if (i==0){
						splitTempData = tempData[0]+","+tempData[1]+","+tempData[2]+","+tempData[3]+","+tempData[4]+","+tempData[5];
					}else{
						splitTempData = splitTempData +"||"+ tempData[0]+","+tempData[1]+","+tempData[2]+","+tempData[3]+","+tempData[4]+","+tempData[5];
					}
					
				});
				//마지막 콤마 삭제
				apiData = apiData.substr(0,apiData.length-1);
				apiData += "]}"
				
			//하나 체크
			}else{
				tempData = p.split("^^");
				classTitle=tempData[4];
				tableShareYn=tempData[6];
				
				apiData +='{';
				apiData +='"companyCode" : "'+tempData[0]+'", ';
				apiData +='"databaseName" : "'+tempData[1]+'", ';
				apiData +='"subjectName" : "'+tempData[2]+'", ';
				apiData +='"tableId" : "'+tempData[3]+'", ';
				apiData +='"resourceId" : "'+tempData[5]+'" ';
				apiData +='},' ;
				
				//마지막 콤마 삭제
				apiData = apiData.substr(0,apiData.length-1);
				
				apiData += "]}";
				
				//요청하기 Param
				splitTempData = tempData[0]+","+tempData[1]+","+tempData[2]+","+tempData[3]+","+tempData[4]+","+tempData[5];
			}
			
			$.ajax({
				type: "POST",
				url : _CONSTANTS["URL_BASE"]+"dc/schema-info/",
				data: apiData,
				contentType: 'application/json',
				success : function(data, status, xhr) {
					
					if (data.code=="success") {
						
						var html ='';
						var popList = data.data.schemaInfo;
						var no = 1;
						var infoSystemName=''; 
						var requestColumn='';
						var dataCount;	
						var tableOpenYn='';	
						
						//현재날짜
						var dt = new Date();
					    var year = dt.getFullYear();        
					    var month = "" + (dt.getMonth()+1); 
					    var day = "" + dt.getDate();   
					    if (month>12){
					    	year = year+1;
					    	month = "1";
					    }
					    //현재날짜
					   	
					    //현재날짜+1개월
					    var dt2 = new Date(year,Number(month)+1,0);
					    var year2 = dt.getFullYear();
					    var month2 = "" + (dt2.getMonth()+1);
					    var day2 = "" + dt2.getDate();
					    
					    if (month2>12){
					    	year2 = year2+1;
					    	month2 = "1";
					    }
					    //현재날짜+1개월
					    
					    if(month.length < 2) month = "0" + month;
					    if(month2.length < 2) month2 = "0" + month2;
					    if(day.length < 2) day = "0" + day;
					    if(day2.length < 2) day2 = "0" + day2;
					    
					    var starDay = year+"-"+ month +"-"+ day;
					    var endDay = year2+"-"+ month2 +"-"+ day2;
					    
						$.each(popList,function(i) {
							
							//공유 가능여부
							if (popList[i].tableOpenYn=="" || popList[i].tableOpenYn==undefined || popList[i].tableOpenYn==null){
								tableOpenYn = "Y";
							}else{
								tableOpenYn = popList[i].tableOpenYn;
							}
							
							if( popList[i].resourceId!="" && popList[i].resourceId!=undefined && popList[i].resourceId!=null){
								resourceId=popList[i].resourceId;								
							}else{
								resourceId="";
							}
							
							if (popList[i].dataCount!="" && popList[i].dataCount!=undefined && popList[i].dataCount!=null){
								dataCount = commaSeparateNumber(popList[i].dataCount);
							}else{
								dataCount = 0;
							}
							
							//데이터베이스명 resourceId/테이블명 tableId/한글명 tableName/유효기간/데이터건수 dataCount/공유가능여부 tableOpenYn/공유상태 tableShareYn
							html += '<tr>';		
							html += "<td>"+no+"</td>";
							html += "<td>"+resourceId+"</td>";
							html += "<td>"+popList[i].tableId+"</td>";
							html += "<td>"+popList[i].tableName+"</td>";
							html += "<td class='dateBox'><input type='text' readonly name='cAcqDate"+no+"' id='d"+i+"' class='dateType' data-date-format='yyyy-mm-dd' value='"+starDay+"'>~";
							html += "<input type='text' readonly class='dateType' id='dd"+i+"' data-date-format='yyyy-mm-dd' value='"+endDay+"'></td>";
							//html += "<td>"+dataCount+"</td>";
							html += "<td>"+tableOpenYn+"</td>";
							html += "<td>"+tableShareYn+"</td>";
							html += "</tr>";
							
							no = no + 1;
							
							//infoSystemName,requestColumn
							if (i==0){
								infoSystemName=popList[i].infoSystemName;
								requestColumn=popList[i].requestColumn;
							}else{
								infoSystemName= infoSystemName +","+ popList[i].infoSystemName;
								requestColumn=requestColumn +"^^"+ popList[i].requestColumn;
							}
							
							$("#tbodyArea3").empty().append(html);
							
						})
						
						html = '<h2>요청사유</h2>'
						html += '<textarea id="inTextarea" placeholder="요청사유를 입력해주세요."></textarea>'
							
						$("#inTextarea").empty().append(html);
						$(".modal_pop_top h3").empty().append(classTitle);
						$("#hidCreatData").val(splitTempData+"=="+infoSystemName);
						$("#hidReqColumn").val(requestColumn);
						
						var gubun = '';
						gubun = "["+$("#hidCompName").val()+"] "+$("#hidTitlePath").val();
						
						$(".route").empty().append(gubun);
						
					}else{
						console.log("에러>>"+data);
						alert("Column 조회 중 오류가 발생했습니다.");
					}
				},
			});
		}
		
		catalogue.create = function (data,datadata){
			
			var paramData1= data;
			var tempParamData1 = '';
			var infoSystemName = ''; 
			var tempStDate = '';
			var stDate = '';
			var paramDatas = '';
			var paramData2= datadata;
			var requestColumn = '';
			var apiData ='';
			var reqReason = '';
			var classTitle = '';
			
			classTitle = paramData1.split("||");
			classTitle = classTitle[0].split(",");
			classTitle = classTitle[4];
			
			reqReason = $("#inTextarea").val();
			
			if (reqReason.length==0){
				alert("요청사유를 입력해주세요.");
				$("#inTextarea").focus();
				return false;
			}

			apiData = '{ ';
			apiData +='"approver": "test@sk.com", ';
			apiData +='"approverCom": "'+$("#hidCompCode").val()+'", ';
			apiData +='"requester": "", ';
			apiData +='"requesterCom": "", ';
			apiData +='"requestAt": "", ';
			apiData +='"classTitle": "'+classTitle+'", ';
			apiData +='"txId": "", ';
			apiData +='"reqReason": "'+reqReason+'", '	;		
			apiData += '"consentDetailDTOList": [ ';
			
			//복수개 체크
			if (paramData1.indexOf("||") != -1) {
				
				/*requestTable~databaseName*/
				tempParamData1 = paramData1.split("==");
				tempParamData1 = tempParamData1[0].split("||");
				/*requestTable~databaseName*/
				
				/*infoSystemName*/
				infoSystemName = paramData1.split("==");
				infoSystemName = infoSystemName[1].split("^^");
				infoSystemName = infoSystemName[0].split(",");
				/*infoSystemName*/
				
				/*startAt,finishAt*/
				tempStDate = paramData1.split("^^");
				tempStDate = tempStDate[1].split("**");
				/*startAt,finishAt*/
			
				/*requestColumn*/
				requestColumn = paramData2.split("^^");
				/*requestColumn*/
				
				$.each(tempParamData1,function(i) {
					
					/*requestTable~databaseName*/
					paramDatas = tempParamData1[i].split(",");
					/*requestTable~databaseName*/
					
					/*startAt,finishAt*/
					stDate = tempStDate[i].split(",");
					/*startAt,finishAt*/
					
					apiData +='{';
					apiData +='"requestColumn": "'+requestColumn[i]+'", ';
					apiData +='"requestTable": "'+paramDatas[3]+'", ';
					apiData +='"companyCode": "'+paramDatas[0]+'", ';
					apiData +='"subjectName": "'+paramDatas[2]+'", ';
					apiData +='"databaseName": "'+paramDatas[1]+'", ';
					apiData +='"resourceId": "'+paramDatas[5]+'", ';
					apiData +='"infoSystemName" : "'+infoSystemName[i]+'", ';
					apiData +='"startAt" : "'+stDate[0]+'", ';
					apiData +='"finishAt": "'+stDate[1]+'" ';
					apiData +='},';
				});
				
				apiData = apiData.substr(0,apiData.length-1);

			}else{
				/*requestTable~resourceId*/
				tempParamData1=paramData1.split("==");
				/*requestTable~resourceId*/
				
				/*infoSystemName*/
				infoSystemName = paramData1.split("==");
				infoSystemName = infoSystemName[1].split("^^");
				/*infoSystemName*/
				
				/*startAt,finishAt*/
				stDate = paramData1.split("^^");
				stDate = stDate[1].split(",");
				/*startAt,finishAt*/
				
				/*requestTable~resourceId*/
				paramDatas = tempParamData1[0].split(",");
				/*requestTable~resourceId*/
				
				/*requestColumn*/
				requestColumn = paramData2;
				/*requestColumn*/
				
				apiData +='{';
				apiData +='"requestColumn": "'+requestColumn+'", ';
				apiData +='"requestTable": "'+paramDatas[3]+'", ';
				apiData +='"companyCode": "'+paramDatas[0]+'", ';
				apiData +='"subjectName": "'+paramDatas[2]+'", ';
				apiData +='"databaseName": "'+paramDatas[1]+'", ';
				apiData +='"resourceId": "'+paramDatas[5]+'", ';
				apiData +='"infoSystemName" : "'+infoSystemName[0]+'", ';
				apiData +='"startAt" : "'+stDate[0]+'", ';
				apiData +='"finishAt": "'+stDate[1]+'" ';
				apiData +='}';
					
			}
			
			apiData += ']';
			apiData += '}';
			
			$.ajax({
				type: "POST",
				url : _CONSTANTS["URL_BASE"]+"dc/"+param.key,
				data: apiData,
				contentType: 'application/json',
				success : function(data, status, xhr) {
					
					if (data.code=="success") {
						hideModal('dataAddBox'); 
						onToastPop('toastPop1');
					}else{
						alert("공유 요청 중 오류가 발생했습니다.");
					}
				},
			});
		}
		
		//스크랩 등록
		catalogue.scrapAdd=function(docId){
			var p = {
					"cl": "DC", 
					"docId":docId
					}
				
			$.ajax({
				type: "POST",
				url : _CONSTANTS["URL_BASE"]+"scrap",
				data: JSON.stringify(p),
				contentType: 'application/json',
				success : function(data, status, xhr) {
	
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("카탈로그 스크랩 중 오류가 발생했습니다.");
				},
			});
		}
		
		//스크랩 삭제
		catalogue.scrapDel=function(docId){
			var p = {
					"cl": "DC", 
					"docId":docId
					}

			$.ajax({
				type: "Delete",
				url : _CONSTANTS["URL_BASE"]+"scrap",
				data: JSON.stringify(p),
				contentType: 'application/json',
				success : function(data, status, xhr) {

				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("카탈로그 스크랩 중 오류가 발생했습니다.");
				},
			});
		}
		
		
		/****************************************************************************************************/
		/** @END Method Definition */

		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			
			setNav(1);
			
			
			
			catalogue.init();
			
		});
		
		$(document).on("click","#btnType",function(){
			var dataChk='';
			
			$('input:checkbox[name=cataChk]').each(function() {
				if($(this).is(':checked')){
					if (dataChk=="") {
						dataChk += ($(this).val());
					}else {
						dataChk += ","+($(this).val());
					}
				}
		    }); 
			
			if (dataChk==""){
				alert("공유 요청할 테이블을 선택해주세요.");
				return false;
			}else{
				showModal('dataAddBox');
			}
			
			catalogue.pop(dataChk);
		
		});
		
		//요청사유 Validation
		$("#inTextareapb0").on('input',function(){
			if( $("#inTextarea").val().length > 0 ){
				$("#creatSubmit").removeClass("disable");
			}
			
			if( $("#inTextarea").val().length == 0 ){
				$("#creatSubmit").addClass("disable");
			}
		})
		
		$(document).on("click",".cancel_btn",function(){
			$("#inTextarea").val("");
			$("#creatSubmit").addClass("disable");
			hideModal('dataAddBox');
		})
		
		$(document).on("click",".submit_btn",function(){
			var creatData = $("#hidCreatData").val(); 
			
			/*requestColumn*/
			var requestColumn = $("#hidReqColumn").val();
			/*requestColumn*/
			
			var tempData = creatData.split("||")
			var splitTempData='';
			
			$.each(tempData,function(i) {
				if (i==0){
					splitTempData = $("#d"+i+"").val()+","+$("#dd"+i+"").val();
				}else{
					splitTempData = splitTempData +"**"+ $("#d"+i+"").val()+","+$("#dd"+i+"").val();
				}	
			})
			
			catalogue.create(creatData+"^^"+splitTempData,requestColumn);

		})
		
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});