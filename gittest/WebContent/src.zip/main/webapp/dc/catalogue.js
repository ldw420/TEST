/**
 * TITLE : DLSP
 * DESC : 메인화면 
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var catalogue = function() {};

head.ready(function () {

	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}

	(function($) { "use strict";
	
		var form,param,pagination;
		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		catalogue.init = function() {

			//메뉴 권한 채크
			//commUsr.menuAuthCheck();
			
			form = $("#frm01");
			param = commAjax.getJsonFromQry(location.href);
			
			
			//main.html 검색(관계사,검색bar)
			if (param.schDcSj!=null || param.schCopm!="" || param.schCopm!=undefined){
				$("#schDcSj").val(param.schDcSj);
				$("#schCopm").val(param.schCopm);
			}
			
			//main.html 카테고리 검색
			if (param.mainKey!="" || param.mainKey!=undefined || param.mainKey!=null){
				
				$("#mainKey").val(param.mainKey);
				$("#schCtg").val(param.mainKey);
				
				//파라미터 지우기
				history.replaceState({}, null, location.pathname);
				catalogue.list2();
			}
		
			pagination = $('#paging').bootpagPo({ total: 0 }).on("page", function(event, num){ catalogue.list(num) });

			//카테고리 정보 가져오기
			//catalogue.ctgList("00003");
			
			//관계사 정보 가져오기
			catalogue.compList("sk004");
			
			//목록 가져오기
			catalogue.list();

		};
		 
		//카테고리
		catalogue.ctgList = function(group_code_id){
			var html = '';
			
			$.ajax({
				type: "GET",
				url : _CONSTANTS["URL_BASE"]+"code/detail/"+group_code_id,
				data: "",
				dataType: "json", 
				success : function(data, status, xhr) {
						
					if (data.code=="success") {
						
						var results = data.data.codeDetailList; 
						html +="<ul>"
						$.each(results, function (i) {	
							
							var p = "'"+results[i].detailCodeId+"'";
							
							html +="<li>"
							html +="<a href='#'> <span class='"+results[i].detailCodeNm.toLowerCase()+"'> </span> "+results[i].detailCodeNm+" </a>"
							html +="</li>"
							if (i==7){								
								html +="</ul>"
								html +="<ul>"
							}
						}); 
						html +="</ul>"
							
						$(".dash_icon_list").empty().append(html);
						
					}else{
						alert("공통 코드 상세 목록 조회 중 오류가 발생했습니다.");
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		}
	
		//관계사
		catalogue.compList = function(group_code_id){
			var html = "<li data-option data-value='all' class='bx--dropdown-item'>";
			html += "<a class='bx--dropdown-link bx--dropdown--selected' href='javascript:ctgSch(0)' tabindex='-1'>모든 관계사</a>";
			html += "</li>";
			
			$.ajax({
				type: "GET",
				url : _CONSTANTS["URL_BASE"]+"code/useDetail/"+group_code_id,
				data: "",
				dataType: "json", 
				success : function(data, status, xhr) {
					
					if (data.code=="success") {
						
						var results = data.data.codeDetailList; 
						
						$.each(results, function (i) {
							
							var p = "'"+results[i].detailCodeId+"'";
							
							html +="<li data-option data-value='cloudFoundry' class='bx--dropdown-item'>";
							html +='<a class="bx--dropdown-link" href="javascript:ctgSch('+ p +')" tabindex="-1">'+ results[i].detailCodeNm +'</a>';
							html +="</li>";
							
						}); 
						$("#bx--dropdown-list-cp").append(html);
						
					}else{
						alert("공통 코드 상세 목록 조회 중 오류가 발생했습니다.");
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		}
		
		//목록
		catalogue.list=function(pageNumber){
			
			var pageNo = commUtil.parseInt(pageNumber,1);
			form.find('#pageNo').val(pageNo);
			
			var param = form.serialize();
	
			$.ajax({
				type: "Get",
				url : _CONSTANTS["URL_BASE"]+"dc",
				data: param,
				dataType: "json",
				success : function(data, status, xhr) {
					if (data.code=="success") {
						
						var html ='';
						var dcList = data.data.dcList;
						var applyCnt;
						
						if(dcList.length > 0){
							
							$.each(dcList,function(i) {							
								
								html += "<li>";
								
								if (dcList[i].docId ==0 || dcList[i].docId==null || dcList[i].docId==undefined) {
									html += "<button class='scrap' value="+dcList[i].classKey+">스크랩</button>";
								}else {
									html += "<button class='scrap on' value="+dcList[i].classKey+">스크랩</button>";
								}
								
								if (dcList[i].applyCnt == "" || dcList[i].applyCnt == undefined || dcList[i].applyCnt == null)
								{
									applyCnt = 0;
								}else{
									applyCnt = dcList[i].applyCnt;
								}
								
								//html += "<a href='./catalogue_view.html' class='popular' onclick='deView("+dcList[i].classKey+")'>"+ dcList[i].classTitle +"</a>";
								if (dcList[i].shareYn=="Y"){
									html += "<a href='#' class='popular' onclick='deView("+dcList[i].classKey+")'>"+ dcList[i].classTitleName +"</a>";
								}else{
									html += "<a href='#' class='' onclick='deView("+dcList[i].classKey+")'>"+ dcList[i].classTitleName +"</a>";
								}
								
								html += "<p>"+ dcList[i].bizMeta +"</p>";							
								html += "<span>관계사│"+ dcList[i].cmpCompanyCodeNm +"</span>";
								html += "<span>카테고리│"+ dcList[i].pathFirst +"</span>";
								html += "<span>조회수│"+ dcList[i].rdcnt +"</span>";
								html += "<span>신청건수│"+ applyCnt +"</span>";
								html += "<span>업데이트│"+ dcList[i].modifyDt +"</span>";
								html += "</li>";						
							});
							
							$("#ulArea").empty().append(html);
							$("#filter").empty().append("필터 ("+data.data.dcListCount+")");
						}else{
							html += "<li>";
							html += "<p style='padding:24px;height:auto;text-align:center;font-size:17px'>검색된 결과가 없습니다.</p>";							
							html += "</li>";

							$("#ulArea").empty().append(html);
							$("#paging").empty();
						}
								
						
						//카테고리
						html = '';
						var dcCtgList = data.data.dcCtgList;
						var dcCtgCountList = data.data.dcCtgCountList;
						var oneLvlCheck = 0;
						var lvlCheck = 0;
						var classKey,dcCtgCountList,cnt;
						
						$.each(dcCtgList,function(i) {
							
							//카테고리 카운트 재설정
							classKey = dcCtgList[i].classKey;
							cnt=0;

							if (dcCtgList[i].classLevel==1){
								$.each(dcCtgCountList,function(j) {
									if (classKey == dcCtgCountList[j].classKey){
										cnt = dcCtgCountList[j].titleFirstCnt;
										return false;
									}
								});
							}
							//카테고리 카운트 재설정
							
							if (i==0){
								html += "<li class='cate'>";
								html += "<span class='chkBox'  value="+dcCtgList[i].classTitle+"></span><a href='#' value="+dcCtgList[i].classTitle+">"+ dcCtgList[i].classTitle +"(<span id="+ dcCtgList[i].classKey +">"+cnt+"</span>)</a>";
							}else{
								if ( (dcCtgList[i].classLevel==2) && (lvlCheck != 2) ){
									html += "<ul>";
									//html += "<li style='display: none;'  class='testCss'><a href='#'>"+ dcCtgList[i].classTitle +"</a></li>";
									html += "<li><a href='#' value="+dcCtgList[i].classTitle+">"+ dcCtgList[i].classTitle +"</a></li>";
									
									lvlCheck = 2;
								}else if ( ((dcCtgList[i].classLevel==2) && (lvlCheck == 2)) ){
									//html += "<li style='display: none;'  class='testCss'><a href='#'>"+ dcCtgList[i].classTitle +"</a></li>";
									html += "<li><a href='#' value="+dcCtgList[i].classTitle+">"+ dcCtgList[i].classTitle +"</a></li>";
									
									lvlCheck = 2;
								}else if ( dcCtgList[i].classLevel==1 ) {
									if (dcCtgList[i-1].classLevel==2){
										html += "</ul>";
										html += "</li>";
									}else{								
										html += "</li>";
									}
									if (oneLvlCheck < 4){
										html += "<li class='cate'>";
										html += "<span class='chkBox' value="+dcCtgList[i].classTitle+"></span><a href='#' value="+dcCtgList[i].classTitle+">"+ dcCtgList[i].classTitle +"(<span id="+ dcCtgList[i].classKey +">"+cnt+"</span>)</a>";
										
										lvlCheck = 1;
									}else{
										html += "<li>";
										html += "<span class='chkBox' value="+dcCtgList[i].classTitle+"></span><a href='#' value="+dcCtgList[i].classTitle+">"+ dcCtgList[i].classTitle +"(<span id="+ dcCtgList[i].classKey +">"+cnt+"</span>)</a>";
										
										lvlCheck = 1;
									}
									oneLvlCheck = oneLvlCheck+1
								}
							}
						});
						
						if ( lvlCheck==2 ){
							html += "</ul>";
							html += "</li>";
						}else{
							html += "</li>";
						}
						
						html += "<li class='showBtnBox'>"
						html += "<a href='javascript:void(0)' class='showBtn'>모든 카테고리 결과 보기</a>"
						html += "</li>"
							
						$(".cate_list").empty().append(html);
						
						//관계사
						html = '';
						var dcCompList = data.data.dcCompList
						var dcCompCountList = data.data.dcCompCountList;
						var detailCodeId
						
						//console.log(data)
						
						$.each(dcCompList,function(i) {
							
							//관계사 카운트 재설정
							detailCodeId = dcCompList[i].detailCodeId;
							cnt = 0;
					
							$.each(dcCompCountList,function(j) {
								if (detailCodeId == dcCompCountList[j].copm){
									cnt = dcCompCountList[j].compcnt
									return false;
								}
							});
							//관계사 카운트 재설정
							
							var p="'"+dcCompList[i].detailCodeId+"'"
							
							html +="<li>";
							//html +="<a href='#' value="+dcCompList[i].detailCodeId+">"+ dcCompList[i].detailCodeNm +"("+dcCompList[i].cnt+")</a>";
							html +="<a href='#' value="+dcCompList[i].detailCodeId+">"+ dcCompList[i].detailCodeNm +"(<span id="+ dcCompList[i].detailCodeId +">"+cnt+"</span>)</a>";
							html +="</li>";
						});
						
						$(".partner_list").empty().append(html);
						
						var pageCnt = Math.ceil(data.data.dcListCount / 10);

						pagination.bootpagPo({
				        	total: pageCnt,
				        	page : pageNo
				        });

					}else{
						
						alert("카탈로그 조회 중 오류가 발생했습니다.");
					}
				},
			});
		}
		
		//우측, 카테고리&관계사 검색용
		catalogue.list2=function(pageNumber){
			
			var pageNo = commUtil.parseInt(pageNumber,1);
			form.find('#pageNo').val(pageNo);
			
			var param = form.serialize();
			//console.log(param)
			$.ajax({
				type: "Get",
				url : _CONSTANTS["URL_BASE"]+"dc",
				data: param,
				dataType: "json",
				success : function(data, status, xhr) {
							
					//console.log(data)
					if (data.code=="success") {
						
						var html ='';
						var dcList = data.data.dcList;
						var applyCnt;
						var mainKey = $("#mainKey").val(); //main.html 에서 넘어온 값
						
						if(dcList.length > 0){
							
							$.each(dcList,function(i) {
								
								html += "<li>";
								
								if (dcList[i].docId ==0 || dcList[i].docId==null || dcList[i].docId==undefined) {
									html += "<button class='scrap' value="+dcList[i].classKey+">스크랩</button>";
								}else {
									html += "<button class='scrap on' value="+dcList[i].classKey+">스크랩</button>";
								}
								
								if (dcList[i].applyCnt == "" || dcList[i].applyCnt == undefined || dcList[i].applyCnt == null)
								{
									applyCnt = 0;
								}else{
									applyCnt = dcList[i].applyCnt;
								}
								
								if (dcList[i].shareYn=="Y"){
									html += "<a href='#' class='popular' onclick='deView("+dcList[i].classKey+")'>"+ dcList[i].classTitleName +"</a>";
								}else{
									html += "<a href='#' class='' onclick='deView("+dcList[i].classKey+")'>"+ dcList[i].classTitleName +"</a>";
								}
								html += "<p>"+ dcList[i].bizMeta +"</p>";							
								html += "<span>관계사│"+ dcList[i].cmpCompanyCodeNm +"</span>";
								html += "<span>카테고리│"+ dcList[i].pathFirst +"</span>";
								html += "<span>조회수│"+ dcList[i].rdcnt +"</span>";
								html += "<span>신청건수│"+ applyCnt +"</span>";
								html += "<span>업데이트│"+ dcList[i].modifyDt +"</span>";
								html += "</li>";
							});
							
							var pageCnt = Math.ceil(data.data.dcListCount / 10);
							
							pagination.bootpagPo({
								total: pageCnt,
								page : pageNo
							});					

						} else {
							html += "<li>";
							html += "<p style='padding:24px;height:auto;text-align:center;font-size:17px'>검색된 결과가 없습니다.</p>";							
							html += "</li>";

							$("#paging").empty();
							
						}
						var dcCtgList = data.data.dcCtgList;
						var dcCtgCountList = data.data.dcCtgCountList;
						var dcCompList = data.data.dcCompList
						var dcCompCountList = data.data.dcCompCountList;
						//console.log(data)
						
						//카테고리 카운트 재설정
						$.each(dcCtgList,function(i) {
							$("#"+dcCtgList[i].classKey).html(0);
						});
					
						$.each(dcCtgCountList,function(j) {
							$("#"+dcCtgCountList[j].classKey).html(dcCtgCountList[j].titleFirstCnt);
						});
						//카테고리 카운트 재설정
						
						//관계사 카운트 재설정
						$.each(dcCompList,function(i) {
							$("#"+dcCompList[i].detailCodeId).html(0);
						});
					
						$.each(dcCompCountList,function(j) {
							$("#"+dcCompCountList[j].copm).html(dcCompCountList[j].compcnt);
						});
						//관계사 카운트 재설정
						
						
						$("#ulArea").empty().append(html);
						$("#filter").empty().append("필터 ("+data.data.dcListCount+")");
						
						if(mainKey!=""){
							mainKey = mainKey.toLowerCase();
							$(".dash_icon_list li ."+mainKey+"").parent().parent().addClass("on");
							$("#mainKey").val("");
						}
						
						
						
					}else{
						alert("카탈로그 조회 중 오류가 발생했습니다.");
					}
				},
			});
		}
		
		catalogue.scrapAdd=function(docId){
		
			var p = {
					"cl": "DC", 
					"docId":docId
					}
			
			$.ajax({
				type: "POST",
				url : _CONSTANTS["URL_BASE"]+"scrap",
				data: JSON.stringify(p),
				contentType: 'application/json',
				success : function(data, status, xhr) {
					
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("카탈로그 스크랩 중 오류가 발생했습니다.");
				},
			});
		}
		
		catalogue.scrapDel=function(docId){
			
			var p = {
					"cl": "DC", 
					"docId":docId
					}

			$.ajax({
				type: "Delete",
				url : _CONSTANTS["URL_BASE"]+"scrap",
				data: JSON.stringify(p),
				contentType: 'application/json',
				success : function(data, status, xhr) {

				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("카탈로그 스크랩 중 오류가 발생했습니다.");
				},
			});
		}
		
		/****************************************************************************************************/
		/** @END Method Definition */

		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			catalogue.init();
			
			setNav(1);
			
			$("#schDcSj").keyup(function(e){
				if(e.keyCode == 13){  
					catalogue.list();
				}
			});

			//검색
			$(document).on("click",".search_btn",function(){
				catalogue.list();
			});
			
			//바로 이용
			$(document).on("click",".useData",function(){
				if ($(".useData").attr("class").length == 10) {
					$("#shareYn").val("Y");
				}else{
					$("#shareYn").val("");
				}
				catalogue.list2();
			});
			
			
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});