head.ready(function () {
	$(document).ready(function(){
		$('#findPwPop').on('click',function(e){
			  showModal('findPw');
			  $('#chkEmail,#checkUsrId,#checkValue').val('');
		  });
		  $('#btnEmailAuth').on('click',function(e){
			  let ev = $('#chkEmail').val();
			  if(commUtil.isBlank(ev)){
				  alert('email 주소를 입력하세요.');return;
			  }else if(!commUtil.checkEmail(ev)){
				  alert('email 형식이 올바르지 않습니다.');return;
			  }
			  $.ajax({
				url:_CONSTANTS["URL_BASE"]+'noAuth/sendEmailAuth',
				method:'post',
				data:{email:ev},
				success:function(res){
					if(res.code=='fail'){
						alert(res.message);
					}else if(res.code == 'success'){
						$('#checkUsrId').val(ev);
						alert('메일이 발송 되었습니다.');
						startEmailTimer();
					}
				}
			  })
		  });
		  $('#btnEmailConfirm').on('click',function(e){
			  if($('#emailTimer').text()=='00:00'){
				  alert('입력시간이 초과 되었습니다.');return;
			  }
			  if($('#checkValue').val().length < 6){
				  alert('인증번호를 6자리로 입력하세요.');return;
			  }
			  $.ajax({
				  url:_CONSTANTS["URL_BASE"]+'noAuth/emailAuth',
				  method:'post',
				  data:{usrId:$('#checkUsrId').val(),checkValue:$('#checkValue').val()},
				  success:function(res){
					  if(res.code == 'success'){
						  hideModal('findPw');
						  $('#pw,#pwC').val('');
						  showModal('resetPw');
					  }else if(res.code == 'fail'){
						  alert(res.message);
					  }
				  }
			  })

		  });
		  function startEmailTimer(){
			  let time = 300;
			  let duration = moment.duration(time * 1000, 'milliseconds');
			  let interval = 1000;
			  let timer = setInterval(function(){
				  duration = moment.duration(duration.asMilliseconds() - interval, 'milliseconds');
				  let t = moment(duration.asMilliseconds()).format('mm:ss');
				  if(t == '00:00')clearInterval(timer);
				  $('#emailTimer').text(t);
				}, interval);
		  }
		  //showModal('resetPw');
		  $('#changePwL').on('click',function(){
			  let usrId = $('#checkUsrId').val();
			  let pw = $('#pw').val();
			  let pwC = $('#pwC').val();

			  if(commUtil.isEmpty(usrId)){
				  alert('이메일 인증일 진행해 주세요');return;
			  }
			  if(!commUtil.checkPw(pw)){
			      alert("영문+숫자+특수기호 8자리 이상으로 구성하여야 합니다."); return;
			  }
			  if(pw != pwC){
				  alert('입력한 비밀번호가 같지 않습니다.');return;
			  }
			  $.ajax({
				  url:_CONSTANTS["URL_BASE"]+'noAuth/pwChg',
				  method:'post',
				  data:{usrId:usrId,pw:pw},
				  success:function(res){
					  if(res.code=='success'){
						  let c = res.data.resultCode;
						  let m = res.data.resultMessage;
						  if(c == '00'){
						  	hideModal('resetPw');
						  	commUtil.toastPop(m);
						  }else{
							  alert(m);
						  }
						  console.log(res.data);
					  }else if(res.code=='fail'){
						  alert(res.message);
					  }
				  }
			  });
		  });
	});
});