/**
 * TITLE : DLSP
 * DESC : 메인화면
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var main = function() {};

head.ready(function () {

	let join = {};
	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}
	let form,param;
	(function($) { "use strict";

		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		join.init = function() {
			form = $('form[name=joinForm]');
			param = {};
			if(true){
				$.ajax({
					url: _CONSTANTS["URL_BASE"]+ 'code/useDetail/sk004',
					success:function(res){
						let list = res.data.codeDetailList;
						let d = form.find('#agency').find('ul.bx--dropdown-list');
						for(let i = 0 ; i < list.length;i++){
							let o = list[i];
							let h = '<li data-option data-value="'+o.detailCodeId+'" class="bx--dropdown-item">'
							       +'<a class="bx--dropdown-link" href="javascript:void(0)" tabindex="-1">'+o.detailCodeNm+'</a> </li>';
							d.append(h);
						}
					}
				})
			}
			form.find('#nm').alphanum();
			$("#password").keyup(function(){
				if( $(this).val().length > 7 ){
					$(this).parent('.pw').addClass('on');
				}else{
					$(this).parent('.pw').removeClass('on');
				}
			});

			$("#email").keyup(function(){
				if( $(this).val() == 'kim' ){
					$(this).parent('.email').addClass('on');
				}else{
					$(this).parent('.email').removeClass('on');
				}
			}).alphanum({allow: '!#$%^&*()+=[]\\\';,/{}|":<>?~`.-_',allowSpace:false });

			$(".chkMember").click(function(){
				if( $(".agree label").hasClass('on') ){
					join.authCheck();
				}else{
					alert('개인정보처리방침에 동의해주세요!');
				}
			});
/*
			$(".privacyBox").scroll(function(){

				var pH = $(this).scrollTop() + $(this).height();
				if( pH == $(".privacyCont").height() ){
					$("#privacyAgree").removeClass('disable');
				}
			});*/

			$(".privacyBox").scroll(function(){

				var pH = $(this).scrollTop() + $(this).height();

				if( pH > ( $(".privacyCont").height() - 100 ) ){
					$("#privacyAgree").removeClass('disable');
				}
			});

			$("#privacyAgree").click(function(){
				if( !$(this).hasClass('disable') ){
					join.agreePrc();
				}
			});
			$('#btnJoin').on('click',function(){
				join.insertUser();
			});
		};

		join.agreePrc = function(){
			$(".agree label").addClass('on');
			$("#agreeChk").prop("checked", true);
			hideModal('privacy');
		}

		join.insertUser = function(){
			$.ajax({
				url: _CONSTANTS["URL_BASE"]+ 'join',
				method:'post',
				data: JSON.stringify(param),
				contentType: 'application/json',
				success : function(res, status, xhr) {
					if(res.code == 'fail'){
						alert(res.message);return;
					}else{
						alert("정상적으로 등록 되었습니다.");
						location.href = "./joinOk.html?nm="+param.nm;
					}
				}
			});
		}
		join.authCheck = function(){
			let dropdown = CarbonComponents.Dropdown;
			let emailPostfix = form.find('#emailPostfix').get(0).innerText;
			let email = form.find('#email').val();
			let agency = form.find('#agency').find('.bx--dropdown--selected').parent().data('value');
			//유효성 체크
			param.nm = form.find('#nm').val();
			param.pw = form.find('#password').val();
			if(commUtil.isBlank(param.nm)){
				alert('이름을 입력하세요.');return;
			}
			if(commUtil.isBlank(email)){
				alert('email을 입력하세요.');return;
			}
			if(commUtil.isBlank(agency)){
				alert('관계사를 선택하세요.');return;
			}
			if(commUtil.isBlank(param.pw)){
				alert('비밀번호를 입력하세요.');return;
			}
			if(param.pw.length < 8){
				alert('비밀번호를 8자이상 입력하세요.');return;
			}

			param.usrId = email + emailPostfix;
			param.agency = agency;

			$.ajax({
				url:_CONSTANTS["URI_AUTH_SERVER"]+'api/authCheck',
				method:'post',
				data:{userID:param.usrId,password:param.pw},
				success:function(res){
					if(res.code == 'fail'){
						alert(res.message);
						return;
					}else if(res.code == 'success'){
						let d = res.data.userInfo;
						if(d.agency != param.agency){
							alert('관계사 정보가 올바르지 않습니다.');
							return;
						}
						param.deptcode = d.deptcode;
						param.deptname = d.deptname;
						param.partneryn = d.partneryn;

						$(this).html('구성원 인증 완료');
						$(this).addClass('comp');
						$(".agreeBtn").css({'display':'block'});
						form.find('*').attr('readonly',true);
					}
				}
			});
		}
		/****************************************************************************************************/
		/** @END Method Definition */

		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			join.init();
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});