/**
 * TITLE : DLSP
 * DESC : 메인화면
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var mydashboard = function() {};

head.ready(function () {

	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}

	(function($) { "use strict";

		//var key = commAjax.getParameter("key");

		var form,param,pagination;
		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		mydashboard.init = function() {

			//메뉴 권한 채크
			//commUsr.menuAuthCheck();

			form = $("#frm01");
			param = commAjax.getJsonFromQry(location.href);

			if (userInfo.authId=="A0001" || userInfo.authId=="A0002") {
				$("#dash_data_box").show();
			}

			mydashboard.toStartDate();
			mydashboard.toEndDate();
			mydashboard.list();

			$('.datepicker').attr({'autocomplete':'off',maxlength:'10'})
				.datepicker({format:'yyyy-mm-dd',immediateUpdates:true}).on('keyup',function(e){
					if( this.value.length > 10){
		                this.value = this.value.substr(0, 10);
		            }
		            let val         = this.value.replace(/\D/g, '');
		            let original    = this.value.replace(/\D/g, '').length;
		            let re  = '';
		            for(let i=0;i<2;i++){
		                if (val.length > 4 && i===0) {
		                    re += val.substr(0, 4) + '-';
		                    val         = val.substr(4);
		                }
		                else if(original>6 && val.length > 2 && i===1){
		                    re += val.substr(0, 2) + '-';
		                    val         = val.substr(2);
		                }
		            }
		            re += val;
		            this.value = re;
		            let keyCode = e.keyCode;
		            if($('div.datepicker:visible').length>1){
		            	$('div.datepicker:visible').hide();
		            }
		            $(this).datepicker('show');
				});

		};


	    mydashboard.toStartDate=function(){

	    	var dt = new Date();

	    	dt.setMonth((dt.getMonth() + 1) - 2);

		    var recentYear = dt.getFullYear();
		    var recentMonth = dt.getMonth() + 1;
		    var recentDay = dt.getDate();

		    if(recentMonth < 10) recentMonth = "0" + recentMonth;
		    if(recentDay < 10) recentDay = "0" + recentDay;

		    $('#dataMySta').val(recentYear + "-" + recentMonth + "-" + recentDay);
		    $('#dataSta').val(recentYear + "-" + recentMonth + "-" + recentDay);


		}

	    mydashboard.toEndDate=function(){

	    	var dt = new Date();

		    var recentYear = dt.getFullYear();
		    var recentMonth = dt.getMonth() + 1;
		    var recentDay = dt.getDate();

		    if(recentMonth < 10) recentMonth = "0" + recentMonth;
		    if(recentDay < 10) recentDay = "0" + recentDay;


		    $('#dataEnd').val(recentYear + "-" + recentMonth + "-" + recentDay);
		    $('#dataMyEnd').val(recentYear + "-" + recentMonth + "-" + recentDay);

		}

		mydashboard.list=function(){

			var param = {
					"div": "0"
			}

			$.ajax({
				type: "POST",
				url :  _CONSTANTS["URL_BASE"]+ 'main/mydashboard',
				data: JSON.stringify(param),
				contentType: 'application/json',
				async: true,
				success : function(data, status, xhr) {

					var getConfmAppListHtml ='';
					var getMyAppListHtml ='';
					var getMyScrapListHtml = '';
					var getMyDataListHtml = '';
					var confmApp = 0;
					var confmAppOk = 0;
					var confmAppNo = 0;

					if (data.code=="success") {
						var mydashboardDetail = data.data.confmAppCnt;

						$("#confmAppCnt").empty().append(data.data.confmAppCnt);
						var myAppCnt = data.data.myAppCnt;

						//나의 요청 현황
						$.each(myAppCnt, function (i) {
							 if (myAppCnt[i].sttus=="00001") {
								 //요청
								 confmApp=confmApp+myAppCnt[i].cnt;
							 }else if (myAppCnt[i].sttus=="00002") {
								 //승인
								 confmAppOk=confmAppOk+myAppCnt[i].cnt;
							 }else if (myAppCnt[i].sttus=="00003") {
								 //반려
								 confmAppNo=confmAppNo+myAppCnt[i].cnt;
							 } else if (myAppCnt[i].sttus=="00004") {
								 //요청 +승인사 요청 완료
								 confmApp=confmApp+myAppCnt[i].cnt;
							 }
						});
						 //요청
						 $("#confmApp").empty().append(confmApp);
						 //승인
						 $("#confmAppOk").empty().append(confmAppOk);
						 //반려
						 $("#confmAppNo").empty().append(confmAppNo);

						 //검토할 요청
						var getConfmAppList = data.data.getConfmAppList;
						$.each(getConfmAppList, function (i) {

							getConfmAppListHtml += "<tr>";
							getConfmAppListHtml += "	<td>"+getConfmAppList[i].title+"</td>";
							getConfmAppListHtml += "	<td >";
							getConfmAppListHtml += "		<a href='app_mng.html?sn="+getConfmAppList[i].sn+"&div="+getConfmAppList[i].div+"'>"+getConfmAppList[i].item+"</a>";
							getConfmAppListHtml += "	</td>";
							getConfmAppListHtml += "	<td>"+getConfmAppList[i].comp+" / "+getConfmAppList[i].userNm+"</td>";
							getConfmAppListHtml += "	<td>"+getConfmAppList[i].registDe+"</td>";
							if (getConfmAppList[i].sttus=="00001"){
								getConfmAppListHtml += "	<td><span class=''>"+getConfmAppList[i].sttusNm+"</span></td>";
							}else if (getConfmAppList[i].sttus=="00002"){
								getConfmAppListHtml += "	<td><span class='ack'>"+getConfmAppList[i].sttusNm+"</span></td>";
							}else if (getConfmAppList[i].sttus=="00003"){
								getConfmAppListHtml += "	<td><span class='apv'>"+getConfmAppList[i].sttusNm+"</span></td>";
							}else {
								getConfmAppListHtml += "	<td><span class=''>"+getConfmAppList[i].sttusNm+"</span></td>";
							}
							if (getConfmAppList[i].confmNm=="") {
								getConfmAppListHtml += "	<td>&nbsp;</td>";
							}else {
								getConfmAppListHtml += "	<td>"+getConfmAppList[i].confmComp+" / "+getConfmAppList[i].confmNm+"</td>";
							}
							getConfmAppListHtml += "	<td>"+getConfmAppList[i].confmDe+"</td>";
							getConfmAppListHtml += "</tr>";

						});
						//검토할 요청 목록 화면에 보이게
						$("#getConfmAppList").append(getConfmAppListHtml);
		//=============================================================================================================================================//
						var getMyAppList = data.data.getMyAppList;
						$.each(getMyAppList, function (j) {

							getMyAppListHtml += "<tr>";
							getMyAppListHtml += "	<td>"+getMyAppList[j].title+"</td>";
							getMyAppListHtml += "<td><a href='app_data_mng.html?sn="+getMyAppList[j].sn+"&div="+getMyAppList[j].div+"'>"+getMyAppList[j].item+"</a></td>";


							if (getMyAppList[j].sttus=="00001"){
								getMyAppListHtml += "	<td><span class=''>"+getMyAppList[j].sttusNm+"</span></td>";
							}else if (getMyAppList[j].sttus=="00002"){
								getMyAppListHtml += "	<td><span class='ack'>"+getMyAppList[j].sttusNm+"</span></td>";
							}else if (getMyAppList[j].sttus=="00003"){
								getMyAppListHtml += "	<td><span class='apv'>"+getMyAppList[j].sttusNm+"</span></td>";
							}else {
								getMyAppListHtml += "	<td><span class=''>"+getMyAppList[j].sttusNm+"</span></td>";
							}
							getMyAppListHtml += "<td>"+getMyAppList[j].confmComp+" / "+getMyAppList[j].confmNm+"</td>";
							if (getMyAppList[j].div==3) {
								getMyAppListHtml += "<td>"+getMyAppList[j].staDtm+" ~ "+getMyAppList[j].endDtm+"</td>";
							} else {
								getMyAppListHtml += "<td>-</td>";
							}

							getMyAppListHtml += "<td>"+getMyAppList[j].registDe+"</td>";
							getMyAppListHtml += "</tr>";

						});
						//공유 요청 목록 화면에 보이게
						$("#getMyAppList").append(getMyAppListHtml);
			//=============================================================================================================================================//
						var myScrapList = data.data.myScrapList;
						$.each(myScrapList, function (j) {

							getMyScrapListHtml += "<tr>";

							if (myScrapList[j].div==1) {
								getMyScrapListHtml += "<td>리포트</td>";
								getMyScrapListHtml += "	<td><a href='/bi/report_view.html?sn="+myScrapList[j].classkey+"'>"+myScrapList[j].item+"</a></td>";
							}else {
								getMyScrapListHtml += "<td>카탈로그</td>";
								getMyScrapListHtml += "	<td><a href='/dc/catalogue_view.html?key="+myScrapList[j].classkey+"'>"+myScrapList[j].item+"</a></td>";
							}
							getMyScrapListHtml += "<td>"+myScrapList[j].ctgNm+"</td>";
							getMyScrapListHtml += "<td>"+myScrapList[j].compNm+"</td>";
							getMyScrapListHtml += "<td>"+myScrapList[j].registDe+"</td>";
							getMyScrapListHtml += "</tr>";
						});

						//스크립 목록 화면에 보이게
						$("#myScrapList").append(getMyScrapListHtml);
				//=============================================================================================================================================//
						var getMyDataList = data.data.getMyDataList;

						$.each(getMyDataList, function (j) {

							getMyDataListHtml += "<tr>";
							getMyDataListHtml += "	<td>";
							getMyDataListHtml += "		<a href='#' class='stut on'>"+getMyDataList[j].item+"</a>";
							getMyDataListHtml += "	</td>";
							getMyDataListHtml += "	<td>"+getMyDataList[j].staDtm+" ~ "+getMyDataList[j].endDtm+"</td>";
							getMyDataListHtml += "	<td>"+getMyDataList[j].confmComp+"</td>";
							getMyDataListHtml += "	<td>"+getMyDataList[j].registDe+"</td>";
							getMyDataListHtml += "</tr>";
						});
						//사용 임박 목록
						$("#getMyDataList").append(getMyDataListHtml);
					}else {
						alert("My Dashboard 조회 중 오류가 발생했습니다.");
					}
				}
			});
		}



		// 나의 공유 요청 목록
		mydashboard.getMyAppList=function(){
			var check = "";
			if($("#dataMySta").val() > $("#dataMyEnd").val()) {
				alert("시작일이 종료일 보다 클 수는 없습니다.");
				return;
			}

			if ($(".showList2").hasClass("on")){
				check = "check";
			}else{
				check = ""
			}

			var param = {
				"staDtm" : $("#dataMySta").val(),
				"endDtm" :$("#dataMyEnd").val(),
				"check" : check
			}

			$.ajax({
				type: "POST",
				url :  _CONSTANTS["URL_BASE"]+ 'main/getMyAppList',
				data: JSON.stringify(param),
				contentType: 'application/json',
				async: true,
				success : function(data, status, xhr) {

					var getConfmAppListHtml ='';

					if (data.code=="success") {

						var getMyAppList = data.data.getMyAppList;
						var getMyAppListHtml="";
						$.each(getMyAppList, function (j) {

							getMyAppListHtml += "<tr>";
							getMyAppListHtml += "	<td>"+getMyAppList[j].title+"</td>";
							getMyAppListHtml += "<td><a href='app_data_mng.html?sn="+getMyAppList[j].sn+"&div="+getMyAppList[j].div+"'>"+getMyAppList[j].item+"</a></td>";

							if (getMyAppList[j].sttus=="00001"){
								getMyAppListHtml += "	<td><span class=''>"+getMyAppList[j].sttusNm+"</span></td>";
							}else if (getMyAppList[j].sttus=="00002"){
								getMyAppListHtml += "	<td><span class='ack'>"+getMyAppList[j].sttusNm+"</span></td>";
							}else if (getMyAppList[j].sttus=="00003"){
								getMyAppListHtml += "	<td><span class='apv'>"+getMyAppList[j].sttusNm+"</span></td>";
							}else {
								getMyAppListHtml += "	<td><span class=''>"+getMyAppList[j].sttusNm+"</span></td>";
							}
							getMyAppListHtml += "<td>"+getMyAppList[j].confmComp+" / "+getMyAppList[j].confmNm+"</td>";
							if (getMyAppList[j].div==3) {
								getMyAppListHtml += "<td>"+getMyAppList[j].staDtm+" ~ "+getMyAppList[j].endDtm+"</td>";
							} else {
								getMyAppListHtml += "<td>-</td>";
							}
							getMyAppListHtml += "<td>"+getMyAppList[j].registDe+"</td>";
							getMyAppListHtml += "</tr>";

						});
						//나의 공유 요청 목록 화면에 보이게
						$("#getMyAppList").empty().append(getMyAppListHtml);

					}else {
						alert("My Dashboard 조회 중 오류가 발생했습니다.");
					}
				}
			});
		}
		//결재 요청 목록
		mydashboard.getConfmAppList=function(){

			var check = "";

			if($("#dataSta").val() > $("#dataEnd").val()) {
				alert("시작일이 종료일 보다 클 수는 없습니다.");
				return;
			}
			//checkbox 확인
			if ($(".showList1").hasClass("on")){
				check = "check";

			}else{
				check = ""
			}

			var param = {
				"staDtm" : $("#dataSta").val(),
				"endDtm" :$("#dataEnd").val(),
				"check" : check
			}

			$.ajax({
				type: "POST",
				url :  _CONSTANTS["URL_BASE"]+ 'main/getConfmAppList',
				data: JSON.stringify(param),
				contentType: 'application/json',
				async: true,
				success : function(data, status, xhr) {

					var getConfmAppListHtml ='';

					if (data.code=="success") {

						 //검토할 요청
						var getConfmAppList = data.data.getConfmAppList;

						$.each(getConfmAppList, function (i) {

							getConfmAppListHtml += "<tr>";
							getConfmAppListHtml += "	<td>"+getConfmAppList[i].title+"</td>";
							getConfmAppListHtml += "	<td >";
							getConfmAppListHtml += "		<a href='app_mng.html?sn="+getConfmAppList[i].sn+"&div="+getConfmAppList[i].div+"'>"+getConfmAppList[i].item+"</a>";
							getConfmAppListHtml += "	</td>";
							getConfmAppListHtml += "	<td>"+getConfmAppList[i].comp+" / "+getConfmAppList[i].userNm+"</td>";
							getConfmAppListHtml += "	<td>"+getConfmAppList[i].registDe+"</td>";
							if (getConfmAppList[i].sttus=="00001"){
								getConfmAppListHtml += "	<td><span class=''>"+getConfmAppList[i].sttusNm+"</span></td>";
							}else if (getConfmAppList[i].sttus=="00002"){
								getConfmAppListHtml += "	<td><span class='ack'>"+getConfmAppList[i].sttusNm+"</span></td>";
							}else if (getConfmAppList[i].sttus=="00003"){
								getConfmAppListHtml += "	<td><span class='apv'>"+getConfmAppList[i].sttusNm+"</span></td>";
							}else {
								getConfmAppListHtml += "	<td><span class=''>"+getConfmAppList[i].sttusNm+"</span></td>";
							}
							if (getConfmAppList[i].confmNm=="") {
								getConfmAppListHtml += "	<td>&nbsp;</td>";
							}else {
								getConfmAppListHtml += "	<td>"+getConfmAppList[i].confmComp+" / "+getConfmAppList[i].confmNm+"</td>";
							}
							getConfmAppListHtml += "	<td>"+getConfmAppList[i].confmDe+"</td>";
							getConfmAppListHtml += "</tr>";

						});
						//검토할 요청 목록 화면에 보이게
						$("#getConfmAppList").empty().append(getConfmAppListHtml);
					}else {
						alert("My Dashboard 조회 중 오류가 발생했습니다.");
					}

				}
			});
		}

		/****************************************************************************************************/
		/** @END Method Definition */

		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			mydashboard.init();

			setNav('0');

			//대기중인 요청만 보기
			$(document).on("click","#showPorg1",function(){
				if ($(".showList1").hasClass("on")){
					$(".showList1").removeClass("on");
				}else{
					$(".showList1").addClass("on");
				}
				mydashboard.getConfmAppList();
			});

			//처리중인 요청만 보기
			$(document).on("click","#showPorg2",function(){
				if ($(".showList2").hasClass("on")){
					$(".showList2").removeClass("on");
				}else{
					$(".showList2").addClass("on");
				}
				mydashboard.getMyAppList();
			});

			// 검토할 요청 검색 버튼 클릭
			$("#dataSearchBtn").click(function() {
				mydashboard.getConfmAppList();
			});

			// 공유 신청 검색 버튼 클릭
			$("#dataMySearchBtn").click(function() {
				mydashboard.getMyAppList(1);
			});

		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});