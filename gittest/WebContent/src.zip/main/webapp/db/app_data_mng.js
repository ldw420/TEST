/**
 * TITLE : DLSP
 * DESC : 메인화면 
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var appMng = function() {};

head.ready(function () {

	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}

	(function($) { "use strict";
	 
		
		var form,param,pagination, div, sn, sttusVal;
		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		appMng.init = function() {

			//메뉴 권한 채크
			//commUsr.menuAuthCheck();
			
			form = $("#frm01");
			param = commAjax.getJsonFromQry(location.href);
			
			div = commAjax.getParameter("div");
			sn = commAjax.getParameter("sn");

			appMng.list();
			
			if (div==2) {
				$("#auth_view").show();
				
			}else if (div==1) {
				$("#report_view").show();
				
			}else if (div==3) {
				$("#data_view").show();
				$("#table_view").show(); 
				
			} 
			
			appMng.appMngDetail();
			appMng.tableList();
 
			
		}; 
		
		//상세 내용 조회
		appMng.appMngDetail=function(){ 

			//쿠키에서 개인정보 추출하는 부분 삭제, 20191023
			param = {
					"div":div
					}
			var url  = ""; 
			
			if (div==2) {
				$("#auth_view").show();
				url = _CONSTANTS["URL_BASE"]+ 'main/authDetail/'+sn;
			}else if (div==1) {
				$("#report_view").show();
				url = _CONSTANTS["URL_BASE"]+ 'main/reportDetail/'+sn;
			}else if (div==3) {
				$("#data_view").show();
				url = _CONSTANTS["URL_BASE"]+ 'main/dataAppDetail/'+sn;
			} 

			
			$.ajax({
				type: "Get",
				url :  url,
				//data: JSON.stringify(param),
				//contentType: 'application/json',
				async: true,		
				success : function(data, status, xhr) {

					var results = data.data.confmDetail;
					if (data.code=="success") {
						if (div==2) {
							$("#auth_usrNm").empty().append(results.usrNm);
							$("#auth_comp").empty().append(results.comp);
							$("#auth_confmSttusNm").empty().append(results.confmSttusNm);
							$("#auth_authNm").empty().append(results.authNm);
							$("#auth_appPrvonsh").empty().append(results.appPrvonsh);
							//요청/승인/반려 글자색 수정
							if (results.confmSttus =="00002") {
								$("#btnSet").hide();
								$("#auth_confmSttusNm").attr('class','ack');
							} else if (results.confmSttus =="00003") {
								$("#btnSet").hide();
								$("#auth_confmSttusNm").attr('class','apv');
							}else {
								$("#btnSet").show();
							}
						}else if (div==1) {  
							$("#repo_registerId").empty().append(results.userNm);
							$("#repo_useAtNm").empty().append(results.useAtNm);
							$("#repo_cn").empty().append(results.cn);
							$("#repo_title").empty().append(results.biRepSj);
							$("#repo_compNm").empty().append(results.copmNm); 
							$("#repo_shrUrl").empty().append(results.shrUrl); 
							$("#repo_ctgNm").empty().append(results.ctgNm); 
							
							if (results.shrAt=="Y") {
								$("#repo_shrAt").empty().append("전체 공유");
							}else {
								$("#repo_shrAt").empty().append("내가 속한 관계사에만 공유");
							}
							
							
							
							//요청/승인/반려 글자색 수정
							if (results.useAt =="00002") {
								$("#btnSet").hide();
								$("#repo_useAtNm").attr('class','ack');
							}else if (results.useAt =="00003") {
								$("#btnSet").hide();
								$("#repo_useAtNm").attr('class','apv');
							}else {
								$("#btnSet").show();
							}
							
							var area = $('#report_view');
							area.find('[data-biurl]').attr('src',_CONSTANTS["URL_BASE"]+"show-image?imageName="+results.imgUrl);
							
							
						}else if (div==3) { 
							$("#data_appPrvonsh").empty().append(results.appPrvonsh)
							$("#data_reqComp").empty().append(results.reqComp)
							$("#data_reqId").empty().append(results.reqUserNm)
							$("#data_sttus").empty().append(results.sttusNm)
							$("#data_classTitle").empty().append(results.classTitle);
							//요청/승인/반려 글자색 수정
							if (results.sttus =="00002" ) {
								$("#btnSet").hide();
								$("#data_sttus").attr('class','ack');
							} else if (results.sttus =="00003") {
								$("#btnSet").hide();
								$("#data_sttus").attr('class','apv');
							} else {
							
								$("#btnSet").show();
							}
							
							sttusVal = results.sttus;
						} 
						
						$("#confmCn").val(results.confmCn);
					 
					}else {
						alert("상세 정보 조회를 실패했습니다.");
					}
					 
				}
			});
		}
		
		
		appMng.list=function(){ 

			var param = {
					"div":div
					}
			 
			
			$.ajax({
				type: "POST",
				url :  _CONSTANTS["URL_BASE"]+ 'main/mydashboard',
				data: JSON.stringify(param),
				contentType: 'application/json',
				async: true,		
				success : function(data, status, xhr) {
					
					var getConfmAppListHtml ='';
					var getMyAppListHtml ='';
					var confmApp = 0;
					var confmAppOk = 0;
					var confmAppNo = 0;
					
					if (data.code=="success") {
						var appMngDetail = data.data.confmAppCnt;
				 
						$("#confmAppCnt").empty().append(data.data.confmAppCnt);
						var myAppCnt = data.data.myAppCnt;
						
						//나의 요청 현황
						$.each(myAppCnt, function (i) {
							 if (myAppCnt[i].sttus=="00001") {
								 //요청
								 confmApp=confmApp+myAppCnt[i].cnt;
							 }else if (myAppCnt[i].sttus=="00002") {
								 //승인
								 confmAppOk=confmAppOk+myAppCnt[i].cnt;
							 }else if (myAppCnt[i].sttus=="00003") {
								 //반려
								 confmAppNo=confmAppNo+myAppCnt[i].cnt;
							 } else if (myAppCnt[i].sttus=="00004") {
								 //요청 +승인사 요청 완료
								 confmApp=confmApp+myAppCnt[i].cnt;
							 } 
						}); 
						 //요청
						 $("#confmApp").empty().append(confmApp);
						 //승인
						 $("#confmAppOk").empty().append(confmAppOk);
						 //반려
						 $("#confmAppNo").empty().append(confmAppNo);
						  
					 
					}else {
						alert("My Dashboard 조회 중 오류가 발생했습니다.");
					}
					 
				}
			});
		}
		
		//요청 테이블 목록 조회
		appMng.tableList=function(){ 

			var url  = ""; 
			var html = "";
			url = _CONSTANTS["URL_BASE"]+ 'main/tableList/'+sn;
			 
			$.ajax({
				type: "Get",
				url :  url, 
				async: true,		
				success : function(data, status, xhr) {
					
					 
					var results = data.data.tebleList;
					if (data.code=="success") {
						$.each(results, function (i) {
							html += "<tr>";
							html += "	<td>"+results[i].seq+"</td>";
							html += "	<td>"+results[i].subjectName+"</td>";
							html += "	<td>"+results[i].resourceid+"</td>";
							html += "	<td>"+results[i].reqTbl+"</td>";
							html += "	<td>"+results[i].staDtm+"~"+results[i].endDtm+"</td>";
							html += "</tr>";
						}); 
						
						$("#tableListHtml").append(html);
						

					 
					}else {
						alert("상세 정보 조회를 실패했습니다.");
					}
					 
				}
			});
		}
		
		//승인 반려 처리
		appMng.confmOkNo=function(sttus){ 

			var param = {
					"div"		:div,
					"confmCn"	:$("#confmCn").val(),
					"sttus" : sttus,
					"sn" : sn
					}
			
			$.ajax({
				type: "POST",
				url :  _CONSTANTS["URL_BASE"]+ 'main/confmOkNo',
				data: JSON.stringify(param),
				contentType: 'application/json',
				async: true,		
				success : function(data, status, xhr) {
					
					if (data.code=="success") {
						alert("승인 처리가 정상적으로 완료되었습니다.");
						
						location.href = "/db/mydashboard.html";
						 
					}else {
						alert("승인 처리  중 오류가 발생했습니다.");
					}
					 
				}
			});
		}
		
 
		
		/****************************************************************************************************/
		/** @END Method Definition */

		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			appMng.init();
			
			$("#caseImg").click(function() { 
				
				 
				window.open('/bi/report_view_popup.html?sn='+sn,'','width=1480,height=850,left=100,top=100');
			});
			
			
			
			$("#buttonOk").click(function() { 
				if ($("#confmCn").val()==""){
					alert("의견을 입력해주세요");
					return false;
				}
				
				if (div==3) {
					if (sttusVal=="00004") {
						appMng.confmOkNo("00002");
					}else {
						appMng.confmOkNo("00004");
					}
				}else {
					appMng.confmOkNo("00002");
				} 
				
			});
			
			$("#buttonNo").click(function() {
				if ($("#confmCn").val()==""){
					alert("의견을 입력해주세요");
					return false;
				}
				appMng.confmOkNo("00003");
			});
			
			
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});