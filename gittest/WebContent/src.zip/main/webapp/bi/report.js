/**
 * TITLE : DLSP
 * DESC : 메인화면 
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var report = function() {};

head.ready(function () {

	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}

	(function($) { "use strict";
	
		var form,param,pagination;
		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		report.init = function() {
 
			//메뉴 권한 채크
			commUsr.menuAuthCheck();
			
			form = $("#frm01");
			param = commAjax.getJsonFromQry(location.href);
			
			pagination = $('#paging').bootpagPo({ total: 0 }).on("page", function(event, num){ report.list(num) });

			//카테고리 정보 가져오기
			report.ctgList("00003");
			
			//관계사 정보 가져오기
			report.compList("sk004");
			
			//목록 가져오기
			report.list();
			
		};
		
		//카테고리
		report.ctgList = function(group_code_id){
			var html = "<li data-option data-value='all' class='bx--dropdown-item'>";
			html += "<a class='bx--dropdown-link bx--dropdown--selected' href='javascript:void(0)' tabindex='-1'>카테고리 선택</a>";
			html += "</li>";
			
			$.ajax({
				type: "GET",
				url : _CONSTANTS["URL_BASE"]+"code/useDetail/"+group_code_id,
				data: "",
				dataType: "json", 
				success : function(data, status, xhr) {
					
					if (data.code=="success") {
						
						var results = data.data.codeDetailList; 
						
						$.each(results, function (i) {
							
							var p = "'"+results[i].detailCodeId+"'";
							
							html +="<li data-option data-value='cloudFoundry' class='bx--dropdown-item'>";
							html +='<a class="bx--dropdown-link" href="javascript:ctgSel('+ p +')" tabindex="-1">'+ results[i].detailCodeNm +'</a>';
							html +="</li>";
							
						}); 
						$("#bx--dropdown-list").append(html);
						
					}else{
						alert("공통 코드 상세 목록 조회 중 오류가 발생했습니다.");
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		}
		
		//관계사
		report.compList = function(group_code_id){
			var html = "<li data-option data-value='all' class='bx--dropdown-item'>";
			html += "<a class='bx--dropdown-link bx--dropdown--selected' href='javascript:ctgSch(0)' tabindex='-1'>모든 관계사</a>";
			html += "</li>";
			
			$.ajax({
				type: "GET",
				url : _CONSTANTS["URL_BASE"]+"code/useDetail/"+group_code_id,
				data: "",
				dataType: "json", 
				success : function(data, status, xhr) {
					
					if (data.code=="success") {
						
						var results = data.data.codeDetailList; 
						
						$.each(results, function (i) {
							
							var p = "'"+results[i].detailCodeId+"'";
							
							html +="<li data-option data-value='cloudFoundry' class='bx--dropdown-item'>";
							html +='<a class="bx--dropdown-link" href="javascript:ctgSch('+ p +')" tabindex="-1">'+ results[i].detailCodeNm +'</a>';
							html +="</li>";
							
						}); 
						$("#bx--dropdown-list-cp").append(html);
						
					}else{
						alert("공통 코드 상세 목록 조회 중 오류가 발생했습니다.");
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		}
		
		//목록
		report.list=function(pageNumber){
			var pageNo = commUtil.parseInt(pageNumber,1);
			form.find('#pageNo').val(pageNo);
			
			var param = form.serialize();
			
			$.ajax({
				type: "Get",
				url : _CONSTANTS["URL_BASE"]+"bi",
				data: param,
				dataType: "json",
				success : function(data, status, xhr) {
					
					if (data.code=="success") {
						//Tableau 리스트
						var html ='';
						var biList = data.data.biList;
						
						if (biList.length>0){
							
							$.each(biList,function(i) {
								
								html += "<li class='onThum'>";
								//html += "<div class='reThum' onclick='deView("+biList[i].sn+")'><img src='"+_CONSTANTS["URL_BASE"]+"gallery/show-image?imageName="+biList[i].imgUrl+"'></div>";
								html += "<div style='border:none;' class='reThum' onclick='deView("+biList[i].sn+")'><img src='"+_CONSTANTS["URL_BASE"]+"show-image?imageName="+biList[i].imgUrl+"'></div>";
								
								if (biList[i].docId !=0) {
									html += "<button class='scrap on' value="+biList[i].sn+">스크랩</button>";
								}else {
									html += "<button class='scrap' value="+biList[i].sn+">스크랩</button>";
								}
								
								html += "<a href='#' class='onReport' onclick='deView("+biList[i].sn+")'>"+ biList[i].biRepSj +"</a>";
								html += "<span>카테고리│"+ biList[i].ctgNm +"</span>"; 
								html += "<span>관계사│"+ biList[i].copmNm +"</span><BR>";
								html += "<span>작성자│"+ biList[i].userNm +"</span>";
								html += "<span>조회수│"+ biList[i].cnt +"</span>";
								html += "<span>업데이트│"+ biList[i].updtDe +"</span>";
								html += "<p  onclick='deView("+biList[i].sn+")'>"+biList[i].cn+"</p>"
								html += "</li>";
							});
							
						}else{
							html += "<li>";
							html += "<p style='padding:24px;height:auto;text-align:center;font-size:17px'>검색된 결과가 없습니다.</p>";
							html += "</li>";
							
							$("#paging").empty();
						}
						
						$("#ulArea").empty().append(html);
						$("#filter").empty().append("필터 ("+data.data.biListCount+")");
						
						//카테고리
						html = '';
						var biCtgList = data.data.biCtgList
						$.each(biCtgList,function(i) {
							
							var p=""+biCtgList[i].detailCodeId+""
							
							if (i < 5){
								html +="<li class='cate'>";
								//html +="<a href='#'  value="+biCtgList[i].detailCodeId+">"+ biCtgList[i].detailCodeNm +"("+biCtgList[i].cnt+")</a>";
								html +="<a href='#'  value="+biCtgList[i].detailCodeId+">"+ biCtgList[i].detailCodeNm +"(<span id="+ biCtgList[i].detailCodeId +">"+biCtgList[i].cnt+"</span>)</a>";
								html +="</li>";
							}else{
								html +="<li>";
								//html +="<a href='#' value="+biCtgList[i].detailCodeId+">"+ biCtgList[i].detailCodeNm +"("+biCtgList[i].cnt+")</a>";
								html +="<a href='#'  value="+biCtgList[i].detailCodeId+">"+ biCtgList[i].detailCodeNm +"(<span id="+ biCtgList[i].detailCodeId +">"+biCtgList[i].cnt+"</span>)</a>";
								html +="</li>";
							}
						});
						
						html += "<li class='showBtnBox'>";
						html += "<a href='javascript:void(0)' class='showBtn'>모든 카테고리 결과 보기</a>";
						html += "</li>";
									
						$(".cate_list").empty().append(html);
						
						//관계사
						html = '';
						var biCompList = data.data.biCompList
						
						$.each(biCompList,function(i) {
							var p="'"+biCompList[i].detailCodeId+"'"
							
							html +="<li>";
							//html +="<a href='#' value="+biCompList[i].detailCodeId+">"+ biCompList[i].detailCodeNm +"("+biCompList[i].cnt+")</a>";
							html +="<a href='#' value="+biCompList[i].detailCodeId+">"+ biCompList[i].detailCodeNm +"(<span id="+biCompList[i].detailCodeId+">"+biCompList[i].cnt+"</span>)</a>";
							html +="</li>";
						});
						
						$(".partner_list").empty().append(html);
						
						var pageCnt = Math.ceil(data.data.biListCount / 10);
						
						pagination.bootpagPo({
							total: pageCnt,
							page : pageNo
						});

					}else{
						alert("Tableau 조회 중 오류가 발생했습니다.");
					}
				},
			});
		}
		
		//우측, 카테고리&관계사 검색용
		report.list2=function(pageNumber){
			
			var pageNo = commUtil.parseInt(pageNumber,1);
			form.find('#pageNo').val(pageNo);
			var param = form.serialize();

			$.ajax({
				type: "Get",
				url : _CONSTANTS["URL_BASE"]+"bi",
				data: param,
				dataType: "json",
				success : function(data, status, xhr) {
					
					if (data.code=="success") {
						//Tableau 리스트
						var html ='';
						var biList = data.data.biList;
						
						if (biList.length>0){
							
							$.each(biList,function(i) {
								
								html += "<li class='onThum'>";
								//html += "<div class='reThum'><img src='"+_CONSTANTS["URL_BASE"]+"gallery/show-image?imageName="+biList[i].imgUrl+"'></div>";
								html += "<div class='reThum'><img src='"+_CONSTANTS["URL_BASE"]+"show-image?imageName="+biList[i].imgUrl+"'></div>";
								
								if (biList[i].docId !=0) {
									html += "<button class='scrap on' value="+biList[i].sn+">스크랩</button>";
								}else {
									html += "<button class='scrap' value="+biList[i].sn+">스크랩</button>";
								}
								
								html += "<a href='#' class='onReport' onclick='deView("+biList[i].sn+")'>"+ biList[i].biRepSj +"</a>";
								html += "<span>카테고리│"+ biList[i].ctgNm +"</span>"; 
								html += "<span>관계사│"+ biList[i].copmNm +"</span><BR>";
								html += "<span>작성자│"+ biList[i].userNm +"</span>";
								html += "<span>조회수│"+ biList[i].cnt +"</span>";
								html += "<span>업데이트│"+ biList[i].updtDe +"</span>";
								html += "<p>"+biList[i].cn+"</p>"
								html += "</li>";
							});
							
							var pageCnt = Math.ceil(data.data.biListCount / 10);

							pagination.bootpagPo({
					        	total: pageCnt,
					        	page : pageNo
					        });
							
						}else{
							html += "<li>";
							html += "<p style='padding:24px;height:auto;text-align:center;font-size:17px'>검색된 결과가 없습니다.</p>"
							html += "</li>";
							
							$("#paging").empty();
						}
						$("#ulArea").empty().append(html);
						//$("#schBiRepSj").val('');
						$("#filter").empty().append("필터 ("+data.data.biListCount+")");
						
						var biCtgList = data.data.biCtgList;
						$.each(biCtgList,function(i) {
							$("#"+biCtgList[i].detailCodeId).html(biCtgList[i].cnt);
						});
						
						var biCompList = data.data.biCompList;
						$.each(biCompList,function(i) {
							$("#"+biCompList[i].detailCodeId).html(biCompList[i].cnt);
						});
						
						
					}else{
						alert("Tableau 조회 중 오류가 발생했습니다.");
					}
				}
			});
		}
		
		report.scrapAdd=function(docId){
			var p = {
					"cl": 'BI', 
					"docId":docId
					}
				
			$.ajax({
				type: "POST",
				url : _CONSTANTS["URL_BASE"]+"scrap",
				data: JSON.stringify(p),
				contentType: 'application/json',
				success : function(data, status, xhr) {
	
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("Tableau 스크랩 중 오류가 발생했습니다.");
				},
			});
		}
		
		report.scrapDel=function(docId){
			var p = {
					"cl": 'BI', 
					"docId":docId
					}

			$.ajax({
				type: "Delete",
				url : _CONSTANTS["URL_BASE"]+"scrap",
				data: JSON.stringify(p),
				contentType: 'application/json',
				success : function(data, status, xhr) {

				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("Tableau 스크랩 중 오류가 발생했습니다.");
				},
			});
		}
		
		report.creat=function() {
			
			if ($("#imgUrlChk").val()==undefined) {
				alert("URL 주소가 올바르지 않습니다.");
				return false;
			}
			
			var shrAt = '';
			if ($('input[id="shareA"]:checked').val()=="on"){
				shrAt = "N";
			}else{
				shrAt = "Y";
			}
		
			param = {
					"rownum":0, 
					"sn":0, 
					"userId":'',
					"biRepSj":$('#biRepSj').val(),
					"shrUrl":$('#imgUrl').val(),   
					"shrAt":shrAt,
					"useAt":'00001',
					"imgUrl":$("#hidimgUrl").val(),
					"ctg":$("#ctgId").val(),
					"cn":$("#inTextarea").val(),
					"copm":$("#copm").val()
					}
		
			$.ajax({
				type: "POST",
				url : _CONSTANTS["URL_BASE"]+"bi",
				data: JSON.stringify(param),
				contentType: 'application/json',
				success : function(data, status, xhr) {
			
					$("#shareReport input").each(function () {
						$(this).val("");
					});
					$("#shareReport textarea").each(function () {
						$(this).val("");
					});
					$(".tbl_preview").empty().append("<span>미리보기</span>");
					$("#shareBB").removeClass("on");
					$("#shareAA").addClass("on");
					$("#bx--dropdown-text-ctg").text("카테고리 선택");
					
					report.list(1);
					hideModal('shareReport'); 
					onToastPop('toastPop1');
					
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("Tableau 등록 중 오류가 발생했습니다.");
				},
			});
		}
		
		report.view=function(){
			
			var imgUrl = $("#imgUrl").val();
			var html = '';
			
			var p = {
					tableauShareUrl : imgUrl 
					};
		
			$.ajax({
				type: "Get",
				//url : _CONSTANTS["URL_BASE"]+"gallery/get-preview-image",
				url : _CONSTANTS["URL_BASE"]+"get-preview-image",
				data: p,
				success : function(data, status, xhr) {
					//html = "<img src='"+_CONSTANTS["URL_BASE"]+"gallery/show-image?imageName="+data.data.fileName+"' width='500px' height='300px'>"
					html = "<img src='"+_CONSTANTS["URL_BASE"]+"show-image?imageName="+data.data.fileName+"' width='500px' height='300px'>"
					html += "<input type='hidden' value="+data.data.fileName+" id='hidimgUrl'>"
					
					
					if (data.data.fileName== undefined){
						
					}else{
						html += "<input type='hidden' value='suc' id='imgUrlChk'>"		
					}
					
					$(".tbl_preview").empty().append(html);
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("Tableau 미리보기 중 오류가 발생했습니다.");
				},
				
			});						
		}

		/****************************************************************************************************/
		/** @END Method Definition */

		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			report.init();
			
			setNav(4);
			
			//검색(엔터)
			$("#schBiRepSj").keyup(function(e){
				if(e.keyCode == 13){  
					report.list();
				}
			});
		
			//검색(클릭)
			$(document).on("click",".search_btn",function(){
				report.list();
			});

			//등록
			$(document).on("click","#btnType",function(){
				if (!$("#btnType").hasClass("disable")){
					var checkBalnk = /^\s+|\s+$/g; //공백만 입력 됐을 경우 return
					if($("#biRepSj").val() == '' || $("#biRepSj").val().replace(checkBalnk,'') == ''){
					   alert("리포트 제목을 입력하십시오.");
					   $('#biRepSj').focus();
					   return false;
					}
					
					if($("#imgUrl").val() == '' || $("#imgUrl").val().replace(checkBalnk,'') == ''){
					   alert("URL을 입력하십시오.");
					   $('#imgUrl').focus();
					   return false;
					}
					
					if ($("#inTextarea").val() == '') {
						alert("설명을 입력하십시오.");	
						$("#inTextarea").focus();
						return false;
					}
					
					if ($("#inTextarea").val().length < 100) {
						alert("설명을 100자 이상 입력하십시오.");
						$("#inTextarea").focus();
						return false;
					}
					
					if ($("#ctgId").val()==''){
						alert("카테고리를 선택하십시오.");	
						return false;
					}
					
					report.creat();
				}
			});
			
			//섬네일 미리보기
			$(document).on("click","#imgView",function(){
				alert("미리보기 생성에 시간이 다소 오래 걸릴 수 있습니다.(1분 내외)");
				report.view();
			});
			
			//취소
			$(document).on("click",".cancel_btn",function(){
					
				$("#shareReport input").each(function () {
					$(this).val("");
				});
				$("#shareReport textarea").each(function () {
					$(this).val("");
				});
				$(".tbl_preview").empty().append("<span>미리보기</span>");
				$("#shareBB").removeClass("on");
				$("#shareAA").addClass("on");
				$("#bx--dropdown-text-ctg").text("카테고리 선택");
				
				//commUtil.removeOverlay();
				
				hideModal('shareReport');

			});
			
			
			//취소(X버튼)
			$(document).on("click",".modal_pop_top a",function(){
					
				$("#shareReport input").each(function () {
					$(this).val("");
				});
				$("#shareReport textarea").each(function () {
					$(this).val("");
				});
				$(".tbl_preview").empty().append("<span>미리보기</span>");
				$("#shareBB").removeClass("on");
				$("#shareAA").addClass("on");
				$("#bx--dropdown-text-ctg").text("카테고리 선택");
				
				//commUtil.removeOverlay();
				
				hideModal('shareReport');

			});
			
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});