/**
 * TITLE : DLSP
 * DESC : 메인화면 
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var report = function() {};

head.ready(function () {

	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}


	(function($) { "use strict";

		var id = commAjax.getParameter("sn");
		var param = '';

		
		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		report.init = function() {
	
			report.list();
		};
		
		report.list=function(){
			param = {}
 
			$.ajax({
				type: "GET",
				url :  _CONSTANTS["URL_BASE"]+ 'bi/'+id,
				data : param ,
				success : function(data, status, xhr) {
					
					var html ='';
					var biDetail = data.data.biDetail;
					if (data.code=="success") {	
						if (biDetail.docId !=0) {
							html += "<button class='scrap on' value="+biDetail.sn+">스크랩</button>";
						}else {
							html += "<button class='scrap' value="+biDetail.sn+">스크랩</button>";
						}
						html += "<h1>"+biDetail.biRepSj+"</h1>";
						html += "<p><span>관계사│"+ biDetail.copmNm +"</span>";
						html += "<span>작성자│"+ biDetail.userNm +"</span>";
						html += "<span>조회수│"+ biDetail.cnt +"</span>";
						html += "<span>업데이트│"+ biDetail.updtDe +"</span></p>";
						html += "<p>"+biDetail.cn.replace(/(?:\r\n|\r|\n)/g,'<br/>')+"</p>";
						
						$("#divArea").append(html);
					
						html ='';
						html += "<div class='gal_box_detial'>";
						html += "</div>";
						
						$("#gal_box").prepend(html);
						
						doViz($(".tableau_viz_section")[0], data.data.reportUrl, null, []);
						
						var prevNextReport = data.data.prevNextReport;
 
						$.each(prevNextReport,function(i) { 
							if (prevNextReport[i].updtDe > biDetail.updtDe) {
								$('.prev').prop('href', './report_view.html?sn='+prevNextReport[i].sn);
								$("#prevTitle").empty();
								$("#prevTitle").prepend(prevNextReport[i].biRepSj);
							}else if(prevNextReport[i].updtDe < biDetail.updtDe) {
								$('.next').prop('href', './report_view.html?sn='+prevNextReport[i].sn);
								$("#nextTitle").empty();
								$("#nextTitle").prepend(prevNextReport[i].biRepSj);
								
							}
						});
						
						
						
						
					}else{
						alert(data.message);
					}
				}
			});
		}
		
		report.scrapAdd=function(docId){
		
			param = {
					"cl": 'BI', 
					"docId":docId
					}
				
			$.ajax({
				type: "POST",
				url : _CONSTANTS["URL_BASE"]+"scrap",
				data: JSON.stringify(param),
				contentType: 'application/json',
				success : function(data, status, xhr) {
	
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("Tableau 스크랩 중 오류가 발생했습니다.");
				},
				
			});
		}
		
		report.scrapDel=function(docId){
		
			param = {
					"cl": 'BI', 
					"docId":docId
					}

			$.ajax({
				type: "Delete",
				url : _CONSTANTS["URL_BASE"]+"scrap",
				data: JSON.stringify(param),
				contentType: 'application/json',
				success : function(data, status, xhr) {

				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("Tableau 스크랩 중 오류가 발생했습니다.");
				},
				
			});
		}
		

		/****************************************************************************************************/
		/** @END Method Definition */

		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			report.init();
		
			setNav(4);
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});