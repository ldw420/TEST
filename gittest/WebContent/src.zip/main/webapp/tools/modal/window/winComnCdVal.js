/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 상세 코드관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var winComnCdVal = function() {};

head.ready(function () {
	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}
	
	
	(function($) { "use strict";

		var usrId = commAjax.getParameter("param");
		$('#winComnCdValSpa0101').text(usrId);
		
		/** @START Method Definition
		/****************************************************************************************************/	
		// This Page Initialize
		winComnCdVal.init = function() {
		
		};
		
		// 상세코드 등록
		winComnCdVal.createComnCd = function(param) {
			
			param = {
					"detailCodeDc":$('#winComnCdValInp0105').val(), 
					"detailCodeId":$('#winComnCdValInp0102').val(), 
					"detailCodeNm":$('#winComnCdValInp0104').val(), 
					"detailCodeOrdr":0, 
					"groupCodeDc":'', 
					"groupCodeId":$('#winComnCdValSpa0101').text(), 
					"groupCodeNm":'', 
					"registDe":'', 
					"registerId":'', 
					"updtDe":'', 
					"updtId":'', 
					"useAt":$('#winComnCdValSel0102').val()
					}

			$.ajax({
				type: "POST",
				url : _CONSTANTS["URL_BASE"]+"code/detail",
				data: JSON.stringify(param),
				contentType: 'application/json',
				async: true,	
				success : function(data, status, xhr) {
		
					if (data.code=="success") {
						alert("정상적으로 등록 되었습니다.");
						opener.comnCdMng.list($('#winComnCdValSpa0101').text());
						$('#winComnCdValInp0105').val('');
						$('#winComnCdValInp0102').val('');
						$('#winComnCdValInp0104').val('');
						 
						 window.close();
					}else {
						alert("상세 코드 등록 중 오류가 발생했습니다.");
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("상세 코드 등록 중 오류가 발생했습니다.");
				},	
			});
		};

		
	
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			winComnCdVal.init();

			// 상세코드 등록
			$("#winComnCdValBtn0101").click(function(event) {
				
				var checkBalnk = /^\s+|\s+$/g; //공백만 입력 됐을 경우 return
				if(document.frmWinComnCdVal.comnCdVal.value == '' || document.frmWinComnCdVal.comnCdVal.value.replace(checkBalnk,'') == ''){
				   alert("상세코드를 입력하십시오.");
				   document.frmWinComnCdVal.comnCdVal.focus();
				   return false;
				} 
				
				if(document.frmWinComnCdVal.comnCdVal.value.length != '5'){
					   alert("상세코드 길이는 5자입니다.");
					   document.frmWinComnCdVal.comnCdVal.focus();
					   return false;
				} 
				
				if(document.frmWinComnCdVal.comnCdValDesc.value == '' || document.frmWinComnCdVal.comnCdValDesc.value.replace(checkBalnk,'') == ''){
				   alert("상세코드 명칭을 입력하십시오.");
				   document.frmWinComnCdVal.comnCdValDesc.focus();
				   return false;
				} 
				
				if(confirm("새로운 상세코드를 추가하겠습니까?")) {
					winComnCdVal.createComnCd();
				} else {
					return false;
				}

			});

			// 닫기 버튼
			$("#winComnCdValBtn0102").click(function(event) {
				window.close();
			});
				
			
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	
	}(jQuery));
});