/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 상위코드관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var winComnCd = function() {};

head.ready(function () {
	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}
	
	
	(function($) { "use strict";

		
		/** @START Method Definition
		/****************************************************************************************************/	
		// This Page Initialize
		winComnCd.init = function() {
		
		};
		
		// 공통코드 등록
		winComnCd.createComnCd = function(param) {

			 param = {
					 "groupCodeDc":'',
					 "groupCodeId":$('#winComnCdInp0101').val(),
					 "groupCodeNm":$('#winComnCdInp0102').val(),
					 "registDe":'',
					 "registerId":'',
					 "updtDe":'',
					 "updtId":'',
					 "useAt":$('#winComnCdSel0101').val()
					 }
			 
			 $.ajax({
				type: "POST",
				url : _CONSTANTS["URL_BASE"]+"code/group",
				data: JSON.stringify(param),
				contentType: 'application/json',
				async: true,	
				success : function(data, status, xhr) {
				//alert(data.code)
					if (data.code=="success") {
						alert("정상적으로 등록 되었습니다.");
						//comnCdMng.groupList();
						$('#winComnCdInp0101').val('');
						$('#winComnCdInp0102').val('');
						$('#winComnCdInp0103').val('');
						 opener.location.reload();
						 window.close();
					}else {
						alert("공통 코드 등록 중 오류가 발생했습니다.");
					}
					
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("공통 코드 등록 중 오류가 발생했습니다.");
				},
				
			});
		   
		};

			
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			winComnCd.init();

			
			// 공통코드 등록
			$("#winComnCdBtn0101").click(function(event) {
		
				var checkBalnk = /^\s+|\s+$/g; //공백만 입력 됐을 경우 return
				if(document.frmWinComnCd.comnCdId.value == '' || document.frmWinComnCd.comnCdId.value.replace(checkBalnk,'')==""){
				   alert("공통코드를 입력하십시오.");
				   document.frmWinComnCd.comnCdId.focus();
				   return false;
				} 
				
				if(document.frmWinComnCd.comnCdId.value.length != '5'){
					   alert("공통코드 길이는 5자입니다.");
					   document.frmWinComnCd.comnCdId.focus();
					   return false;
					} 
				
				if(document.frmWinComnCd.comnCdKorNm.value == '' || document.frmWinComnCd.comnCdKorNm.value.replace(checkBalnk,'')==""){
				   alert("공통코드 명칭을 입력하십시오.");
				   document.frmWinComnCd.comnCdKorNm.focus();
				   return false;
				} 
			
				if(confirm("새로운 공통코드를 추가하겠습니까?")) {
					winComnCd.createComnCd();
				} else {
					return false;
				}
			
			});
			
			// 닫기 버튼
			$("#winComnCdBtn0102").click(function(event) {
				window.close();
			});
			
			
				
			
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	
	}(jQuery));
});