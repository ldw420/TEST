/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 공지사항 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */

head.ready(function () {

	if(typeof jQuery == "undefined") {
		throw new Error("Require jQuery");
	}

	(function($) { "use strict";
		var form,param;
		var noticeModify = function() {};
		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		noticeModify.init = function(noticeMngCd) {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(8);
			//좌측 하위 메뉴 활성화
			$(".left_menu_list li a").click();
			
			form = $('#form');
			param = commAjax.getJsonFromQry(location.href);
			noticeModify.getData();
		}
		noticeModify.getData = function(){

			$.ajax({
				type: "GET",
				url :  _CONSTANTS["URL_BASE"]+ 'bbs/notice/'+param.bbsNo,
				dataType: "json",
				success : function(data, status, xhr) {

					var result = data.data;
					var dt = result.bbsDetail;
					form.find('input[name=bbsSj]').val(dt.bbsSj);
					form.find('input[name=updtId]').val(dt.updtId);
					form.find('input[name=updtDe]').val(dt.updtDe);
					form.find('textarea[name=bbsCn]').val(dt.bbsCn);

				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		}
		noticeModify.update = function(){
			var dt = {
					bbsSj : form.find('#bbsSj').val(),
					bbsCn : form.find('#bbsCn').val()
				}
			if(commUtil.isBlank(dt.bbsSj)){
				alert('제목을 입력하세요.');return;
			}
			if(commUtil.isBlank(dt.bbsCn)){
				alert('내용을 입력하세요.');return;
			}
			if(confirm('공지사항을 수정 하시겠습니까?')){
				$.ajax({
					type:'PUT',
					url :  _CONSTANTS["URL_BASE"]+ 'bbs/notice/'+param.bbsNo,
					contentType: 'application/json; charset=utf-8',
					data:JSON.stringify(dt),
					dataType:'json',
					success:function(data,status,xhr){
						if(data.code=='success'){
							location.href='./noticeDetail.html?'+commAjax.getQueryString();
						}
					}
				});
			}
		}
		/****************************************************************************************************/
		/** @END Method Definition */

		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			noticeModify.init();
			$('#noticeModBtn0101').on('click',function(evt){
				noticeModify.update();
			});
			$('#noticeModBtn0103').on('click',function(evt){
				location.href= './noticeDetail.html?'+commAjax.getQueryString();
			});

		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});