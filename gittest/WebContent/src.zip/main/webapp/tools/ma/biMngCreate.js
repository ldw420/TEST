/**
 * TITLE : DLSP
 * DESC : 시스템관리 - Tableau 레포트 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var biMng = function() {};

head.ready(function () {
	
	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}
	
	var action = commAjax.getParameter("action");
	var sn = commAjax.getParameter("sn");
	
	(function($) { "use strict";
	
		/** @START Method Definition
		/****************************************************************************************************/	
		// This Page Initialize
		biMng.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(7);
			commForm.getComnNmNew("00001", "usrEmail");
			commForm.getComnCdNew("00003", "ctg");
			commForm.getComnCdNew("sk004", "copm");
		};
		
		biMng.creatUser=function(param) {
			
			var userId = $('#usrId').val()+$('#usrEmail').val()
			
			param = {
					"rownum":0, 
					"sn":0, 
					//"userId":userId,
					"biRepSj":$('#repSj').val(), 
					"copm":$('#copm').val(), 
					"shrUrl":$('#shrUrl').val(),   
					"shrAt":$('#shrAt').val(),
					"useAt":$('#useAt').val(),
					"imgUrl":$('#imgUrl').val(),
					"ctg":$('#ctg').val(),
					"cn":$('#cn').val(),
					"updtId":'',
					"updtDe":'',
					"registerId":'',
					"registDe":''
					}
				
			$.ajax({
				type: "POST",
				url : _CONSTANTS["URL_BASE"]+"bi",
				data: JSON.stringify(param),
				contentType: 'application/json',
				async: true,	
				success : function(data, status, xhr) {

					alert("정상적으로 등록 되었습니다.");
					//$("#frmWinbi")[0].reset();
					location.href = "./biMng.html";
	
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("Tableau 등록 중 오류가 발생했습니다.");
				},
				
			});
				
		}
		/****************************************************************************************************/
		/** @END Method Definition */
		
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			biMng.init();	 
			
			//등록
			$("#bn0103").click(function(event) {
			
				var checkBalnk = /^\s+|\s+$/g; //공백만 입력 됐을 경우 return
				if(document.frmbi.usrId.value == '' || document.frmbi.usrId.value.replace(checkBalnk,'') == ''){
				   alert("사용자 ID를 입력하십시오.");
				   document.frmbi.usrId.focus();
				   return false;
				}
				if(document.frmbi.repSj.value == '' || document.frmbi.repSj.value.replace(checkBalnk,'') == ''){
				   alert("레포트 제목을 입력하십시오.");
				   document.frmbi.repSj.focus();
				   return false;
				}
				if(document.frmbi.copm.value == '' || document.frmbi.copm.value.replace(checkBalnk,'') == ''){
				   alert("관계사를 입력하십시오.");
				   document.frmbi.copm.focus();
				   return false;
				}
				if(document.frmbi.shrUrl.value == '' || document.frmbi.shrUrl.value.replace(checkBalnk,'') == ''){
				   alert("공유 URL을 입력하십시오.");
				   document.frmbi.shrUrl.focus();
				   return false;
				}
							
				biMng.creatUser();
			});
			
			//목록
			$("#bn0101").click(function(event) {
				location.href = "./biMng.html";
			});
			
			
			 
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});