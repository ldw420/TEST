/**
 * TITLE : DLSP
 * DESC : 시스템관리 - Tableau 레포트 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var winMenu = function() {};

head.ready(function () {
	
	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}
	

	
	(function($) { "use strict";
	
	var menuId = commAjax.getParameter("p");
	
		/** @START Method Definition
		/****************************************************************************************************/	
		// This Page Initialize
		winMenu.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(6);
			 
			winMenu.authList();
			
			winMenu.list();
		};
		
		winMenu.authList = function() {
			 
			var html = "";
			var chkBoxCnt = "0";
			
			$.ajax({
				type: "GET",
				url : _CONSTANTS["URL_BASE"]+"auth/auth",
				data: "",
				dataType: "json",
				async: true,	
				success : function(data, status, xhr) {
					if (data.code="success") {
						var results = data.data.authList;
						
						$.each(results, function (i) {
							
							if (results[i].useAt=="Y") { 
								if (chkBoxCnt==1) {
									html = html + "<input type='checkbox' id='checkAll' name='' value='"+results[i].authId+"'/>"+results[i].authNm+" <br>";
									chkBoxCnt=0;
								}else {
									html = html + "<input type='checkbox' id='checkAll' name='' value='"+results[i].authId+"'/>"+results[i].authNm+" ";
									chkBoxCnt +=1
								}
								
							}
						});

						$('#chkBox').append(html);
					}else {
						alert("권한 목록 조회 중 오류가 발생했습니다.");
					}
					
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("권한 목록 조회 중 오류가 발생했습니다.");
				}
			});
		};
		
		
		winMenu.list=function(){
			$.ajax({
				type: "GET",
				url :  _CONSTANTS["URL_BASE"]+ 'menu/'+menuId,
				dataType: "json",
				success : function(data, status, xhr) {
			
					var results = data.data.menuDetail;
					var authIdChk = results.authIdChk
					if (authIdChk.indexOf(",") != -1){
						authIdChk = results.authIdChk.split(',')
						$.each(authIdChk, function (i) {
							 $('input:checkbox[id="checkAll"]').each(function() {
							     if(this.value == authIdChk[i]){ //값 비교
							    	 this.checked = true; //checked 처리
							      }
							 })
						})
					}else{
						 $('input:checkbox[id="checkAll"]').each(function() {
						     if(this.value == authIdChk){ //값 비교
						    	 this.checked = true; //checked 처리
						      }
						 })
					}
						
					$('#upperMenuId').val(results.upperMenuId);
					$('#upperMenuName').val(results.upperMenuNm);
					$('#menuId').val(results.menuId);
					$('#menuNm').val(results.menuNm);
					$('#menuUrl').val(results.menuUrl);
					$('#menuDc').val(results.menuDc);
					
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		}
			
		
		winMenu.update=function(menuChkId){

			 var param = {
					 "rownum":0, 
					 "menuSortSn": 0,
					 "useAt": 'Y',
					 "menuId":$('#menuId').val(),
					 "menuNm":$('#menuNm').val(),
					 "authIdChk":menuChkId,
					 "menuUrl":$('#menuUrl').val(),
					 "menuDc":$('#menuDc').val(),
					 "registDe": '',
					 "registerId": '',
				  	 "updtDe":'',
					 "updtId": '',
					 "upperMenuId": $('#upperMenuId').val(),
					 "upperMenuNm": $('#upperMenuName').val(),
					 }
			$.ajax({
				type: "Put",
				url : _CONSTANTS["URL_BASE"]+"menu/"+menuId,
				data: JSON.stringify(param),
				contentType: 'application/json',
				async: true,	
				success : function(data, status, xhr) {
					alert("정상적으로 수정 되었습니다.");
					location.href = "./menuMng.html";
	
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("메뉴 수정 중 오류가 발생했습니다.");
				},
			});
		

		}
		
		/****************************************************************************************************/
		/** @END Method Definition */
		
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			winMenu.init();

			//등록
			$('#btn0101').click(function(){
				var checkBalnk = /^\s+|\s+$/g; //공백만 입력 됐을 경우 return
				if(document.frmwinMenu.menuNm.value == '' || document.frmwinMenu.menuNm.value.replace(checkBalnk,'') == ''){
				   alert("메뉴명을 입력하십시오.");
				   document.frmwinMenu.menuNm.focus();
				   return false;
				}
				
				var menuChkId='';
				
				$('input:checkbox[id=checkAll]').each(function() {
					if($(this).is(':checked'))
						if (menuChkId=="") {
							menuChkId += ($(this).val());
						}else {
							menuChkId += ","+($(this).val());
						}
					});
				
				if(confirm("수정하시겠습니까?")){
					winMenu.update(menuChkId);
				}else{
					return false;
				}
				
			});
		
			//목록
			$('#btn0102').click(function(){
				location.href = "./menuMng.html";
			});
			
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});