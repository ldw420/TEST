/**
 * TITLE : DLSP
 * DESC : 시스템관리 - Q&A 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
head.ready(function () {

	if(typeof jQuery == "undefined") {
		throw new Error("Require jQuery");
	}

	(function($) { "use strict";
		var form,param;
		var qnaRegist = function() {};
		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		qnaRegist.init = function() {
			form = $('#form');
			param = commAjax.getJsonFromQry(location.href);
			qnaRegist.getData();
		}
		qnaRegist.getData = function(){

			$.ajax({
				type: "GET",
				url :  _CONSTANTS["URL_BASE"]+ 'bbs/qna/'+param.bbsNo,
				dataType: "json",
				success : function(data, status, xhr) {

					var result = data.data;
					var dt = result.bbsDetail;
					form.find('input[name=bbsSj]').val(dt.bbsSj);
					form.find('input[name=updtId]').val(dt.updtId);
					form.find('input[name=updtDe]').val(dt.updtDe);
					form.find('textarea[name=bbsCn]').val(dt.bbsCn);

					var ans = result.bbsAnswer;
					if(ans){
						form.find('input[name=bbsAnswerNo]').val(ans.bbsAnswerNo);
						form.find('textarea[name=answerCn]').val(ans.answerCn);
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		}
		qnaRegist.reply = function(){
			var dt = {
				bbsAnswerNo : form.find('#bbsAnswerNo').val(),
				answerCn : form.find('#answerCn').val(),
				bbsNo : param.bbsNo
			};
			if(commUtil.isBlank(dt.answerCn)){
				alert('답변을 입력하세요.');return;
			}
			if(!confirm('답변을 등록 하시겠습니까?')){
				return;
			}
			var json = {
				url : _CONSTANTS["URL_BASE"]+ 'bbs/answer/qna/'+param.bbsNo,
				method:'put',
				dataType: 'json',
				contentType: 'application/json; charset=utf-8',
				data:JSON.stringify(dt),
				success:function(res){
					if(res.code == 'success'){
						location.href= './qnaDetail.html?bbsNo='+param.bbsNo
					}
				}
			};
			if(dt.bbsAnswerNo == ''){
				json.method = 'post';
			}
			$.ajax(json)
		}
		/****************************************************************************************************/
		/** @END Method Definition */

		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			qnaRegist.init();
			$('#qnaDtlBtn0101').on('click',function(evt){
				qnaRegist.reply();
			});
			$('#qnaDtlBtn0103').on('click',function(evt){
				location.href= './qnaDetail.html?'+commAjax.getQueryString();
			});
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});