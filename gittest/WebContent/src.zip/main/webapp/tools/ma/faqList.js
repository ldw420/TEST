/**
 * TITLE : DLSP
 * DESC : 시스템관리 - FQA 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
head.ready(function () {

	if(typeof jQuery == "undefined") {
		throw new Error("Require jQuery");
	}

	(function($) { "use strict";
		var form,param,pagination;
		var faqList = function() {};

		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		faqList.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(8);
			//메뉴 권한 채크
			commUsr.menuAuthCheck();
			
			//좌측 하위 메뉴 활성화
			$(".left_menu_list li a").click();
			
			form = $("#form");
			param = commAjax.getJsonFromQry(location.href);
			form.find('#schBbsSj').val(param.schBbsSj);
			pagination = $('#paging').bootpagEx({ total: 0 }).on("page", function(event, num){ faqList.list(num) });
			faqList.list();
		};
		faqList.list = function(pageNumber){
			var pageNo = commUtil.parseInt(pageNumber,1);
			form.find('#pageNo').val(pageNo)
			var param = form.serialize();

			$.ajax({
				type: "GET",
				url :  _CONSTANTS["URL_BASE"]+ 'bbs/faq',
				data: param,
				dataType: "json",
				async: true,
				success : function(data, status, xhr) {
					if(data.code != 'success'){
						alert('FAQ 조회 중 에러가 발생하였습니다.');return;
					}
					var html = '';
					var tbody = $('#tbFaq tbody').html('');
					var results = data.data.bbsList;

					$.each(results, function (i) {
						var p = results[i].bbsNo+'&'+param;
						var vo = results[i];
						html += "<tr>";
						html += "<td>"+vo.rownum+"</td>";
						html += "<td><a href=./faqDetail.html?bbsNo="+p+">"+ vo.bbsSj +"</a></td>";
						html += "<td>"+ vo.registerId +"</td>";
						html += "<td>"+ vo.registDe +"</td>";
						html += "</tr>";
					});

					tbody.append(html);
					var pageCnt = parseInt(data.data.bbsListCount / 10) + 1;
					pagination.bootpagEx({
			        	total: pageCnt,
			        	page : pageNo
			        });
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		}
		/****************************************************************************************************/
		/** @END Method Definition */

		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			faqList.init();
			$("#btn0101").on('click',function(evt){
				faqList.list();
			})
			// FAQ게시판 등록창 열기
			$("#btn0104").click(function(event) {
				location.href = "./faqRegist.html?"+form.serialize()
			});

		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});