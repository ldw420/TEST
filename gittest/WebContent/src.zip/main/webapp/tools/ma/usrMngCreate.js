/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 사용자관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var usrMng = function() {};

head.ready(function () {
	
	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}
	
	var action = commAjax.getParameter("action");
	var usrId = commAjax.getParameter("usrId");
	
	(function($) { "use strict";
	
		/** @START Method Definition
		/****************************************************************************************************/	
		// This Page Initialize
		usrMng.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(1);
			
			usrMng.authList();
			commForm.getComnNmNew("00001", "usrEmail");
			//관계사
			commForm.getComnCdNew("sk004", "agency");
		};
		
		usrMng.authList = function() {
			 
			var option = ""; 
			
			$.ajax({
				type: "GET",
				url : _CONSTANTS["URL_BASE"]+"auth/auth",
				data: "",
				dataType: "json",
				async: true,	
				success : function(data, status, xhr) {
					if (data.code="success") {
						var results = data.data.authList; 
						
						$.each(results, function (i) {
							
							if (results[i].useAt=="Y") {   
								$("#usrAuth").append("<option value='"+results[i].authId+"'>"+results[i].authNm+"</option>");
							}
						});  
					}else {
						alert("권한 목록 조회 중 오류가 발생했습니다.");
					}
					
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("권한 목록 조회 중 오류가 발생했습니다.");
				}
			});
		};
		
		usrMng.creatUser=function(param) {
			var cttpc='';
			usrId = $('#emailId').val()+$('#usrEmail').val()
			cttpc = $('#hpNo1').val()+$('#hpNo2').val()+$('#hpNo3').val();
			
			param = {
					"rownum":0, 
					"usrId":usrId, 
					"nm":$('#usrNm').val(), 
					"pw":$('#pwd').val(),
					"agency":$('#agency').val(), 
					"authId":$('#usrAuth').val(), 
					"cttpc":cttpc,  
					"accessKeyId" : $('#accessKeyId').val(),
					"secretAccessKey" : $('#secretAccessKey').val(),
					"updtId":'',
					"updtDe":'',
					"registerId":'',
					"registDe":'',
					"pdeConfmDe":''
					}

				$.ajax({
					type: "POST",
					url : _CONSTANTS["URL_BASE"]+"user",
					data: JSON.stringify(param),
					contentType: 'application/json',
					async: true,	
					success : function(data, status, xhr) {
						alert("정상적으로 등록 되었습니다.");
						location.href = "./usrMng.html";
		
					},
					error: function(jqXHR, textStatus, errorThrown) {
						alert("사용자 등록 중 오류가 발생했습니다.");
					},
					
				});
		}
		/****************************************************************************************************/
		/** @END Method Definition */
		
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			usrMng.init();	 
			
			//등록
			$("#btn0103").click(function(event) {
			
				var checkBalnk = /^\s+|\s+$/g; //공백만 입력 됐을 경우 return
				if(document.frmWinUsr.emailId.value == '' || document.frmWinUsr.emailId.value.replace(checkBalnk,'') == ''){
				   alert("사용자 ID를 입력하십시오.");
				   document.frmWinUsr.emailId.focus();
				   return false;
				} 
			
				if(document.frmWinUsr.usrNm.value == '' || document.frmWinUsr.usrNm.value.replace(checkBalnk,'') == ''){
				   alert("사용자 이름을 입력하십시오.");
				   document.frmWinUsr.usrNm.focus();
				   return false;
				} 
				
				if(document.frmWinUsr.pwd.value == '' || document.frmWinUsr.pwd.value.replace(checkBalnk,'') == ''){
				   alert("비밀번호를 입력하십시오.");
				   document.frmWinUsr.pwd.focus();
				   return false;
				} 
				
				if(document.frmWinUsr.pwdCfm.value == '' || document.frmWinUsr.pwdCfm.value.replace(checkBalnk,'') == ''){
				   alert("비밀번호 확인을 입력하십시오.");
				   document.frmWinUsr.pwdCfm.focus();
				   return false;
				} 
				
				if (document.frmWinUsr.pwd.value != document.frmWinUsr.pwdCfm.value) {
					alert("비밀번호가 일치 하지 않습니다.");
					document.frmWinUsr.pwd.value="";
					document.frmWinUsr.pwdCfm.value="";
					return false;
					
				}
				
				
				if(document.frmWinUsr.agency.value == ''){
					   alert("관계사를 선택하세요."); 
					   return false;
					} 
							
				usrMng.creatUser();
			});
			
			//목록
			$("#btn0101").click(function(event) {
				location.href = "./usrMng.html";
			});
			
			
			 
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});