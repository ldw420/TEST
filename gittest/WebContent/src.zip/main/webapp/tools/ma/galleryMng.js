/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 메뉴 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
head.ready(function () {
	
	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}
	
	(function($) { "use strict";
	
		var galleryMng = function() {};	

		
		/** @START Method Definition
		/****************************************************************************************************/	
		// This Page Initialize
		galleryMng.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(14);
			//메뉴 권한 채크
			commUsr.menuAuthCheck();
			
			galleryMng.setDnd();
			galleryMng.getGalleryData();
		};
		
		// setup dnd
		galleryMng.setDnd = function() {
			// 왼쪽
			$("#mappingSortable").sortable({
				forceHelperSize: true,
				opacity: 0.7,
				connectWith: ".connectedSortable",
				tolerance:"pointer",
				receive: function(event, ui) {
					$(ui.item).css("width", galleryMng.caclMappindgWidthPercent($("#splitCount").val()) + "%");
		        	$(ui.item).find(".image img").height(($("#mappingSortable").width() / 3) - ($("#mappingSortable").width() / 50));
//		        	$img.height($img.width());
				},
			}).disableSelection();
			
			// 오른쪽
			$("#cardSortable").sortable({
				forceHelperSize: true,
				opacity: 1,
				classes: {
					"ui-sortable": "highlight"
				},
				connectWith: ".connectedSortable",
				tolerance:"pointer",
				receive: function(event, ui) {
					$(ui.item).css("width", "");
				},
				start: function(event, ui) {
		        },
			}).disableSelection();
		};
		
		galleryMng.getGalleryData = function() {
			$.ajax({
				type: "POST",
				url : _CONSTANTS["URL_BASE"] + "gallery/list",
				//url : "/gallery/list",
				contentType: 'application/json',
				data: JSON.stringify({
					getMappingData: false
				}),
				dataType: "json",
				async: true,
				success : function(data, status, xhr) {
					if(data.code == "success") {
						var galleryList = data.data ? data.data["galleryList"] : null;
						
						galleryMng.setGalleryData(galleryList);
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		}
		
		galleryMng.setGalleryData = function(dataList) {
			//window.galleryList = dataList;
			
			var leftList = [];
			var rightList = [];
			
			if(dataList) {
				for(var i in dataList) {
					if(dataList[i].orderByIndex === 0) {
						rightList.push(dataList[i]);
					} else {
						leftList.push(dataList[i]);
					}
				}
				
				if(leftList && leftList.length > 0) {
					leftList.sort(function (a, b) { 
						return a.orderByIndex < b.orderByIndex ? -1 : a.orderByIndex > b.orderByIndex ? 1 : 0;  
					});
				}
				
				if(rightList && rightList.length > 0) {
					rightList.sort(function (a, b) { 
						return a.biRepSj < b.biRepSj ? -1 : a.biRepSj > b.biRepSj ? 1 : 0;  
					});
				}
			}
			
			$("#mappingSortable").empty().append(galleryMng.createCard(leftList));
			var height = ($("#mappingSortable").width() / 3) - ($("#mappingSortable").width() / 50);
			$("#mappingSortable span img").each(function() {
				$(this).height(height);
			});
			$("#cardSortable").empty().append(galleryMng.createCard(rightList));
		}
		
		galleryMng.createCard = function(dataList) {
			var cardHtml = '';
			if(dataList) {
				for(var i in dataList) {
					cardHtml += '<span type="card" data-wid="' + dataList[i].wid + '" data-vid="' + dataList[i].vid + '" data-title="' + dataList[i].biRepSj + '" class="ui-state-default item card" data-image-name="' + dataList[i].imgName + '" style="cursor: move;">' +
					 '	<div class="title">' + dataList[i].biRepSj + '</div>' +
					 '	<div class="image">' +
					 '		<img src="' + _CONSTANTS["URL_BASE"] + 'gallery/show-image?imageName=' + dataList[i].imgName + '"/>' +
					 '	</div>' +
					 '</span>';
				}
			}
			
			return cardHtml;
		}
		
		galleryMng.caclMappindgWidthPercent = function(count) {
			var count = 3;
			return (100 - 1.07 * count) / count;
		}
		
		galleryMng.saveData = function() {
			if(confirm("저장 하시겠습니까?")) {
				
				var dataList = [];
				var idx = 1;
				$("#mappingSortable .card").each(function(i) {
					dataList.push({
						wid: $(this).data("wid"),
						vid: $(this).data("vid"),
						orderByIndex: idx++
					});
				});
				
				
				// loading 이미지 있으면 띄워주기.
				
				
				$.ajax({
					type: "POST",
					url : _CONSTANTS["URL_BASE"] + "gallery/manage/update-mapping",
					//url : "/gallery/manage/update-mapping",
					contentType: 'application/json',
					data: JSON.stringify({
						galleryList: dataList
					}),
					dataType: "json",
					async: true,
					success : function(data, status, xhr) {
						if(data.code == "success") {
							alert("저장 성공");
						}
					},
					error: function(jqXHR, textStatus, errorThrown) {
						alert(errorThrown);
					}
				});
			}
		}
		
		galleryMng.refreshGalleryData = function() {
			if(confirm('동기화 하시겠습니까?\r\n데이터 양에 따라 1-10분 정도 소요됩니다')) {
				
				
				// loading 이미지 있으면 띄워주기.
				
				
				$.ajax({
					type: "GET",
					url : _CONSTANTS["URL_BASE"] + "gallery/refresh",
					//url : "/gallery/refresh",
					contentType: 'application/json',
					dataType: "json",
					async: true,
					success : function(data, status, xhr) {
						if(data.code == "success") {
							location.reload();
						}
					},
					error: function(jqXHR, textStatus, errorThrown) {
						alert(errorThrown);
					}
				});
			}
		}
		
 
		/****************************************************************************************************/
		/** @END Method Definition */
	
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			galleryMng.init();
			
			$("#btnSave").click(galleryMng.saveData);
			$("#btnRefresh").click(galleryMng.refreshGalleryData);
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});