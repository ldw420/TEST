/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 서약서 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
head.ready(function () {
	
	if(typeof jQuery == "undefined") {
		throw new Error("Require jQuery");
	}

	var sn = commAjax.getParameter("sn");
	
	(function($) { "use strict";
		
		var pdeDetail = function() {};
		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		pdeDetail.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(5);
			
			pdeDetail.pde(sn);
		}
		
		pdeDetail.pde = function(sn) {
			$.ajax({
				type: "GET",
				url : _CONSTANTS["URL_BASE"]+"pde/pde/"+sn,
				data: "",
				dataType: "json",
				async: true,	
				success : function(data, status, xhr) {
					if (data.code="success") {
						var results = data.data.pdeList;
						 
						$('#registerId').append(results[0].registerId); 
						$('#registDe').append(results[0].registDe); 
						$('#cn').append(results[0].cn); 

					}else {
						alert("서약서 상세  조회 중 오류가 발생했습니다.");
					}
					
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("서약서 상세 조회 중 오류가 발생했습니다.");
				}
			});
		}; 
		 
		/****************************************************************************************************/
		/** @END Method Definition */
		
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			 
			pdeDetail.init();
			
			// 서약서 목록으로 이동
			$("#pdeDtlBtn0103").click(function(event) {
				location.href = "./pdeList.html";
			});
			
 
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});