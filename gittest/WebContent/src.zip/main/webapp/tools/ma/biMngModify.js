/**
 * TITLE : DLSP
 * DESC : 시스템관리 - Tableau 레포트 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var biMng = function() {};

head.ready(function () {
	
	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}
	

	
	(function($) { "use strict";
	
	var action = commAjax.getParameter("action");
	var sn = commAjax.getParameter("sn");
	
		/** @START Method Definition
		/****************************************************************************************************/	
		// This Page Initialize
		biMng.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(7);
			
			commForm.getComnCdNew("00003", "ctg");
			commForm.getComnCdNew("sk004", "copm");
			commForm.getComnCdNew("00002", "useAt");
			biMng.modify();
		};
		
		biMng.modify=function(){
			
			$.ajax({
				type: "GET",
				url :  _CONSTANTS["URL_BASE"]+ 'bi/'+sn,
				dataType: "json",
				async: false,
				success : function(data, status, xhr) {

					var results = data.data.biDetail;
					
					$('#usrId').text(results.userId);
					$('#repSj').val(results.biRepSj);
					$('#copm').val(results.copm);
					$('#shrURL').val(results.shrUrl);
					$('#shrAt').val(results.shrAt);
					$('#useAt').val(results.useAt);
					$('#imgUrl').val(results.imgUrl);
					$('#ctg').val(results.ctg);
					$('#cn').val(results.cn);
					$('#biSpa0105').val(results.updtDe);
					$('#updtId').text($.cookie("sessionUsrId"));
					
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
	
		}
		
		biMng.update=function(){
		
			var param = {
						"rownum":0, 
						"sn":0, 
						"userId":$('#usrId').text(),
						"biRepSj":$('#repSj').val(), 
						"copm":$('#copm').val(), 
						"shrUrl":$('#shrURL').val(),   
						"shrAt":$('#shrAt').val(),
						"useAt":$('#useAt').val(),
						"imgUrl":$('#imgUrl').val(),
						"ctg":$('#ctg').val(),
						"cn":$('#cn').val(),
						"updtId":'',
						"updtDe":'',
						"registerId":'',
						"registDe":''
					}

			$.ajax({
				type: "Put",
				url : _CONSTANTS["URL_BASE"]+"bi/"+sn,
				data: JSON.stringify(param),
				contentType: 'application/json',
				async: true,	
				success : function(data, status, xhr) {
					alert("정상적으로 수정 되었습니다.");
					location.href = "./biMng.html";
	
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("Tableau 수정 중 오류가 발생했습니다.");
				},
			});
		

		}
		
		biMng.delete=function(){
			$.ajax({
				type: "Delete",
				url : _CONSTANTS["URL_BASE"]+"bi/"+sn,
				data: "",
				contentType: 'application/json',
				async: true,	
				success : function(data, status, xhr) {
					
					alert("정상적으로 삭제 되었습니다.");
					location.href = "./biMng.html";
	
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("Tableau 삭제 중 오류가 발생했습니다.");
				},
			});
		}
		
		 
		/****************************************************************************************************/
		/** @END Method Definition */
		
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			biMng.init();

			//등록
			$('#btn0103').click(function(){
				var checkBalnk = /^\s+|\s+$/g; //공백만 입력 됐을 경우 return
				if(document.frmbi.repSj.value == '' || document.frmbi.repSj.value.replace(checkBalnk,'') == ''){
				   alert("레포트명을 입력하십시오.");
				   document.frmbi.repSj.focus();
				   return false;
				}
				
				if(document.frmbi.copm.value == '' || document.frmbi.copm.value.replace(checkBalnk,'') == ''){
					   alert("관계사를 입력하십시오.");
					   document.frmbi.copm.focus();
					   return false;
					}
				
				
				if(confirm("저장하시겠습니까?")){
					biMng.update();
				}else{
					return false;
				}
				
			});
			
			//삭제
			$('#btn0104').click(function(){
				if(confirm("Tableau를 삭제하시겠습니까?")){
					biMng.delete();
				}else{
					return false;
				}
			});
			
			//이전
			$('#btn0105').click(function(){
				history.go(-1)
			});
			
			//목록
			$('#btn0101').click(function(){
				location.href = "./biMng.html";
			});
			
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});