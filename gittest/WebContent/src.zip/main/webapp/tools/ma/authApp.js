/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 권한관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var authApp = function() {};

head.ready(function () {
	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}

	(function($) { "use strict";

	var form,param,pagination;

		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		authApp.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(13);

			//메뉴 권한 채크
			commUsr.menuAuthCheck();
			//요청상태
			commForm.getComnCdNew("00002", "schConfmSttus");
			
			//관계사 정보
			commForm.getComnCdNew("sk004", "schAgency");


			form = $("#form");
			param = commAjax.getJsonFromQry(location.href);
			form.find('#schBbsSj').val(param.schBbsSj);
			pagination = $('#paging').bootpagEx({ total: 0 }).on("page", function(event, num){ authApp.authAppList(num) });


			authApp.authAppList();
		};

		authApp.authAppList = function(pageNumber) {

			var pageNo = commUtil.parseInt(pageNumber,1);
			form.find('#pageNo').val(pageNo);
			var param = form.serialize();



			var html = '';
			$('#tbodyArea').find('tr').remove();

			$.ajax({
				type: "GET",
				url : _CONSTANTS["URL_BASE"]+"authApp/authApp",
				data: param,
				dataType: "json",
				async: true,
				success : function(data, status, xhr) {
					if (data.code="success") {
						var results = data.data.authAppList;

						$.each(results, function (i) {

							html += "<tr>";
							if (results[i].confmSttus == "00002") {
								html += "<td>승인 완료</td>";
							}else if (results[i].confmSttus == "00003") {
								html += "<td>반려</td>";
							} else {
							
								html += "<td><input type='checkbox' name='authChk' value='"+ results[i].sn +"'></td>";
							}
							html += "<td>"+ results[i].usrId +"</td>";
							html += "<td>"+ results[i].agency +"</td>";
							html += "<td>"+ results[i].authId +"</td>";
							html += "<td>"+ results[i].confmSttusNm +"</td>";
							html += "<td>"+ results[i].appDe +"</td>";
							html += "<td>"+ results[i].confmId +"</td>";
							html += "<td>"+ results[i].confmDe +"</td>";
							html += "</tr>";
						});

						$('#tbodyArea').append(html);
					}else {
						alert("권한 요청 목록 조회 중 오류가 발생했습니다.");
					}
					
					

					var pageCnt = Math.ceil(data.data.authAppListCount / 10);
					pagination.bootpagEx({
			        	total: pageCnt,
			        	page : pageNo
			        });

				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("권한 목록 조회 중 오류가 발생했습니다.");
				}
			});
		};

		authApp.confmOk = function(chkSn) {
			$.ajax({
				type: "Put",
				url : _CONSTANTS["URL_BASE"]+"authApp/confmOk/"+chkSn,
				data: "",
				dataType: "json",
				async: true,
				success : function(data, status, xhr) {
					if (data.code="success") {
						 alert("승인이 정상적으로 처리되었습니다.");
						 authApp.authAppList();
					}else {
						alert("승인 처리 중 오류가 발생했습니다.");
						return
					}

				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("승인 처리 중 오류가 발생했습니다.");
					return
				}
			});


		};

		authApp.confmNo = function(chkSn) {
			$.ajax({
				type: "Put",
				url : _CONSTANTS["URL_BASE"]+"authApp/confmNo/"+chkSn,
				data: "",
				dataType: "json",
				async: true,
				success : function(data, status, xhr) {
					if (data.code="success") {
						 alert("반려가 정상적으로 처리되었습니다.");
						 authApp.authAppList();
					}else {
						alert("반려  처리 중 오류가 발생했습니다.");
					}

				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("반려 처리 중 오류가 발생했습니다.");
				}
			});


		};




		/****************************************************************************************************/
		/** @END Method Definition */



		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			authApp.init();
			//검색
			$("#btn0101").click(function() {
				authApp.authAppList();
			});

			// 반려
			$("#btn0104").click(function() {
				var chkSn="";
				$('input:checkbox[name=authChk]').each(function() {
			         if($(this).is(':checked'))
			        	 if (chkSn=="") {
			        		 chkSn += ($(this).val());
			        	 }else {
			        		 chkSn += ","+($(this).val());
			        	 }

			      });
				if (chkSn=="") {
					alert("반려 처리 할 사용자를 선택하세요!");
					return false;
				}
				if(confirm("선택한 사용자를 반려처리하시겠습니까?")) {
					authApp.confmNo(chkSn);
				} else {
					return false;
				}
			});

			// 승인 사용
			$("#btn0105").click(function() {
				var chkSn="";
				$('input:checkbox[name=authChk]').each(function() {
			         if($(this).is(':checked'))
			        	 if (chkSn=="") {
			        		 chkSn += ($(this).val());
			        	 }else {
			        		 chkSn += ","+($(this).val());
			        	 }
			      });
				if (chkSn=="") {
					alert("승인처리 할 사용자을 선택하세요!");
					return false;
				}
				if(confirm("선택한 사용자를 승인 처리하시겠습니까?")) {
					authApp.confmOk(chkSn);
				} else {
					return false;
				}
			});



			$("#checkAll").click(function() {
				//클릭되었으면
		        if($("#checkAll").prop("checked")){
		            //input태그의 name이 chk인 태그들을 찾아서 checked옵션을 true로 정의
		            $("input[name=authChk]").prop("checked",true);
		            //클릭이 안되있으면
		        }else{
		            //input태그의 name이 chk인 태그들을 찾아서 checked옵션을 false로 정의
		            $("input[name=authChk]").prop("checked",false);
		        }
			});




		});
		/****************************************************************************************************/
		/** @END Page Initialize */

	}(jQuery));
});