/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 코드관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var comnCdMng = function() {};

head.ready(function () {
	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}
	
	(function($) { "use strict";
		
		/** @START Method Definition
		/****************************************************************************************************/	
		// This Page Initialize
		comnCdMng.init = function() {
			//좌측 메뉴 선택
			commUsr.leftMenuSel(0);
			
			//메뉴 권한 채크
			commUsr.menuAuthCheck();
			
			//상위 코드 목록 조회
			comnCdMng.groupList();
			
		};
 
		// 공통코드 및 상세코드 등록 열기 
		comnCdMng.openWinComnCd = function(action, comnCdEngNm) {
			
			//상세코드 열기
			if (comnCdEngNm == "detail"){
				
				var codeChkId='';
				
				$('input:checkbox[name=codeChk]').each(function() {
				if($(this).is(':checked'))
					if (codeChkId=="") {
						codeChkId += ($(this).val());
					}else {
						codeChkId += ","+($(this).val());
					}
			    }); 
				
				if (codeChkId==""){
					alert("공통코드를 선택해 주세요.")
					return false;
				}
				if (codeChkId.indexOf(",") > -1){
					alert("공통코드를 하나만 선택해 주세요.")
					return false;
				}
				
				window.open("/admin/modal/window/winComnCdVal.html?param="+codeChkId,  "popupNo1", "width=600, height=460");
				
				
			//공통코드 열기
			}else{
				window.open("/admin/modal/window/winComnCd.html",  "popupNo1", "width=600, height=360");	
			}
			
		};
		
		comnCdMng.groupList = function() {
			var html = '';
			$('#tbodyArea').find('tr').remove(); 

			let param = $('#frm01').serialize();
			
			
			$.ajax({
				type: "Get",
				url : _CONSTANTS["URL_BASE"]+"code/group",
				data: param,
				dataType: "json",
				success : function(data, status, xhr) {

					if (data.code=="success") {
						
						var results = data.data.codeGroupList
					
						$.each(results, function (i) {
						
							var paramCode = "'"+results[i].groupCodeId+"'";
							
							html += "<tr style='cursor:pointer;' onClick=javascript:comnCdMng.list("+paramCode+");>";						
							html += "<td onClick='event.cancelBubble=true'><input type='checkbox' name='codeChk' value='"+ results[i].groupCodeId +"' onclick=commForm.nonCheck('checkAll','codeChk');></td>";
							html += "<td>"+ results[i].groupCodeId +"</td>";
							html += "<td>"+ results[i].groupCodeNm +"</td>";
							html += "<td>"+ results[i].useAt +"</td>";
							html += "<td>"+ results[i].registerId +"</td>"; 
							html += "<td>"+ results[i].registDe +"</td>";
							html += "</tr>";
						});
	
						$('#tbodyArea').append(html);
						
					}else{
						alert("공통 코드 목록 조회 중 오류가 발생했습니다.");
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		};


		
		//상세 코드 목록
		comnCdMng.list = function(code) {

			var html = '';
			var p = '';
			
			$('#grpCode').val(code);
			
			$("#deCode").attr("readonly",false);
			$("#deCode").val("");
			$("#deName").val("");
			$("#deDec").val("");
			$("#useYn").val("");
			$("#changeButton1").css("display","");
			$("#changeButton2").css("display","none");
 
			$.ajax({
				type: "GET",
				url : _CONSTANTS["URL_BASE"]+"code/detail/"+code,
				data: "",
				dataType: "json",
				success : function(data, status, xhr) {
					
					if (data.code=="success") {
						
						var results = data.data.codeDetailList;
						
						$.each(results, function (i) {
							
							//코드,코드명,설명,사용여부,상위코드
							p = "'"+results[i].detailCodeId+","+results[i].detailCodeNm.replace(" ","&nbsp")+","+results[i].detailCodeDc.replace(" ","&nbsp")+","+results[i].useAt+","+code+"'"
							
																		
							html += "<tr onclick=valAdd("+p+")>";						
							html += "<td><input type='checkbox' name='codeDeChk' value='"+ results[i].detailCodeId +"' onclick=commForm.nonCheck('checkAll2','codeDeChk');></td>";
							html += "<td>"+ results[i].groupCodeNm +"</td>";
							html += "<td>"+ results[i].detailCodeId +"</td>";
							html += "<td>"+ results[i].detailCodeNm +"</td>";
							html += "<td>"+ results[i].useAt +"</td>";
							html += "<td>"+ results[i].registerId +"</td>";
							html += "<td>"+ results[i].registDe +"</td>";
							html += "</tr>";
							
						});
	
						$('#tbodyArea2').empty().append(html);
						
					}else{
						alert("공통 코드 상세 목록 조회 중 오류가 발생했습니다.");
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		};
		
		comnCdMng.delete = function(codeChkId) {
			$.ajax({
				type: "Delete",
				url : _CONSTANTS["URL_BASE"]+"code/group/"+codeChkId,
				data: "",
				dataType: "json",
				success : function(data, status, xhr) {
					if (data.code=="success") {
						comnCdMng.groupList();
					}else{
						alert("공통 코드를 삭제 중 오류가 발생했습니다.");
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		}
		
		comnCdMng.detailDelete = function(codeChkId) {
			$.ajax({
				type: "Delete",
				url : _CONSTANTS["URL_BASE"]+"code/detail/"+codeChkId+"/"+$('#grpCode').val(),
				data: "",
				dataType: "json",
				success : function(data, status, xhr) {
					if (data.code=="success") {
						alert("정상적으로 삭제 되었습니다.");
						//$("#deCode").attr("readonly",false);
						comnCdMng.list($('#grpCode').val());
					}else{
						alert("상세 코드를 삭제 중 오류가 발생했습니다.");
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		}
		
		// 상세코드 등록
		comnCdMng.createComnCd = function() {
			
			param = {
					"detailCodeDc":$('#deDec').val(), 
					"detailCodeId":$('#deCode').val(), 
					"detailCodeNm":$('#deName').val(), 
					"detailCodeOrdr":0, 
					"groupCodeDc":'', 
					"groupCodeId":$('#hidRootCode').val(), 
					"groupCodeNm":'', 
					"registDe":'', 
					"registerId":'', 
					"updtDe":'', 
					"updtId":'', 
					"useAt":$('#useYn').val()
					}

			$.ajax({
				type: "POST",
				url : _CONSTANTS["URL_BASE"]+"code/detail",
				data: JSON.stringify(param),
				contentType: 'application/json',
				success : function(data, status, xhr) {
		
					if (data.code=="success") {
						alert("정상적으로 등록 되었습니다.");
						comnCdMng.list($('#hidRootCode').val());
						$("#deCode").val("");
						$("#deName").val("");
						$("#deDec").val("");
						$("#useYn").val("");
						 
						//window.close();
					}else {
						alert("상세 코드 등록 중 오류가 발생했습니다.");
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("상세 코드 등록 중 오류가 발생했습니다.");
				},	
			});
		};
		
		
		// 상세코드 수정
		comnCdMng.updateComnCd = function() {
			
			param = {
					"detailCodeDc":$('#deDec').val(), 
					"detailCodeId":$('#deCode').val(), 
					"detailCodeNm":$('#deName').val(), 
					"groupCodeId":$('#hidRootCode').val(), 
					"useAt":$('#useYn').val()
					}
			
			$.ajax({
				type: "put",
				url : _CONSTANTS["URL_BASE"]+"code/update",
				data: JSON.stringify(param),
				contentType: 'application/json',
				success : function(data, status, xhr) {
		
					if (data.code=="success") {
						alert("정상적으로 수정 되었습니다.");
						comnCdMng.list($('#hidRootCode').val());
						$("#deCode").val("");
						$("#deName").val("");
						$("#deDec").val("");
						$("#useYn").val("");
						 
						$("#deCode").attr("readonly",false);
 
					}else {
						alert("상세 코드 수정 중 오류가 발생했습니다.");
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("상세 코드 수정 중 오류가 발생했습니다.");
				},	
			});
		};
		

		
		/****************************************************************************************************/
		/** @END Method Definition */
		
		
		comnCdMng.selComnCdEngNm = "";
	
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			comnCdMng.init();
			
			// 공통목록 조회
			$("#btn0101").click(function() {
				comnCdMng.groupList();
			});
			
			// 공통코드 등록
			$("#btn0103").click(function(event) {
				comnCdMng.openWinComnCd("PUT");
			});
			
			// 공통코드 삭제
			$("#btn0104").click(function() {
				var codeChkId="";
				$('input:checkbox[name=codeChk]').each(function() {
			         if($(this).is(':checked'))
			        	 if (codeChkId=="") {
			        		 codeChkId += ($(this).val());
			        	 }else {
			        		 codeChkId += ","+($(this).val());
			        	 } 
			      }); 
				
				if (codeChkId==""){
					alert("공통 코드를 선택해 주세요.");
					return false;
				}
				
				if(confirm("공통 코드를 삭제 처리하시겠습니까?")) {
					comnCdMng.delete(codeChkId);
				}else{
					return false;
				}
					
			});
	
			// 상세코드값 수정
			$(document).on("click","#btn0107",function(){
 
				var checkBalnk = /^\s+|\s+$/g; //공백만 입력 됐을 경우 return
				if($("#deCode").val() == '' || $("#deCode").val() == ''){
				   alert("상세코드를 입력하십시오.");
				   $("#deCode").focus();
				   return false;
				} 
 
				if($("#deName").val() == '' || $("#deName").val().replace(checkBalnk,'') == ''){
				   alert("상세코드 명칭을 입력하십시오.");
				   $("#deName").focus();
				   return false;
				} 
				
				if(confirm("상세코드를 수정하겠습니까?")) {
					comnCdMng.updateComnCd();
				} else {
					return false;
				}
				
			});
			
			
			// 상세코드값 등록
			$(document).on("click","#btn0105",function(){ 
				var codeChkId="";
				$('input:checkbox[name=codeChk]').each(function() {
			         if($(this).is(':checked'))
			        	 if (codeChkId=="") {
			        		 codeChkId += ($(this).val());
			        	 }else {
			        		 codeChkId += ","+($(this).val());
			        	 } 
			      }); 
				
				if (codeChkId==""){
					alert("공통 코드를 선택해 주세요.");
					return false;
				}
				
				$("#hidRootCode").val(codeChkId);
				
				var checkBalnk = /^\s+|\s+$/g; //공백만 입력 됐을 경우 return
				if($("#deCode").val() == '' || $("#deCode").val() == ''){
				   alert("상세코드를 입력하십시오.");
				   $("#deCode").focus();
				   return false;
				} 
				

				
				if($("#deName").val() == '' || $("#deName").val().replace(checkBalnk,'') == ''){
				   alert("상세코드 명칭을 입력하십시오.");
				   $("#deName").focus();
				   return false;
				} 
				
				if(confirm("새로운 상세코드를 추가하겠습니까?")) {
					comnCdMng.createComnCd();
				} else {
					return false;
				}
				
			});
			
			// 상세코드 삭제
			$(document).on("click","#btn0106",function(){
				var codeChkId="";
				$('input:checkbox[name=codeDeChk]').each(function() {
			         if($(this).is(':checked'))
			        	 if (codeChkId=="") {
			        		 codeChkId += ($(this).val());
			        	 }else {
			        		 codeChkId += ","+($(this).val());
			        	 }
			      }); 
				
				if (codeChkId==""){
					alert("상세 코드를 선택해 주세요.");
					return false;
				}
				
				if(confirm("상세 코드를 삭제 처리하시겠습니까?")) {
					comnCdMng.detailDelete(codeChkId);
				}else{
					return false;
				}
			});
			
			//수정
			$(document).on("click","#btn0107",function(){
				//alert("작업중")
			});
			
			//초기화
			$(document).on("click","#btn0108",function(){
				$("#deCode").val("");
				$("#deName").val("");
				$("#deDec").val("");
				$("#useYn").val("");
				$("#changeButton1").css("display","");
				$("#changeButton2").css("display","none");
				$("#deCode").attr("readonly",false);
			});
			
			//체크박스 | ALL 체크(공통코드)
			commForm.checkScript('checkAll',"codeChk");
			
			//체크박스 | ALL 체크(상세코드)
			commForm.checkScript('checkAll2',"codeDeChk");
			
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	
	}(jQuery));
});