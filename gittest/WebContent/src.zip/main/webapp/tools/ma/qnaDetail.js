/**
 * TITLE : DLSP
 * DESC : 시스템관리 - Q&A 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
head.ready(function () {

	if(typeof jQuery == "undefined") {
		throw new Error("Require jQuery");
	}

	(function($) { "use strict";
		var form,param;
		var qnaDetail = function() {};
		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		qnaDetail.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(8);
			//좌측 하위 메뉴 활성화
			$(".left_menu_list li a").click();
			
			form = $('#form');
			param = commAjax.getJsonFromQry(location.href);
			qnaDetail.getData();
		}
		qnaDetail.getData = function(){

			$.ajax({
				type: "GET",
				url :  _CONSTANTS["URL_BASE"]+ 'bbs/qna/'+param.bbsNo,
				dataType: "json",
				success : function(data, status, xhr) {

					var result = data.data;
					var dt = result.bbsDetail;
					form.find('input[name=bbsSj]').val(dt.bbsSj);
					form.find('input[name=updtId]').val(dt.updtId);
					form.find('input[name=updtDe]').val(dt.updtDe);
					form.find('textarea[name=bbsCn]').val(dt.bbsCn);

					var ans = result.bbsAnswer;
					if(ans){
						form.find('#divBbsAnswer').show();
						form.find('textarea[name=answerCn]').val(ans.answerCn);
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		}
		qnaDetail.delete = function(){
			if(confirm('QNA를 삭제 하시겠습니까?')){
				$.ajax({
					type: 'delete',
					url : _CONSTANTS["URL_BASE"]+ 'bbs/qna/'+param.bbsNo,
					success:function(res){
						location.href= './qnaList.html';
					}
				})
			}
		}
		/****************************************************************************************************/
		/** @END Method Definition */

		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {

			qnaDetail.init();
			$('#qnaDtlBtn0101').on('click',function(evt){
				location.href= './qnaAnsRegist.html?'+commAjax.getQueryString();
			});
			$('#qnaDtlBtn0102').on('click',function(evt){
				location.href= './qnaModify.html?'+commAjax.getQueryString();
			});
			$('#qnaDtlBtn0103').on('click',function(evt){
				qnaDetail.delete();
			});
			$('#qnaDtlBtn0104').on('click',function(evt){
				location.href= './qnaList.html?'+commAjax.getStringParams('pageNo','schBbsSj');
			});
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});