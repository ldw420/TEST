/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 메뉴 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var menuRegist = function() {};

head.ready(function () {
	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}
	
	
	(function($) { "use strict";

		var menuId = commAjax.getParameter("p");
		var menuNm = commAjax.getParameter("p2");
	
		if (menuId==''){
			$('#upperMenuId').val('HOME');
			$('#upperMenuIdHid').val('M0000');
		}else{
			$('#upperMenuId').val(menuNm);	
			$('#upperMenuIdHid').val(menuId);
		}
	

		/** @START Method Definition
		/****************************************************************************************************/	
		// This Page Initialize
		menuRegist.init = function() {
			//권한 정보 가져오기
			menuRegist.authList();
		};
		
		menuRegist.authList = function() {
 
			var html = "";
			var chkBoxCnt = "0";
			
			$.ajax({
				type: "GET",
				url : _CONSTANTS["URL_BASE"]+"auth/auth",
				data: "",
				dataType: "json",
				async: true,	
				success : function(data, status, xhr) {
					if (data.code="success") {
						var results = data.data.authList;
						
						$.each(results, function (i) {
							
							if (results[i].useAt=="Y") { 
								if (chkBoxCnt==1) {
									html = html + "<input type='checkbox' id='checkAll' name='' value='"+results[i].authId+"'/>"+results[i].authNm+" <br>";
									chkBoxCnt=0;
								}else {
									html = html + "<input type='checkbox' id='checkAll' name='' value='"+results[i].authId+"'/>"+results[i].authNm+" ";
									chkBoxCnt +=1
								}
								
							}
						});

						$('#chkBox').append(html);
					}else {
						alert("권한 목록 조회 중 오류가 발생했습니다.");
					}
					
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("권한 목록 조회 중 오류가 발생했습니다.");
				}
			});
		};
		
		
		// 메뉴 등록
		menuRegist.insert = function(menuChkId) {
			
			 var param = {
					 "rownum":0, 
					 "menuSortSn": 0,
					 "useAt": 'Y', 
					 "registDe": '', 
					 "registerId": '', 
					 "updtDe": '', 
					 "updtId": '',
					 "menuId": '', 
					 "menuNm":$('#menuNm').val(),
					 "authIdChk":menuChkId,
					 "menuUrl":$('#menuUrl').val(),
					 "menuDc":$('#menuDc').val(),
					 "upperMenuId": $('#upperMenuIdHid').val(),
					 "upperMenuNm": $('#upperMenuId').val()
					 }
			 $.ajax({
				type: "POST",
				url : _CONSTANTS["URL_BASE"]+"menu",
				data: JSON.stringify(param),
				contentType: 'application/json',
				async: true,	
				success : function(data, status, xhr) { 
					if (data.code=="success") {
						alert("정상적으로 등록 되었습니다.");
						location.href="./menuMng.html";
						
					}
					
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("메뉴 등록 중 오류가 발생했습니다.");
				},
				
			});
		   
		};

			
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			menuRegist.init();

			
			// 메뉴 등록
			$("#btn0101").click(function(event) {
				
				var checkBalnk = /^\s+|\s+$/g;
				if((document.frmMenu.menuNm.value == '') || (document.frmMenu.menuNm.value.replace(checkBalnk,'') == '')){
				   alert("메뉴 명칭을 입력하십시오.");
				   document.frmMenu.menuNm.focus();
				   return false;
				} 
				
				var menuChkId='';	
				$('input:checkbox[id=checkAll]').each(function() {
				if($(this).is(':checked'))
					if (menuChkId=="") {
						menuChkId += ($(this).val());
					}else {
						menuChkId += ","+($(this).val());
					}
			    }); 
				
				if (menuChkId==""){
					alert("메뉴 권한을 선택해주세요.")
					return false;
				}
				
				if((document.frmMenu.menuUrl.value == '') || (document.frmMenu.menuUrl.value.replace(checkBalnk,'') == '')){
				   alert("메뉴 URL을 입력하십시오.");
				   document.frmMenu.menuUrl.focus();
				   return false;
				} 
				
				if(confirm("새로운 메뉴를 추가하겠습니까?")) {
					menuRegist.insert(menuChkId);
				} else {
					return false;
				}
				
			});
			
			//목록
			$("#btn0102").click(function(event) {
				location.href="./menuMng.html";
			});
			
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	
	}(jQuery));
});