/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 용어집 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var ugWord = function() {};

head.ready(function () {
	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}
	
	(function($) { "use strict";
		
		/** @START Method Definition
		/****************************************************************************************************/	
		// This Page Initialize
		ugWord.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(4);
			
			//메뉴 권한 채크
			commUsr.menuAuthCheck();
			
			ugWord.list();
			 
		};
		
		
			ugWord.list = function() {
			
			var html = '';
		
			$('#tbodyArea').find('tr').remove(); 

			let param = $('#frm01').serialize();
			
			$.ajax({
				type: "Get",
				url : _CONSTANTS["URL_BASE"]+"word",
				data: param,
				dataType: "json",
				async: true,	
				success : function(data, status, xhr) {
					
					if (data.code=="success") {

						var results = data.data.wordList
				
						$.each(results, function (i) {		
														
							html += "<tr>";						
							html += "<td><input type='checkbox' name='wordChk' value='"+ results[i].sn +"' onclick=commForm.nonCheck('checkAll','wordChk',);></td>";
							html += "<td><a href=./ugWordDetail.html?sn="+ results[i].sn +">"+ results[i].abrv +"</a></td>";
							html += "<td><a href=./ugWordDetail.html?sn="+ results[i].sn +">"+ results[i].srclang +"</a></td>";
							html += "<td><a href=./ugWordDetail.html?sn="+ results[i].sn +">"+ results[i].koreanNm +"</a></td>";
							html += "<td><a href=./ugWordDetail.html?sn="+ results[i].sn +">"+ results[i].ref +"</a></td>";
							html += "<td><a href=./ugWordDetail.html?sn="+ results[i].sn +">"+ results[i].registerId +"</a></td>"; 
							html += "<td><a href=./ugWordDetail.html?sn="+ results[i].sn +">"+ results[i].registDe +"</a></td>";
							html += "</tr>";
						});
	
						$('#tbodyArea').append(html);
						
					}else{
						alert("용어집 목록 조회 중 오류가 발생했습니다.");
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
			
		}
		ugWord.delete = function(wordChkId) {
			$.ajax({
				type: "Delete",
				url : _CONSTANTS["URL_BASE"]+"word/"+wordChkId,
				data: "",
				dataType: "json",
				async: true,	
				success : function(data, status, xhr) {
					if (data.code=="success") {
						ugWord.list();
					}else{
						alert("용어 삭제 중 오류가 발생했습니다.");
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		}
 
		/****************************************************************************************************/
		/** @END Method Definition */
		
		
		//ugWord.selComnCdEngNm = "";
	
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			ugWord.init();
			
			// 공통목록 조회
			$("#btn0101").click(function() {
				ugWord.list();
			});
			
 
			// 용어집 등록
			$("#btn0103").click(function(event) {
				location.href = "./ugWordRegist.html";
			});
			
			//용어집 삭제
			$("#btn0104").click(function() {
				var wordChkId="";
				$('input:checkbox[name=wordChk]').each(function() {
			         if($(this).is(':checked'))
			        	 if (wordChkId=="") {
			        		 wordChkId += ($(this).val());
			        	 }else {
			        		 wordChkId += ","+($(this).val());
			        	 } 
			    }); 
				if (wordChkId==""){
					alert("용어를 선택해 주세요.")
					return false;
				}
				
				if(confirm("용어를 삭제 처리하시겠습니까?")) {
					ugWord.delete(wordChkId);
				}else{
					return false;
				}
			});
			
			commForm.checkScript("checkAll","wordChk")
			
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	
	}(jQuery));
});