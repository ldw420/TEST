/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 활용사례 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var useCase = function() {};

head.ready(function () {

	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}

	var action = commAjax.getParameter("action");
	var sn = commAjax.getParameter("sn");

	(function($) { "use strict";

		var form,param;
		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		useCase.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(12); 
			
			commForm.getComnCdNew("sk004", "copm");
			
			form = $('#form')
		};

		useCase.insertUseCase=function(param) {
			let dt = form.serializeObject();
			if(commUtil.isBlank(dt.sj)){
				alert('제목을 입력하세요.');return;
			}
			if(commUtil.isBlank(dt.copm)){
				alert('관계사를 입력하세요.');return;
			}
			if(commUtil.isBlank(dt.biurl)){
				alert('report url을 입력하세요.');return;
			}
			/*if(commUtil.isBlank(dt.applcData)){
				alert('적용 데이터를 입력하세요.');return;
			}*/
			if(commUtil.isBlank(dt.cn)){
				alert('내용을 입력하세요.');return;
			}
			if(!confirm('활용사례를 등록 하시겠습니까?')){
				return;
			}
			$.ajax({
				type: "POST",
				url : _CONSTANTS["URL_BASE"]+"useCase",
				data: JSON.stringify(dt),
				contentType: 'application/json',
				success : function(data, status, xhr) {
					if(data.code == 'success'){
						alert("정상적으로 등록 되었습니다.");
						location.href = "./useCase.html";
					}

				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("활용사례 등록 중 오류가 발생했습니다.");
				},

			});

		}
		/****************************************************************************************************/
		/** @END Method Definition */

		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			useCase.init();
			$("#biBtn0103").click(function(event) {
				useCase.insertUseCase();
			});

			$("#biBtn0101").click(function(event) {
				location.href = "./useCase.html?"+commAjax.getQueryString();
			});
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});