/**
 * TITLE : DLSP
 * DESC : 시스템관리 - Tableau 레포트 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var biMng = function() {};

head.ready(function () {
	
	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}
	
	
	(function($) { "use strict";

	var action = commAjax.getParameter("action");
	var sn = commAjax.getParameter("sn");

	
		/** @START Method Definition
		/****************************************************************************************************/	
		// This Page Initialize
		biMng.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(7);
			commForm.getComnCdNew("00003", "ctg");
			biMng.detail();
		};
		
		biMng.detail=function(){
			
			$.ajax({
				type: "GET",
				url :  _CONSTANTS["URL_BASE"]+ 'bi/'+sn,
				dataType: 'json',
				success : function(data, status, xhr) {

					var results = data.data.biDetail;
					
					$('#usrId').text(results.userId);
					$('#repSj').text(results.biRepSj);
					$('#copm').text(results.copmNm);
					$('#shrUrl').text(results.shrUrl);
					$('#useAt').text(results.useAtNm);
					$('#shrAt').text(results.shrAt);
					$('#lstChgDate').text(results.updtDe);
					$('#imgUrl').text(results.imgUrl);
					$('#ctg').val(results.ctg);
					$('#cn').val(results.cn);
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		}
		
		biMng.delete=function(){
			$.ajax({
				type: "Delete",
				url : _CONSTANTS["URL_BASE"]+"bi/"+sn,
				data: "",
				contentType: 'application/json',
				async: true,	
				success : function(data, status, xhr) {
					
					alert("정상적으로 삭제 되었습니다.");
					location.href = "./biMng.html";
	
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("사용자 삭제 중 오류가 발생했습니다.");
				},
			});
		}
		
		 
		/****************************************************************************************************/
		/** @END Method Definition */
	
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			biMng.init();
			
			
			//수정
			$("#btn0103").click(function(){
				location.href="./biMngModify.html?sn="+sn
			});
			
			
			//삭제
			$("#btn0104").click(function(){
				if(confirm("사용자를 삭제하시겠습니까?")){
					biMng.delete();
				}else{
					return false;
				}
			});

			//목록
			$("#btn0101").click(function(){
				location.href="./biMng.html"
			});
			 
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});