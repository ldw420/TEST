/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 권한관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var aeInstInfo = function() {};

head.ready(function () {
	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}
	
	(function($) { "use strict";
	
		/** @START Method Definition
		/****************************************************************************************************/	
		// This Page Initialize
		aeInstInfo.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(3);
			
			//메뉴 권한 채크
			commUsr.menuAuthCheck();
			
			
			aeInstInfo.list();
		};
		
		aeInstInfo.list=function(){
			
			var html = '';
			$('#tbodyArea').find('tr').remove();
			let param = $('#frm01').serialize();
			
			$.ajax({
				type: "Get",
				url : _CONSTANTS["URL_BASE"]+"inst",
				data: param,
				dataType: "json",
				async: true,	
				success : function(data, status, xhr) {
					
					var results = data.data.instList
			
					
					
					$.each(results,function(i) {
						
						var p = results[i].sn
						
						html += "<tr style='cursor:pointer;' onClick = location.href='./aeInstInfoDetail.html?sn="+p+"';>";		
						html += "<td onClick='event.cancelBubble=true'><input type='checkbox' name='instChk' value='"+ p +"' onclick=commForm.nonCheck('checkAll','instChk');></td>";
						html += "<td>"+ results[i].instTy +"</td>";
						html += "<td>"+ results[i].instCl +"</td>";
						html += "<td>"+ results[i].vcpu +"</td>";
						html += "<td>"+ results[i].gpu +"</td>";
						html += "<td>"+ results[i].memory +"</td>";
						html += "<td>"+ results[i].gpumemory +"</td>";
						html += "<td>"+ results[i].nwPrfm +"</td>";
						html += "<td>"+ results[i].price +"</td>";
						html += "<td>"+ results[i].portalUseAt +"</td>";
						html += "<td>"+ results[i].portalInstNm +"</td>";
						html += "</tr>";
						
					});
					
					$("#tbodyArea").append(html);
				},
				error: function(jqXHR, textStatus, errorThrown) {
					//alert(errorThrown);
					alert("인스턴스 조회 중 오류가 발생했습니다.");
				}
			});
			
		}
		
		
		aeInstInfo.delete=function(instChkId){
			$.ajax({
				type: "Delete",
				url : _CONSTANTS["URL_BASE"]+"inst/"+instChkId,
				data: "",
				contentType: 'application/json',
				async: true,	
				success : function(data, status, xhr) {
					alert("정상적으로 삭제 되었습니다.");
					location.href = "./aeInstInfo.html";
	
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("인스턴스 삭제 중 오류가 발생했습니다.");
				},
			});
		}
		
 
		// 공통코드 등록 및 상세정보창 열기 
		aeInstInfo.openWinComnCd = function(action, comnCdEngNm) {
			window.open("/admin/modal/window/winComnCd.html",  "popupNo1", "width=600, height=360");
			 
		};
		
		/****************************************************************************************************/
		/** @END Method Definition */
		
		
		aeInstInfo.selComnCdEngNm = "";
	
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			aeInstInfo.init();
			
			//체크박스 | ALL 체크
			commForm.checkScript("checkAll","instChk");
			
			//검색
			$("#btn0101").click(function() {
				aeInstInfo.list();
			});
 
			// 인스턴스 정보 등록
			$("#btn0103").click(function(event) {
				location.href = "./aeInstInfoRegist.html";
			});
			
			// 인스턴스 정보 등록
			$("#btn0103").click(function(event) {
				location.href = "./aeInstInfoRegist.html";
			});
			
			// 인스턴스 정보 삭제
			$("#btn0104").click(function(event) {
				var instChkId="";
				$('input:checkbox[name=instChk]').each(function() {
			         if($(this).is(':checked'))
			        	 if (instChkId=="") {
			        		 instChkId += ($(this).val());
			        	 }else {
			        		 instChkId += ","+($(this).val());
			        	 } 
			    }); 
								
				if (instChkId==""){
					alert("인스턴스를 선택해 주세요.");
					return false;
				}
				
				aeInstInfo.delete(instChkId);
			});
			
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	
	}(jQuery));
});