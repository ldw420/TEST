/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 활용사례 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */

var useCase = function() {};

head.ready(function () {

	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}

	(function($) { "use strict";

		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		var form,param,pagination;

		useCase.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(12);
			
			//메뉴 권한 채크
			commUsr.menuAuthCheck();
			
			//관계사 selected
			commForm.getComnCdNew("sk004", "schCopm");

			param = commAjax.getJsonFromQry(location.href);
			form = $("#form");
			form.ui_setComponents(param);
			form.find('input').pressEnter(useCase.list);
			pagination = $('#paging').bootpagEx({ total: 0 }).on("page", function(event, num){ useCase.list(num) });
			useCase.list(param.pageNo);
		};

		useCase.list=function(pageNumber){
			var pageNo = commUtil.parseInt(pageNumber,1);
			form.find('#pageNo').val(pageNo);
			var html = '';
			$('#tbodyArea').find('tr').remove();
			let param = form.serialize();

			$.ajax({
				type: "Get",
				url : _CONSTANTS["URL_BASE"]+"useCase",
				data: param,
				dataType: "json",
				async: true,
				success : function(data, status, xhr) {
					var results = data.data.useCaseList
					$.each(results,function(i) {

						var p = results[i].sn + '&' + param

						html += "<tr style='cursor:pointer;' onClick = location.href='./useCaseDetail.html?sn="+p+"';>";
						html += "<td onClick='event.cancelBubble=true'><input type='checkbox' name='useCaseChk' value='"+ results[i].sn +"' onclick=commForm.nonCheck('checkAll','useCaseChk');></td>";
						html += "<td style='text-align:left;'>"+ results[i].sj +"</td>";
						html += "<td>"+ results[i].copmNm +"</td>";
						html += "<td>"+ results[i].useAt +"</td>";
						html += "<td>"+ results[i].registerId +"</td>";
						html += "<td>"+ results[i].registDe +"</td>";
						html += "</tr>";

					});

					$("#tbodyArea").append(html);

					var pageCnt = parseInt(data.data.useCaseListCount / 10) + 1;
					pagination.bootpagEx({
			        	total: pageCnt,
			        	page : pageNo
			        });
				},
				error: function(jqXHR, textStatus, errorThrown) {
					//alert(errorThrown);
					alert("Tableau 조회 중 오류가 발생했습니다.");
				}
			});
		};
		useCase.delte=function(useCaseChkId){
			$.ajax({
				type: "Delete",
				url : _CONSTANTS["URL_BASE"]+"useCase/"+useCaseChkId,
				data: "",
				dataType: "json",
				async: true,
				success : function(data, status, xhr) {
					if (data.code=="success") {
						useCase.list();
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					//alert(errorThrown);
					alert("Tableau를 삭제 중 오류가 발생했습니다.");
				}
			});
		};

		/****************************************************************************************************/
		/** @END Method Definition */

		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			useCase.init();

			//등록
			$("#btn0103").click(function(){
				location.href = "./useCaseCreate.html?"+form.serialize();
			});

			//검색
			$("#btn0101").click(function() {
				useCase.list();
			});

			commForm.checkScript("checkAll","useCaseChk")

			//삭제
			$("#btn0104").click(function() {
				var useCaseChkId="";
				$('input:checkbox[name=useCaseChk]').each(function() {
			         if($(this).is(':checked'))
			        	 if (useCaseChkId=="") {
			        		 useCaseChkId += ($(this).val());
			        	 }else {
			        		 useCaseChkId += ","+($(this).val());
			        	 }
			    });

				if (useCaseChkId==""){
					alert("활용 사례를 선택해 주세요.");
					return false;
				}

				if(confirm("활용 사례를 삭제하시겠습니까?")) {
					useCase.delte(useCaseChkId);
				}else{
					return false;
				}
			});

		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});