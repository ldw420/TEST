/**
 * TITLE : DLSP
 * DESC : 시스템관리 - Q&A 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
head.ready(function () {

	if(typeof jQuery == "undefined") {
		throw new Error("Require jQuery");
	}

	(function($) { "use strict";
		var form,param,pagination;
		var qnaList = function() {};

		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		qnaList.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(8);
			
			//메뉴 권한 채크
			commUsr.menuAuthCheck();
			
			//좌측 하위 메뉴 활성화
			$(".left_menu_list li a").click();
			
			
			form = $("#form");
			param = commAjax.getJsonFromQry(location.href);
			form.find('#schBbsSj').val(param.schBbsSj);
			pagination = $('#paging').bootpagEx({ total: 0 }).on("page", function(event, num){ qnaList.list(num) });
			qnaList.list();
		};
		qnaList.list = function(pageNumber){
			var pageNo = commUtil.parseInt(pageNumber,1);
			form.find('#pageNo').val(pageNo);
			var param = form.serialize();

			$.ajax({
				type: "GET",
				url :  _CONSTANTS["URL_BASE"]+ 'bbs/qna',
				data: param,
				dataType: "json",
				async: true,
				success : function(data, status, xhr) {
					if(data.code != 'success'){
						alert('QnA 조회 중 에러가 발생하였습니다.');return;
					}
					var html = '';
					var tbody = $('#tbQna tbody').html('');
					var results = data.data.bbsList;

					$.each(results, function (i) {
						var p = results[i].bbsNo + '&'+ param;
						var vo = results[i];
						html += "<tr>";
						html += "<td>"+vo.rownum+"</td>";
						html += "<td><a href=./qnaDetail.html?bbsNo="+p+">"+ vo.bbsSj +"</a></td>";
						html += "<td>"+ vo.registerId +"</td>";
						html += "<td>"+ vo.registDe +"</td>";
						html += "</tr>";
					});

					tbody.append(html);
					var pageCnt = parseInt(data.data.bbsListCount / 10) + 1;
					pagination.bootpagEx({
			        	total: pageCnt,
			        	page : pageNo
			        });
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		};
		/****************************************************************************************************/
		/** @END Method Definition */

		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			qnaList.init();

			// qna게시판 등록창 열기
			$("#btn0101").on('click',function(evt){
				qnaList.list();
			})
			$("#btn0104").click(function(event) {
				location.href = "./qnaRegist.html?"+form.serialize();
			});
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});