/**
 * TITLE : DLSP
 * DESC : 시스템관리 - FQA 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
head.ready(function () {

	if(typeof jQuery == "undefined") {
		throw new Error("Require jQuery");
	}

	(function($) { "use strict";
		var form,param;
		var faqDetail = function() {};
		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		faqDetail.init = function(faqMngCd) {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(8);
			//좌측 하위 메뉴 활성화
			$(".left_menu_list li a").click();
			
			form = $('#form');
			param = commAjax.getJsonFromQry(location.href);
			faqDetail.getData();
		}
		faqDetail.getData = function(){

			$.ajax({
				type: "GET",
				url :  _CONSTANTS["URL_BASE"]+ 'bbs/faq/'+param.bbsNo,
				dataType: "json",
				success : function(data, status, xhr) {

					var result = data.data;
					var dt = result.bbsDetail;
					form.find('input[name=bbsSj]').val(dt.bbsSj);
					form.find('input[name=updtId]').val(dt.updtId);
					form.find('input[name=updtDe]').val(dt.updtDe);
					form.find('textarea[name=bbsCn]').val(dt.bbsCn);

				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		}
		faqDetail.delete = function(){
			if(confirm('FAQ를 삭제 하시겠습니까?')){
				$.ajax({
					type: 'delete',
					url : _CONSTANTS["URL_BASE"]+ 'bbs/faq/'+param.bbsNo,
					success:function(res){
						location.href= './faqList.html';
					}
				})
			}
		}
		/****************************************************************************************************/
		/** @END Method Definition */

		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {

			faqDetail.init();

			$('#faqDtlBtn0101').on('click',function(evt){
				location.href= './faqModify.html?'+commAjax.getQueryString();
			});
			$('#faqDtlBtn0102').on('click',function(evt){
				faqDetail.delete();
			});
			$('#faqDtlBtn0103').on('click',function(evt){
				location.href= './faqList.html?'+commAjax.getStringParams('pageNo','schBbsSj');
			});

		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});