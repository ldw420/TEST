/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 사용자관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */

var usrMng = function() {};
	
head.ready(function () {
	
	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}
	
	(function($) { "use strict";

		
		/** @START Method Definition
		/****************************************************************************************************/	
		// This Page Initialize
		usrMng.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(1);
			
			//메뉴 권한 채크
			commUsr.menuAuthCheck();
			
			usrMng.list();
			usrMng.authList();
			
			//관계사 정보
			commForm.getComnCdNew("sk004", "schAgency");
		};
		
		usrMng.authList = function() {
			 
			var option = ""; 
			
			$.ajax({
				type: "GET",
				url : _CONSTANTS["URL_BASE"]+"auth/auth",
				data: "",
				dataType: "json",
				async: true,	
				success : function(data, status, xhr) {
					if (data.code="success") {
						var results = data.data.authList; 
						
						$.each(results, function (i) {
							
							if (results[i].useAt=="Y") {   
								$("#schAuth").append("<option value='"+results[i].authId+"'>"+results[i].authNm+"</option>");
							}
						}); 
					}else {
						alert("권한 목록 조회 중 오류가 발생했습니다.");
					}
					
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("권한 목록 조회 중 오류가 발생했습니다.");
				}
			});
		};
		
		usrMng.list=function(){
			
			var html = '';
			$('#tbodyArea').find('tr').remove();
			let param = $('#frm01').serialize();
  
			$.ajax({
				type: "Get",
				url : _CONSTANTS["URL_BASE"]+"user",
				data: param,
				dataType: "json",
				async: true,	
				success : function(data, status, xhr) {
					
					var results = data.data.userList; 
					$("#totCnt").append(results.length);
					
					$.each(results,function(i) {
						
						var p = results[i].usrId;
						
						html += "<tr style='cursor:pointer;' onClick=location.href='./usrMngDetail.html?usrId="+p+"'>";					
						html += "<td onClick='event.cancelBubble=true'><input type='checkbox' name='userChk' value='"+ results[i].usrId +"' onclick=commForm.nonCheck('checkAll','userChk');></td>";
						html += "<td>"+ results[i].usrId +"</td>";
						html += "<td>"+ results[i].nm +"</td>";
						html += "<td>"+ results[i].authNm +"</td>";
						html += "<td>"+ results[i].agencyNm +"</td>";
						html += "<td>"+ results[i].deptname +"</td>";
						html += "<td>"+ results[i].registerId +"</td>";
						html += "<td>"+ results[i].registDe +"</td>";
						html += "</tr>";
						
					});
					
					$("#tbodyArea").append(html);
				},
				error: function(jqXHR, textStatus, errorThrown) {
					//alert(errorThrown);
					alert("사용자 조회 중 오류가 발생했습니다.");
				}
			});
		};
		
		usrMng.delete=function(userChkId){
			$.ajax({
				type: "Delete",
				url : _CONSTANTS["URL_BASE"]+"user/"+userChkId,
				data: "",
				dataType: "json",
				async: true,	
				success : function(data, status, xhr) {
					if (data.code=="success") {
						usrMng.list();
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					//alert(errorThrown);
					alert("사용자를 삭제 중 오류가 발생했습니다.");
				}
			});
		}
 
		/****************************************************************************************************/
		/** @END Method Definition */
	
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			usrMng.init();
			
			//등록
			$("#btn0103").click(function(){
				location.href = "./usrMngCreate.html";
			});
			
			//검색
			$("#btn0101").click(function() {
				usrMng.list();
			});
			
			//
			
			commForm.checkScript("checkAll","userChk")
			
			//삭제
			$("#btn0104").click(function() {
				var userChkId="";
				$('input:checkbox[name=userChk]').each(function() {
			         if($(this).is(':checked'))
			        	 if (userChkId=="") {
			        		 userChkId += ($(this).val());
			        	 }else {
			        		 userChkId += ","+($(this).val());
			        	 } 
			    }); 
				
				if (userChkId==""){
					alert("사용자를 선택해 주세요.");
					return false;
				}
				
				if(confirm("사용자를 삭제 처리하시겠습니까?")) {
					usrMng.delete(userChkId);
				}else{
					return false;
				}
					
			});
			
					
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});