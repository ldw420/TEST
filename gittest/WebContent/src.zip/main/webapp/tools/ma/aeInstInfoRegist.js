/**
 * TITLE : DLSP
 * DESC : 시스템관리 - FQA 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
head.ready(function () {
	
	if(typeof jQuery == "undefined") {
		throw new Error("Require jQuery");
	}

	(function($) { "use strict";
	
		var aeInstInfo = function() {};
		
		var sn = commAjax.getParameter("sn");
		
		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		aeInstInfo.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(3);
		};
		

		
		aeInstInfo.insert=function(){
			
			var param = {
						"instTy":$('#aeInstInfoRegInp0101').val(), 
						"instCl":$('#aeInstInfoRegInp0102').val(), 
						"vcpu":$('#aeInstInfoRegInp0103').val(),
						"gpu":$('#aeInstInfoRegInp0104').val(), 
						"memory":$('#aeInstInfoRegInp0105').val(), 
						"gpumemory":$('#aeInstInfoRegInp0106').val(),   
						"nwPrfm":$('#aeInstInfoRegInp0107').val(),
						"price":$('#aeInstInfoRegInp0108').val(),
						"portalUseAt":$('#aeInstInfoRegInp0109').val(),
						"portalInstNm":$('#aeInstInfoRegInp0110').val(),
						"rownum":0, 
						"sn":0, 
						"updtId":'',
						"updtDe":'',
						"registerId":'',
						"registDe":'',
						"useAt":$('#aeInstInfoRegInp0109').val()
					}

			$.ajax({
				type: "POST",
				url : _CONSTANTS["URL_BASE"]+"inst/",
				data: JSON.stringify(param),
				contentType: 'application/json',
				async: true,	
				success : function(data, status, xhr) {
					alert("정상적으로 등록 되었습니다.");
					location.href = "./aeInstInfo.html";
	
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("인스턴스 등록 중 오류가 발생했습니다.");
				},
			});
		

		}

		/****************************************************************************************************/
		/** @END Method Definition */
		
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			aeInstInfo.init();
			
			// 목록이동
			$("#aeInstInfoRegBtn0102").click(function(event) {
				location.href = "./aeInstInfo.html";
			});
			
			$("#aeInstInfoRegBtn0101").click(function(event) {
				aeInstInfo.insert();
			});
			 
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});