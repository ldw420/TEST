/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 활용사례 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var useCase = function() {};

head.ready(function () {

	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}


	(function($) { "use strict";
	var form,param;
	var action = commAjax.getParameter("action");
	var sn = commAjax.getParameter("sn");


		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		useCase.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			form = $('#form')
			commUsr.leftMenuSel(12);
			useCase.detail();

		};

		useCase.detail=function(){

			$.ajax({
				type: "GET",
				url :  _CONSTANTS["URL_BASE"]+ 'useCase/'+sn,
				dataType: 'json',
				success : function(data, status, xhr) {

					var results = data.data.useCaseDetail;

					form.ui_setComponents(results);
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		}

		useCase.delete=function(){
			$.ajax({
				type: "Delete",
				url : _CONSTANTS["URL_BASE"]+"bi/"+sn,
				data: "",
				contentType: 'application/json',
				async: true,
				success : function(data, status, xhr) {

					alert("정상적으로 삭제 되었습니다.");
					location.href = "./useCase.html";

				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("사용자 삭제 중 오류가 발생했습니다.");
				},
			});
		}


		/****************************************************************************************************/
		/** @END Method Definition */

		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			useCase.init();


			//수정
			$("#biBtn0103").click(function(){
				location.href="./useCaseModify.html?"+commAjax.getQueryString();
			});


			$("#biBtn0104").click(function(){
				if(confirm("사용자를 삭제하시겠습니까?")){
					useCase.delete();
				}else{
					return false;
				}
			});

			//목록
			$("#biBtn0101").click(function(){
				location.href="./useCase.html?"+commAjax.getStringParams('pageNo','schSj','schCopm');
			});

		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});