/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 용어집 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
head.ready(function () {
	
	if(typeof jQuery == "undefined") {
		throw new Error("Require jQuery");
	}

	(function($) { "use strict";
	
		var sn = commAjax.getParameter("sn");
		
		var ugWordDetail = function() {};
		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		ugWordDetail.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(4);
			
			ugWordDetail.list();
			
		}
		
		 
		ugWordDetail.list = function() {
			
			$.ajax({
				type: "Get",
				url : _CONSTANTS["URL_BASE"]+"word/"+sn,
				data: "",
				dataType: "json",
				async: true,	
				success : function(data, status, xhr) {
					
					if (data.code=="success") {

						var results = data.data.wordList;
						
						$('#ugWordRegInp0101').val(results[0].abrv);
						$('#ugWordRegInp0102').val(results[0].srclang);
						$('#ugWordRegInp0104').val(results[0].koreanNm);
						$('#ugWordRegInp0105').val(results[0].ref);
						$('#ugWordRegInp0106').val(results[0].registerId);
						$('#ugWordRegInp0107').val(results[0].registDe);
						$('#faqModTexa0101').val(results[0].wordDc);
 
						
					}else{
						alert("용어집 상세 조회 중 오류가 발생했습니다.");
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
			
		}
		
		/****************************************************************************************************/
		/** @END Method Definition */
		
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			ugWordDetail.init();
			
			 
			
			// 목록이동
			$("#ugWordRegBtn0102").click(function(event) {
				location.href = "./ugWord.html";
			});
			
			 
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});