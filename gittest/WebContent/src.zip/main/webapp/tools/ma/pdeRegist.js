/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 서약서 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
head.ready(function () {
	
	if(typeof jQuery == "undefined") {
		throw new Error("Require jQuery");
	}

	(function($) { "use strict";
		
		var pdeRegist = function() {};
		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		pdeRegist.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(5);
			
			//메뉴 권한 채크
			commUsr.menuAuthCheck();
			
			$('#frmPdeReg')[0].reset(); 
		}
		
		pdeRegist.pdsInsert = function(param) {
			
			//commForm.getSessionCheck();
 
			param = {"cn":document.frmPdeReg.cn.value};
			$.ajax({
				type: "Post",
				url : _CONSTANTS["URL_BASE"]+"pde/pde",
				data: JSON.stringify(param),
				contentType: 'application/json',
				async: true,	
				success : function(data, status, xhr) {
 
					if (data.code=="success") {
						 alert("서약서가 정상적으로 등록 처리되었습니다.");
						 location.href = "./pdeList.html";
					}else {
						alert(data.message);
						$('#frmPdeReg')[0].reset(); 
					}
					
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("서약서 등록 처리 중 오류가 발생했습니다.");
					authMng.authList();
					document.frm01.authNm.value = "";
				}
			});
			 
		};
		
		 
		/****************************************************************************************************/
		/** @END Method Definition */
		
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			pdeRegist.init();
			
			// 서약서 목록으로 이동
			$("#pdeRegBtn0102").click(function(event) {
				location.href = "./pdeList.html";
			});
			// 서약서 등록
			$("#pdeRegBtn0101").click(function() { 
				if(document.frmPdeReg.cn.value == ''){
				   alert("서약서 내용을 입력하십시오.");
				   document.frmPdeReg.cn.focus();
				   return false;
				} 
				
				if(confirm("새로운 서약서를 추가하겠습니까?")) {
					let param = $('#frmPdeReg').serialize();
					pdeRegist.pdsInsert(param);
				} else {
					return false;
				}
			});
			 
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});