/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 활용사례 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var useCase = function() {};

head.ready(function () {

	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}

	(function($) { "use strict";

	var action = commAjax.getParameter("action");
	var sn = commAjax.getParameter("sn");
	var form,param;
		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		useCase.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			form = $('#form')
			commUsr.leftMenuSel(12);
			
			commForm.getComnCdNew("sk004", "copm");

			useCase.modify();
		};

		useCase.modify=function(){

			$.ajax({
				type: "GET",
				url :  _CONSTANTS["URL_BASE"]+ 'useCase/'+sn,
				dataType: "json",
				success : function(data, status, xhr) {

					var results = data.data.useCaseDetail;

					form.ui_setComponents(results);

				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});

		}

		useCase.update=function(){
			var dt = form.serializeObject();
			if(commUtil.isBlank(dt.sj)){
				alert('제목을 입력하세요.');return;
			}
			if(commUtil.isBlank(dt.copm)){
				alert('관계사를 입력하세요.');return;
			}
			if(commUtil.isBlank(dt.biurl)){
				alert('report url을 입력하세요.');return;
			}
			/*if(commUtil.isBlank(dt.applcData)){
				alert('적용 데이터를 입력하세요.');return;
			}*/
			if(commUtil.isBlank(dt.cn)){
				alert('내용을 입력하세요.');return;
			}
			if(!confirm('활용사례를 수정 하시겠습니까?')){
				return;
			}
			$.ajax({
				type: "Put",
				url : _CONSTANTS["URL_BASE"]+"useCase/"+sn,
				data: JSON.stringify(dt),
				contentType: 'application/json',
				async: true,
				success : function(data, status, xhr) {
					alert("정상적으로 수정 되었습니다.");
					location.href = "./useCaseDetail.html?"+commAjax.getQueryString();

				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("Tableau 수정 중 오류가 발생했습니다.");
				},
			});


		}

		useCase.delete=function(){
			if(!confirm('활용사례를 삭제 하시겠습니까?')){
				return;
			}
			$.ajax({
				type: "Delete",
				url : _CONSTANTS["URL_BASE"]+"useCase/"+sn,
				data: "",
				contentType: 'application/json',
				async: true,
				success : function(data, status, xhr) {

					alert("정상적으로 삭제 되었습니다.");
					location.href = "./useCase.html";

				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("Tableau 삭제 중 오류가 발생했습니다.");
				},
			});
		}


		/****************************************************************************************************/
		/** @END Method Definition */

		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			useCase.init();

			//등록
			$('#biBtn0103').click(function(){
				useCase.update();
			});

			//삭제
			$('#biBtn0104').click(function(){
				useCase.delete();
			});

			//이전
			$('#biBtn0105').click(function(){
				history.go(-1)
			});

			//목록
			$('#biBtn0101').click(function(){
				location.href = "./useCaseDetail.html?"+commAjax.getQueryString();
			});

		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});