/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 관계사 정보 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var compInfoMng = function() {};

head.ready(function () {
	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}
	
	(function($) { "use strict";
		
		/** @START Method Definition
		/****************************************************************************************************/	
		// This Page Initialize
		compInfoMng.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(15);
			
			//메뉴 권한 채크
			commUsr.menuAuthCheck();
			
			compInfoMng.compInfoList(); 
		};
		
		compInfoMng.compInfoList = function() {
			var html = ''; 
			
			$.ajax({
				type: "GET",
				url : _CONSTANTS["URL_BASE"]+"/comp-info",
				data: "",
				dataType: "json",
				success : function(data, status, xhr) {
					
					if (data.code="success") {
						var results = data.data.compInfoList;
						
						$.each(results, function (i) {
							
							var securityGroup,subnetId,accountId;
							
							if (results[i].securityGroup!=null && results[i].securityGroup!=undefined && results[i].securityGroup!=''){
								securityGroup = results[i].securityGroup
							}else{
								securityGroup = '';
							}
							
							if (results[i].subnetId!=null && results[i].subnetId!=undefined && results[i].subnetId!=''){
								subnetId = results[i].subnetId
							}else{
								subnetId = '';
							}
							
							if (results[i].accountId!=null && results[i].accountId!=undefined && results[i].accountId!=''){
								accountId = results[i].accountId
							}else{
								accountId = '';
							}
								
							html += "<tr>";						
							//html += "<td><input type='checkbox' name='compCkeck' value='"+ results[i].detailCodeId +"' onclick=commForm.nonCheck("checkAll","compCkeck")></td>";
							html += "<td style='display:none;'>"+ results[i].groupCodeId +"</td>";
							html += "<td>"+ results[i].detailCodeId +"</td>";
							html += "<td>"+ results[i].detailCodeNm +"</td>";
//							html += '<td><input type="text" class="form-control input-xs" id="securityGroup'+i+'"  placeholder="securityGroup" value='+ securityGroup +'></td>';
//							html += '<td><input type="text" class="form-control input-xs" id="subnetId'+i+'"  placeholder="subnetId" value='+ subnetId +'></td>';
//							html += '<td><input type="text" class="form-control input-xs" id="accountId'+i+'"  placeholder="accountId" value='+ accountId +'></td>';
//							html += '<td><button type="button" class="btn btn-success btn-xs" id="btn0105" onclick="fn_add('+p+')">등록</button></td>';
							html += '<td><input type="text" class="form-control input-xs" id="securityGroup"  placeholder="securityGroup" value='+ securityGroup +'></td>';
							html += '<td><input type="text" class="form-control input-xs" id="subnetId"  placeholder="subnetId" value='+ subnetId +'></td>';
							html += '<td><input type="text" class="form-control input-xs" id="accountId"  placeholder="accountId" value='+ accountId +'></td>';
							html += '<td><button type="button" class="btn btn-success btn-xs" id="btn0105">등록</button></td>';
							html += "</tr>";
						});

						$('#tbodyArea').empty().append(html);
					}else {
						alert("관계사 정보 조회 중 오류가 발생했습니다.");
					}
					
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("관계사 정보 조회 중 오류가 발생했습니다.");
				}
			});
		};
		
//		compInfoMng.add = function(p) {
//			var data = p;
//			var splitData = data.split(",");
//			var no=splitData[0];
//			var groupCodeId=splitData[1];
//			var detailCodeId=splitData[2];
//			var detailCodeNm=splitData[3];
//			var securityGroup = $("#securityGroup"+no).val();
//			var subnetId = $("#subnetId"+no).val();
//			var accountId = $("#accountId"+no).val();
//			
//			if(commUtil.isBlank(securityGroup)){
//				alert('Security Group을 입력하세요.');
//				$("#securityGroup"+no).focus();return;
//			}
//			if(commUtil.isBlank(subnetId)){
//				alert('Subnet ID를 입력하세요.');
//				$("#subnetId"+no).focus();return;
//			}
//			if(commUtil.isBlank(accountId)){
//				alert('Account ID를 입력하세요.');
//				$("#accountId"+no).focus();return;
//			}
//			
//			var param = {
//					"accountId" : accountId,
//					"compabrvnm" : detailCodeId,
//					"detailCodeId" : detailCodeId,
//					"detailCodeNm" : detailCodeNm,
//					"groupCodeId" : groupCodeId,
//					"securityGroup": securityGroup, 
//					"subnetId": subnetId, 
//					"accountId": accountId
//					}
//			
//			$.ajax({
//				type: "POST",
//				url : _CONSTANTS["URL_BASE"]+"/comp-info",
//				data: JSON.stringify(param),
//				contentType: 'application/json',
//				success : function(data, status, xhr) {
//					
//					if (data.code="success") {
//						alert("정상적으로 등록 되었습니다.");
//						compInfoMng.compInfoList();
//					}else {
//						alert("관계사 정보 등록 중 오류가 발생했습니다.");
//					}
//				},
//				error: function(jqXHR, textStatus, errorThrown) {
//					alert("관계사 정보 등록 중 오류가 발생했습니다.");
//				}
//			});
//		}
		
		/****************************************************************************************************/
		/** @END Method Definition */
		
	
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			compInfoMng.init();
			
			//등록
			$(document).on("click","#btn0105",function(){
				var checkBtn = $(this);
				var tr = checkBtn.parent().parent();
				var td = tr.children();
				var input = td.find('input');
				
//				alert($(input).eq(0).val())
//				alert($(input).eq(1).val())
//				alert($(input).eq(2).val())
//				return false;

				var groupCodeId = td.eq(0).text();
				var compabrvnm = td.eq(1).text();
				var detailCodeId = td.eq(1).text();
				var detailCodeNm = td.eq(2).text();
				var securityGroup = input.eq(0).val();
			    var subnetId = input.eq(1).val();
			    var accountId = input.eq(2).val();
			    
				if(commUtil.isBlank(securityGroup)){
					alert('Security Group을 입력하세요.');
					input.eq(0).focus();return;
				}
				if(commUtil.isBlank(subnetId)){
					alert('Subnet ID를 입력하세요.');
					input.eq(1).focus();return;
				}
				if(commUtil.isBlank(accountId)){
					alert('Account ID를 입력하세요.');
					input.eq(2).focus();return;
				}
				
				var param = {
						"accountId" : accountId,
						"compabrvnm" : detailCodeId,
						"detailCodeId" : detailCodeId,
						"detailCodeNm" : detailCodeNm,
						"groupCodeId" : groupCodeId,
						"securityGroup": securityGroup, 
						"subnetId": subnetId, 
						"accountId": accountId
						}
				
				$.ajax({
					type: "POST",
					url : _CONSTANTS["URL_BASE"]+"/comp-info",
					data: JSON.stringify(param),
					contentType: 'application/json',
					success : function(data, status, xhr) {
						
						if (data.code="success") {
							alert("정상적으로 등록 되었습니다.");
							compInfoMng.compInfoList();
						}else {
							alert("관계사 정보 등록 중 오류가 발생했습니다.");
						}
					},
					error: function(jqXHR, textStatus, errorThrown) {
						alert("관계사 정보 등록 중 오류가 발생했습니다.");
					}
				});
			})

		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	
	}(jQuery));
});