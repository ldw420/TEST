/**
 * TITLE : DLSP
 * DESC : 시스템관리 - Tableau 레포트 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var winMenu = function() {};

head.ready(function () {
	
	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}
	

	
	(function($) { "use strict";
	
	var menuId = commAjax.getParameter("p");
	
		/** @START Method Definition
		/****************************************************************************************************/	
		// This Page Initialize
		winMenu.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(6);
			 
			winMenu.authList();
			
			winMenu.list();
		};
		
		winMenu.authList = function() {
			 
			var html = "";
			var chkBoxCnt = "0";
			
			$.ajax({
				type: "GET",
				url : _CONSTANTS["URL_BASE"]+"auth/auth",
				data: "",
				dataType: "json",
				async: false,	
				success : function(data, status, xhr) {
					if (data.code="success") {
						var results = data.data.authList;
						
						$.each(results, function (i) {
							
							if (results[i].useAt=="Y") { 
								if (chkBoxCnt==1) {
									html = html + "<input type='checkbox' id='checkAll' name='' value='"+results[i].authId+"' onclick='return false;' />"+results[i].authNm+" <br>";
									chkBoxCnt=0;
								}else {
									html = html + "<input type='checkbox' id='checkAll' name='' value='"+results[i].authId+"' onclick='return false;' />"+results[i].authNm+" ";
									chkBoxCnt +=1
								}
								
							}
						});

						$('#chkBox').append(html);
					}else {
						alert("메뉴 상세 조회 중 오류가 발생했습니다.");
					}
					
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("메뉴 상세 조회 중 오류가 발생했습니다.");
				}
			});
		};
		
		
		winMenu.list=function(){
			
			
			$.ajax({
				type: "GET",
				url :  _CONSTANTS["URL_BASE"]+ 'menu/'+menuId,
				dataType: "json",
				success : function(data, status, xhr) {
			
					var results = data.data.menuDetail;
					var authIdChk = results.authIdChk
					if (authIdChk.indexOf(",") != -1){
						authIdChk = results.authIdChk.split(',')
						$.each(authIdChk, function (i) {
							 $('input:checkbox[id="checkAll"]').each(function() {
							     if(this.value == authIdChk[i]){ //값 비교
							    	 this.checked = true; //checked 처리
							      }
							 })
						})
					}else{
						 $('input:checkbox[id="checkAll"]').each(function() {
						     if(this.value == authIdChk){ //값 비교
						    	 this.checked = true; //checked 처리
						      }
						 })
					}
												
					$('#upperMenuNm').val(results.upperMenuNm);
					$('#menuNm').val(results.menuNm);
					$('#menuUrl').val(results.menuUrl);
					$('#menuDc').val(results.menuDc);
					$('#registerId').val(results.registerId);
					$('#registDe').val(results.registDe);
					
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		}
			
		
		

		/****************************************************************************************************/
		/** @END Method Definition */
		
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			winMenu.init();

			//수정
			$('#winComnCdBtn0101').click(function(){
				location.href="./menuMngModify.html?p="+menuId+""
			});
		
			//목록
			$('#winComnCdBtn0102').click(function(){
				location.href = "./menuMng.html";
			});
			
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});