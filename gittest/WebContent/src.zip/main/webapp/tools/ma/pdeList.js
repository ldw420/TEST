/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 서약서 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */

var pdeMngList = function() {};

head.ready(function () {
	
	if(typeof jQuery == "undefined") {
		throw new Error("Require jQuery");
	}
	
	(function($) { "use strict";
		
		/** @START Method Definition
		/****************************************************************************************************/	
		// This Page Initialize
		pdeMngList.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(5);
			
			//메뉴 권한 채크
			commUsr.menuAuthCheck();
			
			pdeMngList.pdeList();
			 
		};
		
		pdeMngList.pdeList = function() {
			var html = ''; 
			var sBun = 0;
			$('#tbodyArea').find('tr').remove(); 

			$.ajax({
				type: "GET",
				url : _CONSTANTS["URL_BASE"]+"pde/pde",
				data: "",
				dataType: "json",
				async: true,	
				success : function(data, status, xhr) {
					if (data.code="success") {
						var results = data.data.pdeList;
						
						$.each(results, function (i) {
						
							sBun = sBun +1;
							
							var title = "<a href='pdeDetail.html?sn="+results[i].sn+"'>"+results[i].registerId+"님이 "+results[i].registDe+"에 등록한 서약서</a>";
							html += "<tr>";		
							html += "<td>"+ sBun +"</td>"; 
							html += "<td>"+ title +"</td>"; 
							html += "<td>"+ results[i].registerId +"</td>";
							html += "<td>"+ results[i].registDe +"</td>";
							
							html += "</tr>";
						});

						$('#tbodyArea').append(html);
					}else {
						alert("서약서 목록 조회 중 오류가 발생했습니다.");
					}
					
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("서약서 목록 조회 중 오류가 발생했습니다.");
				}
			});
		}; 
		
		/****************************************************************************************************/
		/** @END Method Definition */
		
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			pdeMngList.init();
			
			// pde게시판 등록창 열기
			$("#btn0104").click(function(event) {
				location.href = "./pdeRegist.html";
			});
			 
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});