/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 권한관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var authMng = function() {};

head.ready(function () {
	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}
	
	(function($) { "use strict";
		
		/** @START Method Definition
		/****************************************************************************************************/	
		// This Page Initialize
		authMng.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(2);
			
			//메뉴 권한 채크
			commUsr.menuAuthCheck();
			
			authMng.authList(); 
		};
		
		authMng.authList = function() {
			var html = ''; 
			$('#tbodyArea').find('tr').remove(); 

			$.ajax({
				type: "GET",
				url : _CONSTANTS["URL_BASE"]+"auth/auth",
				data: "",
				dataType: "json",
				async: true,	
				success : function(data, status, xhr) {
					if (data.code="success") {
						var results = data.data.authList;
						
						$.each(results, function (i) {
							
							html += "<tr>";						
							html += "<td><input type='checkbox' name='authChk' value='"+ results[i].authId +"'></td>";
							html += "<td>"+ results[i].authId +"</td>";
							html += "<td>"+ results[i].authNm +"</td>";
							if (results[i].useAt=="Y") {
								html += "<td>사용</td>";
							}else {
								html += "<td>미사용</td>";
							} 
							html += "<td>"+ results[i].registerId +"</td>";
							html += "<td>"+ results[i].registDe +"</td>";
							html += "<td>"+ results[i].updtId +"</td>";
							html += "<td>"+ results[i].updtDe +"</td>";
							html += "</tr>";
						});

						$('#tbodyArea').append(html);
					}else {
						alert("권한 목록 조회 중 오류가 발생했습니다.");
					}
					
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("권한 목록 조회 중 오류가 발생했습니다.");
				}
			});
		};
		
		authMng.authDelete = function(chkAuthId) {
			$.ajax({
				type: "Put",
				url : _CONSTANTS["URL_BASE"]+"auth/authUnUse/"+chkAuthId,
				data: "",
				dataType: "json",
				async: true,	
				success : function(data, status, xhr) {
					if (data.code="success") {
						 alert("권한이 정상적으로 미사용 처리되었습니다.");
						 authMng.authList();
					}else {
						alert("권한 미사용 처리 중 오류가 발생했습니다.");
					}
					
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("권한 미사용 처리 중 오류가 발생했습니다.");
				}
			});

 
		};
		
		authMng.authUse = function(chkAuthId) {
			$.ajax({
				type: "Put",
				url : _CONSTANTS["URL_BASE"]+"auth/authUse/"+chkAuthId,
				data: "",
				dataType: "json",
				async: true,	
				success : function(data, status, xhr) {
					if (data.code="success") {
						 alert("권한이 정상적으로 사용 처리되었습니다.");
						 authMng.authList();
					}else {
						alert("권한 사용 처리 중 오류가 발생했습니다.");
					}
					
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("권한 사용 처리 중 오류가 발생했습니다.");
				}
			});
		};
		
		authMng.authDel = function(chkAuthId) {
			$.ajax({
				type: "Delete",
				url : _CONSTANTS["URL_BASE"]+"auth/authDel/"+chkAuthId,
				data: "",
				dataType: "json",
				async: true,	
				success : function(data, status, xhr) {
					if (data.code="success") {
						 alert("권한이 정상적으로 삭제 처리되었습니다.");
						 authMng.authList();
					}else {
						alert("권한 삭제 처리 중 오류가 발생했습니다.");
					}
					
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("권한 삭제 처리 중 오류가 발생했습니다.");
				}
			});
		};
		
		authMng.authInsert = function(param) {
			param = {"authNm":document.frm01.authNm.value}
			$.ajax({
				type: "Post",
				url : _CONSTANTS["URL_BASE"]+"auth/auth",
				data: JSON.stringify(param),
				contentType: 'application/json',
				async: true,	
				success : function(data, status, xhr) {
 
					if (data.code=="success") {
						 alert("권한이 정상적으로 등록 처리되었습니다.");
						 authMng.authList();
						 document.frm01.authNm.value = "";
					}else {
						alert(data.message);
						authMng.authList();
						document.frm01.authNm.value = "";
					}
					
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("권한 등록 처리 중 오류가 발생했습니다.");
					authMng.authList();
					document.frm01.authNm.value = "";
				}
			});
		};
		
		/****************************************************************************************************/
		/** @END Method Definition */
		
 
	
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			authMng.init();
			
			// 권한 등록
			$("#btn0103").click(function(event) {
				authMng.openWinauth("PUT");
			});
			
			// 권한 미사용
			$("#btn0104").click(function() {
				var chkAuthId="";
				$('input:checkbox[name=authChk]').each(function() {
			         if($(this).is(':checked'))
			        	 if (chkAuthId=="") {
			        		 chkAuthId += ($(this).val());
			        	 }else {
			        		 chkAuthId += ","+($(this).val());
			        	 }
			        	 
			      }); 
				if (chkAuthId=="") {
					alert("미사용처리 할 권한을 선택하세요!");
					return false;
				}
				if(confirm("선택한 권한을 미사용 처리하시겠습니까?")) {
					authMng.authDelete(chkAuthId);	
				} else {
					return false;
				}
			});
			
			// 권한 사용
			$("#btn0105").click(function() {
				var chkAuthId="";
				$('input:checkbox[name=authChk]').each(function() {
			         if($(this).is(':checked'))
			        	 if (chkAuthId=="") {
			        		 chkAuthId += ($(this).val());
			        	 }else {
			        		 chkAuthId += ","+($(this).val());
			        	 }
			      }); 
				if (chkAuthId=="") {
					alert("사용처리 할 권한을 선택하세요!");
					return false;
				}
				if(confirm("선택한 권한을 사용 처리하시겠습니까?")) {
					authMng.authUse(chkAuthId);	
				} else {
					return false;
				}
			});
			
			// 권한 사용
			$("#btn0106").click(function() {
				var chkAuthId="";
				$('input:checkbox[name=authChk]').each(function() {
			         if($(this).is(':checked'))
			        	 if (chkAuthId=="") {
			        		 chkAuthId += ($(this).val());
			        	 }else {
			        		 chkAuthId += ","+($(this).val());
			        	 }
			      }); 
				if (chkAuthId=="") {
					alert("삭제할 권한을 선택하세요!");
					return false;
				}
				if(confirm("선택한 권한을 삭제 처리하시겠습니까?")) {
					authMng.authDel(chkAuthId);	
				} else {
					return false;
				}
			});
			
			$("#checkAll").click(function() {
				//클릭되었으면
		        if($("#checkAll").prop("checked")){
		            //input태그의 name이 chk인 태그들을 찾아서 checked옵션을 true로 정의
		            $("input[name=authChk]").prop("checked",true);
		            //클릭이 안되있으면
		        }else{
		            //input태그의 name이 chk인 태그들을 찾아서 checked옵션을 false로 정의
		            $("input[name=authChk]").prop("checked",false);
		        }
			});
			
			$("#btn0101").click(function() { 
				if(document.frm01.authNm.value == ''){
				   alert("권한명을 입력하십시오.");
				   document.frm01.authNm.focus();
				   return false;
				} 
				
				if(confirm("새로운 권한을 추가하겠습니까?")) {
					let param = $('#frm01').serialize();
					authMng.authInsert(param);
				} else {
					return false;
				}
			});
	
	

			
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	
	}(jQuery));
});