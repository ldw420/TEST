head.ready(function () {

	if(typeof jQuery == "undefined") {
		throw new Error("Require jQuery");
	}

	(function($) { "use strict";
		var form,param;
		var noticeDetail = function() {};
		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		noticeDetail.init = function() {
			form = $('#form');
			param = commAjax.getJsonFromQry(location.href);
			noticeDetail.getData();
		}
		noticeDetail.getData = function(){

			$.ajax({
				type: "GET",
				url :  _CONSTANTS["URL_BASE"]+ 'bbs/notice/'+param.bbsNo,
				dataType: "json",
				success : function(data, status, xhr) {

					var result = data.data;
					var dt = result.bbsDetail;
					form.find('input[name=bbsSj]').val(dt.bbsSj);
					form.find('input[name=updtId]').val(dt.updtId);
					form.find('input[name=updtDe]').val(dt.updtDe);
					form.find('textarea[name=bbsCn]').val(dt.bbsCn);

				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		}
		noticeDetail.delete = function(){
			if(confirm('공지사항을 삭제 하시겠습니까?')){
				$.ajax({
					type: 'delete',
					url : _CONSTANTS["URL_BASE"]+ 'bbs/notice/'+param.bbsNo,
					success:function(res){
						location.href= './noticeList.html';
					}
				})
			}
		}
		/****************************************************************************************************/
		/** @END Method Definition */

		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {

			noticeDetail.init();
			$('#noticeDtlBtn0101').on('click',function(evt){
				location.href= './noticeModify.html?'+commAjax.getQueryString();
			});
			$('#noticeDtlBtn0102').on('click',function(evt){
				noticeDetail.delete();
			});
			$('#noticeDtlBtn0103').on('click',function(evt){
				location.href= './noticeList.html?'+commAjax.getStringParams('pageNo','schBbsSj');
			});
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});