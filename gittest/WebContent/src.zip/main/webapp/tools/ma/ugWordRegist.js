/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 용어집 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
head.ready(function () {
	
	if(typeof jQuery == "undefined") {
		throw new Error("Require jQuery");
	}

	(function($) { "use strict";
		
		var ugWordRegist = function() {};
		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		ugWordRegist.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(4);
			
		}
		
		 
			ugWordRegist.creatWord=function(param) {
				
				param = {
						"abrv":$('#ugWordRegInp0101').val(), 
						"koreanNm":$('#ugWordRegInp0104').val(), 
						"ref":$('#ugWordRegInp0105').val(), 
						"registDe":'', 
						"registerId":'', 
						"sn":0, 
						"srclang":$('#ugWordRegInp0102').val(), 
						"updtDe":'', 
						"updtId":'', 
						"wordDc":$('#faqModTexa0101').val()
						}

				$.ajax({
					type: "POST",
					url : _CONSTANTS["URL_BASE"]+"word",
					data: JSON.stringify(param),
					contentType: 'application/json',
					async: true,	
					success : function(data, status, xhr) {
			
						if (data.code=="success") {
							alert("정상적으로 등록 되었습니다.");
							$('#winComnCdValInp0105').val('');
							$('#winComnCdValInp0102').val('');
							$('#winComnCdValInp0104').val('');
							location.href = "./ugWord.html";
						}else {
							alert("용어 등록 중 오류가 발생했습니다.");
						}
					},
					error: function(jqXHR, textStatus, errorThrown) {
						alert("용어 등록 중 오류가 발생했습니다.");
					},
					
				});
			}
		
		/****************************************************************************************************/
		/** @END Method Definition */
		
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			ugWordRegist.init();
			
			$("#ugWordRegBtn0101").click(function(event) {
				
				var checkBalnk = /^\s+|\s+$/g; //공백만 입력 됐을 경우 return
				if(document.frmugWordReg.ugWordRegInp0101.value == '' || document.frmugWordReg.ugWordRegInp0101.value.replace(checkBalnk,'') == ''){
				   alert("약어를 입력하십시오.");
				   document.frmugWordReg.ugWordRegInp0101.focus();
				   return false;
				} 
			
				if(document.frmugWordReg.ugWordRegInp0102.value == '' || document.frmugWordReg.ugWordRegInp0102.value.replace(checkBalnk,'') == ''){
				   alert("원어를 입력하십시오.");
				   document.frmugWordReg.ugWordRegInp0102.focus();
				   return false;
				} 
				
				if(document.frmugWordReg.ugWordRegInp0104.value == '' || document.frmugWordReg.ugWordRegInp0104.value.replace(checkBalnk,'') == ''){
				   alert("한글명을 입력하십시오.");
				   document.frmugWordReg.ugWordRegInp0104.focus();
				   return false;
				} 
				if(document.frmugWordReg.ugWordRegInp0105.value == '' || document.frmugWordReg.ugWordRegInp0105.value.replace(checkBalnk,'') == ''){
				   alert("출처를 입력하십시오.");
				   document.frmugWordReg.ugWordRegInp0105.focus();
				   return false;
				} 
				if(document.frmugWordReg.faqModTexa0101.value == '' || document.frmugWordReg.faqModTexa0101.value.replace(checkBalnk,'') == ''){
				   alert("설명을 입력하십시오.");
				   document.frmugWordReg.faqModTexa0101.focus();
				   return false;
				} 
			
				ugWordRegist.creatWord();
			});
			
			// 목록이동
			$("#ugWordRegBtn0102").click(function(event) {
				location.href = "./ugWord.html";
			});
			
			 
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});