/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 메뉴 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
head.ready(function () {
	
	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}
	
	(function($) { "use strict";
	
		var menuMng = function() {};	

		
		/** @START Method Definition
		/****************************************************************************************************/	
		// This Page Initialize
		menuMng.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(6);
			//메뉴 권한 채크
			commUsr.menuAuthCheck();
			
			menuMng.list();
 
		};
		
		// 메뉴등록 등록 열기 
		menuMng.openWinMenu = function(action) {
			var menuChkId='';
			
			$('input:checkbox[name=menuChk]').each(function() {
				if($(this).is(':checked'))
					if (menuChkId=="") {
						menuChkId += ($(this).val());
					}else {
						menuChkId += ","+($(this).val());
					}
			    }); 
				
				if (menuChkId.indexOf(",") > -1){
					alert("메뉴를 하나만 선택해 주세요.")
					return false;
				}
			
				window.open("/admin/modal/window/winMenu.html?p="+menuChkId+"",  "popupNo1", "width=600, height=360");	
		};
		
		menuMng.list=function(){
			
			var html = '';
			$('#tbodyArea').find('tr').remove(); 

			let param = $('#frm01').serialize();
			

			$.ajax({
				type: "Get",
				url : _CONSTANTS["URL_BASE"]+"menu",
				data: param,
				dataType: "json",
				async: true,	
				success : function(data, status, xhr) {
					
					if (data.code=="success") {
						
						var results = data.data.menuList
						var tempPath
						var tempSpace
						
						
						$.each(results, function (i) {
							
							tempPath = '';
							tempSpace = '';
							
							tempPath = results[i].menuPath;
							tempPath = tempPath.match(/>/g);
							
							if(tempPath != null) {
								tempPath = tempPath.length // 2개이므로 2가 출력된다!
								
								if (tempPath == 1) {
									tempSpace = "&nbsp;&nbsp;&nbsp;&nbsp;ㄴ"
								}else if (tempPath == 2){
									tempSpace = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ㄴ"
								}else if (tempPath == 3){
									tempSpace = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ㄴ"
								}
							}
												
							html += "<tr style='cursor:pointer;' onClick = location.href='./menuMngDetail.html?p="+results[i].menuId+"';>";						
							html += "<td onClick='event.cancelBubble=true'><input type='checkbox' name='menuChk' value='"+ results[i].menuId +"^^"+results[i].menuNm+"' onclick=commForm.nonCheck('checkAll','menuChk');></td>";
							html += "<td>"+ results[i].menuId +"</td>";
							html += "<td style='text-align:left;'>"+tempSpace+""+ results[i].menuNm +"</td>";
							html += "<td style='text-align:left;'>"+ results[i].menuUrl +"</td>";
							html += "<td style='text-align:left;'>"+ results[i].menuPath +"</td>"; 
							html += "<td>"+ results[i].useAt +"</td>";
							html += "<td>"+ results[i].registerId +"</td>";
							html += "<td>"+ results[i].registDe +"</td>";
							html += "</tr>";
						});
	
						$('#tbodyArea').append(html);
						
					}else{
						alert("메뉴 조회 중 오류가 발생했습니다.");
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		}
		
		menuMng.delete=function(menuId){
			$.ajax({
				type: "Delete",
				url : _CONSTANTS["URL_BASE"]+"menu/"+menuId,
				data: "",
				contentType: 'application/json',
				async: true,	
				success : function(data, status, xhr) {
					
					alert("정상적으로 삭제 되었습니다.");
					location.href = "./menuMng.html";
	
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert("메뉴 삭제 중 오류가 발생했습니다.");
				},
			});
		}
		
 
		/****************************************************************************************************/
		/** @END Method Definition */
	
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			menuMng.init();
			

			
			
			
			// 검색
			$("#btn0101").click(function(event) {
				menuMng.list();
			});
			
			// 메뉴 등록 등록창 열기 
			$("#btn0103").click(function(event) {
				//menuMng.openWinMenu("PUT");
				
				var menuChkId="";
				var menuChkNm="";
				var tempId = '';
				$('input:checkbox[name=menuChk]').each(function() {
					if($(this).is(':checked'))
						if (menuChkId=="") {
							tempId= ($(this).val()).split('^^')
							menuChkId += (tempId[0]);
							menuChkNm += (tempId[1])
						}else {
							tempId= ($(this).val()).split('^^')
							menuChkId += ","+(tempId[0]);
							menuChkNm += ","+(tempId[1])
						}
				    }); 
				
					if (menuChkId.indexOf(",") > -1){
						alert("메뉴를 하나만 선택해 주세요.")
						return false;
					}
				
				location.href="./menuMngRegist.html?p="+menuChkId+"&p2="+menuChkNm+""
			});
			
			//수정
			$("#btn0105").click(function(event) {
				var menuChkId="";
				var menuChkNm="";
				var tempId = '';
				$('input:checkbox[name=menuChk]').each(function() {
					if($(this).is(':checked'))
						if (menuChkId=="") {
							tempId= ($(this).val()).split('^^')
							menuChkId += (tempId[0]);
							menuChkNm += (tempId[1])
						}else {
							tempId= ($(this).val()).split('^^')
							menuChkId += ","+(tempId[0]);
							menuChkNm += ","+(tempId[1])
						}
				    }); 
				
				if (menuChkId==""){
					alert("메뉴를 선택해 주세요.")
					return false;
				}
					
				if (menuChkId.indexOf(",") > -1){
					alert("메뉴를 하나만 선택해 주세요.")
					return false;
				}
					
				location.href="./menuMngModify.html?p="+menuChkId+""
			});
			
			
			$("#btn0104").click(function(event) {
				
				var menuChkId='';
				var menuChkNm="";
				var tempId='';
				
				$('input:checkbox[name=menuChk]').each(function() {
					if($(this).is(':checked'))
						if (menuChkId=="") {
							tempId= ($(this).val()).split('^^')
							menuChkId += (tempId[0]);
							menuChkNm += (tempId[1])
						}else {
							tempId= ($(this).val()).split('^^')
							menuChkId += ","+(tempId[0]);
							menuChkNm += ","+(tempId[1])
						}
				    }); 
				
				if (menuChkId==""){
					alert("메뉴를 선택해 주세요.")
					return false;
				}
	
				if(confirm("메뉴를 삭제하시겠습니까?")) {
					menuMng.delete(menuChkId);
				}else{
					return false;
				}
			});
			
			
			//체크박스 | ALL 체크
			commForm.checkScript('checkAll',"menuChk");
			 
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});