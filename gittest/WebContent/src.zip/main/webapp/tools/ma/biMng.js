/**
 * TITLE : DLSP
 * DESC : 시스템관리 - Tableau 레포트 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */

var biMng = function() {};

head.ready(function () {

	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}

	(function($) { "use strict";

	var form,param,pagination;


		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		biMng.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(7);

			//메뉴 권한 채크
			commUsr.menuAuthCheck();
			
			//관계사 selected
			commForm.getComnCdNew("sk004", "schCopm");
			
			//카테고리
			commForm.getComnCdNew("00003", "schCtg");

			form = $("#frm01");
			param = commAjax.getJsonFromQry(location.href);
			form.find('#schBbsSj').val(param.schBbsSj);
			pagination = $('#paging').bootpagEx({ total: 0 }).on("page", function(event, num){ biMng.list(num) });



			biMng.list();
		};

		biMng.list=function(pageNumber){

			var pageNo = commUtil.parseInt(pageNumber,1);
			form.find('#pageNo').val(pageNo);
			var param = form.serialize();

			var html = '';
			$('#tbodyArea').find('tr').remove();

			$.ajax({
				type: "Get",
				url : _CONSTANTS["URL_BASE"]+"biAdmin",
				data: param,
				dataType: "json",
				async: true,
				success : function(data, status, xhr) {

					var results = data.data.biList;

					$.each(results,function(i) {

						var p = results[i].sn

						html += "<tr style='cursor:pointer;' onClick = location.href='./biMngDetail.html?sn="+p+"';>";
						html += "<td onClick='event.cancelBubble=true'><input type='checkbox' name='biChk' value='"+ results[i].sn +"' onclick=commForm.nonCheck('checkAll','biChk');></td>";
						html += "<td>"+ results[i].userId +"</td>";
						html += "<td>"+ results[i].ctgNm +"</td>";
						html += "<td style='text-align:left;'>"+ results[i].biRepSj +"</td>";
						html += "<td>"+ results[i].copmNm +"</td>";
						html += "<td>"+ results[i].shrAt +"</td>";
						html += "<td>"+ results[i].useAtNm +"</td>";
						html += "<td>"+ results[i].cnt +"</td>";
						html += "</tr>";

					});

					$("#tbodyArea").append(html);

					var pageCnt = Math.ceil(data.data.biListCount / 10);

					pagination.bootpagEx({
			        	total: pageCnt,
			        	page : pageNo
			        });

				},
				error: function(jqXHR, textStatus, errorThrown) {
					//alert(errorThrown);
					alert("Tableau 조회 중 오류가 발생했습니다.");
				}
			});
		};
		biMng.delte=function(biChkId){
			$.ajax({
				type: "Delete",
				url : _CONSTANTS["URL_BASE"]+"bi/"+biChkId,
				data: "",
				dataType: "json",
				async: true,
				success : function(data, status, xhr) {
					if (data.code=="success") {
						biMng.list();
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					//alert(errorThrown);
					alert("Tableau를 삭제 중 오류가 발생했습니다.");
				}
			});
		};

		/****************************************************************************************************/
		/** @END Method Definition */

		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			biMng.init();

			//등록
			$("#btn0103").click(function(){
				//location.href = "./biMngCreate.html";
			});

			//검색
			$("#btn0101").click(function() {
				biMng.list();
			});

			commForm.checkScript("checkAll","biChk")


			//삭제
			$("#btn0104").click(function() {
				var biChkId="";
				$('input:checkbox[name=biChk]').each(function() {
			         if($(this).is(':checked'))
			        	 if (biChkId=="") {
			        		 biChkId += ($(this).val());
			        	 }else {
			        		 biChkId += ","+($(this).val());
			        	 }
			    });

				if (biChkId==""){
					alert("Tableau를 선택해 주세요.");
					return false;
				}

				if(confirm("Tableau를 삭제하시겠습니까?")) {
					biMng.delte(biChkId);
				}else{
					return false;
				}

			});


		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});