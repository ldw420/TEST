/**
 * TITLE : DLSP
 * DESC : 기본 JavaScript 라이브러리 Loader
 * Library		:: jQuery, UnderscoreJS, HeadJS, Bootstrap
 *   [20190826][(주)씨씨미디어서비스][박영철]
 *
 */

// Base Paths
var libBase 		= "/js/";
var jsFrameworkBase = "/js/framework/";
var jqPluginBase 	= "/js/framework/jquery/plugin/";
var commonBase 		= "/js/common/";
var moduleBase 		= "/js/module/";

// Base Library
var bootstrap 		= jsFrameworkBase + "bootstrap/bootstrap.js";

// jQuery Plugin
var jqCookie 		= jsFrameworkBase + "jquery/jquery.cookie.js";
var jqForm 			= jsFrameworkBase + "jquery/jquery.form.js";
var jqValidate 		= jsFrameworkBase + "jquery/jquery.validate.js";
var jqMin 			= jsFrameworkBase + "jquery/jquery-3.3.1.min.js";
var jqUi 			= jsFrameworkBase + "jquery/jquery-ui.js";
var library 		= libBase + "library/json2.js";
var moment          = libBase + "library/moment.min.js";
var alphanum        = libBase + "library/jquery.alphanum.js";
// Bootstrap Plugin
var bsDatepicker 	= jsFrameworkBase + "bootstrap/plugin/bootstrap-datepicker.js";

// common
var chkAuth 		= commonBase + "checkAuth.js";
var consts 			= commonBase + "commConst.js";
var string 			= commonBase + "commString.js";
var utils 			= commonBase + "commUtil.js";
var validate 		= commonBase + "commValidate.js";
// module Plugin
var navMain 		= moduleBase + "navigation/navMain.js";
var paging       	= jsFrameworkBase + "jquery/jquery.bootpag.js"; //bootpag 페이징
var jqueryEx     	= commonBase + "jquery.extend.js";  //jquery 확장 파일
// JavaScript Library Load
/*, chkAuth*/

head.load(
		jqMin
		, jqueryEx
		, jqCookie
		, jqForm
		, jqUi
		, bootstrap
		, library
		, utils
		, validate
		, bsDatepicker
		, consts
		, jqValidate
		, alphanum
		, moment
		, chkAuth
		, navMain
		, string
		, paging
);
