/**
 * 함수 설명 : 숫자만 입력 
 * @param obj = input obj
 */
function fncOnlyNumber(obj) {
	obj.value = obj.value.replace(/[^0-9]/g,'');
}

/**
 * 함수 설명 : 영문 소문자,숫자만 입력 
 * @param obj = input obj
 */
function fncNumLowerCheck(obj) {
	obj.value = obj.value.replace(/[^a-z0-9]/g,'');
}


/**
 * 함수 설명 : 영문,숫자,-(하이픈)만 입력 
 * @param obj = input obj
 */
function fnceEngNumCheck(obj) {
	obj = obj.replace(/[^a-zA-Z0-9-]/g,'');
	return obj;
}

/**
 * 함수 설명 : 파일 확장자 체크
 * @param filename 파일명
 * @param allowFileExts 확장자
 * @return boolean
 */
function isValidFileType(filename, allowFileExts) {
	var fileExt, sepcnt;
	sepcnt = filename.lastIndexOf(".");

	fileExt = filename.substring(sepcnt + 1);
	
	if(allowFileExts.indexOf(fileExt.toUpperCase()) >= 0 ) {
		return true;
	}else{
		return false;
	}
}

/**
 * 함수 설명 : 파일 확장자 가져오기
 * @param filename 파일명
 * @return string
 */
function getFileExt(fileName){
	var fileExt, sepcnt;
	sepcnt = fileName.lastIndexOf(".");
	
	fileExt = fileName.substring(sepcnt + 1);
	
	return fileExt.toUpperCase();
}



