/**
 * Front-End Configure Resource
 * [2014.02.01][GeunheeZhang(jjangadang@gmail.com)]
 */

//////////////////////////////////////////////////////////////////////
var _CONSTANTS = new Object();
//////////////////////////////////////////////////////////////////////


_CONSTANTS["IS_DEBUG"] = true;
//_CONSTANTS["IS_DEBUG"] = false;

// Apache Tomcat docBase
_CONSTANTS["URI_BASE"] = "/";

// URL Patterns
_CONSTANTS["AJAX_URL_PATTERN"] = ".xhr";
_CONSTANTS["FILE_URL_PATTERN"] = ".file";
_CONSTANTS["JSON_URL_PATTERN"] = ".do";
_CONSTANTS["XLS_URL_PATTERN"] = ".do";


//HOST별 URI 세팅
var host = jQuery(location).attr('host').split(":");
var protocol = $(location).attr('protocol');

_CONSTANTS["URI_HOSTNAME"] = protocol+"//"+host[0];

if (host[1]!="" && host[1] !=undefined && host[1] !="undefined") {
	_CONSTANTS["URI_PORT"] = ":"+host[1];
} else {
	_CONSTANTS["URI_PORT"] = "";
}

if (host[0] != "localhost") {
	_CONSTANTS["URI_BASE"] = "/analy/";
}else {
	_CONSTANTS["URI_BASE"] = "/";
}


// Basics URL
// ex) http://localhost:8080/
_CONSTANTS["URL_BASE"] = _CONSTANTS["URI_HOSTNAME"] + _CONSTANTS["URI_PORT"] + _CONSTANTS["URI_BASE"]+"api/v1/";

_CONSTANTS["URL_BASE2"] = _CONSTANTS["URI_HOSTNAME"] + _CONSTANTS["URI_PORT"] + _CONSTANTS["URI_BASE"];


// Login Page URL
// ex) http://localhost:8080/login.html
_CONSTANTS["LOGIN_URL"] = "/login.html";

// Index Page URL
// ex) http://localhost:8080/index.html
_CONSTANTS["INDEX_URL"] = "/index.html";
//////////////////////////////////////////////////////////////////////

//auth server
//_CONSTANTS["URI_AUTH_SERVER"] = "https://coeus-dev.skcc.com/auth/";
if (host[0] == "localhost") {
	_CONSTANTS["URI_AUTH_SERVER"] = "https://coeus-dev.skcc.com/auth/";
	//_CONSTANTS["URI_AUTH_SERVER"] = "https://coeus.skcc.com/auth/";
} else {
	_CONSTANTS["URI_AUTH_SERVER"] = _CONSTANTS["URI_HOSTNAME"]+"/auth/";
} 

