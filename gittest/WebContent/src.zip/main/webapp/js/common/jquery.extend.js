const $_ajax = $.ajax;

$.ajax = function(options){
	let opt = options || {};
	if(isValidLogin)return;
	let sucCallback = options.success;
    opt.success = function(res, status, xhr){
    	if(res.code == 'success'){

    	}
    	if(res.code == 'notLogin'){
    		isValidLogin = true;
    		alert("로그인 후 사용가능합니다.");
    		location.href = loginPage;
			return;
    	}
    	if(res.code == 'notAuth'){
    		alert("메뉴에 대한 권한이 없습니다.");
    		window.history.back();
			return;
    	}
    	if(res.code == 'exception'){
    		alert("시스템 처리 중 오류가 발생하였습니다.");
    		console.log('exception');
    		return
    	}
    	if(sucCallback instanceof Function){
    		sucCallback(res, status, xhr);
    	}
    }
    return $_ajax(opt);
};

$.fn.bootpagEx = function(opt){
	let defOpt = {
		total:16
	   ,maxVisible: 10
	   ,prev:'<i class="fa fa-chevron-left"></i>'
	   ,next:'<i class="fa fa-chevron-right"></i>'
	   ,wrapClass:'paging'
	   ,activeClass:'current'
    }
	let o = $.extend({},defOpt,opt);
	return $(this).bootpag(o);
}

$.fn.bootpagPo = function(opt){
	let defOpt = {
		total:16
	   ,maxVisible: 10
	   ,prev:'<'
	   ,next:'>'
 	   ,wrapClass:'pagination'
	   ,activeClass:'current'
	   ,firstLastUse: true
	   ,first: '<<'
	   ,last: '>>'
	}
	let o = $.extend({},defOpt,opt);
	return $(this).bootpag(o);
}

$.fn.extend({
	ui_setComponents :  function(data){ //셀렉터의 영역에서 key 값을 가진 컴포넌트들에 값을 자동으로 매핑
    	if(!data)return this;
    	for(var key in data){
    		try{
	    		var ob = $(this).find('[data='+key+'],[name='+key+']');
	    		if(ob.length > 0){
	    			ob.each(function(index,item){
	    				$(item).ui_setComponent(data[key]);
	    			});
	    		}
    		}catch(ex){}
    	}
    	return this;
    },
    ui_setComponent : function(val){
    	var item = this;

    	var tagName = item[0].tagName.toLowerCase();
		if('div,span,td,textarea'.indexOf(tagName) > -1){
			item.html(val);
		}else if('input' == tagName){
			if(item.attr('type') == 'text' || item.attr('type') == 'password'){
				item.val(val);
			}else if(item.attr('type') == 'radio'){
				item.filter('[value='+val+']').prop('checked',true);
			}else if(item.attr('type') == 'checkbox'){
				item.filter('[value='+val+']').prop('checked',true);
			}
		}else if('select' == tagName){
			item.val(val+'');
		}else{
			item.val(val);
		};
		return this;
    },
    serializeObject : function() {
    	var a = {}, b = function(b, c) {
    		var d = a[c.name];
    		"undefined" != typeof d && d !== null ? $.isArray(d) ? d.push(c.value)
    				: a[c.name] = [ d, c.value ] : a[c.name] = c.value
    	};
    	return $.each(this.serializeAll(), b), a;
    },
    serializeAll : function () {
	    var data = $(this).serializeArray();

	    $(':disabled[name]', this).each(function () {
	        data.push({ name: this.name, value: $(this).val() });
	    });

	    return data;
	},
	pressEnter : function(fn){
		this.each(function(){
			$(this).on('keypress',function(evt){
				if(evt.which == '13' && fn){
					fn(evt);
				};
			})
		})
		return this;
	}
});
