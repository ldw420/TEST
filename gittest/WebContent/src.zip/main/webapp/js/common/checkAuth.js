let authUtil = new Object();

authUtil.isLogin = function(){
	return !commUtil.isEmpty(authUtil.getAuthToken());
}
authUtil.getUserInfo = function(){
	let userInfo = commUtil.parseJwt(authUtil.getAuthToken());

	return userInfo;
}
authUtil.setAuthToken = function(token){
	if(token){
		let date = new Date();
		date.setTime(date.getTime()+ (3600 * 1000 * 12)); //쿠키 유지시간 12시간
		$.cookie('authToken',token,{expires: date,path:'/'});
	}
	return authUtil.getAuthToken()!=null;
}
authUtil.delAuthToken = function(){
	$.cookie('authToken',null,{expires:0,path:'/'})
}
authUtil.getAuthToken = function(){
	return $.cookie('authToken');
}
authUtil.refreshAuthToken = function(){
	return authUtil.setAuthToken(authUtil.getAuthToken());
}