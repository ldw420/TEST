

if(typeof jQuery == "undefined") {
	throw new Error("Require jQuery");
}

var loginPage = "/login.html";

/**
 * START : Ajax 처리 관련 메소드
 */
////////////////////////////////////////////////////////////////////////////////////////////////////
var commAjax = new Object();

	/**
	 * Description : getParameters
	 * Parameters : Request Parameters
	 * Example : 'http://localhost:8080/comn/index/getSysdate.xhr'
	 */
	//////////////////////////////////////////////////
	commAjax.getParameter = function (param) {
		var returnValue;
		var url = location.href;
		var parameters = (url.slice(url.indexOf('?') + 1, url.length)).split('&');

		for (var i = 0; i < parameters.length; i++) {
			var varName = parameters[i].split('=')[0];

			if (varName.toUpperCase() == param.toUpperCase()) {
				returnValue = parameters[i].split('=')[1];
				let v = decodeURIComponent(returnValue);
				return commUtil.xssString(v);
			}
		}
	}; // END : utilAjax.getParameter
	//////////////////////////////////////////////////

	/**
	 * Description : 요청보낼 URI 생성
	 * Parameters : urlSub - Controller's package/class/method, Request Parameters
	 * Example : 'http://localhost:8080/RMMS/syst/user/get.json?userId=jjanga&userNm=test'
	 */
	//////////////////////////////////////////////////
	commAjax.getUrl = function(reqUrl)
	{
		var strUrl = "";
		var uri = "";
		var cXhrKey = "";

		if(reqUrl.length < 2) {
			window.alert(_MESSAGE.M001);
			return false;
		} else {
			uri = reqUrl.pkgNm + "/" + reqUrl.clsNm + "/" + reqUrl.mthdNm;
		}

		// XHR_KEY 가 존재한다면...
		if(typeof $.cookie("CXHR_KEY") != "undefined") {
			cXhrKey = "?CXHR_KEY=" + $.cookie("CXHR_KEY");
		}

		// XMLHTTPRequest(Ajax) 요청보낼 URL
		strUrl = _CONSTANTS["URI_HOSTNAME"]
			+ _CONSTANTS["URI_PORT"]
			+ _CONSTANTS["URI_BASE"]
			+ uri
			+ _CONSTANTS["JSON_URL_PATTERN"]
			+ cXhrKey;

		return strUrl;
	}; // END : commAjax.getUrl
	//////////////////////////////////////////////////


	/**
	 * Description : Excel File Create 요청보낼 URI 생성
	 * Parameters[0] :
	 * Example : 'http://localhost:8080/RMMS/comn/excel/download.xls'
	 */
	//////////////////////////////////////////////////
	commAjax.getUrlXls = function()
	{

		// XHR_KEY 가 존재한다면...
		var cXhrKey = "";
		if(typeof $.cookie("CXHR_KEY") != "undefined") {
			cXhrKey = "?CXHR_KEY=" + $.cookie("CXHR_KEY");
		}

		var uri = "comn/excel/download";
		var strUrl = _CONSTANTS["URI_HOSTNAME"]
				+ _CONSTANTS["URI_PORT"]
				+ _CONSTANTS["URI_BASE"]
				+ uri
				+ _CONSTANTS["XLS_URL_PATTERN"]
				+ cXhrKey;

		return strUrl;
	}; // END : commAjax.getUrlXls
	//////////////////////////////////////////////////


	/**
	 * Description : Excel File Download 요청보낼 URI 생성
	 * Parameters[0] :
	 * Example : 'http://localhost:8080/RMMS/excel/download.xls'
	 */
	//////////////////////////////////////////////////
	commAjax.getUrlXlsDownload = function()
	{

		var uri = _CONSTANTS["EXCEL_DOWNLOAD_SUBFIX"];
		var strUrl = _CONSTANTS["URI_HOSTNAME"]
				+ _CONSTANTS["URI_PORT"]
				+ _CONSTANTS["URI_BASE"]
				+ uri;

		return strUrl;
	}; // END : commAjax.getUrlXlsDownload
	//////////////////////////////////////////////////


	/**
	 * Description : URL에서 정보 얻기
	 * Parameters[0] : URL
	 * Example :
	 * 	var myURL = parseURL('http://abc.com:8080/dir/index.html?id=255&m=hello#top');
	 *	myURL.file;	 // = 'index.html'
	 *	myURL.hash;	 // = 'top'
	 *	myURL.host;	 // = 'abc.com'
	 *	myURL.query;	// = '?id=255&m=hello'
	 *	myURL.params;   // = Object = { id: 255, m: hello }
	 *	myURL.path;	 // = '/dir/index.html'
	 *	myURL.segments; // = Array = ['dir', 'index.html']
	 *	myURL.port;	 // = '8080'
	 *	myURL.protocol; // = 'http'
	 *	myURL.source;   // = 'http://abc.com:8080/dir/index.html?id=255&m=hello#top'
	 *
	 */
	//////////////////////////////////////////////////
	commAjax.parseURL = function(url)
	{
		var a =  document.createElement('a');
		a.href = url;
		return {
			source: url,
			protocol: a.protocol.replace(':',''),
			host: a.hostname,
			port: a.port,
			query: a.search,
			params: (function(){
				var ret = {},
					seg = a.search.replace(/^\?/,'').split('&'),
					len = seg.length, i = 0, s;
				for (;i<len;i++) {
					if (!seg[i]) { continue; }
					s = seg[i].split('=');
					ret[s[0]] = s[1];
				}
				return ret;
			})(),
			file: (a.pathname.match(/\/([^\/?#]+)$/i) || [,''])[1],
			hash: a.hash.replace('#',''),
			path: a.pathname.replace(/^([^\/])/,'/$1'),
			relative: (a.href.match(/tps?:\/\/[^\/]+(.+)/) || [,''])[1],
			segments: a.pathname.replace(/^\//,'').split('/')
		};
	};
	//////////////////////////////////////////////////


	/**
	 * Description : Get JSON From Query String
	 * Parameters[0] : Query String
	 * Example :
	 */
	//////////////////////////////////////////////////
	commAjax.getJsonFromQry = function(qryString) {
		var hash;
		var json = {};
		var hashes = commAjax.getQueryString(qryString).split('&');
		for (var i = 0; i < hashes.length; i++) {
			hash = hashes[i].split('=');
			json[hash[0]] = hash[1];
		}
		return json;
	};
	commAjax.getQueryString = function(qryString){
		let query = decodeURIComponent(qryString||location.href);
		return query.slice(query.indexOf('?') + 1)
	}
	commAjax.getStringParams = function(){
		let args = arguments;
		let r = [];
		let json = commAjax.getJsonFromQry();
		for(let i in args){
			let p = args[i];
			r.push((p +'='+ (json[p]||'')));
		}
		return r.join('&');
	}
	//////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////


/**
 * START : 날짜 관련 메소드
 */
////////////////////////////////////////////////////////////////////////////////////////////////////
var commDate = new Object();


	/**
	 * Description : 현재 날짜, 시간 형식에 맞추어 변환
	 * Parameters : 형식, 년월일 구분자, 시분초 구분자
	 * Example : yMdhmsi : 년 월 일 시 분 초 밀리초
	 *			   매개변수가 없다면 Timestamp(밀리초까지) 반환
	 */
	//////////////////////////////////////////////////
	commDate.today = function(format, divFirst, divSecond)
	{
		this.format;
		this.divFirst;
		this.divSecond;

		var today = new Date();
		var returnDate = "";

		var argumentLength = commDate.today.arguments.length;

		// 매개변수에 따른 Overloading 처리
		if(argumentLength === 0) {
		// 매개변수가 없다면 Timestamp(밀리초까지) 반환
			return today.getTime();
		} else if(argumentLength === 1) {
			this.format = format;
			this.divFirst = "-";
			this.divSecond = ":";
		} else if(argumentLength === 2) {
			this.format = format;
			this.divFirst = divFirst;
			this.divSecond = ":";
		} else {
			this.format = format;
			this.divFirst = divFirst;
			this.divSecond = divSecond;
		}

		var todayYear = today.getFullYear();
		var todayMonth = today.getMonth() + 1;
		var todayMonth2 = today.getMonth();
		var todayDay = today.getDate();
		var todayHour = today.getHours();
		var todayMinute = today.getMinutes();
		var todaySecond = today.getSeconds();
		var todayMilliSecond = today.getMilliseconds();

		// 10보다 작을 경우 두자리수로 표현
		if(todayMonth < 10)		 todayMonth = "0" + todayMonth;
		if(todayMonth2 < 10)		 todayMonth2 = "0" + todayMonth2;
		if(todayDay < 10)		   todayDay = "0" + todayDay;
		if(todayHour < 10)		  todayHour = "0" + todayHour;
		if(todayMinute < 10)		todayMinute = "0" + todayMinute;
		if(todaySecond < 10)		todaySecond = "0" + todaySecond;
		if(todayMilliSecond < 10)   todayMilliSecond = "0" + todayMilliSecond;
		if(todayMilliSecond > 10 && todayMilliSecond < 100) todayMilliSecond = "00" + todayMilliSecond;

		var arrFormats = this.format.split("");
		var arrDates = new Array();
		var arrTimes = new Array();

		for(var i=0; i<arrFormats.length; i++) {
			switch(arrFormats[i])
			{
				case "y":
					arrDates.push(todayYear);
					break;
				case "M":
					arrDates.push(todayMonth);
					break;
				case "F":
					arrDates.push(todayMonth2);
					break;
				case "d":
					arrDates.push(todayDay);
					break;
				case "h":
					arrTimes.push(todayHour);
					break;
				case "m":
					arrTimes.push(todayMinute);
					break;
				case "s":
					arrTimes.push(todaySecond);
					break;
				case "i":
					arrTimes.push(todayMilliSecond);
					break;
			}
		} // for(var i=0; i<arrFormats.length; i++) {

		if(arrTimes.length > 0) {
			returnDate = arrDates.join(this.divFirst) + " " + arrTimes.join(this.divSecond);
		} else {
			returnDate = arrDates.join(this.divFirst);
		}

		return returnDate;

	}; // END : commDate.today
	//////////////////////////////////////////////////


	/**
	 * Description : 입력받은 Date Type을 String Type으로 변환
	 * Parameters : Date, Type(A:년-월-일, B:년-월-일 시:분:초, C:년-월, D:년, E:년월일, F:년월일시분초)
	 */
	//////////////////////////////////////////////////
	commDate.getDate = function(inputDate, returnType)
	{


		var originDate = new Date(inputDate);
		var returnDate = "";
		if(returnType == undefined || returnType == null || returnType == "") {
			returnType = "A";
		}

		var dateYear = originDate.getFullYear();
		var dateMonth = originDate.getMonth() + 1;
		var dateDay = originDate.getDate();
		var dateHour = originDate.getHours();
		var dateMinute = originDate.getMinutes();
		var dateSecond = originDate.getSeconds();

		// 10보다 작을 경우 두자리수로 표현
		if(dateMonth < 10)		 dateMonth = "0" + dateMonth;
		if(dateDay < 10)		   dateDay = "0" + dateDay;
		if(dateHour < 10)		  dateHour = "0" + dateHour;
		if(dateMinute < 10)		dateMinute = "0" + dateMinute;
		if(dateSecond < 10)		dateSecond = "0" + dateSecond;

		if(returnType == "B") {
			returnDate = dateYear + "-" + dateMonth + "-" + dateDay + " " + dateHour + ":" + dateMinute + ":" + dateSecond;
		} else if(returnType == "C") {
			returnDate = dateYear + "-" + dateMonth;
		} else if(returnType == "D") {
			returnDate = dateYear;
		} else if(returnType == "E") {
			returnDate = dateYear + dateMonth + dateDay;
		} else if(returnType == "A") {
			returnDate = dateYear + "-" + dateMonth + "-" + dateDay;
		} else if(returnType == "F") {
			returnDate = dateYear + dateMonth + dateDay + dateHour + dateMinute + dateSecond;
		}

		return returnDate;

	}; // END : commDate.getDate
	//////////////////////////////////////////////////



	/**
	 * Description : 입력받은 Date Type을 String Type으로 변환 (YYYYMMDD)
	 * Parameters : Date, Type(A:년-월-일, B:년-월-일 시:분:초, C:년-월, D:년, E:년월일, F:년월일시분초)
	 */
	//////////////////////////////////////////////////
	commDate.getDateB = function(inputDate, returnType)
	{

		var returnDate = "";

		if(returnType == undefined || returnType == null || returnType == "") {
			returnType = "A";
		}

		var dateYear = inputDate.substring(0,4);
		var dateMonth = inputDate.substring(4,6);
		var dateDay = inputDate.substring(6,8);

		if(returnType == "B") {
			returnDate = dateYear + "-" + dateMonth + "-" + dateDay + " " + dateHour + ":" + dateMinute + ":" + dateSecond;
		} else if(returnType == "C") {
			returnDate = dateYear + "-" + dateMonth;
		} else if(returnType == "D") {
			returnDate = dateYear;
		} else if(returnType == "E") {
			returnDate = dateYear + dateMonth + dateDay;
		} else if(returnType == "A") {
			returnDate = dateYear + "-" + dateMonth + "-" + dateDay;
		} else if(returnType == "F") {
			returnDate = dateYear + dateMonth + dateDay + dateHour + dateMinute + dateSecond;
		}

		return returnDate;

	}; // END : commDate.getDate
	//////////////////////////////////////////////////


	/**
	 * Description : 입력일 기준으로 이전, 이후 날짜 반환
	 * Parameters[0] : Date
	 * Parameters[1] : Return Type(A:년-월-일, B:년월일, C:년/월/일, D:년-월, E:년월, F:년/월, G:년)
	 * Parameters[2] : 이전 혹은 이후 일
	 * Parameters[3] : 이전 혹은 이후 월
	 * Example : commDate.getDay(new Date(), 'A') -> '2014-05-12'
	 * 				commDate.getDay(new Date('2014-05-12'), 'A', -3, -2) -> '2014-03-09'
	 */
	//////////////////////////////////////////////////
	commDate.getDay = function(date, type, boaDay, boaMonth, boaYear)
	{
		if(typeof date == 'undefined' || date == null || date == "") {
			date = new Date();
		}
		if(typeof type == 'undefined' || type == null || type == "") {
			type = "A";
		}
		if(typeof boaDay == 'undefined' || boaDay == null || boaDay == "") {
			boaDay = 0;
		}
		if(typeof boaMonth == 'undefined' || boaMonth == null || boaMonth == "") {
			boaMonth = 0;
		}
		if(typeof boaYear == 'undefined' || boaYear == null || boaYear == "") {
			boaYear = 0;
		}

		date.setFullYear(date.getFullYear() + Number(boaYear));
		date.setMonth(date.getMonth() + Number(boaMonth));
		date.setDate(date.getDate() + Number(boaDay));


		var dateYear = date.getFullYear();
		var dateMonth = date.getMonth() + 1;
		var dateDay = date.getDate();

		// 10보다 작을 경우 두자리수로 표현
		if(dateMonth < 10)		 dateMonth = "0" + dateMonth;
		if(dateDay < 10)		   dateDay = "0" + dateDay;

		if(type == "A") {
			date = dateYear + "-" + dateMonth + "-" + dateDay;
		} else if(type == "B") {
			date = dateYear + dateMonth + dateDay;
		} else if(type == "C") {
			date = dateYear + "/" + dateMonth + "/" + dateDay;
		} else if(type == "D") {
			date = dateYear + "-" + dateMonth;
		} else if(type == "E") {
			date = dateYear + dateMonth;
		} else if(type == "F") {
			date = dateYear + "/" + dateMonth;
		} else if(type == "G") {
			date = dateYear;
		}

		return date;

	}; // END : commDate.getDay
	//////////////////////////////////////////////////

	commDate.getStatDate = function()
	{
		var endDate = commDate.getDay(new Date(), 'A', _CONSTANTS["LONG_NONIO_START_DAY"], _CONSTANTS["LONG_NONIO_START_MONTH"], _CONSTANTS["LONG_NONIO_START_YEAR"]);

		return endDate;
	};
	commDate.getEndDate = function()
	{
		var statDate  = commDate.getDay(new Date(), 'A', _CONSTANTS["LONG_NONIO_END_DAY"], _CONSTANTS["LONG_NONIO_END_MONTH"], _CONSTANTS["LONG_NONIO_END_YEAR"]);

		 return statDate;
	};
	// END : commDate.getDay
	//////////////////////////////////////////////////

	/**
	 * Description : 현재시각(서버) 조회(SQL 이용)
	 */
	//////////////////////////////////////////////////
	commDate.getSysdate = function() {

		if(_CONSTANTS["IS_DEBUG"] === true) {

			var uri = new Object();
				uri.pkgNm = "comn";
				uri.clsNm = "sysdate";
				uri.mthdNm = "get";

			// Get XMLHTTPRequest Full URL
			var reqUrl = commAjax.getUrl(uri);
			var reqData = "";

			// XMLHTTPRequest
			$.getJSON(reqUrl, function(data, textStatus, jqXHR) {

				/*
				if(data.RESULTS != "EMPTY") {
					$("#sysdate").html(data.RESULTS + ".");

					if(typeof $.cookie("USR_ID") != "undefined" && $.cookie("USR_ID") != "") {
						$("#sysdate").append("&nbsp;You are " + $.cookie("USR_ID") + ".");
					} else {
						$("#sysdate").append("&nbsp;You are Unknown.");
					}
				}
				*/
			});

		}
	}; // END : commDate.getSysdate
	//////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////


/**
 * START : Form 관련 메소드
 */
////////////////////////////////////////////////////////////////////////////////////////////////////
var commForm = new Object();

	/**
	 * Description : 해당 요소의 선택 혹은 입력 값 가져오기
	 * Parameters : 요소 ID
	 * Example : Checkbox, Select 가 Multiple 일 경우에는 "," 구분자로 구분하여 값을 반환.
	 *		   Checkbox, Radio 는 ID 에 해당하는 NAME으로 조회.
	 */
	//////////////////////////////////////////////////
	commForm.getVal = function(elemId) {
		// 매개변수
		this.elemId;		// 타겟 엘리먼트 ID

		// 매개변수 값 대입
		this.elemId = "#" + elemId;

		var elemValue = "";

		// 엘리먼트가 존재한다면...
		if($(this.elemId)) {
			var tagName = $(this.elemId).get(0).tagName;
			tagName = tagName.toLowerCase();

			var inputType = "";
			var elemName = $(this.elemId).attr("name");

			/**
			 * Tag Name 에 따른 처리
			 * input, textarea, select 태그만 처리
			 */
			if(tagName === "input") {
			// INPUT : checkbox, radio, text, hidden, password

				// Input Type
				inputType = $(this.elemId).attr("type");

				if(inputType === "checkbox") {
				// CHECKBOX : 같은 이름으로 여러개일 경우 ","으로 구분하여 반환

					var checkedCheckbox = "input[name=" + elemName + "]:checkbox:checked";

					$(checkedCheckbox).each(function(index) {

						if(index === 0) {
							elemValue = $(this).val();
						} else {
							elemValue += "," + $(this).val();
						}

					});

				} else if(inputType === "radio") {
				// RADIO :

					var checkedRadio = "input[name=" + elemName + "]:radio:checked";
					elemValue = $(checkedRadio).val();

				} else if(inputType === "text") {
				// TEXT :

					elemValue = $(this.elemId).val();

				} else if(inputType === "hidden") {
				// HIDDEN :

					elemValue = $(this.elemId).val();

				} else if(inputType === "password") {
				// PASSWORD :

					elemValue = $(this.elemId).val();

				} // if(inputType === "checkbox") {

			} else if(tagName === "textarea") {
			// TEXTAREA : 줄바꿈, 앞뒤 공백 처리

				elemValue = $(this.elemId).val().replace( /\r?\n/g, "\r\n" );
				elemValue = $.trim(elemValue);

			} else if(tagName === "select") {
			// SELECT : 멀티, 싱글 셀렉트 구분 처리

				if($(this.elemId).attr("multiple")) { // Multiple

					elemValue = $(this.elemId).val() || [];
					elemValue = elemValue.join(",");

				} else { // Single

					elemValue = $(this.elemId).val();

				}

			} else {
				return false;
			} // if(tagName === "input") {

		} // if(!$(this.elemId)) {

		return elemValue;
	}; // END : commForm.getVal
	//////////////////////////////////////////////////


	/**
	 * Description : 해당 요소에 값넣기, 값에 해당하는 요소 선택하기
	 * Parameters : 요소 ID, 요소 값(","를 구분자로 사용)
	 */
	//////////////////////////////////////////////////
	commForm.setElem = function(elemId, elemVal) {
		// 매개변수
		this.elemId;		// 타겟 엘리먼트 ID
		this.elemVal = new Array(); // 엘리먼트 값(배열로 변환)

		/**
		 * 매개변수 값 대입
		 */
		this.elemId = "#" + elemId;
		var arrElemVals = elemVal.split(",");
		var elemLength = arrElemVals.length;

		// 엘리먼트가 존재한다면...
		if($(this.elemId)) {
			var tagName = $(this.elemId).get(0).tagName;
			tagName = tagName.toLowerCase();

			var inputType = "";
			var elemName = $(this.elemId).attr("name");

			/**
			 * Tag Name 에 따른 처리
			 * input, textarea, select 태그만 처리
			 */
			if(tagName === "input") {
			// INPUT : checkbox, radio, text, hidden, password

				// Input Type
				inputType = $(this.elemId).attr("type");
				var thisVal = "";

				if(inputType === "checkbox") {
				// CHECKBOX : 같은 이름의 체크박스가 여러개일 경우 "," 구분자로 값을 받아 처리

					var elemCheckbox = "input[name=" + elemName + "]:checkbox";
					$(elemCheckbox).each(function(index) {
						thisVal = $(this).val();
						for(var i=0; i<elemLength; i++) {
							if(thisVal === $.trim(arrElemVals[i])) {
								$(this).attr("checked", true);
							}
						}
					});

				} else if(inputType === "radio") {
				// RADIO

					var elemRadio = "input[name=" + elemName + "]:radio";
					$(elemRadio).each(function(index) {
						thisVal = $(this).val();
						for(var i=0; i<elemLength; i++) {
							if(thisVal === $.trim(arrElemVals[i])) {
								$(this).attr("checked", true);
							}
						}
					});

				} else if(inputType === "text") {
				// TEXT

					$(this.elemId).val(arrElemVals[0]);

				} else if(inputType === "hidden") {
				// HIDDEN

					$(this.elemId).val(arrElemVals[0]);

				} else if(inputType === "password") {
				// PASSWORD

					$(this.elemId).val(arrElemVals[0]);

				} // if(inputType === "checkbox") {

			} else if(tagName === "textarea") {
			// TEXTAREA

				$(this.elemId).val(arrElemVals[0]);

			} else if(tagName === "select") {
			// SELECT : 싱글, 멀티 셀렉트도 처리

				$(this.elemId).find("option").each(function() {
					thisVal = $(this).val();
					for(var i=0; i<elemLength; i++) {
						if(thisVal === $.trim(arrElemVals[i])) {
							$(this).attr("selected", true);
						}
					}
				});

			} else {
				return false;
			} // if(tagName === "input") {

		} // if(!$(this.elemId)) {

	}; // END : commForm.setElem
	//////////////////////////////////////////////////

	/**
	 * Description : ALL 체크
	 * Parameters : ALL 체크 박스 이름, TD 체크 박스 이름
	 */
	commForm.checkScript = function(allname,name){

		$("#"+allname+"").click(function() {
			//클릭되었으면
	        if($("#"+allname+"").prop("checked")){
	            //input태그의 name이 chk인 태그들을 찾아서 checked옵션을 true로 정의
	            $("input[name="+name+"]").prop("checked",true);
	        //클릭이 안되있으면
	        }else{
	            //input태그의 name이 chk인 태그들을 찾아서 checked옵션을 false로 정의
	            $("input[name="+name+"]").prop("checked",false);
	        }
		});
	};

	/**
	 * Description : TD 체크 박스 해제 시 ALL 체크 박스 해제
	 * Parameters : ALL 체크 박스 이름, TD 체크 박스 이름
	 */
	commForm.nonCheck = function(allName,name){
        if ($("input[name="+name+"]:checked").length != $("input[name="+name+"]").length) {
        	$("#"+allName+"").prop("checked",false);
        }
	};


	/**
	 * Description : 지정한 Form 요소들의 값을 JSON 형의 데이터로 변환 - {"firstname":"Jesper","surname":"Aaberg","phone":["555-0100","555-0120"]}
	 * Parameters : Form ID
	 */
	//////////////////////////////////////////////////
	commForm.getValJson = function(formId) {

		this.formId;
		this.formId = "#" + formId;

		// URI 형태로 요소값 추출
		var serialVal = $(this.formId).serializeArray();
		var jsonData = JSON.stringify(serialVal);

		return jsonData;

	}; // END : commForm.getValJson
	//////////////////////////////////////////////////


	/**
	 * Description : 지정한 Form의 유효성 체크 (Input 에 required-data='true' Attribute 추가)
	 * Parameters : Form ID
	 */
	//////////////////////////////////////////////////
	commForm.checkValidate = function(formId) {
		var arrEmptyElemId = new Array();

		$("#" + formId).find("input[required-data='true']").each(function(index) {

			if($(this).val() == "" || $(this).val() == null) {
				arrEmptyElemId.push($(this).attr("id"));
			}

		});

		$("#" + formId).find("select[required-data='true']").each(function(index) {

			if($(this).val() == "" || $(this).val() == null) {
				arrEmptyElemId.push($(this).attr("id"));
			}

		});

		return arrEmptyElemId;

	}; // END : commForm.checkValid
	//////////////////////////////////////////////////


	/**
	 * Description : <select> 해당 요소에 값넣기 및 선택하기
	 * Parameters : 요소ID, JSON, 선택값
	 */
	//////////////////////////////////////////////////
	commForm.setSelect = function(elemId, jsonArr, selectedVal) {

		var selectElem = $("#" + elemId);
		selectElem.html("");

		// <select>가 존재한다면...
		if(selectElem) {

			for(var i=0; i<jsonArr.length; i++) {

				if(selectedVal && selectedVal === jsonArr[i].cd) {
					selectElem[0].options.add(new Option(jsonArr[i].cdNm, jsonArr[i].cd, "", "true"), i);
				} else {
					selectElem[0].options.add(new Option(jsonArr[i].cdNm, jsonArr[i].cd), i);
				}

			}

		}

	};
	//////////////////////////////////////////////////


	/**
	 * Description : <select> 해당 요소에 값넣기 및 선택하기 + 기본선택 추가
	 * Parameters : 요소ID, JSON, 선택값, 기본선택
	 */
	//////////////////////////////////////////////////
	commForm.setSelectNone = function(elemId, jsonArr, selectedVal) {

		var add = 0;
		var selectElem = $("#" + elemId);

		if(selectElem.length === 0) {
			return;
		}

		selectElem.html("");
		selectElem[0].options.add(new Option("전체", "", "", "true"), 0);
		add = 1;

		for(var i=0; i<jsonArr.length; i++) {

			if(selectedVal && selectedVal === jsonArr[i].cd) {
				selectElem[0].options.add(new Option(jsonArr[i].cdNm, jsonArr[i].cd, "", "true"), i+add);
			} else {
				selectElem[0].options.add(new Option(jsonArr[i].cdNm, jsonArr[i].cd), i+add);
			}

		}

	};
	//////////////////////////////////////////////////


	/**
	 * Description : <select> 해당 요소에 값넣기 및 선택하기 + 기본선택 추가
	 * Parameters : 요소ID, JSON, 선택값, 기본선택
	 *
	 * 팝업창 내에 등록시 초기설정 선택으로 해 주기위한 추가 메소드
	 */
	//////////////////////////////////////////////////
	commForm.setSelectNone2 = function(elemId, jsonArr, selectedVal) {

		var add = 0;
		var selectElem = $("#" + elemId);

		if(selectElem.length === 0) {
			return;
		}

		selectElem.html("");
		selectElem[0].options.add(new Option("선택", "", "", "true"), 0);
		add = 1;

		for(var i=0; i<jsonArr.length; i++) {

			if(selectedVal && selectedVal === jsonArr[i].cd) {
				selectElem[0].options.add(new Option(jsonArr[i].cdNm, jsonArr[i].cd, "", "true"), i+add);
			} else {
				selectElem[0].options.add(new Option(jsonArr[i].cdNm, jsonArr[i].cd), i+add);
			}

		}

	};
	//////////////////////////////////////////////////


	//////////////////////////////////////////////////
	commForm.setSelect2 = function(elemId, jsonArr) {

		var selectElem = $("#" + elemId);
		selectElem.html("");

		// <select>가 존재한다면...
		if(selectElem) {

			  selectElem.html("");
			  selectElem[0].options.add(new Option("선택", ""), 0);
			  add = 1;

			  for(var i=0; i<jsonArr.RESULTS.length; i++) {
				  selectElem[0].options.add(new Option(jsonArr.RESULTS[i], jsonArr.RESULTS[i]), i+add);
			  }

		}

	};
	//////////////////////////////////////////////////


	/**
	 * Description : 공통코드 ComboBox 생성 2nd
	 * Parameters : 공통코드영문명, Field ID, 선택값
	 */
	//////////////////////////////////////////////////
	commForm.getComnCdNew = function(comnCd, fieldId) {
		var comboBox = "";

		$.ajax({
			type: "GET",
			url : _CONSTANTS["URL_BASE"]+"code/useDetail/"+comnCd,
			data: "",
			dataType: "json",
			async: false,
			success : function(data, status, xhr) {

				if (data.code=="success") {

					var results = data.data.codeDetailList;
					$.each(results, function (i) {

							comboBox += "<option value='" + results[i].detailCodeId + "'>" + results[i].detailCodeNm + "</option>";

					});

					$("#" + fieldId).append(comboBox);

				}else{
					alert("공통 코드 상세 목록 조회 중 오류가 발생했습니다.");
				}
			},
			error: function(jqXHR, textStatus, errorThrown) {
				alert(errorThrown);
			}
		});
	};
	//////////////////////////////////////////////////
	//////////////////////////////////////////////////
	/**
	 * Description : 공통코드 ComboBox 생성 2nd
	 * Parameters : 공통코드영문명, Field ID, 선택값
	 */
	//////////////////////////////////////////////////
	commForm.getComnNmNew = function(comnCd, fieldId) {
		var comboBox = "";

		$.ajax({
			type: "GET",
			url : _CONSTANTS["URL_BASE"]+"code/useDetail/"+comnCd,
			data: "",
			dataType: "json",
			async: false,
			success : function(data, status, xhr) {

				if (data.code=="success") {

					var results = data.data.codeDetailList;
					$.each(results, function (i) {

							comboBox += "<option value='" + results[i].detailCodeNm + "'>" + results[i].detailCodeNm + "</option>";

					});

					$("#" + fieldId).append(comboBox);

				}else{
					alert("공통 코드 상세 목록 조회 중 오류가 발생했습니다.");
				}
			},
			error: function(jqXHR, textStatus, errorThrown) {
				alert(errorThrown);
			}
		});
	};


	//////////////////////////////////////////////////
	/**
	 * Description : Session Check
	 * Parameters :
	 */
	//////////////////////////////////////////////////
	commForm.getSessionCheck = function() {

		$.ajax({
			type: "GET",
			url : _CONSTANTS["URL_BASE"]+"loginCheck/",
			data: "",
			dataType: "json",
			async: true,
			success : function(data, status, xhr) {


			},
			error: function(jqXHR, textStatus, errorThrown) {
				alert(errorThrown);
			}
		});

	};



	/**
	 * Description : <select> 해당 요소에 선택 변경하기
	 * Parameters : 요소ID, 선택값
	 */
	//////////////////////////////////////////////////
	commForm.selectOption = function(elemId, selectedVal) {

		$("#" + elemId + " option[value='" + selectedVal + "']").attr("selected", "selected");

	};


////////////////////////////////////////////////////////////////////////////////////////////////////


/**
 * START : 문자열 관련 메소드
 */
////////////////////////////////////////////////////////////////////////////////////////////////////
var commString = new Object();

	/**
	 * Description : 문자열 자르기(한글 안깨지도록...)
	 * Parameters : 처리할 문자열, 길이, 말줄임표시
	 */
	//////////////////////////////////////////////////
	commString.cutString = function(string, length, tailString) {

		this.string;
		this.length;
		this.tailString;

		var argumentLength = commString.cutString.arguments.length;

		// 매개변수에 따른 Overloading 처리
		if(argumentLength === 2) {
			this.string = string;
			this.length = length;
			this.tailString = "";
		} else if(argumentLength === 3) {
			this.string = string;
			this.length = length;
			this.tailString = tailString;
		} else {
			return false;
		}

		var checkLength = 0;

		for(var i=0; i<this.string.length; i++) {

			// 한글은 2바이트로 처리
			if(this.string.charCodeAt(i) > 128) {
				checkLength += 2;
			} else {
				checkLength += 1;
			}

			// 원하는 길이로 잘라서 반환
			if(checkLength > this.length) {
				return this.string.substring(0, i) + this.tailString;
			}

		} // for(var i=0; i<this.string.length; i++) {

		return this.string;

	}; // END : commString.cutString
	//////////////////////////////////////////////////


	/**
	 * Description : Object내 문자열 Encoding(한글 안깨지도록...)
	 * Parameters : Object
	 */
	//////////////////////////////////////////////////
	commString.encodeObject = function(data) {
		for(var key in data){
			if(typeof data[key] === "string"){
				data[key] = encodeURI(data[key]);
			}
		}
		return data;
	};  // END : commString.encodeObject
	//////////////////////////////////////////////////


	/**
	 * Description : 문자열 중 html에서 제대로 표현되지 않는 값 변환
	 * Parameters : str 원본 String
	 */
	//////////////////////////////////////////////////
	commString.convertToStr = function(str) {
		var result = str;
		result = result.replace(/<</g,'&lt&lt;');
		result = result.replace(/>>/g,'&gt&gt;');

		return result;
	};  // END : commString.convertToStr
	//////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////


/**
 * START : Console 관련 메소드
 */
////////////////////////////////////////////////////////////////////////////////////////////////////
var konsole = new Object();

	/**
	 * Description : console.log Method 대체
	 * Parameters : Message
	 */
	//////////////////////////////////////////////////
	konsole.log = function(message)	{
		if(_CONSTANTS["IS_DEBUG"] === true) {
			if(window.console && typeof window.console.log === "function") {
				window.console.log(message);
			} else {
				//window.alert(message);
			}
		}
	}; // END : konsole.log
	//////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////////////////////////
var commUsr = new Object();

	//////////////////////////////////////////////////
	/**
	 * Description : User Log Out, Delete User Info Cookies
	 * Example :
	 */
	//////////////////////////////////////////////////
	commUsr.logOut = function() {
		authUtil.delAuthToken();
	};
	//////////////////////////////////////////////////
	/**
	 * Description : 화면별 권한 채크
	 * Parameters[0] : menuCd
	 * Example :
	 */
	//////////////////////////////////////////////////
	let isValidLogin = false;
	commUsr.menuAuthCheck = function()
	{
		if (!authUtil.isLogin()) {
			isValidLogin = true;
			$(location).attr("href", _CONSTANTS["LOGIN_URL"]);
			return;
		}


		param = {"menuUrl":$(location).attr('pathname')};

		$.ajax({
			type: "POST",
			url : _CONSTANTS["URL_BASE"]+"menuCheck/",
			data: JSON.stringify(param),
			contentType: 'application/json',
			dataType: "json",
			async: true,
			success : function(data, status, xhr) {


			},
			error: function(jqXHR, textStatus, errorThrown) {
				alert(errorThrown);
			}
		});

	};
	//////////////////////////////////////////////////

	/**
	 * Description : 좌측 메뉴 활성화
	 * Parameters[0] : menu_sunbun
	 * Example :
	 */
	//////////////////////////////////////////////////
	commUsr.leftMenuSel = function(menu_sunbun)
	{
		$(".left_menu_list li").removeClass("on");
		$(".left_menu_list li:eq("+menu_sunbun+")").addClass("on");

	};
	//////////////////////////////////////////////////

	//////////////////////////////////////////////////


	/**
	 * Description : "index.html" 에서 로그인여부 체크
	 */
	//////////////////////////////////////////////////
	commUsr.checkLogin = function() {

		var uri = new Object();
			uri.pkgNm = "syst";
			uri.clsNm = "usr";
			uri.mthdNm = "checkLogin";

		// Get XMLHTTPRequest Full URL
		var reqUrl = commAjax.getUrl(uri);
		var reqData = "";

		// XMLHTTPRequest
		$.getJSON(reqUrl, function(data, textStatus, jqXHR) {

			// 로그인하지않은 사용자 로그인페이지로 이동
			if(data.IS_LOGIN == "NO") {
				// 로그인 페이지로 이동
				$(location).attr("href", _CONSTANTS["LOGIN_URL"]);
			}

		});

	}; // END : commUsr.checkLogin
	//////////////////////////////////////////////////

	/* *************************************************************
	 * 메인팝업 */
	commUsr.mainPopup = function() {
		var reqData = "";
		var objReqUri = new Object();
		objReqUri.pkgNm = "syst";
		objReqUri.clsNm = "popup";
		objReqUri.mthdNm = "mainPopup";

		// Get XMLHTTPRequest Full URL
		var reqUrl = commAjax.getUrl(objReqUri);

		// XMLHTTPRequest
		$.post(reqUrl, reqData, function(data, textStatus, jqXHR) {
			konsole.log("REQUEST_URL :: " + data.REQUEST_URL);
			konsole.log("REQUEST_DATA :: " + JSON.stringify(data.REQUEST_DATA));
			konsole.log("RESULTS :: " + JSON.stringify(data.RESULTS));

			// Manage XMLHTTPRequest Result
			if(data.RESULTS != "EMPTY") {
				var arr = Array();
		    	arr = data.RESULTS[0];
	    		var url = arr.fileUrl;
				url = url + "?popupId=" + arr.popupId;

				if ($.cookie(arr.popupId) != "done") {
					var openWindows = window.open(url,arr.popupId,"width="+arr.popupWSize+",height="+arr.popupHSize+",top="+arr.popupHlc+",left="+arr.popupWlc+",toolbar=no,status=no,location=no,scrollbars=yes,menubar=no,resizable=yes");
					if (window.focus) {openWindows.focus()}
				}
			}
		});
	};
	/* ************************************************************* */

////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////


	/**
	 * START : 공통 사용 권한 관리
	 */
	////////////////////////////////////////////////////////////////////////////////////////////////////
	var comnAuth = new Object();
	comnAuth.MULTAUTH = "";

	// 다중 게시판 권한 가져오기
	comnAuth.getMultAuth = function(reqData) {
	    var objReqUri = new Object();
        objReqUri.pkgNm = "syst";
        objReqUri.clsNm = "brdMng";
        objReqUri.mthdNm = "getDetail";

	    // Get XMLHTTPRequest Full URL
	    var reqUrl = commAjax.getUrl(objReqUri);

	    // XMLHTTPRequest
	    $.ajax({
	    	type : "POST",
			url : reqUrl,
			data : reqData,
	    	async: false,
	    	success : function(data, textStatus, jqXHR) {
		        konsole.log("REQUEST_URL :: " + data.REQUEST_URL);
		        konsole.log("REQUEST_DATA :: " + JSON.stringify(data.REQUEST_DATA));
		        konsole.log("RESULTS :: " + JSON.stringify(data.RESULTS));

		        if(data.SESSION_CHECK!="ENDSESSION"){
		        	  // Manage XMLHTTPRequest Result
				    if(data.RESULTS != "EMPTY") {
				    	comnAuth.MULTAUTH = data.RESULTS[0].menuCd;
				    }
		       	}else{
		       		commUsr.logOut();
		       		alert("세션이 종료되었습니다.\n로그인페이지로 이동합니다.");
		   			$(location).attr("href", _CONSTANTS["LOGIN_URL"]);
		       	}
	    	}
	    });

	    return comnAuth.MULTAUTH;
	};

let commUtil = new Object();
commUtil.isEmpty = function(val){
	return ( val == null || val == undefined );
}
commUtil.isBlank = function(val){
	return ( !val || val.trim().length === 0 );
}
commUtil.parseInt = function(val,defVal){
	let v = 0;
	try{
		if($.isNumeric(val)){
			v = parseInt(val);
		}else{
			if($.isNumeric(defVal)){
				v = parseInt(defVal);
			}
		}
	}catch(ex){

	}
	return v;
}
commUtil.xssString = function(val){
	return val.replace(/&/gi, '&amp;').replace(/</gi, '&lt;').replace(/>/gi, '&gt;');
}
commUtil.checkEmail = function(val){
	let exptext = /^[A-Za-z0-9_\.\-]+@[A-Za-z0-9\-]+\.[A-Za-z0-9\-]+/;
	return exptext.test(val);
}
commUtil.checkPw = function(val){
    var pattern1 = /[0-9]/;
    var pattern2 = /[a-zA-Z]/;
    var pattern3 = /[~!@\#$%<>^&*.]/;//포함할수 있는 특수문자
    if(!pattern1.test(val)||!pattern2.test(val)||!pattern3.test(val)||val.length<8||val.length>50){
        return false;
    }else{
    	return true;
    }
}
commUtil.movePage = function(url,param,isPost,target){
	var method = isPost ? 'post': 'get';
	if(!url){
		console.log('빈 url');
		return;
	};
	var form = document.createElement('form');
	form.action = url;
	for(var key in param){
		var objs = document.createElement('input');
		objs.setAttribute('type', 'hidden');
		objs.setAttribute('name',  key);
		objs.setAttribute('value', param[key]);
		form.appendChild(objs);
	};
	form.setAttribute('method', method);
	form.setAttribute('action', url);
	form.target=target||'_blank';
	form.id='nForm';
	document.body.appendChild(form);
	form.submit();
}

commUtil.parseJwt = function(token) {
	let re = '';
	try{
    let base64Url = token.split('.')[1];
    let base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    let jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
    re = JSON.parse(jsonPayload);
	}catch(e){
		//console.log('jwt parsing error');
	}
    return re;
}
commUtil.overlay = function(){
	$('body #ajax-loading').show();
};
commUtil.removeOverlay = function(){
	$('body #ajax-loading').hide();
};
const toastPopId = "toastPopAlert";
commUtil.toastPop = function(val){
	
	if(commUtil.isEmpty(val)){
		console.log('not message');return;
	}
	let t = $('body').find('#'+toastPopId);
	t.html(val);
	onToastPop(toastPopId);
}
$(document).ready(function(){
	if ($(location).attr('pathname').indexOf('report')!=-1){
		$('#modalTest').append('<div id="ajax-loading"><div id="ajax-loading-image"><img src="/img_portal/ajax-loader.gif" alt="Loading..." /></div></div>')
					   .append('<div class="toastPop" id="'+toastPopId+'"/>');
	}else{
		$('body').append('<div id="ajax-loading"><div id="ajax-loading-image"><img src="/img_portal/ajax-loader.gif" alt="Loading..." /></div></div>')
				 .append('<div class="toastPop" id="'+toastPopId+'"/>');
	}
	$(document).ajaxStart(function(as){
		commUtil.overlay();
	}).ajaxStop(function(ae) {
		commUtil.removeOverlay();
	});
});