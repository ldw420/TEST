
if(typeof jQuery == "undefined") {
	throw new Error("Require jQuery");
}

(function($) { "use strict";

	/** @START Page Initialize
	/****************************************************************************************************/
	$(document).ready(function() {
		
		var tmpTop = new Object();
		
		tmpTop.init = function(menuCd) {
			
			var homeText = "Home";
			var homeUrl = _CONSTANTS["URL_BASE"] + "index.html";
			var pageTitle = ""; // 페이지 타이틀
			var dpth1stUrl = ""; // 1 Depth Url
			var dpth1stText = ""; // 1 Depth Title
			var dpth2ndUrl = ""; // 2 Depth Url
			var dpth2ndText = ""; // 2 Depth Title
			
			var menu = new Object();		
		    var reqUri = new Object();
	        	reqUri.pkgNm = "syst";
	        	reqUri.clsNm = "menu";
	        	reqUri.mthdNm = "get";

		    // Get XMLHTTPRequest Full URL
		    var reqUrl = commAjax.getUrl(reqUri);
		    var reqData = "menuCd=" + menuCd;

		    // Get This Menu Info
		    $.post(reqUrl, reqData, function(data, textStatus, jqXHR) {
		        konsole.log("REQUEST_URL :: " + reqUrl);
		        konsole.log("REQUEST_DATA :: " + reqData);
		        konsole.log("RESULTS :: " + JSON.stringify(data.RESULTS));
	        
		        // Manage XMLHTTPRequest Result
			    if(data.RESULTS != "EMPTY") {
			    	var results = data.RESULTS[0];

					menu.nm = results[1];
					menu.path = results[2];
					menu.dpth = Number(results[3]);
					menu.upMenuCd = results[4];
					menu.upMenuNm = results[5];
					menu.upMenuPath = results[6];
					
					if(menu.dpth == 2) {
					// 2 Depth Menu
						dpth1stUrl = _CONSTANTS["URL_BASE"] + menu.upMenuPath;
						dpth1stText = menu.upMenuNm;					
						dpth2ndUrl = _CONSTANTS["URL_BASE"] + menu.path;
						dpth2ndText = menu.nm;					
						pageTitle = menu.upMenuNm + " - " + menu.nm;
					} else {
					// 1 Depth Menu
						dpth1stUrl = _CONSTANTS["URL_BASE"] + menu.upMenuPath;
						dpth1stText = menu.upMenuNm;
						pageTitle = menu.upMenuNm + " - " + menu.nm;			
					}				
			    }
			    
			    // 화면 출력
				$("#topPageTitle").text(pageTitle);
				$("#topMenuHome").attr("href", homeUrl);
				$("#topMenuHome").text(homeText);
				$("#topMenuStep1st").text(dpth1stText);
				$("#topMenuStep1st").attr("href", dpth1stUrl);
			
				if(menu.dpth == 2) {
					$("#topMenuStep2nd").attr("href", dpth2ndUrl);
					$("#topMenuStep2nd").text(dpth2ndText);
				} else {
					$("#topMenuStep img").eq(2).hide();
					$("#topMenuStep2nd").hide();
				}		    
		    });		
		};		

		
		// Top HTML Tag
		var inHtml = '';		
			inHtml += '<div class="logo"><img src="' + _CONSTANTS["URL_BASE"] + 'images/img/logo.gif" id="btnLogo"></div>';
			inHtml += '<div class="loginfo"><span id="topUserName">' + $.cookie("USR_NM") + '</span>님이 로그인하셨습니다.&nbsp;<img src="' + _CONSTANTS["URL_BASE"] + 'images/btn/logout.gif" id="btnLogOut"></div>';
			
			inHtml += '<div class="tit">';
			inHtml += '		<img src="' + _CONSTANTS["URL_BASE"] + 'images/img/ico_dot.gif"><span id="topPageTitle"></span>';
			inHtml += '</div>';
			inHtml += '<div class="location" id="topMenuStep">';
			inHtml += '		<img src="' + _CONSTANTS["URL_BASE"] + 'images/img/ico_home.gif"><a href="" id="topMenuHome"></a>';
			inHtml += '		<img src="' + _CONSTANTS["URL_BASE"] + 'images/img/ico_arr.gif"><a href="" id="topMenuStep1st"></a>';
			inHtml += '		<img src="' + _CONSTANTS["URL_BASE"] + 'images/img/ico_arr.gif"><a href="" id="topMenuStep2nd"></a>';
			inHtml += '</div>';	

		$("body #scontainer").prepend(inHtml);	
		
		// User Log out
		$("#btnLogOut").click(function(event) {
			commUsr.logOut();
			$(location).attr("href",  _CONSTANTS["URL_BASE"] + "login.html");
		});
		
		// Link Index.html
		$("#btnLogo").click(function(event) {
			$(location).attr("href",  _CONSTANTS["URL_BASE"] + "index.html");
		});			
		
	});
	/****************************************************************************************************/
	/** @END Page Initialize */
	
}(jQuery));