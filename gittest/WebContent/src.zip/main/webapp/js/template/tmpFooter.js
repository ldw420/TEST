

if(typeof jQuery == "undefined") {
	throw new Error("Require jQuery");
}

(function($) { "use strict";



}(jQuery));