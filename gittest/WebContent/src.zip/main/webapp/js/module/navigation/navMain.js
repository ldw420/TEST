	if(typeof jQuery == "undefined") {
		throw new Error("Require jQuery");
	}

	var navMain = new Object();

	let userInfo = null;
	(function($) { "use strict";

	var inHtml = "";

	inHtml += '<div class="header_top_inner">';
	inHtml += '	<a href="/main.html" class="top_logo">관리자</a>';
	inHtml += '	<div class="top_right">';
	inHtml += '		<span></span>';
	inHtml += '		<a href="#" onclick="nLogout()">로그아웃</a>';
	inHtml += '	</div>';
	inHtml += '</div>';
	$("#navMain").html(inHtml);

	var inLeftHtml = '';

	inLeftHtml += '	<ul class="left_menu_list">';
	inLeftHtml += '		<li><a href="javascript:menuUrlLink(\'M0002\');"><span>공통코드</span></a></li>';
	inLeftHtml += '		<li><a href="javascript:menuUrlLink(\'M0003\');"><span>사용자관리</span></a></li>';
	inLeftHtml += '		<li><a href="javascript:menuUrlLink(\'M0004\');"><span>권한관리</span></a></li>';
	inLeftHtml += '		<li><a href="javascript:menuUrlLink(\'M0005\');"><span>인스턴스 정보 관리</span></a></li>';
	inLeftHtml += '		<li><a href="javascript:menuUrlLink(\'M0006\');"><span>용어집 관리</span></a></li>';
	inLeftHtml += '		<li><a href="javascript:menuUrlLink(\'M0007\');"><span>서약서 관리</span></a></li>';
	inLeftHtml += '		<li><a href="javascript:menuUrlLink(\'M0008\');"><span>메뉴 관리</span></a></li>';
	inLeftHtml += '		<li><a href="javascript:menuUrlLink(\'M0009\');""><span>Tableau 레포트 관리</span></a></li>';
	inLeftHtml += '		<li><a href="javascript:menuUrlLink(\'M0010\');""><span>게시판 관리</span><i class="fa fa-angle-down"></i></a>';
	inLeftHtml += '			<ul>';
	inLeftHtml += '				<li><a href="javascript:menuUrlLink(\'M0011\');""><span>FAQ관리</span></a></li>';
	inLeftHtml += '				<li><a href="javascript:menuUrlLink(\'M0012\');""><span>QNA관리</span></a></li>';
	inLeftHtml += '				<li><a href="javascript:menuUrlLink(\'M0013\');""><span>공지사항관리</span></a></li>';
	inLeftHtml += '			</ul>';
	inLeftHtml += '		</li>';
	inLeftHtml += '		<li><a href="javascript:menuUrlLink(\'M0014\');""><span>활용사례 관리</span></a></li>';
	inLeftHtml += '		<li><a href="javascript:menuUrlLink(\'M0016\');""><span>권한 신청 관리</span></a></li>';
	inLeftHtml += '		<li><a href="javascript:menuUrlLink(\'M0017\');""><span>Tableau 갤러리 관리</span></a></li>';
	inLeftHtml += '		<li><a href="javascript:menuUrlLink(\'M0028\');""><span>관계사 정보 관리</span></a></li>';
	inLeftHtml += '	</ul>';
	$("#navLeft").html(inLeftHtml);

	// Footer HTML Tag
	var footerHtml = '';
		footerHtml += '	<p>We believe Data can improve the quality of human life</p>';
		footerHtml += '<div class="footer_inner">';
		footerHtml += '	<span class="btm_logo">COEUS</span>';
		footerHtml += '	Copyright © COEUS of SK Holdings, C&C. All rights reserved.';
		footerHtml += '</div>';

	$("footer").append(footerHtml);

	// 팝업창 사이즈 조절 함수
	try{
		setPop();
	}catch(e){

	}

	/** @START Page Initialize
	/****************************************************************************************************/

	}(jQuery));


	navMain.init = function() {

		userInfo = authUtil.getUserInfo();
		var inHeaderHtml = '';

		inHeaderHtml += '	<div class="header_inner">';
		inHeaderHtml += '	<a href="/main.html" class="coeus_logo">COEUS</a>';
		inHeaderHtml += '	<nav>';
		inHeaderHtml += '	<ul>';
		inHeaderHtml += '		<li><a href="/db/mydashboard.html">My Dashboard</a></li>';
		inHeaderHtml += '  		<li><a href="/dc/catalogue.html">카탈로그</a></li>';
		if (userInfo.authId =="A0003" || userInfo.authId =="A0004" || userInfo.authId =="A0005") {
			inHeaderHtml += '  		<li><a href="#" onClick="alert(\'메뉴에 대한 권한이 없습니다.\');">분석환경</a>';
		}else {
			inHeaderHtml += '  		<li><a href="/ae/analsList.html">분석환경</a>';
		}
		inHeaderHtml += '  			<ul>';
		if (userInfo.authId =="A0003" || userInfo.authId =="A0004" || userInfo.authId =="A0005") {
			inHeaderHtml += '  				<li><a href="#" onClick="alert(\'메뉴에 대한 권한이 없습니다.\');"  class="sagemaker">SageMaker</a></li>';
		} else {
			inHeaderHtml += '  				<li><a href="/ae/analsList.html" class="sagemaker">SageMaker</a></li>';
		}
	//	inHeaderHtml += '  				<li><a href="http://skytale-1434641513.ap-northeast-2.elb.amazonaws.com:8080/skytale/" class="skytale"  target="_blank">SKYTALE</a></li>';
		inHeaderHtml += '  			</ul>';
		inHeaderHtml += '		</li>';
		inHeaderHtml += '			<li>';
		inHeaderHtml += '			<a href="/bi/gallery.html">시각화도구</a>';
		inHeaderHtml += '			<ul>';
		inHeaderHtml += '				<li><a href="/bi/gallery.html">갤러리</a></li>';
		if (userInfo.authId =="A0003") {
			inHeaderHtml += '				<li><a href="#" onClick="alert(\'메뉴에 대한 권한이 없습니다.\');">리포트</a></li>';
		}else {
			inHeaderHtml += '				<li><a href="/bi/report.html">리포트</a></li>';
		}
		inHeaderHtml += '			</ul>';
		inHeaderHtml += '		</li>';
		inHeaderHtml += '		<li>';
		inHeaderHtml += '			<a href="/bbs/notice.html">커뮤니티</a>';
		inHeaderHtml += '		<ul>';
		inHeaderHtml += '			<li><a href="/bbs/notice.html">공지사항</a></li>';
		inHeaderHtml += '			<li><a href="/bbs/faq.html">FAQ</a></li>';
		//inHeaderHtml += '			<li><a href="/bbs/qna.html">Q&A</a></li>';
		inHeaderHtml += '			</ul>';
		inHeaderHtml += '		</li>';
		inHeaderHtml += '		<li>';
		inHeaderHtml += '			<a href="https://coeus.skcc.com/docs/index.html"  target="_blank">사용가이드</a>';
		inHeaderHtml += '			<ul>';
		inHeaderHtml += '				<li><a href="https://coeus.skcc.com/docs/index.html" target="_blank">COEUS 소개</a></li>';
		inHeaderHtml += '			</ul>';
		inHeaderHtml += '		</li>';
		if (userInfo.authId =="A0001") {
			inHeaderHtml += '		<li><a href="/tools/ma/comnCdMng.html">Tools</a></li>';
		}
		inHeaderHtml += '	</ul>';
		inHeaderHtml += '		</nav>';
		inHeaderHtml += '	</div>';
		$(".portalMenu").html(inHeaderHtml);


		var inDashInfoHtml = '';

		inDashInfoHtml += '<div class="dash_info">';
		inDashInfoHtml += '			<div class="dash_info_box">';
		inDashInfoHtml += '				<div class="dash_info_inner">';
		inDashInfoHtml += '					<div class="info_box user">';
		inDashInfoHtml += '						<h2 class="gen">'+ userInfo.nm +'님</h2>';
		inDashInfoHtml += '						<span class="pos">'+ userInfo.authNm +' / '+ userInfo.agencyNm +'</span>';
		inDashInfoHtml += '						<span class="status" onclick="showModal(\'reqAuth\'); return false;">권한신청</span>';
		inDashInfoHtml += '					</div>';
		inDashInfoHtml += '					<div class="info_box req">';
		inDashInfoHtml += '						<ul>';
		if (userInfo.authId =="A0001" || userInfo.authId =="A0002") {
			inDashInfoHtml += '							<li class="review">';
			inDashInfoHtml += '								검토할 요청';
			inDashInfoHtml += '								<a href="/db/mydashboard.html"><span class="num" id="topConfmAppCnt"></span></a>	';
			inDashInfoHtml += '							</li>';
		}
		inDashInfoHtml += '							<li class="ready">';
		inDashInfoHtml += '								승인대기 요청';
		inDashInfoHtml += '								<a href="/db/mydashboard.html"><span class="num" id="topConfmApp"></span></a>		';
		inDashInfoHtml += '							</li>';
		inDashInfoHtml += '						</ul>';
		inDashInfoHtml += '					</div>';
		inDashInfoHtml += '					<div class="info_box clipping">';
		inDashInfoHtml += '						<i class="cicon">clipping_icon</i>';
		inDashInfoHtml += '						클리핑한 데이터';
		inDashInfoHtml += '						<a href="/db/mydashboard.html"><span class="num" id="topMyScrapList"></span></a>		';
		inDashInfoHtml += '					</div>';
		inDashInfoHtml += '					<a class="logOut" href="#" onclick="nLogout()">로그아웃</a>';
		inDashInfoHtml += '				</div>';
		inDashInfoHtml += '			</div>';
		inDashInfoHtml += '		</div>';

		var inDashInfoHtml2 = '';
		inDashInfoHtml2 += '<div class="dash_info_box">';
		inDashInfoHtml2 += '	<div class="dash_info_inner">';
		inDashInfoHtml2 += '		<div class="info_box user">';
		inDashInfoHtml2 += '			<h2 class="gen">'+ userInfo.nm +'님의 Dashboard</h2>';
		inDashInfoHtml2 += '			<span class="pos">'+ userInfo.authNm +' / '+ userInfo.agencyNm +'</span>';
		inDashInfoHtml2 += '			<span class="status" onclick="showModal(\'reqAuth\'); return false;">권한신청</span>';
		inDashInfoHtml2 += '		</div>';
		inDashInfoHtml2 += '		<div class="myDashList">';
		inDashInfoHtml2 += '			<ul>';
		if (userInfo.authId =="A0001" || userInfo.authId =="A0002") {
			inDashInfoHtml2 += '				<li class="fst">';
			inDashInfoHtml2 += '					<h3>검토할 요청</h3>';
			inDashInfoHtml2 += '					<div class="myDashNum">';
			inDashInfoHtml2 += '						<a href="/db/mydashboard.html"><p id="confmAppCnt"></p></a>';
			inDashInfoHtml2 += '					</div>';
			inDashInfoHtml2 += '				</li>';
		}
		inDashInfoHtml2 += '				<li class="req">';
		inDashInfoHtml2 += '					<h3>나의 요청 현황</h3>';
		inDashInfoHtml2 += '					<div class="myDashNum w33 ing">';
		inDashInfoHtml2 += '						<span>처리중</span>';
		inDashInfoHtml2 += '						<a href="/db/mydashboard.html"><p id="confmApp"></p></a>';
		inDashInfoHtml2 += '					</div>';
		inDashInfoHtml2 += '					<div class="myDashNum w33 app">';
		inDashInfoHtml2 += '						<span>승인</span>';
		inDashInfoHtml2 += '						<a href="/db/mydashboard.html"><p id="confmAppOk"></p></a>';
		inDashInfoHtml2 += '					</div>';
		inDashInfoHtml2 += '					<div class="myDashNum w33 rtn">';
		inDashInfoHtml2 += '						<span>반려</span>';
		inDashInfoHtml2 += '						<a href="/db/mydashboard.html"><p id="confmAppNo"></p></a>';
		inDashInfoHtml2 += '					</div>';
		inDashInfoHtml2 += '				</li>';
		inDashInfoHtml2 += '			</ul>';
		inDashInfoHtml2 += '		</div>';
		inDashInfoHtml2 += '		<a class="logOut" href="#" onclick="nLogout()">로그아웃</a>';
		inDashInfoHtml2 += '	</div>';
		inDashInfoHtml2 += '</div>';

		var shrAppHtml ='';
		shrAppHtml +='	<div class="toastPop" id="toastPop3">';
		shrAppHtml +='	권한 요청이 전송되었습니다.';
		shrAppHtml +='</div>';
		shrAppHtml +='<div class="modal_pop dataSet" id="reqAuth">';
		shrAppHtml +='	<div class="modal_pop_top">';
		shrAppHtml +='		<h3>권한 요청</h3>';
		shrAppHtml +='		<a href="#" onclick="hideModal(\'reqAuth\'); return false;">닫기</a>';
		shrAppHtml +='	</div>';
		shrAppHtml +='	<div class="modal_pop_cont">';
		shrAppHtml +='		<div class="modal_pop_cont_inner">';
		shrAppHtml +='			<div class="shareReport_box">';
		shrAppHtml +='				<ul>';
		shrAppHtml +='					<li>';
		shrAppHtml +='						<div class="shareRpt_ipt">';
		shrAppHtml +='							<h2>요청권한</h2>';
		shrAppHtml +='							<div class="radioBox auth">';
		shrAppHtml +='								<input type="radio" id="shareA" name="share" checked  value="A0006">';
		shrAppHtml +='								<label for="shareA" id="authDiscA" class="on">Data Scientist</label>';
		shrAppHtml +='								<input type="radio" id="shareB" name="share"  value="A0004">';
		shrAppHtml +='								<label for="shareB" id="authDiscB" >Data Analyst</label>';
		shrAppHtml +='								<input type="radio" id="shareC" name="share"  value="A0005">';
		shrAppHtml +='								<label for="shareC" id="authDiscC" >Data Analyst (C)</label>';
		shrAppHtml +='								<input type="radio" id="shareD" name="share" value="A0002">';
		shrAppHtml +='								<label for="shareD" id="authDiscD" >Data Steward</label>';
		shrAppHtml +='								<input type="radio" id="shareE" name="share" value="A0007">';
		shrAppHtml +='								<label for="shareD" id="authDiscE" >Data Scientist (C)</label>';
		shrAppHtml +='							</div>';
		shrAppHtml +='						</div>';
		shrAppHtml +='					</li>';
		shrAppHtml +='					<li>';
		shrAppHtml +='						<div class="shareRpt_ipt">';
		shrAppHtml +='							<h2>권한상세</h2>';
		shrAppHtml +='							<p class="info txt authDiscA">Python, R 사용이 가능한 통계/머신러닝 분석가 COEUS에서 제공하는 Notebook을 사용하기 위해 Data Steward에게 분석환경 사용 권한 획득이 필요하다.</p>';
		shrAppHtml +='							<p class="info txt authDiscB" style="display:none">각 비즈니스 조직에서 Domain에 대한 깊은 이해와 기본적인 이론적 분석역량을 모두 가지고 있어, 데이터 기반 업무 혁신을 리드하는 분석가 역할을 한다. COEUS에서 제공하는 BI Report을 조회할 수 있으며, 별도로 관리되는 Report을 조회하기 위해서는 Data Steward에게 권한획득이 필요하다.</p>';
		shrAppHtml +='							<p class="info txt authDiscC" style="display:none">각 비즈니스 조직에서 Domain에 대한 깊은 이해와 기본적인 이론적 분석역량을 모두 가지고 있어, 데이터 기반 업무 혁신을 리드하는 분석가 역할을 한다. COEUS에서 제공하는 BI Report을 조회할 수 있으며, 별도로 관리되는 Report을 조회하기 위해서는 Data Steward에게 권한획득이 필요하다. Report 생성 및 변형을 하기 위한 Tool 사용 권한 승인을 Data Steward로 부터 받아야 한다.</p>';
		shrAppHtml +='							<p class="info txt authDiscD" style="display:none">각 사의 Data Governance을 관리하는 담당자로서, 데이터 공유요청 승인 및 레포트 공유, 데이터 기준 정보, 품질, 보안 Life cycle을 관리감독하는 역할을 한다.</p>';
		shrAppHtml +='							<p class="info txt authDiscE" style="display:none">Python, R 사용이 가능한 통계/머신러닝 분석가 COEUS에서 제공하는 Notebook을 사용하기 위해 Data Steward에게 분석환경 사용 권한 획득이 필요하다.</p>';
		shrAppHtml +='						</div>';
		shrAppHtml +='					</li>';
		shrAppHtml +='					<li>';
		shrAppHtml +='						<div class="shareRpt_ipt inTextarea">';
		shrAppHtml +='							<h2>요청사유</h2>';
		shrAppHtml +='							<textarea id="inTextarea1" placeholder="요청사유를 입력해주세요!"></textarea>';
		shrAppHtml +='						</div>';
		shrAppHtml +='					</li>';
		shrAppHtml +='				</ul>';
		shrAppHtml +='			</div>';
		shrAppHtml +='		</div>';
		shrAppHtml +='	</div>';
		shrAppHtml +='	<div class="modal_pop_btm">';
		shrAppHtml +='		<a href="#" class="cancel_btn" id ="cancel_btn_auth" return false;>취소</a>';
		shrAppHtml +='		<a href="#" class="btnType submit_btn1 disable" return false; id="nReqAuthSubmit1">권한요청</a>';
		shrAppHtml +='	</div>';
		shrAppHtml +='</div>';
		shrAppHtml +='<div class="mask"></div>';


		if ( !$(".dash_info").hasClass('myDashboard') ){
			$(".dash_info").html(inDashInfoHtml+shrAppHtml);
		}else {
			$(".dash_info").html(inDashInfoHtml2+shrAppHtml);
		}

		if ($(location).attr('pathname')!="/login.html" && $(location).attr('pathname')!="/join.html" && $(location).attr('pathname')!="/joinOk.html") {
			navMain.dataCount();
		}

		try{
		setPop();
		}catch(ex){}

	}

	navMain.dataCount=function(){

		var param = {
				"div": "0"
		}

		$.ajax({
			type: "POST",
			url :  _CONSTANTS["URL_BASE"]+ 'main/mydashboard',
			data: JSON.stringify(param),
			contentType: 'application/json',
			async: true,
			success : function(data, status, xhr) {


				var confmApp = 0;
				var confmAppOk = 0;
				var confmAppNo = 0;

				if (data.code=="success") {
					//검토할 요청
					var mydashboardDetail = data.data.confmAppCnt;
					$("#topConfmAppCnt").empty().append(data.data.confmAppCnt);

					var myAppCnt = data.data.myAppCnt;

					//나의 요청 현황
					$.each(myAppCnt, function (i) {
						 if (myAppCnt[i].sttus=="00001") {
							 //요청
							 confmApp=confmApp+myAppCnt[i].cnt;
						 }else if (myAppCnt[i].sttus=="00002") {
							 //승인
							 confmAppOk=confmAppOk+myAppCnt[i].cnt;
						 }else if (myAppCnt[i].sttus=="00003") {
							 //반려
							 confmAppNo=confmAppNo+myAppCnt[i].cnt;
						 } else if (myAppCnt[i].sttus=="00004") {
							 //요청 +승인사 요청 완료
							 confmApp=confmApp+myAppCnt[i].cnt;
						 }
					});
					 //요청
					 $("#topConfmApp").empty().append(confmApp);

					 //스크랩 카운트
					var myScrapList = data.data.myScrapList;
					$("#topMyScrapList").empty().append(myScrapList.length);



				}else {
					alert("조회 중 오류가 발생했습니다.");
				}

			}
		});
	}

	$(document).ready(function() {
		navMain.init();

		$(".shareRpt_ipt .radioBox label").click(function(){

			$(".shareRpt_ipt .radioBox label").removeClass('on');

			if( $(this).hasClass('on') ){
				$(this).removeClass('on');
			}else{
				$(this).addClass('on');
				$("p.info.txt").hide();
				$("p.info.txt."+$(this).attr('id')).show();
			}
		});


		$(".left_menu_list li a").click(function(){
			if( $(this).parent().find('ul').length ){
				if($(this).parent().find('ul').css('display') == 'none'){
					$(this).parent().find('ul').slideDown();
					$(this).parent().addClass('on');
				}else{
					$(this).parent().removeClass('on');
					$(this).parent().find('ul').slideUp();
				}

				return false;
			}
		});

		//요청사유 Validation
		$("#inTextarea1").on('input',function(){
			if( $("#inTextarea1").val().length > 0 ){
				$("#nReqAuthSubmit1").removeClass("disable");
			}

			if( $("#inTextarea1").val().length == 0 ){
				$("#nReqAuthSubmit1").addClass("disable");
			}
		})

		// User Log out
		$("#btnLogOut").click(function(event) {
			nLogout();
		});

		// Link Index.html
		$("#btnLogo").click(function(event) {
			$(location).attr("href",  _CONSTANTS["URL_BASE"] + "index.html");
		});

		// 갤러리 gnb 처리
		if( $(".gallery_list").length == 1 || $(".gallery_view").length == 1 ){
			setNav(3);
		}

		//권한 등록
		$(document).on("click","#nReqAuthSubmit1",function(){
			var radioVal = $('input[name="share"]:checked').val();
			var textVal = $("#inTextarea1").val();
			var checkBalnk = /^\s+|\s+$/g; //공백만 입력 됐을 경우 return

			if (textVal == '' || textVal.replace(checkBalnk,'') == '') {
				alert("요청사유를 입력하십시오.");
				$("#inTextarea1").focus();
				return false;
			}

			if (radioVal==userInfo.authId) {
				alert("동일한 권한을 신청할 수 없습니다.");
				return false;
			}

			var param = {
				"authId" : radioVal,
				"appPrvonsh" : textVal
			}

			$.ajax({
				type: "POST",
				url : _CONSTANTS["URL_BASE"]+"authApp/authApp",
				data: JSON.stringify(param),
				contentType: 'application/json',
				success : function(data, status, xhr) {

					if (data.code=="success") {
						hideModal('reqAuth');
						onToastPop('toastPop3');

						//클리어
						$(".radioBox.auth").find("label").removeClass("on");
						$("#authDiscA").addClass("on");
						$("#inTextarea1").val('');
						//클리어

					}else if (data.code=="fail"){
						alert(data.message);
					}else{
						alert("권한 신청 중 오류가 발생했습니다.");
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		});

		//권한 취소 버튼
		$(document).on("click","#cancel_btn_auth",function(){
			//클리어
			$(".radioBox.auth").find("label").removeClass("on");
			$("#authDiscA").addClass("on");
			$("#inTextarea1").val('');
			//클리어

			hideModal('reqAuth');
		})


	});

	// gnb on 처리
	function setNav(a){

		if(a == 'main'){
			$('nav').addClass('mainDash');
		}else{
			$('nav ul li').removeClass('on');
			$('nav ul li').eq(a).addClass('on');
		}
	}
	function nLogout(){
		commUsr.logOut();
		$(location).attr("href",  "/login.html");
	}

	function menuUrlLink(menuId){
		console.log(menuId)
		$.ajax({
			type: "GET",
			url :  _CONSTANTS["URL_BASE"]+ 'menu/'+menuId,
			dataType: "json",
			success : function(data, status, xhr) {

				var results = data.data.menuDetail;

				$(location).attr("href",  results.menuUrl);

			},
			error: function(jqXHR, textStatus, errorThrown) {
				alert(errorThrown);
			}
		});
	}

	/****************************************************************************************************/
	/** @END Page Initialize */