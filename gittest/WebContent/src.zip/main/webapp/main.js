/**
 * TITLE : DLSP
 * DESC : 메인화면
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
var main = function() {};

head.ready(function () {

	if(typeof jQuery === "undefined") {
		throw new Error("Require jQuery");
	}


	(function($) { "use strict";


		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		main.init = function() {

			main.mainDataList();

			//관계사 정보 가져오기
			main.compList("sk004");

		};

		//관계사
		main.compList = function(group_code_id){
			var html = "<li data-option data-value='all' class='bx--dropdown-item'>";
			html += "<a class='bx--dropdown-link bx--dropdown--selected' href='javascript:ctgSch(0)' tabindex='-1'>모든 관계사</a>";
			html += "</li>";

			$.ajax({
				type: "GET",
				url : _CONSTANTS["URL_BASE"]+"code/useDetail/"+group_code_id,
				data: "",
				dataType: "json",
				success : function(data, status, xhr) {

					if (data.code=="success") {

						var results = data.data.codeDetailList;

						$.each(results, function (i) {

							var p = "'"+results[i].detailCodeId+"'";

							html +="<li data-option data-value='cloudFoundry' class='bx--dropdown-item'>";
							html +='<a class="bx--dropdown-link" href="javascript:ctgSch('+ p +')" tabindex="-1">'+ results[i].detailCodeNm +'</a>';
							html +="</li>";

						});
						$("#bx--dropdown-list-cp").empty().append(html);

					}else{
						alert("공통 코드 상세 목록 조회 중 오류가 발생했습니다.");
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		}

		main.mainDataList = function(){
			$.ajax({
				url: _CONSTANTS["URL_BASE"]+'main/data',
				success:function(data){
					if(data.code != 'success'){
						console.log('메인 데이터 조회 중 에러가 발생하였습니다.');return;
					}
					//활용 내역 리스트
					var useCaseList = data.data.useCaseList;
					var area = $('#dash_status_list_slider').html('');
					var html = '';
					$.each(useCaseList, function (i) {
						let vo = useCaseList[i];
						var tiile 		= "";
						var viewData 	= "";

						if (vo.sttus=="00002") {
							viewData = vo.confmDe;

							if (vo.div=="1") {
								tiile = vo.comp+"의 '" +vo.item+"'이 게시 되었습니다.";
							}else if (vo.div=="2") {
								tiile = vo.comp+"의 '" +vo.item+"'가 추가로 부여되었습니다.";
							}else if (vo.div=="3") {
								tiile = vo.confmComp+"의 '" +vo.item+"'데이터가 "+vo.comp+"로 공유 승인 되었습니다.";
							}

						} else if (vo.sttus=="00003") {
							viewData = vo.confmDe;

							if (vo.div=="1") {
								tiile = vo.comp+"의 '" +vo.item+"'이 반려 처리되었습니다.";
							}else if (vo.div=="2") {
								tiile = vo.comp+"의 '" +vo.item+"'가 반려 처리되었습니다.";
							}else if (vo.div=="3") {
								tiile = vo.comp+"의 '" +vo.item+"' 데이터가 "+vo.confmComp+"로 공유 요청이 반려 처리 되었습니다.";
							}

						} else if (vo.sttus=="00004") {
							viewData = vo.registDe;
							tiile = vo.comp+"의 '" +vo.item+"' 데이터가 "+vo.confmComp+"로 공유 요청 되었습니다.";

						} else if (vo.sttus=="00001") {
							viewData = vo.registDe;

							if (vo.div=="1") {
								tiile = vo.comp+"의 '" +vo.item+"'이 추가로 요청되었습니다.";
							}else if (vo.div=="2") {
								tiile = vo.comp+"의 '" +vo.item+"'가 요청되었습니다.";
							}else if (vo.div=="3") {
								tiile = vo.comp+"의 '" +vo.item+"' 데이터가 "+vo.confmComp+"로 공유 요청 되었습니다.";
							}
						}

						html += "<li>";
						html += "<span class='data_title'>"+tiile+"</span>";
						html += "<span class='date'>"+viewData+"</span>";
						html += "</li>";
					});
					area.html(html);





					//공지사항 리스트
					var noticeList = data.data.noticeList;
					var area = $('#noticeArea').html('');
					var html = '';
					$.each(noticeList, function (i) {
						let vo = noticeList[i];
						let p = 'bbsNo='+vo.bbsNo;
						html += "<li>";
						html += "<a href=/bbs/notice_view.html?"+p+">"+ vo.bbsSj +"</a>";
						html += "<span>"+vo.updtDe+"</span>";
						html += "</li>";
					});
					area.html(html);

					//검색어 리스트
					var srchwrdList = data.data.srchwrdList;
					var area = $('#areaSrchwrd').html('');
					var html = '';
					$.each(srchwrdList, function (i) {
						let vo = srchwrdList[i];
						let p = '';
						html += "<li><span>"+vo.rownum+"</span>";
						html += vo.srchwrd;
						html += "</li>";
					});
					area.html(html);

					//최신레포트
					var area = $('#areaBi');
					var dt = data.data.biVo;
					if(dt){
						area.find('[data-biRepSj]').html(dt.biRepSj);

						$("#biReportView").attr("href", "/bi/report_view.html?sn="+dt.sn)


					}
					//활용사례
					var area = $('#areaUseCase');
					var dt = data.data.useCaseVo;
					if(dt){
						area.find('[data-sj]').html(dt.sj);
						//area.find('[data-biurl]').attr('src',_CONSTANTS["URL_BASE"]+"gallery/show-image?imageName="+dt.biurl);
						area.find('[data-biurl]').attr('src',dt.biurl);//"/img_portal/main_case_img.png"


						//area.find('[data-biurl]').attr('src',_CONSTANTS["URL_BASE"]+"show-image?imageName="+dt.biurl);  //1d1f527b-ee11-4ae3-aa2a-99133e0814f6.png
						area.find('[data-cn]').html(dt.cn.replace(/(?:\r\n|\r|\n)/g, '<br/>'));
					}
				}
			});
		}


		/****************************************************************************************************/
		/** @END Method Definition */

		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			main.init();
			setNav('main');

		});


		$("#schDcSj").keyup(function(e){
			var schDcSj= $("#schDcSj").val();
			var schCopm= $("#schCopm").val();

			if(e.keyCode == 13){
				location.href="./dc/catalogue.html?schDcSj="+schDcSj+"&schCopm="+schCopm;
			}
		});

		$(document).on("click",".search_btn",function(){
			var schDcSj= $("#schDcSj").val();
			var schCopm= $("#schCopm").val();

			location.href="./dc/catalogue.html?schDcSj="+schDcSj+"&schCopm="+schCopm;
		});

		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});