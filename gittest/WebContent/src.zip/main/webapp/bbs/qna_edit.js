/**
 * TITLE : DLSP
 * DESC : 시스템관리 - Q&A 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
head.ready(function () {

	if(typeof jQuery == "undefined") {
		throw new Error("Require jQuery");
	}

	(function($) { "use strict";
		let form,param;
		let qnaRegist = function() {};
		let isUpdate = false;
		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		qnaRegist.init = function() {
			//좌측 메뉴 선택(0부터 시작)
			commUsr.leftMenuSel(8);
			//좌측 하위 메뉴 활성화
			$(".left_menu_list li a").click();
			form = $('#form');
			param = commAjax.getJsonFromQry(location.href);
			if(!commUtil.isBlank(param.bbsNo)){
				isUpdate = true;
				form.find('#bbsNo').val(param.bbsNo);
				qnaRegist.getData();
			}

		}
		qnaRegist.getData = function(){
			$.ajax({
				type: "GET",
				url :  _CONSTANTS["URL_BASE"]+ 'userbbs/qna/'+param.bbsNo,
				dataType: "json",
				success : function(data, status, xhr) {
					let result = data.data;
					let dt = result.bbsDetail;
					form.ui_setComponents(dt);
				}
			});
		}
		qnaRegist.save = function(){
			var dt = {
					bbsNo : form.find('#bbsNo').val(),
					bbsSj : form.find('#bbsSj').val(),
					bbsCn : form.find('#bbsCn').val()
				}
			if(commUtil.isBlank(dt.bbsSj)){
				alert('제목을 입력하세요.');return;
			}
			if(commUtil.isBlank(dt.bbsCn)){
				alert('내용을 입력하세요.');return;
			}

			if(isUpdate){
				if(confirm('QnA를 수정 하시겠습니까?')){
					$.ajax({
						type:'PUT',
						url :  _CONSTANTS["URL_BASE"]+ 'userbbs/qna/'+dt.bbsNo,
						contentType: 'application/json; charset=utf-8',
						data:JSON.stringify(dt),
						dataType:'json',
						success:function(data,status,xhr){
							if(data.code=='success'){
								location.href='./qna_view.html?'+commAjax.getQueryString();
							}
						}
					});
				}
			}else{
				if(confirm('QnA를 등록 하시겠습니까?')){
					$.ajax({
						type:'POST',
						url :  _CONSTANTS["URL_BASE"]+ 'userbbs/qna',
						contentType: 'application/json; charset=utf-8',
						data:JSON.stringify(dt),
						dataType:'json',
						success:function(data,status,xhr){
							if(data.code=='success'){
								location.href='./qna.html';
							}
						}
					});
				}
			}
		}

		/****************************************************************************************************/
		/** @END Method Definition */

		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			qnaRegist.init();

			$('#qnaRegBtn0101').on('click',function(evt){
				qnaRegist.save();
			});
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});