/**
 * TITLE : DLSP
 * DESC : 시스템관리 - QNA 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
head.ready(function () {

	if(typeof jQuery == "undefined") {
		throw new Error("Require jQuery");
	}

	(function($) { "use strict";

		var form,param,pagination;
		var qnaList = function() {};

		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		qnaList.init = function() {

			setNav(7);
			//메뉴 권한 채크
			commUsr.menuAuthCheck();
			form = $("#form");
			param = commAjax.getJsonFromQry(location.href);
			pagination = $('#paging').bootpagPo({ total: 0 }).on("page", function(event, num){ qnaList.list(num) });
			qnaList.list(param.pageNo);
			form.find('#schBbsSj').pressEnter(qnaList.list).val(param.schBbsSj);
			form.find('.dateSearchBtn').on('click',qnaList.list);
		};
		qnaList.list = function(pageNumber){
			var pageNo = commUtil.parseInt(pageNumber,1);
			form.find('#pageNo').val(pageNo);
			param = form.serialize();

			$.ajax({
				type: "GET",
				url :  _CONSTANTS["URL_BASE"]+ 'userbbs/qna',
				data: param,
				dataType: "json",
				success : function(data, status, xhr) {
					let listCount = data.data.bbsListCount;
					if(data.code != 'success'){
						alert('QNA 조회 중 에러가 발생하였습니다.');return;
					}
					var results = data.data.bbsList;
					var tbody = $('#tbQna tbody').html('');
					var html = '';
					if(listCount == 0){
						html = '<tr><td colspan="5" class="empty">등록된 QNA가 없습니다.</td></tr>'
					}else{
						$.each(results, function (i) {
							var p = results[i].bbsNo+'&'+param;
							var vo = results[i];
							html += '<tr>';
							html += '<td>'+vo.rownum+'</td>';
							html += '<td class="tal"><a href=./qna_view.html?bbsNo='+p+' class="stut'+(vo.answerYn=='Y'?' on':'')+'">'+ vo.bbsSj +'</a></td>';
							html += '<td>'+ vo.nm +'</td>';
							html += '<td>'+ vo.rdcnt +'</td>';
							html += '<td>'+ vo.registDe +'</td>';
							html += '</tr>';
						});
					}
					tbody.html(html);
					form.find('#listCount').html(listCount);
					var pageCnt = parseInt(listCount / 10) + 1;
					pagination.bootpagPo({
			        	total: pageCnt,
			        	page : pageNo
			        });
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		};

		/****************************************************************************************************/
		/** @END Method Definition */

		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			qnaList.init();

			$("#btn0101").on('click',function(evt){
				qnaList.list();
			})
			// qna게시판 등록창 열기
			$("#btn0104").click(function(event) {
				location.href = "./qnaRegist.html?"+form.serialize();
			});
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});