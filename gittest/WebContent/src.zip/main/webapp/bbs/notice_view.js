/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 공지사항 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
head.ready(function () {

	if(typeof jQuery == "undefined") {
		throw new Error("Require jQuery");
	}

	(function($) { "use strict";
		var form,param;
		var noticeDetail = function() {};
		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		noticeDetail.init = function() {
			
			setNav(7);
			
			
			form = $('#form');
			param = commAjax.getJsonFromQry(location.href);
			noticeDetail.getData();
		}
		noticeDetail.getData = function(){

			$.ajax({
				type: "GET",
				url :  _CONSTANTS["URL_BASE"]+ 'userbbs/notice/'+param.bbsNo,
				dataType: "json",
				success : function(data, status, xhr) {

					let result = data.data;
					let dt = result.bbsDetail;
					let pdt = result.bbsPrevDetail;
					let ndt = result.bbsNextDetail;
					form.ui_setComponents(dt);

					if(pdt!=null){
						let prev = form.find('a.prev').show();
						prev.ui_setComponents(pdt);
						prev.find('a.link').on('click',function(){
							location.href='notice_view.html?bbsNo='+pdt.bbsNo+'&'+commAjax.getStringParams('pageNo','schBbsSj');;
						});
					}
					if(ndt!=null){
						let next = form.find('a.next').show();
						next.ui_setComponents(ndt);
						next.find('a.link').on('click',function(){
							location.href='notice_view.html?bbsNo='+ndt.bbsNo+'&'+commAjax.getStringParams('pageNo','schBbsSj');;
						});
					}

				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		}
		noticeDetail.delete = function(){
			if(confirm('공지사항을 삭제 하시겠습니까?')){
				$.ajax({
					type: 'delete',
					url : _CONSTANTS["URL_BASE"]+ 'bbs/notice/'+param.bbsNo,
					success:function(res){
						location.href= './noticeList.html';
					}
				})
			}
		}
		/****************************************************************************************************/
		/** @END Method Definition */

		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {

			noticeDetail.init();
			$('#noticeDtlBtn0101').on('click',function(evt){
				location.href= './noticeModify.html?'+commAjax.getQueryString();
			});
			$('#noticeDtlBtn0102').on('click',function(evt){
				noticeDetail.delete();
			});
			$('#noticeDtlBtn0103').on('click',function(evt){
				location.href= './noticeList.html?'+commAjax.getStringParams('pageNo','schBbsSj');
			});
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});