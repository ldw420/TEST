/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 공지사항 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
head.ready(function () {

	if(typeof jQuery == "undefined") {
		throw new Error("Require jQuery");
	}

	(function($) { "use strict";

		var form,param,pagination;
		var noticeList = function() {};

		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		noticeList.init = function() {

			setNav(7);
			//메뉴 권한 채크
			commUsr.menuAuthCheck();
			form = $("#form");
			param = commAjax.getJsonFromQry(location.href);
			form.find('#schBbsSj').val(param.schBbsSj);
			pagination = $('#paging').bootpagPo({ total: 0 }).on("page", function(event, num){ noticeList.list(num) });
			noticeList.list(param.pageNo);
			form.find('#schBbsSj').pressEnter(noticeList.list);
			form.find('.dateSearchBtn').on('click',noticeList.list);
		};
		noticeList.list = function(pageNumber){
			var pageNo = commUtil.parseInt(pageNumber,1);
			form.find('#pageNo').val(pageNo);
			param = form.serialize();

			$.ajax({
				type: "GET",
				url :  _CONSTANTS["URL_BASE"]+ 'userbbs/notice',
				data: param,
				dataType: "json",
				success : function(data, status, xhr) {
					let listCount = data.data.bbsListCount;
					if(data.code != 'success'){
						alert('공지사항 조회 중 에러가 발생하였습니다.');return;
					}
					var results = data.data.bbsList;
					var tbody = $('#tbNotice tbody').html('');
					var html = '';
					if(listCount == 0){
						html = '<tr><td colspan="5" class="empty">등록된 공지사항이 없습니다.</td></tr>'
					}else{
						$.each(results, function (i) {
							var p = results[i].bbsNo+'&'+param;
							var vo = results[i];
							html += '<tr>';
							html += '<td>'+vo.rownum+'</td>';
							html += '<td class="tal"><a href=./notice_view.html?bbsNo='+p+'>'+ vo.bbsSj +'</a></td>';
							html += '<td>'+ vo.registerId +'</td>';
							html += '<td>'+ vo.rdcnt +'</td>';
							html += '<td>'+ vo.registDe +'</td>';
							html += '</tr>';
						});
					}
					tbody.html(html);
					form.find('#listCount').html(listCount);
					var pageCnt = parseInt(listCount / 10) + 1;
					pagination.bootpagPo({
			        	total: pageCnt,
			        	page : pageNo
			        });
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		};

		/****************************************************************************************************/
		/** @END Method Definition */

		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			noticeList.init();

			$("#btn0101").on('click',function(evt){
				noticeList.list();
			})
			// notice게시판 등록창 열기
			$("#btn0104").click(function(event) {
				location.href = "./noticeRegist.html?"+form.serialize();
			});
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});