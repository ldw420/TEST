/**
 * TITLE : DLSP
 * DESC : 시스템관리 - 공지사항 관리
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
head.ready(function () {

	if(typeof jQuery == "undefined") {
		throw new Error("Require jQuery");
	}

	(function($) { "use strict";

		var form,param,pagination;
		var noticeList = function() {};

		/** @START Method Definition
		/****************************************************************************************************/
		// This Page Initialize
		noticeList.init = function() {
			
			setNav(7);
			//메뉴 권한 채크
			commUsr.menuAuthCheck();
			form = $("#form");
			param = commAjax.getJsonFromQry(location.href);
			form.find('#schBbsSj').val(param.schBbsSj);
			pagination = $('#paging').bootpagPo({ total: 0 }).on("page", function(event, num){ noticeList.list(num) });
			noticeList.list(param.pageNo);
			form.find('#schBbsSj').pressEnter(noticeList.list);
			form.find('.dateSearchBtn').on('click',noticeList.list);
		};
		noticeList.list = function(pageNumber){
			var pageNo = commUtil.parseInt(pageNumber,1);
			form.find('#pageNo').val(pageNo);
			param = form.serialize();

			$.ajax({
				type: "GET",
				url :  _CONSTANTS["URL_BASE"]+ 'userbbs/faq',
				data: param,
				dataType: "json",
				success : function(data, status, xhr) {
					let listCount = data.data.bbsListCount;
					if(data.code != 'success'){
						alert('FAQ 조회 중 에러가 발생하였습니다.');return;
					}
					var results = data.data.bbsList;
					var tbody = $('#faqList').html('');
					var html = '';
					if(listCount == 0){
						html = ''
					}else{
						$.each(results, function (i) {
							
/*							<button class="bx--accordion__heading" aria-expanded="false" aria-controls="pane1">
                            <svg focusable="false" preserveAspectRatio="xMidYMid meet" style="will-change: transform;" xmlns="http://www.w3.org/2000/svg" class="bx--accordion__arrow" width="16" height="16" viewBox="0 0 16 16" aria-hidden="true"><path d="M11 8L6 13 5.3 12.3 9.6 8 5.3 3.7 6 3z"></path></svg>
                            <div class="bx--accordion__title">
                                <!-- <div class="faq_no">01</div> -->
                                FAQ 첫번째 질문입니다.FAQ 첫번째 질문입니다.FAQ 첫번째 질문입니다.FAQ 첫번째 질문입니다.FAQ 첫번째 질문입니다.FAQ 첫번째 질문입니다.FAQ 첫번째 질문입니다.FAQ 첫번째 질문입니다.
                                FAQ 첫번째 질문입니다.FAQ 첫번째 질문입니다.FAQ 첫번째 질문입니다.FAQ 첫번째 질문입니다.FAQ 첫번째 질문입니다.FAQ 첫번째 질문입니다.FAQ 첫번째 질문입니다.FAQ 첫번째 질문입니다.
                            </div>
                        </button>
                        <div id="pane1" class="bx--accordion__content">
                            <p>첫번째 질문 답변입니다.</p>
                        </div>
                    </li>*/
                    
                    
							var p = results[i].bbsNo+'&'+param;
							var vo = results[i];
							html += '<li data-accordion-item class="bx--accordion__item">';;
							html += '<button class="bx--accordion__heading" aria-expanded="false" aria-controls="pane'+i+'">'
							html += '    <svg focusable="false" preserveAspectRatio="xMidYMid meet" style="will-change: transform;" xmlns="http://www.w3.org/2000/svg"';
							html += '    class="bx--accordion__arrow" width="16" height="16" viewBox="0 0 16 16" aria-hidden="true"><path d="M11 8L6 13 5.3 12.3 9.6 8 5.3 3.7 6 3z"></path></svg>';
							html += '    <div class="bx--accordion__title">'+vo.bbsSj+'</div>';
							html += '</button>';
							html += '    <div id="pane'+i+'" class="bx--accordion__content">';
							html += '        <p>'+vo.bbsCn.replace(/(?:\r\n|\r|\n)/g,'<br/>')+'</p>';
							html += '    </div>';
							html += '</li>';
						});
					}
					tbody.html(html);
					form.find('#listCount').html(listCount);
					var pageCnt = parseInt(listCount / 10) + 1;
					pagination.bootpagPo({
			        	total: pageCnt,
			        	page : pageNo
			        });
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		};

		/****************************************************************************************************/
		/** @END Method Definition */

		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			noticeList.init();

			$("#btn0101").on('click',function(evt){
				noticeList.list();
			})
			// notice게시판 등록창 열기
			$("#btn0104").click(function(event) {
				location.href = "./noticeRegist.html?"+form.serialize();
			});
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});