/**
 * TITLE : DLSP
 * DESC : 분석환경 - 분석환경 조회
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
head.ready(function () {
	if(typeof jQuery == "undefined") {
		throw new Error("Require jQuery");
	}
	
	(function($) { "use strict";
		var analsList = function() {};
		
		/** @START Method Definition
		/****************************************************************************************************/	
		// This Page Initialize
		analsList.init = function() {
			var html = '';
			var insNameArr = [];
			
			//메뉴 권한 채크
			commUsr.menuAuthCheck();

			$.ajax({
				type: "GET",
//				url : "http://localhost:8080/analsList",
				url : _CONSTANTS["URL_BASE"]+"analsList",
				data: {"notebookInstanceName": ""},
				dataType: "json",
				async: true,
				success : function(data, status, xhr) {
					
					if (data.status=="ERROR") {
						alert(data.error);
						$(location).attr("href", "/login.html");
					}
					
					
					if(data.length > 0) {
						$('#listLen').val(data.length);
						//하나만 생성 가능
						$("#bthRegist").addClass('disable');
						
						$.each(data, function (i) {
							html += "<tr>";

							if(data[i].notebookInstanceStatus == 'Deleting') {
								html += "<td id='tdName' style='text-align: center;'>"+ data[i].notebookInstanceName +"</td>";
							} else {
								html += "<td id='tdName' style='text-align: center;'><a href='#' onclick='fn_detail_view(\"" + data[i].notebookInstanceName + "\"); return false;'>"+ data[i].notebookInstanceName +"</a></td>";
							}
							html += "<td style='text-align: center;'>"+ data[i].instanceType.substring(data[i].instanceType.lastIndexOf('.')+1); +"</td>";
							html += "<td style='text-align: center;'>"+ data[i].creationTime +"</td>";

							if(data[i].notebookInstanceStatus == 'InService') {
								html += "<td id='tdStatus' style='text-align: center;'><span class='srv in'>"+ data[i].notebookInstanceStatus +"</span></td>";
							} else if(data[i].notebookInstanceStatus == 'Pending' ||
									data[i].notebookInstanceStatus == 'Stopping' ||
									data[i].notebookInstanceStatus == 'Deleting' ||
									data[i].notebookInstanceStatus == 'Updating') {
								html += "<td id='tdStatus' style='text-align: center;'><span class='srv ing'>"+ data[i].notebookInstanceStatus +"</span></td>";
							} else{
								html += "<td id='tdStatus' style='text-align: center;'><span class='srv'>"+ data[i].notebookInstanceStatus +"</span></td>";
							}
							 
							if(data[i].notebookInstanceStatus == 'InService') {
								html += "<td id='tdAction' style='text-align: center;'>";
//								html += "<a href='#' class='act' onclick='fn_open_jupyter(\"" + data[i].notebookInstanceName + "\"); return false;'>Jupyter Lab 열기</a> | ";
//								html += "<a href='#' class='act' onclick='fn_stop_instances(\"" + data[i].notebookInstanceName + "\"); return false;'>Stop</a>";
								html += "<a href='#' class='act' onclick='fn_open_jupyter(\"" + data[i].notebookInstanceName + "\"); return false;'>Jupyter Lab 열기</a>";
								html += "</td>";
							} else {
								if(data[i].notebookInstanceStatus == 'Stopped') {
									html += "<td id='tdAction' style='text-align: center;'><a href='#' class='act' onclick='fn_start_instances(\"" + data[i].notebookInstanceName + "\"); return false;'>Start</a></td>";
								} else {
									html += "<td id='tdAction' style='text-align: center;'>-</td>";
								}

								if(data[i].notebookInstanceStatus == 'Pending' ||
										data[i].notebookInstanceStatus == 'Stopping' ||
										data[i].notebookInstanceStatus == 'Deleting' ||
										data[i].notebookInstanceStatus == 'Updating') {
									insNameArr.push({name: data[i].notebookInstanceName, status: data[i].notebookInstanceStatus});
								}
							}

							html += "<td style='text-align: center;'>"+ data[i].price +"</td>";
							html += "<td style='text-align: center;'><span class='dataSet'>("+ data[i].dataSetInfoCnt +")</span></td>";
							html += "<td style='text-align: center;'>"+ data[i].instanceType +"</td>";
							html += "</tr>";
						});
					} else {
						html += "<tr>";
						html += "<td colspan='8' class='empty'>데이터 분석을 시작하려면 Jupyter 노트북 인스턴스를 생성해야 합니다.</td>";
						html += "</tr>";
					}

					$('#tbodyArea').append(html);
//					console.log(insNameArr.length);
//					console.log(insNameArr);
//
					if(insNameArr.length > 0) {
						fn_auto_refresh_status(insNameArr);
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					//alert(errorThrown);
					alert(textStatus);
					
				}
			});
		};

		/****************************************************************************************************/
		/** @END Method Definition */
		
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			analsList.init();
			
			setNav(2);
			
			$("#btn0101").click(function(event) {
				fn_notebook_list();
			});

			// notice게시판 등록창 열기
			$("#bthRegist").click(function(event) {
				
				//하나만 생성 가능
				if ($("#listLen").val()>0) {
					//alert("이미 생성한 Notebook이 존재합니다.");
					//commUtil.toastPop("이미 생성한 Notebook이 존재합니다.")
					return false;
				}else{
					location.href = "./analsRegist.html";					
				}

			});

//			$("#btn0105").click(function(event) {
//				var chkLen = $('input[name="insChk"]:checked').length;
//
//				if(chkLen == 0) {
//					alert("삭제하려는 항목을 선택 하시기 바랍니다.");
//					return;
//				}
//			});
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});