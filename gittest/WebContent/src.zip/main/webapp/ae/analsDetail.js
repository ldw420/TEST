/**
 * TITLE : DLSP
 * DESC : 분석환경 - 분석환경 상세
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
head.ready(function () {
	if(typeof jQuery == "undefined") {
		throw new Error("Require jQuery");
	}
	
	(function($) { "use strict";
		var analsDetail = function() {};
		
		/** @START Method Definition
		/****************************************************************************************************/	
		// This Page Initialize
		analsDetail.init = function() {
			var html = '';
			var location = unescape(document.location);
			var args0 = location.substring(location.indexOf("=")+1, location.length);

			$.ajax({
				type: "GET",
				url : _CONSTANTS["URL_BASE"]+"/analsDetail",
				data: {"notebookInstanceName": args0},
				dataType: "json",
				async: true,
				success : function(data, status, xhr) {
					
					if (data.status=="ERROR") {
						alert(data.error+"\n\n 페이지 새로고침을 해주세요");
					}
					
					if(data != '') {
						$('#instanceNameArea').text(data.notebookInstanceName);
						$('#delInstanceNmArea').text(data.notebookInstanceName+" 삭제");

						if(data.notebookInstanceStatus == 'InService') {
							$('#inServiceArea').show();
							$('#stoppedArea').hide();

							$('#inServiceArea').text(data.notebookInstanceStatus);
							$('#stoppedArea').text("");

							$('#btnOpenJupyterLab').prop('disabled', false);
							$('#btnStop').prop('disabled', false);
							$('#btnStart').prop('disabled', true);
							$('#btnDel').prop('disabled', true);
							$('#btnMod').prop('disabled', true);
						} else {
							if(data.notebookInstanceStatus == 'Pending' ||
									data.notebookInstanceStatus == 'Stopping' ||
									data.notebookInstanceStatus == 'Updating' ||
									data.notebookInstanceStatus == 'Deleting') {
								$('#inServiceArea').hide();
								$('#stoppedArea').show();

								$('#inServiceArea').text("");
								$('#stoppedArea').text(data.notebookInstanceStatus);

								$('#btnOpenJupyterLab').prop('disabled', true);

								if(data.notebookInstanceStatus == 'Pending') {
									$('#btnStart').hide();
									$('#btnStop').show();
									$('#btnDel').show();
									$('#btnStartLoading').show();
								}

								if(data.notebookInstanceStatus == 'Stopping') {
									$('#btnStart').show();
									$('#btnStop').hide();
									$('#btnDel').show();

									$('#btnStopLoading').show();
								}

								if(data.notebookInstanceStatus == 'Updating') {
									$('#btnStart').show();
									$('#btnStop').hide();
									$('#btnDel').show();

									$('#btnUpdateLoading').show();
								}

								$('#btnStart').prop('disabled', true);
								$('#btnStop').prop('disabled', true);
								$('#btnDel').prop('disabled', true);
								$('#btnMod').prop('disabled', true);

								fn_stats_chk(data.notebookInstanceName);
							} else {
								$('#inServiceArea').hide();
								$('#stoppedArea').show();
								
								$('#inServiceArea').text("");
								$('#stoppedArea').text(data.notebookInstanceStatus);
								
								$('#btnOpenJupyterLab').prop('disabled', true);
								$('#btnStop').prop('disabled', true);
								$('#btnStart').prop('disabled', false);
								$('#btnDel').prop('disabled', false);
								$('#btnMod').prop('disabled', false);
							}
						}

//						console.log(data.aeInstInfoList);
						var aeInstInfoList = JSON.parse(data.aeInstInfoList);

						$.each(aeInstInfoList, function (i) {
							var instTy = aeInstInfoList[i].instTy;
							instTy = instTy.charAt(0).toUpperCase() + instTy.slice(1);

							html += "<li>";
							html += "	<div class='instance_sel_box'>";

							if(data.instanceType == aeInstInfoList[i].instTyFull) {
								html += "		<input type='radio' id='insType_"+ i +"' name='insType' value='"+ aeInstInfoList[i].instTyFull +"' checked />";
								html += "		<label for='label_"+ i +"' id='label_"+ i +"' class='on'>";
							} else {
								html += "		<input type='radio' id='insType_"+ i +"' name='insType' value='"+ aeInstInfoList[i].instTyFull +"' />";
								html += "		<label for='label_"+ i +"' id='label_"+ i +"'>";
							}

							html += "			<p>"+ aeInstInfoList[i].portalInstNm +"</p>";
							html += "			<ul>";
							html += "				<li>vCPU: <span>"+ aeInstInfoList[i].vCpu +"</span></li>";
							html += "				<li>메모리: <span>"+ aeInstInfoList[i].memory +" GiB</span></li>";
							html += "				<li>과금: <span>"+ aeInstInfoList[i].price +"</span></li>";
							html += "				<li>인스턴스 유형: <span>"+ aeInstInfoList[i].instTyFull +"</span></li>";
							html += "			</ul>";
							html += "	</div>";
							html += "</li>";
						});

						$('#instance_sel_list_area').append(html);

						$('#disk').val(data.volumeSizeInGb);

						setSliderNum(data.volumeSizeInGb+"GB");

						fn_dataset_info_list(data.notebookInstanceName);
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		};
		
		/****************************************************************************************************/
		/** @END Method Definition */
		
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			analsDetail.init();
			
			setNav(2);

			$("#btnOpenJupyterLab").click(function(event) {
				fn_open_jupyter();
			});

			$("#btnStart").click(function(event) {
				fn_start_instances();
			});

			$("#btnStop").click(function(event) {
				fn_stop_instances();
			});

			$("#btnDel").click(function(event) {
				showModal('delPop');
			});

			$("#btnDelConfirm").click(function(event) {
				fn_delete_instances();
			});

			$("#btnMod").click(function(event) {
				location.href = "./analsModify.html?args="+$('#instanceNameArea').text();
			});

			$("#btnDelClose").click(function(event) {
				location.href = "./analsList.html";
			});

			$("#btnDelOk").click(function(event) {
				location.href = "./analsList.html";
			});
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});