/**
 * TITLE : DLSP
 * DESC : 분석환경 - 분석환경 등록
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
head.ready(function () {
	if(typeof jQuery == "undefined") {
		throw new Error("Require jQuery");
	}
	
	(function($) { "use strict";
		var analsRegist = function() {};
		
		/** @START Method Definition
		/****************************************************************************************************/	
		// This Page Initialize
		analsRegist.init = function() {
			var html = '';

			$.ajax({
				type: "GET",
				url : _CONSTANTS["URL_BASE"]+"/getAeInstInfoList",
				data: "",
				dataType: "json",
				async: true,
				success : function(data, status, xhr) {
					
					if (data.status=="ERROR") {
						alert(data.error+"\n\n 페이지 새로고침을 해주세요");
					}
					
					if(data.length > 0) {
						$.each(data, function (i) {
							var instTy = data[i].instTy;
							instTy = instTy.charAt(0).toUpperCase() + instTy.slice(1);

							html += "<li>";
							html += "	<div class='instance_sel_box'>";
							html += "		<input type='radio' id='insType_"+ i +"' name='insType' value='"+ data[i].instTyFull +"' />";
							html += "		<label for='label_"+ i +"' id='label_"+ i +"' onclick='fn_radio_check(\"" + i + "\"); return false;'>";
							html += "			<p>"+ data[i].portalInstNm +"</p>";
							html += "			<ul>";
							html += "				<li>vCPU: <span>"+ data[i].vCpu +"</span></li>";
							html += "				<li>메모리: <span>"+ data[i].memory +" GiB</span></li>";
							html += "				<li>과금: <span>"+ data[i].price +"</span></li>";
							html += "				<li>인스턴스 유형: <span>"+ data[i].instTyFull +"</span></li>";
							html += "			</ul>";
							html += "	</div>";
							html += "</li>";
						});

						$('.instance_sel_list').append(html);
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		};
		
		/****************************************************************************************************/
		/** @END Method Definition */
		
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			analsRegist.init();
			
			setNav(2);

			$("#btnCreateInstance").click(function(event) {
				fn_create_notebook();
			});

			$("#btnCreate").click(function(event) {
				fn_dataset_list();
			});

			$(".modal_search_btn").click(function(event) {
				var $div = $(this).closest(".modal_search");
				var srchWord = $div.find("#koreanNm").val();
				fn_dataset_list(srchWord);
			});

			$("#close_btn").click(function(event) {
				$('#koreanNm').val("");
				$("#allCheck").prop("checked",false);

				hideModal('dataAddBox');
			});

			$("#cancel_btn1").click(function(event) {
				$('#koreanNm').val("");
				$("#allCheck").prop("checked",false);

				hideModal('dataAddBox');
			});

			$("#cancel_btn2").click(function(event) {
				var html = '';
				var chkLen = $('input:checkbox[name=chkDt]:checked').length;

				if(chkLen == 0) {
					alert("추가하려는 데이터셋을 선택하시기 바랍니다.");
					return;
				} else {
					$('input[name=chkDt]').each(function() {
						if($(this).is(':disabled') == false) {
							if($(this).is(':checked')) {
								var chkVal = $(this).val();
								var chkValS = chkVal.split('|');

								html += "<a href='#' class='dtArea' id='"+ chkValS[0] +"' onclick='fn_delete_dataset(\"" + chkValS[0] + "\"); return false;'><span>"+ chkValS[0] +"</span></a>";
								html += "<input type='hidden' class='dtAreaH' id='"+ chkValS[0] +"_H' value='"+chkValS[1]+"' />";
							}
						}
					});

					$('.empty').hide();
					$('.dataset_sel_inner').append(html);

					$('#koreanNm').val("");
					$("#allCheck").prop("checked",false);
					
					hideModal('dataAddBox');
				}
			});

			$("#allCheck").click(function() {
				$('input[name=chkDt]').each(function() {
					if($(this).is(':disabled') == false) {
						if($("#allCheck").prop("checked")) {
							$(this).prop('checked', true);
						} else {
							$(this).prop('checked', false);
						}
					}
				});
			});
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});