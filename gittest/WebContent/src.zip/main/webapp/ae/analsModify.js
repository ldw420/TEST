/**
 * TITLE : DLSP
 * DESC : 분석환경 - 분석환경 상세
 * [20190826][(주)씨씨미디어서비스][박영철]
 */
head.ready(function () {
	if(typeof jQuery == "undefined") {
		throw new Error("Require jQuery");
	}
	
	(function($) { "use strict";
		var analsModify = function() {};
		
		/** @START Method Definition
		/****************************************************************************************************/	
		// This Page Initialize
		analsModify.init = function() {
			var html = '';
			var location = unescape(document.location);
			var args0 = location.substring(location.indexOf("=")+1, location.length);

			$.ajax({
				type: "GET",
				url : _CONSTANTS["URL_BASE"]+"/analsDetail",
				data: {"notebookInstanceName": args0},
				dataType: "json",
				async: true,
				success : function(data, status, xhr) {
					
					if (data.status=="ERROR") {
						alert(data.error+"\n\n 페이지 새로고침을 해주세요");
					}
					
					if(data != '') {
						$('#instanceNameArea').text(data.notebookInstanceName);

						if(data.notebookInstanceStatus == 'InService') {
							$('#inServiceArea').show();
							$('#stoppedArea').hide();

							$('#inServiceArea').text(data.notebookInstanceStatus);
							$('#stoppedArea').text("");
						} else {
							if(data.notebookInstanceStatus == 'Pending' ||
									data.notebookInstanceStatus == 'Stopping' ||
									data.notebookInstanceStatus == 'Updating' ||
									data.notebookInstanceStatus == 'Deleting') {
								$('#inServiceArea').hide();
								$('#stoppedArea').show();

								$('#inServiceArea').text("");
								$('#stoppedArea').text(data.notebookInstanceStatus);
							} else {
								$('#inServiceArea').hide();
								$('#stoppedArea').show();
								
								$('#inServiceArea').text("");
								$('#stoppedArea').text(data.notebookInstanceStatus);
							}
						}

						var aeInstInfoList = JSON.parse(data.aeInstInfoList);

						$.each(aeInstInfoList, function (i) {
							var instTy = aeInstInfoList[i].instTy;
							instTy = instTy.charAt(0).toUpperCase() + instTy.slice(1);

							html += "<li>";
							html += "	<div class='instance_sel_box'>";

							if(data.instanceType == aeInstInfoList[i].instTyFull) {
								html += "		<input type='radio' id='insType_"+ i +"' name='insType' value='"+ aeInstInfoList[i].instTyFull +"' checked />";
								html += "		<label for='label_"+ i +"' id='label_"+ i +"' class='on'>";
							} else {
								html += "		<input type='radio' id='insType_"+ i +"' name='insType' value='"+ aeInstInfoList[i].instTyFull +"' />";
								html += "		<label for='label_"+ i +"' id='label_"+ i +"'>";
							}

							html += "			<p>"+ aeInstInfoList[i].portalInstNm +"</p>";
							html += "			<ul>";
							html += "				<li>vCPU: <span>"+ aeInstInfoList[i].vCpu +"</span></li>";
							html += "				<li>메모리: <span>"+ aeInstInfoList[i].memory +" GiB</span></li>";
							html += "				<li>과금: <span>"+ aeInstInfoList[i].price +"</span></li>";
							html += "				<li>인스턴스 유형: <span>"+ aeInstInfoList[i].instTyFull +"</span></li>";
							html += "			</ul>";
							html += "	</div>";
							html += "</li>";
						});

						$('#instance_sel_list_area').append(html);

						$('#disk').val(data.volumeSizeInGb);

						setSliderNum(data.volumeSizeInGb+"GB");

						fn_dataset_info_list(data.notebookInstanceName);
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					alert(errorThrown);
				}
			});
		};
		
		/****************************************************************************************************/
		/** @END Method Definition */
		
		/** @START Page Initialize
		/****************************************************************************************************/
		$(document).ready(function() {
			analsModify.init();
			
			setNav(2);
			
			$("#btnCancle").click(function(event) {
				location.href = "./analsDetail.html?args="+$('#instanceNameArea').text();
			});

			$("#btnCreate").click(function(event) {
				fn_dataset_list();
			});

			$("#btnModify").click(function(event) {
				fn_modify_instances();
			});

			$("#close_btn").click(function(event) {
				$('#koreanNm').val("");
				$("#allCheck").prop("checked",false);

				hideModal('dataAddBox');
			});

			$("#cancel_btn1").click(function(event) {
				$('#koreanNm').val("");
				$("#allCheck").prop("checked",false);

				hideModal('dataAddBox');
			});

			$("#cancel_btn2").click(function(event) {
				var html = '';
				var chkLen = $('input:checkbox[name=chkDt]:checked').length;

				if(chkLen == 0) {
					alert("추가하려는 데이터셋을 선택하시기 바랍니다.");
					return;
				} else {
					$('input[name=chkDt]').each(function() {
						if($(this).is(':disabled') == false) {
							if($(this).is(':checked')) {
//								html += "<a href='#' class='dtArea' id='"+ $(this).val() +"' onclick='fn_delete_dataset(\"" + $(this).val() + "\"); return false;'><span>"+ $(this).val() +"</span></a>";

								var chkVal = $(this).val();
								var chkValS = chkVal.split('|');

								html += "<a href='#' class='dtArea' id='"+ chkValS[0] +"' onclick='fn_delete_dataset(\"" + chkValS[0] + "\"); return false;'><span>"+ chkValS[0] +"</span></a>";
								html += "<input type='hidden' class='dtAreaH' id='"+ chkValS[0] +"_H' value='"+chkValS[1]+"' />";
							}
						}
					});

					$('.empty').hide();
					$('.dataset_sel_inner').append(html);

					$('#koreanNm').val("");
					$("#allCheck").prop("checked",false);
					
					hideModal('dataAddBox');
				}
			});

			$("#allCheck").click(function() {
				$('input[name=chkDt]').each(function() {
					if($(this).is(':disabled') == false) {
						if($("#allCheck").prop("checked")) {
							$(this).prop('checked', true);
						} else {
							$(this).prop('checked', false);
						}
					}
				});
			});
		});
		/****************************************************************************************************/
		/** @END Page Initialize */
	}(jQuery));
});