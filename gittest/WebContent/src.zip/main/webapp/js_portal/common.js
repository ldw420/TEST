// common.js
$(window).ready(function(){
	
	var agent = navigator.userAgent.toLowerCase();
	
	//익스 일 경우 select box 처리
	if (agent.indexOf("chrome") == -1 && agent.indexOf("edge") == -1) {
		$(".bx--dropdown-link").click(function(){
			console.log(  $(this) );
			$(this).parent().parent('ul.bx--dropdown-list').find('li > a').removeClass('bx--dropdown--selected');
			$(this).addClass('bx--dropdown--selected');
			$(this).parent().parent().parent().parent('ul.bx--dropdown').find('.bx--dropdown-text').html($(this).html());
		});		
	}
	
	if( $(".dash_icon_list").length > 0 ){
		$(".dash_icon_list ul li a").click(function(){
				
			if ( $(this).parent().hasClass('on') ){
				$(".dash_icon_list ul li").removeClass('on');
			}else{
				$(".dash_icon_list ul li").removeClass('on');
				$(this).parent().addClass('on');
			}
			return false;			
		});
	}

	// slider 클릭
	$("a.unit").click(function(){
		setSliderNum($(this).html());
		return false;
	});

	setPop();
	
	// 카탈로그 / 리포트 리스트 클릭 시 동작 (스크랩버튼 구분을 위한...)
	$(".catalogue_cont_list ul li").click(function(e){
		if( !$(e.target).hasClass('scrap') ){
			location.href=$(this).data('link');
		}
	});

	$(".chkBox").click(function(){
		if( $(this).hasClass('on') ){
			$(this).removeClass('on');
			$(this).parent().find('a').removeClass('chkAll');
			$(this).parent().find('ul > li > a').removeClass('on');
		}else{
			$(this).addClass('on');
			$(this).parent().find('a').addClass('chkAll');
			$(this).parent().find('ul > li > a').addClass('on');
		}
	});

	$(".catalogue_sel_list li a").click(function(){
		if( !$(this).hasClass('showBtn') ){
			if( $(this).hasClass('on') ){
				$(this).removeClass('on');
				$(this).parent().find('ul li').hide();
				removeChk($(this));
			}else{
				$(this).addClass('on');
				$(this).parent().find('ul li').show();
				addChk($(this));
			}
		}
		return false;
	});

	footerStatic();

});

$(window).resize(function(){
	setPop();
	footerStatic();
});


$(window).scroll(function(){
	if( $("header.landing").length > 0 ){
		if( $(window).scrollTop() > 100 ){
			$("header.landing").addClass('onScr');
		}else{
			$("header.landing").removeClass('onScr');
		}
	}
});

function removeChk(a){
	var $this = a;
	if( !$this.parent().parent().hasClass('cate_list') ){
		$this.removeClass('chkAll');
		$this.parent().parent().parent().find('.chkBox').removeClass('on');
		$this.parent().parent().parent().find('a.chkAll').removeClass('chkAll');
	}
}

function addChk(a){
	var $this = a;
	if( !$this.parent().parent().hasClass('cate_list') ){
		var max = $this.parent().parent().find('li').length;
		var cnt = 0;
		for( var i = 0; i<max; i++ ){
			if( $this.parent().parent().find('li').eq(i).find('a').hasClass('on') ){
				cnt++;
			}
		}
		if( max == cnt ){
			$this.parent().parent().parent().find('.chkBox').addClass('on');
			$this.parent().parent().parent().find('a.on').addClass('chkAll');
		}
	}
}


function commaSeparateNumber(val) {
  while (/(\d+)(\d{3})/.test(val.toString())) {
	val = val.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
  }
  return val;
}

function showModal(a){
	var $modal = $("#"+a);
	$modal.addClass('on');
	$(".mask").fadeIn();
}

function hideModal(a){
	var $modal = $("#"+a);
	$modal.removeClass('on');
	$(".mask").fadeOut();			
}


function changeUnit(){
	setSlider($(".disk").val());
}

function setSliderNum(a){
	var num = a;
	var unit = num.substring(num.length,(num.length-2));
	$(".bx--dropdown-link").removeClass('bx--dropdown--selected');		
	$(".bx--dropdown-text").html( unit );
	for( var i = 0; i<$(".bx--dropdown-list li").length; i++){
		if( $(".bx--dropdown-list li").eq(i).data('value') == unit ){
			$(".bx--dropdown-list li").eq(i).find('.bx--dropdown-link').addClass('bx--dropdown--selected');
		}
	}
	$(".disk").val(num.slice(0,-2));
	setSlider(num.slice(0,-2));
}

//set slider
function setSlider(a){
	var unit = $(".bx--dropdown-text").html();

	if($.isNumeric(a) && a != 0){				
						
		if(unit == 'GB'){					
			if(a > 16000){
				$(".disk").val(16000);
				a = 16000;
			}else if( a < 5 ){
				$(".disk").val(5);
				a = 5;
			}
		}else{
			if(a > 16){
				$(".disk").val(16);
				a = 16;
			}
			a = a* 1000;
		}

		if(a > 50){
			$(".slider").addClass('over');
		}else{
			$(".slider").removeClass('over');
		}

		var spacing = $(".sliderUnits").width() / $(".sliderUnits a.unit").length;
		
		a = getSlierWidth(a,spacing);

		var btnPos = (a + (spacing / 2)) - 10;

		$(".sliderBtn").css({'left':btnPos});
		$(".sliderVolume").width(a);

	}else{
		$(".disk").val(a.slice(0,-1));
	}
}

function getSlierWidth(a,spacing){
	var num = new Array;
	for( var i = 0; i < $(".sliderUnits a.unit").length; i++ ){
		var unit = $(".sliderUnits a.unit").eq(i).html();
		
		if( unit.indexOf('G') != -1){
			unit = parseInt( unit.slice(0,-2) );
		}else{
			unit = (unit.slice(0,-2)) * 1000;
		}
		num.push( unit );
	}
	for( var j = 0; j < num.length; j++ ) {
		if( num[j] >= a ){			
			if(j == 0){
				a = 0;
			}else{
				a = ( (a - num[j-1]) / (num[j]-num[j-1]) ) * spacing;
				if( j > 1 ){
					a = a + ( spacing * (j-1));
				}
			}
			break;
		}
	}
	return parseInt(a);
}

function setPop(){

	

	var wH = $(window).height();
	var margin = 310;
	

	if( wH < 960 && wH > 860 ){
		margin = 200;
	}else if( wH < 860 && wH > 760 ){
		margin = 160;
	}else if( wH < 760 && wH > 660 ){
		margin = 120;
	}else if( wH < 660 && wH > 560 ){
		margin = 80;
	}else if( wH < 560 && wH > 460 ){
		margin = 40;
	}else if( wH < 460){
		margin = 20;
	}

	if( $(".modal_pop").hasClass('hFixed') ){
		margin = 120;
	}

	var mH = wH - margin;
	var cH = ( mH + 10 ) - 236;
	var iH = cH;
	
	$(".modal_pop").height(mH);
	$(".modal_pop .modal_pop_cont").height(cH);
	$(".modal_pop .modal_pop_cont .modal_pop_cont_inner").height(iH);

	mH = mH / 2;
	$(".modal_pop").css({'margin-top':'-'+mH+'px'});
}

function onToastPop(a){
	var $toast = $("#"+a);
	$toast.fadeIn();
	setTimeout(function() {
		$toast.fadeOut();
	}, 2000);
}


//footer 하단 고정 (class="variable" 추가)
function footerStatic() {
	var bodyH = $('body').height();
	var winH = $(window).height();
	var variableH = $('.variable').innerHeight();

	if( bodyH < winH ) {
		$('.variable').css('min-height', variableH + (winH - bodyH));
	}else{
		$('.variable').css('min-height', '');
	}
}


//------------
function gfn_grep(codes, companyCd){
	var retval = "";
	retval = jQuery.grep(codes, function(element, index){
	      if(element.detailCodeId == companyCd){
	    	  return element.detailCodeNm;
	      }
	});
	return retval;
}